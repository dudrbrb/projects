// import header
$('header').html(`<div class="logo">
                    <h1><a href="/"><img src="../web/img/top-nav/logo.png" alt="PicKo LOGO"></a></h1>
                </div>
                <div class="tools">
                    <ul>
                        <li>KR</li>
                        <li><img src="../web/img/top-nav/search.png" alt="검색 버튼"></li>
                        <li><img src="../web/img/top-nav/mypage.png" alt="마이페이지 버튼"></li>
                        <li><img src="../web/img/top-nav/cart.png" alt="장바구니"></li>
                    </ul>
                </div>
                <nav>
                    <ul class="top-menu-btn">
                        <li><img src="../web/img/top-nav/menu.png" alt="메뉴 여는 버튼"></li>
                        <li><a href="#">BEST</a></li>
                        <li><a href="#">TODAY'S DEAL</a></li>
                        <li><a href="#">NEW</a></li>
                        <li><a href="#">PRE-ORDER</a></li>
                    </ul>
                </nav>
            </div>`)

