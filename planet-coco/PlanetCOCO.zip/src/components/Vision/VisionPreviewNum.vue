<script setup>
import { onMounted, ref, toRef, watch } from "vue";

const props = defineProps({
    num: Number
})
const currentNum = ref(0)
let interval = null
let increment = true
const animate = () => {
    clearInterval(interval)
    interval = setInterval(() => {

        currentNum.value += increment ? 1 : -1
        if (increment && currentNum.value >= props.num || !increment && currentNum.value <= props.num) {
            currentNum.value = props.num
            clearInterval(interval)
        }
    }, 16)
}
onMounted(() => {
    animate()
})
watch(toRef(props, 'num'), () => {
    if (props.num > currentNum.value) {
        increment = true
        animate()
    } else {
        increment = false
        animate()
    }
})
</script>

<template>
    <div class="vision-preview-progress__num">{{ currentNum }}%</div>
</template>

<style lang="postcss">
</style>