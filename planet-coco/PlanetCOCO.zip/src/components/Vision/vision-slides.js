import brandGif from "@/assets/img/vision_brand.gif";
import creativeLabs from "@/assets/img/vision_creative_labs.gif";
import irl from "@/assets/img/vision_irl.gif";
import souvenirShop from "@/assets/img/vision_souvenir_shop.gif";
import vision from "@/assets/img/vision_vision.gif";
export default {
  brand: {
    title: "BRAND",
    image: brandGif,
    slides: [
      {
        title: "THE COCO NARRATIVE",
        percents: 75,
        text: "The first phase of our roadmap will be an Introduction to the compelling narrative \
                    of Planet COCO. Storytelling is indispensable in expressing our creative spirit, and  \
                    the on-going tale of COCOs will serve as the backbone in all stages of the project. \
                    Our characters will be brought to life in various art forms, animations and more \
                    mediums. We will broaden our narrative and construct an innovative ecosystem \
                    where the community effectively experience the world of Planet COCO in its entirety. ",
      },
      {
        title: "BRANDING",
        percents: 50,
        text: "Planet COCO is a brand, and we believe branding is essential in adding sustainable  \
              value to the project and holders in the long-term. One Planet COCO NFT is a visual \
              avatar representation in the world of Planet COCO and serves as an exclusive \
              passport to the adventures, collaborations and real-life events lying ahead within \
              and around the COCO-verse. With the story of Planet COCO functioning as the \
              foundation, our goal is to constantly evolve, build, and expand to various mediums \
              and grow into a bold and unique creative brand. ",
      },
      {
        title: "PARTNERSHIPS",
        percents: 25,
        text: "Our project is based on the ethos of collaboration. The team has always been \
        fascinated by the process of merging bright imaginations in the creation of a new, \
        lucid idea. We are always looking to long-term global creative partnerships with \
        fashion, digital, and lifestyle brands who share our artistic vision in working \
        together and bringing new concepts to life.",
      },
    ],
  },
  creative_lab: {
    title: "CREATIVE LAB",

    image: creativeLabs,
    slides: [
      {
        title: "INTERACTIVE STORYTELLING",
        percents: 50,
        text: "Interactive storytelling is what brings magic to Planet COCO: sharing the experience \
        of production with the community. Our Creative Lab is where the community \
        participate as co-creators in the process of establishing the world of Planet COCO. \
        Holders will receive narrating and designing tasks for future project concept \
        development. Creators of selected concepts will receive a percentage share of the \
        new project’s total revenue.",
      },
      {
        title: "CREATORS HUB",
        percents: 50,
        text: "The Creative Lab will also function as a hub where holders willing to build within \
        the Web3 space can participate in session events and classes with advisory guests, \
        make connections with other builders, and receive funding from the team. Creators \
        hub events will be held alongside online art classes and community workshops of \
        various themes, open for all holders.",
      },
      {
        title: "GRAPHIC STANDARD MANUAL",
        percents: 25,
        text: "Character storytelling, graphic design, and branding is what we do best. We are all \
        about providing room to develop and giving the opportunities to build back to the \
        community. Team Planet COCO will be providing a detailed step-by-step guide on \
        how to grow your NFT, product, or an idea into an attractive brand. Create and build \
        what you want with our guide, you are the creator.",
      },
    ],
  },
  irl: {
    title: "IRL",

    image: irl,
    slides: [
      {
        title: "BRIDGING TWO WORLDS",
        percents: 50,
        text: "One of our core missions is bridging the gap between the Web2 and Web3 space \
        through live Planet COCO events. We will be experimenting in different channels, \
        disintegrating the borders between the physical and digital. We hope to provide a \
        ground where holders can further expand their COCO experience whilst connecting \
        with new people. 70% of revenues from all off-line events will be directed to our \
        Community Wallet. This will be reinvested into future community events, \
        giveaways, merch and more.",
      },
      {
        title: "STORYTELLING BOOTH",
        percents: 25,
        text: "All holders are welcome in our storytelling booths. We plan on opening a space \
        where holders will be able to experience the process of creative ideation at various \
        events from NFT meet-ups to festivals, exhibits and more. Participants will have \
        access to art classes, mini workshops and will share the experience in creating the \
        world of Planet COCO. We believe real life engagement and curated interactivity \
        will open up new possibilities stretching beyond the limits of digital experience.",
      },
      {
        title: "FAN-ART EXHIBITION",
        percents: 25,
        text: "The Planet COCO website will feature a new page showcasing the best of Planet \
        COCO fan art in various forms. Selected pieces from the website will be brought \
        to the world in an immersive real-life gallery where holders will be able to connect \
        with each other and experience the COCO universe, highlighted by the artists and \
        creative community behind Planet COCO. ",
      },
    ],
  },
  souvenir_shop: {
    title: "SOUVENIR SHOP",
    image: souvenirShop,
    slides: [
      {
        title: "CURATED MERCH",
        percents: 50,
        text: "Get ready to suit up and gear up as we journey together into the world of COCO. We \
        will be presenting a curated selection of physical items at our exclusive Souvenir \
        Shop. Items will include unidentified shiny and cool objects that drifted into the \
        lands of Planet COCO, along with special pieces of COCO merchandise and \
        collectibles(e.g. Mascot Figures) that capture the unique and fun traits from our \
        Planet COCO collection.",
      },
      {
        title: "BURNING MECHANISM",
        percents: 25,
        text: "Eligible holders will be able to either claim or purchase goods as an NFT through our \
        “COCO Souvenir Shop” collection. Burning the NFT will grant access to confirming \
        shipping information in order to receive real-life goods. Further details on the COCO \
        Souvenir Shop will be announced through our official channels in the near future. \
        Sneak peeks on some of the items will be available at the “Shop” tab in our official \
        website post the genesis mint. ",
      },
      {
        title: "CONCEPT POP-UP",
        percents: 25,
        text: "We are planning guerrilla popup installations of our Souvenir Shop in selected \
        locations during the coming days. This will serve as a real-life showcase where \
        holders are introduced to our narrative and fully dive into the digital and physical \
        experience in the world of COCO. Details on the concept of our Souvenir shop will \
        be released in Q1 2023.",
      },
    ],
  },
  vision: {
    title: "VISION 2.0",
    image: vision,
    slides: [
      {
        title: "CORE TEAM EXPANSION",
        percents: 25,
        text: "Phase 2 of our roadmap will kick off with new family members. The team will \
        on-board new full-time talents including designers, engineers, marketers and artists \
        from various backgrounds. Our website will be updated with a Careers page \
        available for checking open roles post mint. We are excited to share the experiences \
        of collaboration and development along the journey together!",
      },
      {
        title: "COCOMAG",
        percents: 25,
        text: "The team is exploring into building a NFT web-zine where you can share your \
        creative imaginations, connect with new people, and exchange alpha via your own \
        contents. Contents can be anything from critical market analyses to a casual review \
        on your recent NFT trade, or even memes. Holders of Planet COCO will be eligible to \
        access a physical printed copy of Cocomag every quarter, with excerpted articles and \
        exclusive contents from our web-zine that highlights some of the pinnacle moments \
        in the Web3 and NFT space.",
      },
      {
        title: "A COCO FUTURE",
        percents: 25,
        text: "Our team will deliver more details on the second phase of our roadmap with revised \
        and updated alpha around the end of our COCOmap 1.0. We will be holding AMAs as \
        well as Twitter Spaces to share our plans on what’s coming next for Planet COCO. \
        However the future may be, the pillars of our foundation will not have changed: \
        prioritizing sustainability and building a community-centered web3 brand. ",
      },
    ],
  },
};
