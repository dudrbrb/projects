<script setup>
import { computed, ref } from "@vue/runtime-core";
import slidesData from "./vision-slides"
import PageCard from "../PageCard.vue";
import { EffectFade, Keyboard, Navigation, Pagination } from 'swiper';
import VisionPreviewNum from "./VisionPreviewNum.vue";
const props = defineProps({
    activeItem: String
})
const activeCategory = computed(() => slidesData[props.activeItem])
const modules = [
    Navigation, Pagination, Keyboard, EffectFade
]
const slides = computed(() => activeCategory.value.slides)
const activeSlideIdx = ref(0)
const activeSlide = computed(() => slides.value[activeSlideIdx.value])
const onChange = (e) => {
    activeSlideIdx.value = e.realIndex
    console.log('change', e)
}
</script>

<template>
    <PageCard
        title="Vision"
        tooltip="Our roadmap is our vision.
Explore our roadmap in detail!"
        class="vision-preview"
    >
        <div class="vision-preview__title">{{ activeCategory.title }}</div>
        <div class="vision-preview__image">
            <img :src="activeCategory.image" alt="image" width="300" height="300" />
        </div>
        <div class="vision-preview-progress">
            <div class="vision-preview-progress__header">
                <div class="vision-preview-progress__title">{{ activeSlide.title }}</div>
                <VisionPreviewNum :num="activeSlide.percents" />
            </div>
            <div class="vision-preview-progress__bar">
                <div
                    class="vision-preview-progress__bar-active"
                    :style="{ width: activeSlide.percents + '%' }"
                ></div>
            </div>
        </div>
        <Swiper
            @slide-change="onChange"
            :pagination="{ clickable: true }"
            :keyboard="{ enabled: true }"
            :modules="modules"
            :fadeEffect="{ crossFade: true }"
            effect="fade"
            :spaceBetween="30"
            class="vision-preview-slider"
        >
            <SwiperSlide v-for="(slide, idx) in slides" :key="idx" class="vision-preview-slide">
                <div>{{ slide.text }}</div>
            </SwiperSlide>
        </Swiper>
    </PageCard>
</template>

<style lang="postcss">
</style>