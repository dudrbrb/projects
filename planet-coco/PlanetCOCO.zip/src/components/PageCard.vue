<script setup>
defineProps({
    title: String,
    tooltip: String
})
</script>

<template>
    <div class="page-card page-limited card">
        <slot name="header">
            <div class="page-card__header">
                <h3 class="page-card__title">{{ title }}</h3>
                <div class="page-card__info">
                    <img src="@/assets/img/info.png" alt="info" width="26" height="28" />
                    <div class="page-card__tooltip">{{ tooltip }}</div>
                </div>
            </div>
        </slot>

        <div class="page-card__content">
            <slot />
        </div>
    </div>
</template>

<style lang="postcss">
</style>