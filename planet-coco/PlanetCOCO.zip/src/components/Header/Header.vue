<script setup>
import { ref } from "@vue/reactivity";
import svgPlay from "@/assets/icons/play.svg"
import svgPause from "@/assets/icons/pause.svg"
import bgm from "@/assets/audio/bgm.mp3"
import menuItems from "./header-menu-items"
import { useMenu } from "@/helpers/useMenu";
const isPaused = ref(true)

const audio = ref(null)
const togglePause = () => {
    isPaused.value = !isPaused.value
    if (isPaused.value) {
        audio.value.pause()
    } else {
        audio.value.play()

    }
}
const initiatePlaying = () => {
    if (window.innerWidth > 950) {
        togglePause()
    }
    document.removeEventListener('click', initiatePlaying)
}
// if (import.meta.env.MODE !== 'development') {
//     document.addEventListener('click', initiatePlaying)
// }
const { isOpen: isMenuOpen, toggle: toggleMenu } = useMenu()
</script>

<template>
    <header class="header">
        <div class="header-logo">
            <RouterLink :to="{ name: 'Home' }">
                <img src="@/assets/img/logo.png" alt="logo" width="146" height="66" />
            </RouterLink>
        </div>
        <div class="header-icecream" :class="{ pause: isPaused }">
            <div class="header-icecream__icon" @click.prevent="togglePause">
                <img src="@/assets/img/icecream.jpeg" alt="icecream" width="58" height="58" />
                <div class="header-icecream__icon-nav">
                    <svgPlay class="header-icecream__icon-nav-play" v-if="isPaused" />
                    <svgPause class="header-icecream__icon-nav-pause" v-else />
                </div>
            </div>
            <div class="header-icecream__content">
                <div class="header-icecream__title">ICECREAM TRUCK</div>
                <div class="header-icecream__subtitle">PLANET COCO EP</div>
            </div>
        </div>
        <div class="header-menu">
            <div class="header-menu-items">
                <component
                    :is="item.disabled ? 'div' : 'router-link'"
                    :to="{ name: item.route }"
                    class="header-menu-item"
                    :class="{ disabled: item.disabled }"
                    v-for="(item, idx) in menuItems"
                    :key="idx"
                >{{ item.name }}</component>
            </div>
        </div>
        <!-- <a
            href="javascript:void(0)"
            class="header-burger"
            :class="{ open: isMenuOpen }"
            @click.prevent="toggleMenu"
        >
            <span></span>
            <span></span>
            <span></span>
        </a>-->
        <div class="header-burger " :class="{ active: isMenuOpen }" @click.prevent="toggleMenu">
            <i></i>
            <i></i>
            <i></i>
        </div>

        <audio ref="audio" loop>
            <source :src="bgm" />
        </audio>
    </header>
</template>

<style lang="postcss">
</style>