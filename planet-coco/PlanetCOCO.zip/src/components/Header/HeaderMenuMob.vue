<script setup>
import { useMenu } from "@/helpers/useMenu";
import menuItems from "./header-menu-items"
const { close: closeMenu } = useMenu()
</script>

<template>
    <div class="header-menu-mob">
        <div class="header-menu-mob__items">
            <component
                :is="item.disabled ? 'div' : 'router-link'"
                :to="{ name: item.route }"
                class="header-menu-mob__item"
                :class="{ disabled: item.disabled, 'header-menu-mob__item-mint': item.name === 'MINT' }"
                v-for="(item, idx) in menuItems"
                :key="idx"
                @click="closeMenu"
            >
                <span class="header-menu-mob__item-text">
                    <span>{{ item.name }}</span>
                    <span class="header-menu-mob__item-info" v-if="item.name === 'MINT'">
                        <img src="@/assets/img/info.png" alt="info" /> Available only on PC*
                    </span>
                </span>

                <img class="header-menu-mob__item-image" :src="item.image" alt="image" />
            </component>
        </div>
    </div>
</template>

<style lang="postcss">
</style>