import about from "@/assets/img/menu_about.png";
import vision from "@/assets/img/menu_vision.png";
import mint from "@/assets/img/menu_mint.png";
import shop from "@/assets/img/menu_shop.png";
import lore from "@/assets/img/menu_lore.png";
import faq from "@/assets/img/menu_faq.png";
export default [
  {
    name: "ABOUT",
    route: "About",
    image: about,
  },
  {
    name: "VISION",
    route: "Vision",
    image: vision,
  },
  {
    name: "MINT",
    route: "#",
    disabled: true,
    image: mint,
  },
  {
    name: "SHOP",
    route: "#",
    disabled: true,
    image: shop,
  },
  {
    name: "LORE",
    route: "Lore",
    image: lore,
  },
  {
    name: "FAQ",
    route: "Faq",
    image: faq,
  },
];
