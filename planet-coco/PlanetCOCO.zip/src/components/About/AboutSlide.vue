<script setup>
defineProps({
    title: String,
    img: String
})
</script>

<template>
    <div class="about-slide">
        <div class="about-slide__content">
            <h2 class="about-slide__title">{{ title }}</h2>
            <div class="about-slide__text">
                <slot name="text" />
            </div>
            <div class="about-slide__actions">
                <slot name="actions" />
            </div>
        </div>
        <div class="about-slide__image">
            <img :src="img" alt="image" />
        </div>
    </div>
</template>

<style lang="postcss">
</style>