<script setup>
import { Navigation, Pagination, Keyboard, EffectFade } from 'swiper';
import AboutSlide from './AboutSlide.vue';
import img1 from "@/assets/img/about_1.png"
import img4 from "@/assets/img/about_4.png"
import AboutSlideWithTooltip from './AboutSlideWithTooltip.vue';
import AboutSlideTeam from './AboutSlideTeam.vue';
import { ref } from '@vue/reactivity';
import { computed, onMounted } from '@vue/runtime-core';
const modules = [
    Navigation, Pagination, Keyboard, EffectFade
]

let swiper = null
const onSwiper = sw => {
    swiper = sw
}
const slideNext = () => {
    if (!swiper) return
    swiper.slideTo(1)
}
const effect = ref('fade')
const checkEffect = () => {
    effect.value = window.innerWidth > 950 ? 'fade' : 'slide'
}
checkEffect()
onMounted(() => {
    window.addEventListener('resize', checkEffect)
})

</script>

<template>
    <Swiper
        :spaceBetween="30"
        class="about-slider"
        :pagination="{ clickable: true }"
        :keyboard="{ enabled: true }"
        :modules="modules"
        :fadeEffect="{ crossFade: true }"
        ref="swiperEl"
        :effect="effect"
        @swiper="onSwiper"
        :key="effect"
    >
        <SwiperSlide>
            <AboutSlide :img="img1" title="STORY">
                <template #text>
                    Planet COCO is a story about the beginning of a new generation.
                    New generation brings new lifestyle. Planet COCO curates a creative lifestyle
                    centering around art, creativity, and fashion culture.
                    <br />
                    <br />Surround yourself with like-minded creators as we build a spirited community by
                    collaborating, connecting, and building. Daze into our dreamy days within and
                    escape to the world of mellow adventures!
                </template>
                <template #actions>
                    <a
                        class="about-slide__button"
                        href="#"
                        @click.prevent="slideNext"
                    >EXPLORE THE COCOVERSE</a>
                </template>
            </AboutSlide>
        </SwiperSlide>
        <SwiperSlide>
            <AboutSlideWithTooltip />
        </SwiperSlide>
        <SwiperSlide>
            <AboutSlideTeam />
        </SwiperSlide>
        <SwiperSlide>
            <AboutSlide :img="img4" title="FUTURE" class="about-slide about-slide-future">
                <template #text>
                    Web3 space moves very fast. As do all NFT projects,
                    Planet COCO will too be challenged by the test of time.
                    <br />
                    <br />Our goal is to create and deliver consistent value and prioritize project sustainability.
                    Team Planet COCO and the community together will function as a vital foundation
                    for the stability and longevity of our COCO ecosystem. Keep in touch for more
                    updates!
                </template>
                <template #actions>
                    <div class="about-slide-future__buttons">
                        <a
                            href="https://twitter.com/planetcoconft"
                            target="_blank"
                            class="about-slide__button"
                        >TWITTER</a>
                        <a
                            href="https://discord.gg/PlanetCOCOnft"
                            target="_blank"
                            class="about-slide__button"
                        >DISCORD</a>
                    </div>
                </template>
            </AboutSlide>
        </SwiperSlide>
    </Swiper>
</template>

<style lang="postcss">
</style>