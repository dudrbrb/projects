<script setup>
import AboutSlide from "./AboutSlide.vue";
import team1 from "@/assets/img/team_1.png"
import team2 from "@/assets/img/team_2.jpg"
import team3 from "@/assets/img/team_3.jpg"
import team4 from "@/assets/img/team_4.jpg"
import img3 from "@/assets/img/about_3.png"
const items = [
    {
        name: "Dazed Kim",
        role: "Lead Artist",
        img: team1,
        link: "https://twitter.com/dazekimnft"
    },
    {
        name: "Coldy",
        role: "Director",
        img: team2,
        link: "https://twitter.com/coldyiscoldy"
    },
    {
        name: "Null 1",
        role: "Web3 Enabler",
        img: team3,
        link: "https://twitter.com/home"
    },
    {
        name: "null 2",
        role: "Community",
        img: team4,
        link: "https://twitter.com/home"
    }
]
</script>

<template>
    <AboutSlide :img="img3" title="TEAM" class="about-slide about-slide-team">
        <template #text>
            The carefully hand-picked team members are undoubtedly the most valuable asset
            to our project. World-wide talents include Web3 enabler null, community
            lead null, concept artist Wisefull, motion designer 5doggie, and of course our
            wonderful MOD team.
        </template>
        <template #actions>
            <div class="about-slide-team__items">
                <a
                    :href="item.link"
                    target="_blank"
                    class="about-slide-team__item"
                    v-for="(item, idx) in items"
                    :key="idx"
                >
                    <div class="about-slide-team__item-image">
                        <img :src="item.img" alt="image" />
                    </div>
                    <div class="about-slide-team__item-content">
                        <div class="about-slide-team__item-name">{{ item.name }}</div>
                        <div class="about-slide-team__item-role">{{ item.role }}</div>
                    </div>
                </a>
            </div>
        </template>
    </AboutSlide>
</template>

<style lang="postcss">
</style>