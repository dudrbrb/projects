<script setup>
import AboutSlide from "./AboutSlide.vue";
import img2 from "@/assets/img/about_2.png"
import { ref } from "@vue/reactivity";
import { computed } from "@vue/runtime-core";

const showTooltip = ref(false)
const slideButtons = ref(null)
const activeTooltipIdx = ref(0)
const buttons = computed(() => [...slideButtons.value.children])

const onMouseMove = e => {
    const target = e.target
    switchTooltip(target)
    console.log(activeTooltipIdx.value)
}
const onClickOutside = e => {
    let target = e.target
    while (target != null) {
        if (target === slideButtons.value) return;
        target = target.parentNode
    }
    showTooltip.value = false
    document.removeEventListener('click', onClickOutside)

}
const switchTooltip = (target) => {
    const activeIndex = buttons.value.findIndex(btn => btn === target)
    if (activeIndex < 0) return
    showTooltip.value = true
    activeTooltipIdx.value = activeIndex
    document.removeEventListener('click', onClickOutside)
    document.addEventListener('click', onClickOutside)
}
const onClick = e => {
    const target = e.target
    switchTooltip(target)
}

const onMouseLeave = e => {
    showTooltip.value = false
}
</script>

<template>
    <AboutSlide class="about-slide about-slide-with-tooltip" :img="img2" title="ETHOS">
        <template
            #text
        >Our values are focused heavily in the process of paving our way towards a sustainable, creative lifestyle brand which directly reflects the manifesto behind our project below:</template>
        <template #actions>
            <div class="about-slide-with-tooltip__content">
                <div
                    class="about-slide__buttons"
                    ref="slideButtons"
                    @click="onClick"
                    @mousemove="onMouseMove"
                    @mouseleave="onMouseLeave"
                >
                    <a
                        class="about-slide__button"
                        href="#"
                        @click.prevent
                        ref="slideButton"
                    >CREATIVITY</a>
                    <a
                        class="about-slide__button"
                        href="#"
                        @click.prevent
                        ref="slideButton"
                    >COMMUNITY</a>
                    <a
                        class="about-slide__button"
                        href="#"
                        @click.prevent
                        ref="slideButton"
                    >COLLABORATION</a>
                </div>
                <Transition name="t-fade">
                    <div class="about-slide__tooltip" v-if="showTooltip && activeTooltipIdx === 0">
                        <div class="about-slide__tooltip-title">
                            Here at Planet COCO, we strongly
                            believe in the power of a creative mind.
                        </div>
                        <div class="about-slide__tooltip-description">
                            We aim to build an open community where you can surround
                            yourself with interesting design, ideas, and fashion. Connect with
                            new people, share creativity, learn, and expand your artistic mind as
                            we bring these best of imaginations to life together.
                        </div>
                    </div>
                    <div
                        class="about-slide__tooltip"
                        v-else-if="showTooltip && activeTooltipIdx === 1"
                    >
                        <div
                            class="about-slide__tooltip-title"
                        >Everything about Planet COCO 
                        starts with the community.</div>
                        <div
                            class="about-slide__tooltip-description"
                        >Our full-time professional moderation team will be our friendly 
                        guide within the COCO community while we share ideas, listen to 
                        music, and make new friends. The team will continue to assist in 
                        building a community worth staying, collaborating with various 
                        projects and individuals resonating in the Web2 and Web3 space, 
                        unveiling the creative possibilities lying under the shining rock.</div>
                    </div>
                    <div
                        class="about-slide__tooltip"
                        v-else-if="showTooltip && activeTooltipIdx === 2"
                    >
                        <div
                            class="about-slide__tooltip-title"
                        >It is in the heart of COCO to build 
                        through collective experiences.</div>
                        <div
                            class="about-slide__tooltip-description"
                        >Planet COCO will serve as a platform where passionate minds meet, 
                        interact to share and visualize unique concepts, engage in activities, 
                        face challenges, create strange things with weird people as we seek 
                        new partnerships and move forth together into a globally 
                        recognized community brand: a hub for the creative soul.</div>
                    </div>
                </Transition>
            </div>
        </template>
    </AboutSlide>
</template>

<style lang="postcss">
</style>