export default [
  {
    title: "WHAT IS PLANET COCO?",
    text: "Planet COCO is a story about the beginning of a new generation. \
        New generation brings new lifestyle. Planet COCO curates a creative lifestyle \
        centering around art, creativity, and fashion culture.\
        <br><br> \
        Surround yourself with like-minded creators as we build a spirited community by \
        collaborating, connecting, and building. Daze into our dreamy days within and \
        escape to the world of mellow adventures!",
  },
  {
    title: "HOW BIG IS THE COLLECTION?",
    text: "TBA: Details related to the mint will be announced soon.",
  },
  {
    title: "WHAT CHAIN WILL IT BE ON?",
    text: "COCOs will be residing in the Ethereum Blockchain. Every COCO is hand-drawn \
      with care and have been warped to this world by our beloved artist, Dazed KIM. \
      Each COCO is seamlessly crafted from hundreds of different fun traits including \
      detailed clothing, neat hair styles, cute accessories and more.",
  },
  {
    title: "WHO IS THE TEAM BEHIND PLANET COCO?",
    text: "Planet COCO is co-founded by South Korean artist DazedKim and brand director \
      Coldy. Kim is currently living in South Korea working as a full-time digital artist \
      creating Planet COCO. Kim's biggest passion is connecting and sharing through \
      creativity. Past works of Kim include collaborations with IKEA, KIA Motors, and LOTTE. \
      <br><br> \
      Also living in South Korea, Coldy is a graduate of advertisement & journalism and \
      has a 7 year background of branding in the fashion industry. Coldy's mission is to \
      bring people together in the versatile space of Web3. The carefully hand-picked \
      team members are undoubtedly the most valuable asset to our project. World-wide \
       talents include Web3 enabler null, community lead null, concept artist \
      Wisefull, motion designer 5doggie, and of course our wonderful MOD team. ",
  },
  {
    title: "WHAT IS THE ROADMAP?",
    text: "One Planet COCO NFT is a visual avatar representation in the world of Planet COCO \
      and serves as an exclusive passport to the adventures, collaborations and real-life \
      events lying ahead within and around the COCO-verse. Check out our roadmap in \
      detail by clicking the VISION tab above.",
  },
  {
    title: "HOW DO I GET WHITELISTED?",
    text: "Planet COCO does not have a specific set of process that gurantees a spot in the \
      whitelist. However, stay tuned to our official channels and make sure to actively \
      interact with them to land within our radar!",
  },
  {
    title: "DO I GET ANY COMMERCIAL RIGHTS?",
    text: "You will have all the rights to use your NFT within the ownership terms of service. \
      This means that you can use your purchased art as a PFP, make new artworks, or \
      even monetize them by creating your own IRL merch and goods. Realize your \
      imaginations, and make sure to share them with the community!",
  },
  {
    title: "HOW DO I STAY UPDATED?",
    text: 'Stay tuned to our official channels for updates on Planet COCO.\
<br><br> \
      Twitter: <a target="_blank" href="https://twitter.com/PlanetCOCOnft">https://twitter.com/PlanetCOCOnft</a> \
      Discord: <a target="_blank" href="https://discord.gg/PlanetCOCOnft">https://discord.gg/PlanetCOCOnft</a> ',
  },
];
