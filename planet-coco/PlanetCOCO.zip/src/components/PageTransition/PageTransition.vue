<script setup>

</script>

<template>
    <div class="page-transition">
        <img src="@/assets/img/transition_icon.gif" alt="page-transition" />
    </div>
</template>

<style lang="postcss">
</style>