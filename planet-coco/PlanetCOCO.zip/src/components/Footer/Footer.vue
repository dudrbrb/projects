<script setup>
import imgTwitter from "@/assets/img/twitter.png"
import imgDiscord from "@/assets/img/discord.png"
import imgOpensea from "@/assets/img/opensea.png"
import imgEtherscan from "@/assets/img/etherscan.png"
import { computed, ref } from "@vue/runtime-core"
import { useRoute } from "vue-router"
import { usePageTransition } from "@/helpers/usePageTransition"
import { useMenu } from "@/helpers/useMenu"
const items = [
    {
        icon: imgTwitter,
        link: "https://twitter.com/planetcoconft"
    },
    {
        icon: imgDiscord,
        link: "https://discord.gg/PlanetCOCOnft"
    },
    {
        icon: imgOpensea,
        link: "https://opensea.io/"
    },
    {
        icon: imgEtherscan,
        link: "https://etherscan.io/"
    },
]
const route = useRoute()
const { isOpen: showPageTransition } = usePageTransition()
const { isOpen: isMenuOpen } = useMenu()
const isMobile = ref(false)
const checkMobile = () => {
    isMobile.value = window.innerWidth < 950
}
checkMobile()
window.addEventListener('resize', () => {
    checkMobile()
})
const isFooterStick = computed(() => {
    return (route.name === 'Home' || (route.name === 'Faq' && !isMobile.value) || showPageTransition.value || isMenuOpen.value)
})
</script>

<template>
    <footer class="footer" :class="{ stick: isFooterStick }">
        <div class="footer-copyright">2023 PLANET COCO. ALL RIGHTS RESERVED</div>
        <div class="footer-terms">
            <router-link :to="{ name: 'Terms' }">TERMS&CONDITIONS</router-link>
        </div>
        <div class="footer-soc">
            <a
                :href="item.link"
                target="_blank"
                class="footer-soc-item"
                v-for="(item, idx) in items"
                :key="idx"
            >
                <img :src="item.icon" alt="soc" width="48" height="48" />
            </a>
        </div>
    </footer>
</template>

<style lang="postcss">
</style>