<script setup>
import svgVision from "../../assets/icons/vision_helper.svg"
</script>

<template>
    <div class="page-helper-canvas page-helper-vision">
        <img
            class="page-helper-vision__cursor"
            src="@/assets/img/page_helper_cursor.png"
            alt="cursor"
            width="30"
        />
        <svgVision class="page-helper-vision__image" width="145" />
    </div>
</template>

<style lang="postcss">
</style>