<script setup>
import svgPause from "@/assets/icons/pause.svg"
import svgPlay from "@/assets/icons/play.svg"
</script>

<template>
    <div class="page-helper-canvas page-helper-lore">
        <img
            class="page-helper-lore__cursor"
            src="@/assets/img/page_helper_cursor.png"
            alt="cursor"
            width="30"
        />
        <div class="page-helper-lore__element">
            <svgPlay class="page-helper-lore__play" />
            <svgPause class="page-helper-lore__pause" />
        </div>
    </div>
</template>

<style lang="postcss">
</style>