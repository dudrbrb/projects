<script setup>

</script>

<template>
    <div class="page-helper-canvas page-helper-faq">
        <img
            class="page-helper-faq__mouse"
            src="@/assets/img/page_helper_mouse.png"
            alt="mouse"
            width="30"
        />
        <div class="page-helper-faq__element">
            <div class="page-helper-faq__items">
                <div class="page-helper-faq__item"></div>
                <div class="page-helper-faq__item"></div>
                <div class="page-helper-faq__item"></div>
                <div class="page-helper-faq__item"></div>
            </div>
            <div class="page-helper-faq__scrollbar"></div>
        </div>
    </div>
</template>

<style lang="postcss">
</style>