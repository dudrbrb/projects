<script setup>import { ref } from "@vue/reactivity";
import { onMounted } from "@vue/runtime-core";


</script>

<template>
    <div class="page-helper-canvas page-helper-about">
        <div class="page-helper-about__arrow page-helper-about__arrow-left" ref="arrowLeft">
            <img src="@/assets/img/page_helper_arrow.png" alt="arrow" />
        </div>
        <div class="page-helper-about__arrow page-helper-about__arrow-right" ref="arrowRight">
            <img src="@/assets/img/page_helper_arrow.png" alt="arrow" />
        </div>
        <div class="page-helper-about__dots">
            <div class="page-helper-about__dot"></div>
            <div class="page-helper-about__dot"></div>
            <div class="page-helper-about__dot"></div>
            <div class="page-helper-about__dot"></div>
        </div>
    </div>
</template>

<style lang="postcss">
</style>