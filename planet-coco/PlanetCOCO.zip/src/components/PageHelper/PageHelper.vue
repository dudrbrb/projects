<script setup>
import svgAbout from "@/assets/icons/about_helper.svg"
import { usePageHelper } from "@/helpers/usePageHelper";
import { computed, watch } from "@vue/runtime-core";
import { useRoute } from "vue-router";
import PageHelperAbout from "./PageHelperAbout.vue";
import PageHelperLore from "./PageHelperLore.vue";
import PageHelperVision from "./PageHelperVision.vue";
import PageHelperFaq from "./PageHelperFaq.vue";
const route = useRoute()
const items = {
    About: {
        title: "USE DIRECTION KEY TO NAVIGATE",
        component: PageHelperAbout
    },
    Vision: {
        title: "SELECT CATEGORY TO VIEW DETAIL",
        component: PageHelperVision
    },
    Lore: {
        title: "HOVER CURSOR TO PLAY VIDEO",
        component: PageHelperLore
    },
    Faq: {
        title: "SCROLL DOWN TO BROWSE LIST",
        component: PageHelperFaq
    }
}
const activeItem = computed(() => items[route.name])
const hasPageHelper = computed(() => !!activeItem.value)
watch(activeItem, () => {
})
const { isOpen, show, hide } = usePageHelper()
let timeout = null
watch(isOpen, () => {
    clearTimeout(timeout)
    if (isOpen.value) {
        timeout = setTimeout(() => {
            hide()
            timeout = null
        }, 2000)
    }
})
const skipAnimation = () => {
    hide()
}
</script>

<template>
    <Transition name="t-page-helper">
        <div class="page-helper" v-if="isOpen && hasPageHelper" @click="skipAnimation">
            <div class="page-helper-element">
                <div class="page-helper__title">{{ activeItem.title }}</div>
                <component :is="activeItem.component" />
            </div>
        </div>
    </Transition>
</template>

<style lang="postcss">
</style>