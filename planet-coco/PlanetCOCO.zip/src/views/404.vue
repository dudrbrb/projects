<template>
    <div>Not found</div>
</template>

<script setup>
</script>