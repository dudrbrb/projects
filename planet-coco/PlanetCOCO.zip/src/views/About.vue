<script setup>
import PageCard from "@/components/PageCard.vue";
import AboutSlider from "@/components/About/AboutSlider.vue";

</script>

<template>
    <div class="page-about about">
        <PageCard title="About" tooltip="Discover all the motives behind project Planet COCO here">
            <AboutSlider />
        </PageCard>
    </div>
</template>

<style lang="postcss">
</style>
