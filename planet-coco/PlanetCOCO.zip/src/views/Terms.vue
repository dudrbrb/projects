<script setup>
import PageCard from "@/components/PageCard.vue";

</script>

<template>
    <PageCard
        class="terms page-terms page-limited"
        title="TERMS&CONDITIONS"
        tooltip="We provide a wide range of usage 
    for your COCO images. "
    >
        <div class="terms-block">
            <div class="terms-text">
                Planet COCO is a collection of NFT digital artworks on the Ethereum blockchain. This website serves as an interface that provides information and allows participants to purchase, or
                mint, the digital collectibles. Users are entirely responsible for the management of their own private wallets, validating transactions, validating contracts generated in this website upon
                approval. This website and its connected services are provided as is, without warranty of any kind. By using this website you are accepting the sole responsibility for any and all
                transactions involving Planet COCO digital collectibles. Planet COCO and the team holds no ability to undo, reverse, or restore any transactions done in this website.
            </div>
        </div>
        <div class="terms-block">
            <h3 class="terms-title">OWNERSHIP AGREEMENT</h3>
            <div class="terms-text">
                i. Ownership: Each Planet COCO is an NFT running on the Ethereum blockchain. Upon purchasing an NFT, the buyer owns the art, the COCO character, completely. Ownership of the NFT
                is proven and secured by the Smart Contract and the Ethereum Network. Planet COCO and the team owns no right to modify the ownership state of any Planet COCO NFT.
                <br />
                <br />ii. Personal Use: The owner is granted with a worldwide royalty-free license to use the purchased NFT, or art, for the following purposes: (i) for non-commercial personal use, (ii) for the
                purpose of purchasing and selling your Planet COCO NFT at an external, third party marketplace, under the circumstances that the specific marketplace carries the ability to verify the
                ownership of each Planet COCO NFT and the individual rights of its actual owners in displaying the art, (iii) for the purpose of displaying your Planet COCO NFT in a third party website or
                application that permits the inclusion of your purchased Planet COCO NFT, under the circumstances that the specific website or application carries the ability to verify the ownership of
                each Planet COCO NFT and the individual rights of its actual owners in displaying the art, provided that the Planet COCO NFT art is no longer visible once the owner withdraws
                involvement in the website or application.
                <br />
                <br />iii. Commercial Use: The owner is granted with a worldwide royalty-free license to use the purchased NFT, or art, in creating "Derivative Works" based on the art. "Derivative Works" may
                include, but is not limited to, the use of the art in producing and merchandising products and goods fit for sale(e.g. clothing, accessories). The Planet COCO NFT commercial rights and
                ownership agreement does not limit the owner from earning revenue from any of the foregoing, under the circumstances that the specific marketplace, website or application carries the
                ability to verify the ownership of each Planet COCO NFT and the individual rights of its actual owners in displaying the art, provided that the Planet COCO NFT art is no longer visible once
                the owner withdraws involvement in the marketplace, website or application.
            </div>
        </div>
    </PageCard>
</template>

<style lang="postcss">
</style>