
<script setup>
import { useCookies } from "../helpers/useCookies";
import { useFirebase } from "../helpers/useFirebase";
import { ref } from "@vue/reactivity";
const { setTempCookie, getCookie } = useCookies();
const { getDoc, doc, db,setDoc, collection, query, getDocs, where} = useFirebase();
let inputValue = ref("");
let attempts = ref(0);
let submitDisabled = ref(false);
let successfulSubmit = ref(false);
let allreadyExistAddress = ref(false);
let unvalidAddress = ref(false);
let tooManyAttempts = ref(false);

if (getCookie("successInsert")) {
        submitDisabled.value = true;
        successfulSubmit.value = true;
    }
    if (getCookie("walletcollectordban")) {
        submitDisabled.value = true;
        tooManyAttempts.value = true;
        console.log(attempts.value);
    }
        const shakeErr = ()=>{
            document.getElementById("walletContainer").classList.add("shake");
            setTimeout(() => {
                document.getElementById("walletContainer").classList.remove("shake")
            }, 300);
        }
        const setallreadyExistAddressErr = ()=>{
            endLoadingProtocol();
            shakeErr();
            unvalidAddress.value = false;
            allreadyExistAddress.value = true;
        }
        const setunvalidAddressErr = ()=>{
            shakeErr();
            attempts.value = attempts.value+1;
            console.log(attempts.value);
            allreadyExistAddress.value = false;
            unvalidAddress.value = true;
        }
        const addAddressToCocoList = ()=>{
            unvalidAddress.value = false;
            allreadyExistAddress.value = false;
            const docRef = doc(db, `cocolist/${inputValue.value}`);
            const newAddress = inputValue.value;
            const currentDateTime = new Date().toUTCString();
            fetch("https://ipapi.co/json/").then((res) => {
                res.json().then((val) => {
                    const ip = val["ip"];
                    const country = val["country_name"];
                    const city = val["city"];
                    const region = val["region"];
                    const newData = {
                        serialnumber:newAddress,
                        utcdatetime:currentDateTime,
                        ip:ip,
                        country:country,
                        city:city,
                        region:region}
                    setDoc(docRef,newData).then((res)=>{
                        endLoadingProtocol();
                        //set to one hour in production
                    setTempCookie("successInsert",true,7200);
                    submitDisabled.value = true;
                    successfulSubmit.value = true;
                    }).catch((err)=>{console.log(err+"please try again");})
                });
                }).catch((err)=>{
                    setDoc(docRef,{serialnumber:newAddress,utcdatetime:currentDateTime}).then((res)=>{
                        //set to one hour in production
                    setTempCookie("successInsert",true,3600);
                    submitDisabled.value = true;
                    successfulSubmit.value = true;
                    }).catch((err)=>{console.log(err+"please try again");})
                });
        }
        const setTooManyAttemptsErr = ()=>{
            shakeErr();
                //set to one hour in production
            setTempCookie("walletcollectordban",true,3600);
            submitDisabled.value = true;
            unvalidAddress.value = false;
            allreadyExistAddress.value = false;
            tooManyAttempts.value = true;
        }
        const startLoadingProtocol = ()=>{
            submitDisabled.value = true;
            document.getElementById("walletSubmitText").style.display = "none"
            document.getElementById("walletSubmit").classList.add("lds-ring");
        }
        const endLoadingProtocol = ()=>{
            document.getElementById("walletSubmit").classList.remove("lds-ring");
            document.getElementById("walletSubmitText").style.display = "inline"
            submitDisabled.value = false;
        }
        const handleSubmit = async ()=>{
            const docRef = doc(db, `cocolist/${inputValue.value}`);
            // set input value less than 40 chars in production
            if (attempts.value<4 && inputValue.value.length < 40) {
                setunvalidAddressErr();
            }
            else if (attempts.value>=4) {
                setTooManyAttemptsErr();
            }else{
            const colRef = collection(db,"cocolist");
            var namequery = query(colRef, where("serialnumber", "==", inputValue.value));
            startLoadingProtocol();
            getDocs(namequery).then((q)=>{
                //if query is not empty
                if (!q.empty) {
                setallreadyExistAddressErr()
                }
                else{
                    addAddressToCocoList()
                }
            })}
        }

</script>

<template>
    <div id="walletContainer" >
            <div id="walletShowPassword"><img src="../assets/img/eth_logo.png" /></div>
            <input :type="'text'" placeholder="ENTER ETHEREUM WALLET ADDRESS" @input="event => inputValue = event.target.value"/>
            <button id="walletSubmit" @click="handleSubmit" :disabled="submitDisabled" :style="submitDisabled?'color:grey;':''"><span id="walletSubmitText">SUBMIT</span>
                <div></div><div></div><div></div><div></div></button>
    </div>
    <label id="walletLabel">
        <div v-if="successfulSubmit">WALLET SUBMIT SUCCESSFUL. WELCOME TO PLANET COCO!</div>
        <div v-if="allreadyExistAddress">THIS ADDRESS IS ALREADY ON THE COCOLIST</div>
        <div v-if="unvalidAddress">THIS DOESN'T SEEM TO BE AN ETHEREUM WALLET ADDRESS. PLEASE TRY AGAIN</div>
        <div v-if="tooManyAttempts">TOO MANY ATTEMPTS. PLEASE TRY AGAIN LATER</div>
    </label>
</template>

<style lang="css" scoped>
@media screen and (max-width: 992px) {
    #walletContainer{
        flex-direction: column;
    }
    #walletContainer input{
        width: 85% !important;
        font-size: medium !important;
        margin-top: 16px;
        margin-bottom: 16px;
    }
    #walletShowPassword{
        width: 55.25px !important;
    }
    #walletSubmit{
        width: 85% !important;
        font-size: 20px !important;
    }
    .lds-ring {
    height: 44px !important;
}
}
#walletWrapper{
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    margin-left: 20px;
    margin-right: 20px;
}
#walletContainer{
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
#walletContainer input{
    width:54%;
    padding: 12px 17px;
    background-color: white;
    border-color: green;
    border-radius: 20px;
    font-size: 25px;
    font-weight: 900;
    color: black;
}
#walletContainer input:hover::-webkit-input-placeholder{
    color: #cbcbcba8;
}
#walletContainer input:hover:-ms-input-placeholder{
    color: #cbcbcba8;
}
#walletContainer input:hover::placeholder{
    color: #cbcbcba8;
}
::-webkit-input-placeholder { /* Edge */
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

::placeholder {
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

input:focus{
    outline: none;
    background-color: #f7eb63;
}

#walletShowPassword{
    width:52px;
    font-size: 25px;
    font-weight: 900;
    padding: 12px 17px;
    background-color: white;
    border-radius: 20px;
    margin: 0 15px;
    display: flex;
    justify-content: center;
    align-items: center;
}
#walletSubmit{
    width: 14%;
    padding: 12px 17px;
    font-size: 25px;
    font-weight: 900;
    background-color: #f7eb63;
    border-radius: 20px;
    margin: 0 15px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 200ms ease-out;
}
#walletSubmit:hover{
    background-color: #38454c;
    color: white;
}
#walletLabel{
    height: 40px;
}
#walletLabel div{
    margin-top: 20px;
    font-size: 15px;
    font-weight: 900;
    color: black;
    text-align: center;
}

@-webkit-keyframes shaker {
	0% { -webkit-transform: translate(10px, 10); }
	50% { -webkit-transform: translate(-10px, -10); }
	100% { -webkit-transform: translate(-10px, -10); }
}
@keyframes shaker {
	0% { transform: translate(10px, 0);}
	50% { transform: translate(-10px, 0); }
	100% { transform: translate(10px, 0); }
}

.shake {
	-webkit-animation-name: shaker;
	-webkit-animation-duration: 0.2s;
	-webkit-transform-origin:50% 50%;
	-webkit-animation-timing-function: linear;
	animation-name: shaker;
	animation-duration: .2s;
	transform-origin:50% 50%;
	animation-timing-function: linear;
}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 55.25px;
  height: 55.25px;
}
.lds-ring div {
    box-sizing: border-box;
  display: block;
  position: absolute;
  width: 25px;
  height: 25px;
  margin: 8px;
  border: 3px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

::-moz-selection { /* Code for Firefox */
  color: black;
  background: lightgrey;
}

::selection {
  color: black;
  background: lightgrey;
}
</style>
