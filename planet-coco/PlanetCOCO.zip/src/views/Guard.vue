
<script setup>
import { useGuard } from "../helpers/useGuard";
import { useCookies } from "../helpers/useCookies";
import { useHider } from "../helpers/useHider";
import { useFirebase } from "../helpers/useFirebase";
import WalletCollector from "./WalletCollector.vue"
import { ref } from "@vue/reactivity";
const { setTempCookie, getCookie } = useCookies();
const { hide:hideHeaderandFooter } = useHider();
const { getDoc, doc, db } = useFirebase();
const { isAllowed: isUserAllowed, allow: AllowUser } = useGuard()
let inputValue = ref("");
let attempts = ref(0);
let submitDisabled = ref(false);
let isPasswordShown = ref(false);
let inCorrectPassword = ref(false);
let tooManyAttempts = ref(false);

    // before initial
    hideHeaderandFooter();
    if (getCookie("guardban")) {
        submitDisabled.value = true;
        tooManyAttempts.value = true;
    }

        const togglePassword = ()=>{
            isPasswordShown.value = !isPasswordShown.value
        }
        const shakeErr = ()=>{
            document.getElementById("guardContainer").classList.add("shake");
            setTimeout(() => {
                document.getElementById("guardContainer").classList.remove("shake")
            }, 300);
        }
        const setIncorrectPasswordErr = ()=>{
            shakeErr();
            inCorrectPassword.value = true;
        }
        const setTooManyAttemptsErr = ()=>{
            shakeErr();
            //set to one hour in production
            setTempCookie("guardban",true,3600);
            submitDisabled.value = true;
            unvalidAddress.value = false;
            inCorrectPassword.value = false;
            tooManyAttempts.value = true;
        }
        const startLoadingProtocol = ()=>{
            submitDisabled.value = true;
            document.getElementById("guardSubmitText").style.display = "none"
            document.getElementById("guardSubmit").classList.add("lds-ring");
        }
        const endLoadingProtocol = ()=>{
            document.getElementById("guardSubmit").classList.remove("lds-ring");
            document.getElementById("guardSubmitText").style.display = "inline"
            submitDisabled.value = false;
        }
        const handleSubmit = ()=>{
            const docRef = doc(db, `password/passwordDoc`);
            startLoadingProtocol()
            getDoc(docRef)
            .then((res) => {
            endLoadingProtocol();
            const data = res.data();
            const password = data["serial-number"];
            const accessDuration = data["access-duration-seconds"];
            if (attempts.value<4 && inputValue.value != password) {
                attempts.value = attempts.value+1;
                setIncorrectPasswordErr();
            }
            else if (attempts.value>=4) {
                setTooManyAttemptsErr();
            }else{
                if (isUserAllowed.value == false) {
                setTempCookie("allowed",true,accessDuration)
                if (getCookie("allowed")) {
                    AllowUser();
                }
            }
            }
            })
            .catch((err) => {
            console.log(err);
            });
        }
        
</script>

<template>
    <div id="guardWrapper">
        <div id="guardContainer" v-if="!isUserAllowed">
            <button id="guardShowPassword" @click="togglePassword">{{ isPasswordShown? "🔓":"🔒" }}</button>
            <input :type="isPasswordShown?'text':'password'" placeholder="ENTER SIM SERIAL NUMBER" @input="event => inputValue = event.target.value"/>
            <button id="guardSubmit" @click="handleSubmit" :disabled="submitDisabled" :style="submitDisabled?'color:grey':''"><span id="guardSubmitText">SUBMIT</span>
                <div></div><div></div><div></div><div></div></button>
    </div>
    <div id="guardLabel" v-if="!isUserAllowed">
        <div v-if="inCorrectPassword">INCORRECT SERIAL NUMBER. PLEASE TRY AGAIN.</div>
        <div v-if="tooManyAttempts">TOO MANY ATTEMPTS. PLEASE TRY AGAIN LATER.</div>
    </div>
    <WalletCollector v-if="isUserAllowed"></WalletCollector>
    <div id="walletCollectorFooter">
        <div id="bottomLogoImgContainer"><img src="../assets/img/bottom_logo.png" alt="logo img"/></div>
        <div>WALLET COLLECTOR V1.1.3</div>
        <div>POWERED BY PLANET COCO</div>
    </div>
    </div>
</template>

<style lang="css" scoped>
@media screen and (max-width: 992px) {
    #guardContainer{
        flex-direction: column;
    }
    #guardContainer input{
        width: 85% !important;
        font-size: medium !important;
        margin-top: 16px;
        margin-bottom: 16px;
    }
    #guardShowPassword{
        width: 20% !important;
    }
    #guardSubmit{
        width: 85% !important;
        font-size: 20px !important;
    }
    .lds-ring {
    height: 44px !important;
}

}
@media screen and (max-height: 500px){
    #walletCollectorFooter{
        display: none !important;
    }
}
#guardWrapper{
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    margin-left: 20px;
    margin-right: 20px;
}
#guardContainer{
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
#guardContainer input{
    width:54%;
    padding: 12px 17px;
    background-color: white;
    border-color: green;
    border-radius: 20px;
    font-size: 25px;
    font-weight: 900;
    color: black;
}
#guardContainer input:hover::-webkit-input-placeholder{
    color: #cbcbcba8;
}
#guardContainer input:hover:-ms-input-placeholder{
    color: #cbcbcba8;
}
#guardContainer input:hover::placeholder{
    color: #cbcbcba8;
}

::-webkit-input-placeholder { /* Edge */
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

::placeholder {
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}
input:focus{
    outline: none;
    background-color: #f7eb63;
}

#guardShowPassword{
    width:52px;
    font-size: 25px;
    font-weight: 900;
    padding: 12px 17px;
    background-color: white;
    border-radius: 20px;
    margin: 0 15px;
    display: flex;
    justify-content: center;
    align-items: center;
}
#guardSubmit{
    width: 14%;
    padding: 12px 17px;
    font-size: 25px;
    font-weight: 900;
    background-color: #f7eb63;
    border-radius: 20px;
    margin: 0 15px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 200ms ease-out;
}
#guardSubmit:hover{
    background-color: #38454c;
    color: white;
}
#guardLabel{
    height: 40px;
}
#guardLabel div{
    margin-top: 20px;
    font-size: 15px;
    font-weight: 900;
    color: black;
    text-align: center;
}
#walletCollectorFooter{
    position: absolute;
    bottom: 16px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
#walletCollectorFooter div{
    font-size: 12px;
    font-weight: 900;
    color: black;
}
#bottomLogoImgContainer{
    height: 50px;
    width: 100px;
    padding: 0 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 18px;
    margin-bottom: 5px;
}

@-webkit-keyframes shaker {
	0% { -webkit-transform: translate(10px, 10); }
	50% { -webkit-transform: translate(-10px, -10); }
	100% { -webkit-transform: translate(-10px, -10); }
}
@keyframes shaker {
	0% { transform: translate(10px, 0);}
	50% { transform: translate(-10px, 0); }
	100% { transform: translate(10px, 0); }
}

.shake {
	-webkit-animation-name: shaker;
	-webkit-animation-duration: 0.2s;
	-webkit-transform-origin:50% 50%;
	-webkit-animation-timing-function: linear;
	animation-name: shaker;
	animation-duration: .2s;
	transform-origin:50% 50%;
	animation-timing-function: linear;
}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 55.25px;
  height: 55.25px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 25px;
  height: 25px;
  margin: 8px;
  border: 3px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

::-moz-selection { /* Code for Firefox */
  color: black;
  background: lightgrey;
}

::selection {
  color: black;
  background: lightgrey;
}
</style>
