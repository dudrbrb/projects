<script setup>
import PageCard from "@/components/PageCard.vue";
import faqData from "@/components/Faq/faq-data"
import { computed, ref } from "@vue/runtime-core";
const activeItem = ref(0)
const activeData = computed(() => faqData[activeItem.value])
const selectItem = (idx) => {
    activeItem.value = idx
    if (window.innerWidth < 950) {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    }

}
</script>

<template>
    <div class="faq page-faq page-limited">
        <div class="faq-row">
            <PageCard
                class="faq-preview"
                title="FAQ"
                tooltip="Find answers to some of the most
    frequently asked questions here."
            >
                <Transition mode="out-in" name="t-fade">
                    <div class="faq-preview__text" v-html="activeData.text" :key="activeData.text"></div>
                </Transition>
            </PageCard>
            <div class="faq-items">
                <a
                    href="#"
                    class="faq-item"
                    :class="{ active: idx == activeItem }"
                    v-for="(item, idx) in faqData "
                    :key="idx"
                    @click.prevent="selectItem(idx)"
                >{{ item.title }}</a>
            </div>
        </div>
    </div>
</template>

<style lang="postcss">
</style>