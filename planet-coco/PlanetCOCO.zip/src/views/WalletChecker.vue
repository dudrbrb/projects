
<script setup>
import { useCookies } from "../helpers/useCookies";
import { useFirebase } from "../helpers/useFirebase";
import { ref } from "@vue/reactivity";
import { useHider } from "../helpers/useHider";
import checkImg from '@/assets/img/wl_green_check.png'
import xImg from '@/assets/img/wl_x_pink.png'
const { hide:hideHeaderandFooter } = useHider();
const { setTempCookie, getCookie } = useCookies();
const { getDoc, doc, db,setDoc, collection, query, getDocs, where} = useFirebase();
let inputValue = ref("");
let check = ref();
let attempts = ref(0);
let submitDisabled = ref(false);
let addressIsOnCocoList = ref(false);
let addressNotOnCocoList = ref(false);
let unvalidAddress = ref(false);
let tooManyAttempts = ref(false);

        // before initial
        hideHeaderandFooter();
    if (getCookie("walletcheckerban")) {
        submitDisabled.value = true;
        tooManyAttempts.value = true;
    }
        const shakeErr = ()=>{
            document.getElementById("walletCheckerContainer").classList.add("shake");
            setTimeout(() => {
                document.getElementById("walletCheckerContainer").classList.remove("shake")
            }, 300);
        }
        const setCheckToTrue = ()=>{
            check.value = true;
        }
        const setCheckToFalse = ()=>{
            check.value = false;
        }
        const handleCheck = ()=>{
            if(check.value == true){
                return checkImg
            } else if (check.value == false) {
                return xImg
            }
            else{
                return ""
            }
        }
        const setaddressIsOnCocoList = ()=>{
            endLoadingProtocol();
            unvalidAddress.value = false;
            addressNotOnCocoList.value = false;
            addressIsOnCocoList.value = true;
            setCheckToTrue();
        }
        const setaddressNotOnCocoList = ()=>{
            endLoadingProtocol();
            unvalidAddress.value = false;
            addressIsOnCocoList.value = false;
            addressNotOnCocoList.value = true;
            setCheckToFalse();
        }
        const setunvalidAddressErr = ()=>{
            shakeErr();
            document.getElementById("walletCheckerShowPasswordImge").src=""
            attempts.value = attempts.value+1;
            addressIsOnCocoList.value = false;
            addressNotOnCocoList.value = false;
            unvalidAddress.value = true;
        }
        const setTooManyAttemptsErr = ()=>{
            shakeErr();
                //set to one hour in production
            setTempCookie("walletcheckerban",true,3600);
            submitDisabled.value = true;
            unvalidAddress.value = false;
            addressIsOnCocoList.value = false;
            addressNotOnCocoList.value = false;
            tooManyAttempts.value = true;
        }
        const startLoadingProtocol = ()=>{
            submitDisabled.value = true;
            document.getElementById("walletCheckerSubmitText").style.display = "none"
            document.getElementById("walletCheckerSubmit").classList.add("lds-ring");
        }
        const endLoadingProtocol = ()=>{
            document.getElementById("walletCheckerSubmit").classList.remove("lds-ring");
            document.getElementById("walletCheckerSubmitText").style.display = "inline"
            submitDisabled.value = false;
        }
        const handleSubmit = async ()=>{
            const docRef = doc(db, `cocolist/${inputValue.value}`);
            // set input value less than 40 chars in production
            if (attempts.value<4 && inputValue.value.length < 40) {
                setunvalidAddressErr();
            }
            else if (attempts.value>=4) {
                setTooManyAttemptsErr();
            }else{
            const colRef = collection(db,"cocolist");
            var namequery = query(colRef, where("serialnumber", "==", inputValue.value));
            startLoadingProtocol();
            getDocs(namequery).then((q)=>{
                //if query is not empty
                if (!q.empty) {
                setaddressIsOnCocoList()
                }
                else{
                setaddressNotOnCocoList()
                }
            })}
        }

</script>

<template>
    <div id="walletCheckerWrapper">
        <div id="walletCheckerContainer" >
            <div id="walletCheckerShowPassword"><img id="walletCheckerShowPasswordImge" :src="handleCheck()"/></div>
            <input :type="'text'" placeholder="ENTER ETHEREUM WALLET ADDRESS" @input="event => inputValue = event.target.value"/>
            <button id="walletCheckerSubmit" @click="handleSubmit" :disabled="submitDisabled" :style="submitDisabled?'color:grey;':''"><span id="walletCheckerSubmitText">CHECK</span>
                <div></div><div></div><div></div><div></div></button>
    </div>
    <label id="walletCheckerLabel">
        <div v-if="addressNotOnCocoList">THIS ADDRESS IS NOT ON THE COCOLIST</div>
        <div v-if="addressIsOnCocoList">THIS ADDRESS IS ON THE COCOLIST! SEE YOU SOON, COCO!</div>
        <div v-if="unvalidAddress">THIS DOESN'T SEEM TO BE AN ETHEREUM WALLET ADDRESS. PLEASE TRY AGAIN</div>
        <div v-if="tooManyAttempts">TOO MANY ATTEMPTS. PLEASE TRY AGAIN LATER</div>
    </label>
    <div id="walletCollectorFooter">
        <div id="bottomLogoImgContainer"><img src="../assets/img/bottom_logo.png" alt="logo img"/></div>
        <div>WALLET CHECKER V2.1.2</div>
        <div>POWERED BY PLANET COCO</div>
    </div>
    </div>
</template>

<style lang="css" scoped>
@media screen and (max-width: 992px) {
    #walletCheckerContainer{
        flex-direction: column;
    }
    #walletCheckerContainer input{
        width: 85% !important;
        font-size: medium !important;
        margin-top: 16px;
        margin-bottom: 16px;
    }
    #walletCheckerShowPassword{
        width: 55.25px !important;
    }
    #walletCheckerSubmit{
        width: 85% !important;
        font-size: 20px !important;
    }
    .lds-ring {
    height: 44px !important;
}
}
@media screen and (max-height: 500px){
    #walletCollectorFooter{
        display: none !important;
    }
}
#walletCheckerWrapper{
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    margin-left: 20px;
    margin-right: 20px;
}
#walletCheckerContainer{
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
#walletCheckerContainer input{
    width:54%;
    padding: 12px 17px;
    background-color: white;
    border-color: green;
    border-radius: 20px;
    font-size: 25px;
    font-weight: 900;
    color: black;
}
#walletCheckerContainer input:hover::-webkit-input-placeholder{
    color: #cbcbcba8;
}
#walletCheckerContainer input:hover:-ms-input-placeholder{
    color: #cbcbcba8;
}
#walletCheckerContainer input:hover::placeholder{
    color: #cbcbcba8;
}
::-webkit-input-placeholder { /* Edge */
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

::placeholder {
  color: #cbcbcb;
  text-align: center;
  transition: 200ms ease-out;
}

input:focus{
    outline: none;
    background-color: #f7eb63;
}

#walletCheckerShowPassword{
    height:55.25px;
    width:55.25px;
    font-size: 25px;
    font-weight: 900;
    padding: 10px 10px;
    background-color: white;
    border-radius: 20px;
    margin: 0 15px;
    display: flex;
    justify-content: center;
    align-items: center;
}

#walletCheckerSubmit{
    width: 14%;
    padding: 12px 17px;
    font-size: 25px;
    font-weight: 900;
    background-color: #f7eb63;
    border-radius: 20px;
    margin: 0 15px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 200ms ease-out;
}
#walletCheckerSubmit:hover{
    background-color: #38454c;
    color: white;
}
#walletCheckerLabel{
    height: 40px;
}
#walletCheckerLabel div{
    margin-top: 20px;
    font-size: 15px;
    font-weight: 900;
    color: black;
    text-align: center;
}
#walletCollectorFooter{
    position: absolute;
    bottom: 16px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
#walletCollectorFooter div{
    font-size: 12px;
    font-weight: 900;
    color: black;
}
#bottomLogoImgContainer{
    height: 50px;
    width: 100px;
    padding: 0 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 18px;
    margin-bottom: 5px;
}

@-webkit-keyframes shaker {
	0% { -webkit-transform: translate(10px, 10); }
	50% { -webkit-transform: translate(-10px, -10); }
	100% { -webkit-transform: translate(-10px, -10); }
}
@keyframes shaker {
	0% { transform: translate(10px, 0);}
	50% { transform: translate(-10px, 0); }
	100% { transform: translate(10px, 0); }
}

.shake {
	-webkit-animation-name: shaker;
	-webkit-animation-duration: 0.2s;
	-webkit-transform-origin:50% 50%;
	-webkit-animation-timing-function: linear;
	animation-name: shaker;
	animation-duration: .2s;
	transform-origin:50% 50%;
	animation-timing-function: linear;
}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 55.25px;
  height: 55.25px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 25px;
  height: 25px;
  margin: 8px;
  border: 3px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

::-moz-selection { /* Code for Firefox */
  color: black;
  background: lightgrey;
}

::selection {
  color: black;
  background: lightgrey;
}
</style>
