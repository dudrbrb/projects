<script setup>
import PageCard from "@/components/PageCard.vue";
import VisionPreview from "@/components/Vision/VisionPreview.vue";
import { ref } from "@vue/reactivity";
const items = [
    {
        name: "BRAND",
        value: "brand"
    },
    {
        name: "CREATIVE LAB",
        value: "creative_lab"
    },
    {
        name: "IRL",
        value: 'irl'
    },
    {
        name: "SOUVENIR SHOP",
        value: "souvenir_shop"
    },
    {
        name: "VISION 2.0",
        value: "vision"
    }
]
const activeItem = ref('brand')
const selectItem = (value) => {
    activeItem.value = value
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    })
}
</script>

<template>
    <div class="page-vision vision page-limited">
        <div class="vision-row">
            <Transition mode="out-in" name="t-vision">
                <VisionPreview :activeItem="activeItem" :key="activeItem" />
            </Transition>
            <div class="vision-items">
                <a
                    href="#"
                    @click.prevent="selectItem(item.value)"
                    class="vision-item"
                    :class="{ active: activeItem == item.value }"
                    v-for="(item, idx) in items"
                    :key="idx"
                >{{ item.name }}</a>
            </div>
        </div>
    </div>
</template>

<style lang="postcss">
</style>