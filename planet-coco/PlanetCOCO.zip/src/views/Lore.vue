<script setup>
import PageCard from "@/components/PageCard.vue";
import { ref } from "@vue/reactivity";
import { computed } from "@vue/runtime-core";
const isPlaying = ref(false)
const video = ref(null)
const onMouseEnter = (e) => {
    if (isPlaying.value) return

    isPlaying.value = true
    setTimeout(() => {
        video.value.play()
    }, 200)

}
const onMouseLeave = e => {
    if (!isPlaying.value) return
    video.value.pause()
    isPlaying.value = false

}
const onClick = () => {
    if (isPlaying.value) {
        setTimeout(() => {
            isPlaying.value = false
        }, 0)


    } else {
        isPlaying.value = true
        setTimeout(() => {
            if (isPlaying.value) {

                video.value.play()
            }
        }, 200)
    }

}
const isMobile = ref(false)
const onResize = () => {
    isMobile.value = window.innerWidth < 950
}
onResize()
window.addEventListener('resize', onResize)
const listeners = computed(() => {
    if (isMobile.value) {
        return {
            click: onClick
        }
    }
    return {

        mouseleave: onMouseLeave,
        mouseenter: onMouseEnter
    }

})
</script>

<template>
    <div class="page-lore lore page-limited">
        <div class="lore-row">
            <PageCard
                class="lore-content"
                title="LORE"
                tooltip="This is an archive of the full origin story of Planet COCO"
            >
                <h2 class="lore-content__title">THE WHITE WHIRL</h2>
                <div class="lore-content__text">
                    Once upon a future...In a galaxy far away, an unknown white mass with great
                    gravitational force emerged, the size capable of engulfing multiple planets.
                    <br />
                    <br />Powerfully destructive by nature, the mass effortlessly devoured all planets in it's
                    path, setting off a swarm of aestroids and debris across the entire galaxy.
                    <br />
                    <br />This supernatural event was later documented as the arrival of the "White Whirl"
                </div>
                <a href="#" @click.prevent class="lore-content__button">COMING SOON</a>
                <div class="lore-content__pagination swiper-pagination">
                    <span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span>
                    <!-- <span class="swiper-pagination-bullet" v-for="(item) in 1" :key="item"></span> -->
                </div>
            </PageCard>
            <div class="lore-video" v-on="listeners">
                <Transition name="t-fade">
                    <video
                        loop
                        autoplay
                        muted
                        playsinline
                        class="lore-video__video"
                        ref="video"
                        v-if="isPlaying"
                        @click="onClick"
                    >
                        <source src="@/assets/img/lore.mp4" type="video/mp4" />
                    </video>
                    <img
                        class="lore-video__image"
                        src="@/assets/img/lore_placeholder.jpg"
                        alt="placeholder"
                        v-else
                    />
                </Transition>
            </div>
        </div>
    </div>
</template>

<style lang="postcss">
</style>