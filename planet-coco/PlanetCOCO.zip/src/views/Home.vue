<script setup>
import { onMounted, ref } from "vue";

const isDay = ref(true)
const toggleDay = () => {
    let timeout = 3000
    if (!isDay.value) {

        timeout = 10000
    }
    setTimeout(() => {
        isDay.value = !isDay.value
    }, timeout)
}
toggleDay()
const onAfterEnter = () => {
    toggleDay()
}
const isDesktop = ref(false)
const onResize = () => {
    isDesktop.value = window.innerWidth >= 950
}
onResize()
onMounted(() => {
    window.addEventListener('resize', onResize)
})
</script>

<template>
    <div class="page-home home">
        <div class="home-desktop" v-if="isDesktop">
            <Transition name="t-home" @afterEnter="onAfterEnter">
                <img
                    class="home-day"
                    src="@/assets/img/home_day.jpg"
                    alt="planet-coco-light"
                    v-if="isDay"
                />
                <img
                    class="home-night"
                    src="@/assets/img/home_night.jpg"
                    alt="planet-coco-light"
                    v-else
                />
            </Transition>
        </div>
        <div class="home-mob" v-else>
            <Transition name="t-home" @afterEnter="onAfterEnter">
                <div class="home-day" v-if="isDay">
                    <img src="@/assets/img/home_mob_day.jpg" alt="planet-coco-light" />
                    <img class="home-mob-text" src="@/assets/img/home_mob_text_day.png" alt="planet-coco-light" />
                </div>

                <div class="home-night" v-else>
                    <img src="@/assets/img/home_mob_night.jpg" alt="planet-coco-light" />
                    <img class="home-mob-text" src="@/assets/img/home_mob_text_night.png" alt="planet-coco-light" />
                </div>
            </Transition>
        </div>
    </div>
</template>

<style lang="postcss">
</style>