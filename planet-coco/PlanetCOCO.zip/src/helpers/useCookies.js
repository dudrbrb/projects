export const useCookies = () => {
  const getCookie = (cname) => {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(";");
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  };
  const setTempCookie = (name, value, secs) => {
    var now = new Date();
    var time = now.getTime();
    typeof secs == "string" ? parseInt(secs) : (time += secs * 1000);
    now.setTime(time);
    document.cookie =
      `${name}=` + value + "; expires=" + now.toUTCString() + "; path=/";
  };
  return { getCookie, setTempCookie };
};
