import { ref } from "@vue/reactivity";

const isOpen = ref(false);
export const useMenu = () => {
  const open = () => {
    isOpen.value = true;
  };
  const close = () => {
    isOpen.value = false;
  };
  const toggle = () => {
    if (isOpen.value) {
      close();
    } else {
      open();
    }
  };
  return { open, close, isOpen, toggle };
};
