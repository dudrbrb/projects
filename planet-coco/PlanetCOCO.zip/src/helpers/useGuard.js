import { ref } from "@vue/reactivity";
import { useCookies } from "./useCookies.js";
const { getCookie } = useCookies();
const isAllowed = ref(false);
export const useGuard = () => {
  const allow = () => {
    isAllowed.value = true;
  };
  const prevent = () => {
    isAllowed.value = false;
  };
  if (getCookie("allowed")) {
    allow();
  } else {
    prevent();
  }
  return { allow, prevent, isAllowed };
};
