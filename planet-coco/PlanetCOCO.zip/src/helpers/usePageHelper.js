import { ref } from "@vue/reactivity";

const isOpen = ref(false);
export const usePageHelper = () => {
  const show = (name) => {
    isOpen.value = true;
  };
  const hide = () => {
    isOpen.value = false;
  };
  return { isOpen, show, hide };
};
