// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "@firebase/firestore";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  orderBy,
  query,
  startAt,
  endAt,
  getDocs,
  where,
  limit,
} from "@firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyClEuTquH0AsX3n4WnhpvdruIbGTHs5rTw",
  authDomain: "planet-coco.firebaseapp.com",
  projectId: "planet-coco",
  storageBucket: "planet-coco.appspot.com",
  messagingSenderId: "796357758220",
  appId: "1:796357758220:web:694961cec0bcbd6dbc8d29",
  measurementId: "G-MCEBLS08V3",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
export const useFirebase = () => {
  return {
    db,
    getDoc,
    doc,
    updateDoc,
    setDoc,
    collection,
    query,
    getDocs,
    where,
  };
};
