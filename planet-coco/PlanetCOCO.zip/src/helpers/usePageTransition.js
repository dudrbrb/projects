import { ref } from "@vue/reactivity";

const isOpen = ref(false);
let timeout = null;
let isCalled = false;
const callbacks = [];
export const usePageTransition = () => {
  const show = () => {
    clearTimeout(timeout);
    isCalled = false;
    isOpen.value = true;
    timeout = setTimeout(() => {
      timeout = null;
      _hide();
    }, 1500);
  };
  const hide = () => {
    isCalled = true;
    _hide();
  };
  const _hide = () => {
    if (isCalled && !timeout) {
      isOpen.value = false;
      callbacks.forEach((cb) => cb());
    }
  };
  const onHide = (fn) => {
    callbacks.push(fn);
  };
  return { isOpen, show, hide, onHide };
};
