import { ref } from "@vue/reactivity";

const isHidden = ref(false);
export const useHider = () => {
  const hide = () => {
    isHidden.value = true;
  };
  const show = () => {
    isHidden.value = false;
  };
  return { isHidden, hide, show };
};
