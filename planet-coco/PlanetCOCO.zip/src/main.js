import { createApp } from "vue";
import "./assets/css/style.css";
import App from "./App.vue";
import { Swiper, SwiperSlide } from "swiper/vue";
import { Navigation, Pagination } from "swiper";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import 'swiper/css/effect-fade';


import router from "./routes/router";

const app = createApp(App);

app.use(router);

app.component("Swiper", Swiper);
app.component("SwiperSlide", SwiperSlide);
app.mount("#app");
