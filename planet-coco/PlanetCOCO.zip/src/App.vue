<script setup>
import Header from "./components/Header/Header.vue";
import Footer from "./components/Footer/Footer.vue";
import PageTransition from "./components/PageTransition/PageTransition.vue";
import { usePageTransition } from "./helpers/usePageTransition";
import HeaderMenuMob from "./components/Header/HeaderMenuMob.vue";
import { useMenu } from "./helpers/useMenu";
import { useHider } from "./helpers/useHider";
import PageHelper from "./components/PageHelper/PageHelper.vue";
import { onMounted } from "@vue/runtime-core";
const { isOpen: showPageTransition } = usePageTransition()
const { isOpen: isMenuOpen, close: closeMenu } = useMenu()
const { isHidden } = useHider()
onMounted(() => {
  window.addEventListener('resize', () => {
    if (window.innerWidth > 950) {
      closeMenu()
    }
  })
})
</script>

<template>
  <div class="content-wrapper">
    <Header v-if="!isHidden" />
    <Transition name="t-fade">
      <HeaderMenuMob v-if="isMenuOpen" />
    </Transition>
    <router-view></router-view>
    <Transition name="t-page-transition">
      <PageTransition v-if="showPageTransition" />
    </Transition>
    <PageHelper />
    <Footer v-if="!isHidden"/>
  </div>
</template>

<style lang="postcss">
</style>
