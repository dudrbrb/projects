export default [
  {
    path: "/:pathMatch(.*)*",
    name: "404",
    component: () => import("@/views/404.vue"),
  },
  {
    path: "/",
    name: "Home",
    component: () => import("@/views/Home.vue"),
  },
  {
    path: "/about",
    name: "About",
    component: () => import("@/views/About.vue"),
  },
  {
    path: "/vision",
    name: "Vision",
    component: () => import("@/views/Vision.vue"),
  },
  {
    path: "/lore",
    name: "Lore",
    component: () => import("@/views/Lore.vue"),
  },
  {
    path: "/faq",
    name: "Faq",
    component: () => import("@/views/Faq.vue"),
  },
  {
    path: "/terms",
    name: "Terms",
    component: () => import("@/views/Terms.vue"),
  },
  {
    path: "/walletcollector",
    name: "WalletCollector",
    component: () => import("@/views/Guard.vue"),
  },
  {
    path: "/walletchecker",
    name: "WalletChecker",
    component: () => import("@/views/WalletChecker.vue"),
  },
];
