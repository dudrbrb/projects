import { useMenu } from "@/helpers/useMenu";
import { usePageHelper } from "@/helpers/usePageHelper";
import { usePageTransition } from "@/helpers/usePageTransition";
import { watch } from "@vue/runtime-core";
import { createRouter, createWebHistory } from "vue-router";

import routes from "./index";
const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    // always scroll to top
    return { top: 0 };
  },
});

const {
  show: showPageTransition,
  hide: closePageTransition,
  onHide: onPageTransitionHide,
} = usePageTransition();
const { show: showPageHelper, hide: hidePageHelper } = usePageHelper();
const { close: closeMenu } = useMenu();
let pageTransitionDone = false;
router.beforeEach((to, from, next) => {
  hidePageHelper();
  showPageTransition();
  closeMenu();
  next();
});
onPageTransitionHide(() => {
  setTimeout(() => {
    showPageHelper();
  }, 500);
});
router.afterEach((to) => {
  closePageTransition();
});

export default router;
