const plugin = require("tailwindcss/plugin");
module.exports = {
  content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
  mode: "jit",
  theme: {
    extend: {
      spacing: {
        header: "5.625rem",
        "header-mob": "3.75rem",
        "card-offset": "4.375rem",
        "card-offset-mob": "1.25rem",
      },
      borderRadius: {
        xl: "1.7rem",
        "xl-mob": "1.4rem",
      },
      zIndex: {
        100: 100,
        200: 200,
      },
      fontSize: {
        "2lg": "1.375rem",
        "4xl": "2rem",
      },
    },
    screens: {
      md: { max: "950px" },
      sm: { max: "768px" },
      xs: { max: "560px" },
    },
    colors: {
      yellow: "#f7eb63",
      white: "#ffffff",
      blue: "#92c2ea",
      pink: "#ec86d0",
      black: "#000000",
      green: "#47D7AC",
      gray: {
        DEFAULT: "#b2b2b2",
        light: "#E1E1E1",
      },
      transparent: "transparent",
      bg: "#eaeff3",
    },
    fontFamily: {
      main: "rooney-sans",
    },
  },
  plugins: [
    plugin(({ addUtilities, theme }) => {
      const utilities = [
        {
          ".flex-center": {
            display: "flex",
            "align-items": "center",
            "justify-content": "center",
          },
        },
        {
          ".flex-y-center": {
            display: "flex",
            "align-items": "center",
          },
        },
        {
          ".flex-x-center": {
            display: "flex",
            "justify-content": "center",
          },
        },
      ];
      addUtilities(utilities);
    }),
  ],
};
