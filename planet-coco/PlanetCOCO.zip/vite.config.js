import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import { ViteAliases } from "vite-aliases";
import svgLoader from "vite-svg-loader";
import eslintPlugin from "vite-plugin-eslint";
// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    ViteAliases(),
    vue(),

    svgLoader({
      svgoConfig: {
        multipass: true,
        plugins: [
          "preset-default",
          {
            name: "convertColors",
            params: {
              currentColor: true,
            },
          },
          {
            name: "removeDimensions",
          },
        ],
      },
      svgo: true,
    }),
    // eslintPlugin(),
  ],
  build: {},
  server: {
    port: 3000,
    host: '0.0.0.0'
  },
});
