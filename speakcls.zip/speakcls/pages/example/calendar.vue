<template>
    <div class="mb-calendar">
        <div class="cal-title">
            <div class="year-month">{{showYear + '.' + showMonth}}</div>
        </div>
        <div class="cal_wrap">
            <div class="dates" @scroll="checkScroll($event)"></div>
        </div>
    </div>
</template>
<style  lang="scss">

.mb-calendar {
    width: 360px;
    margin: 100px auto;

    .cal-title {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: 700;
        font-size: 48px;
        line-height: 78px;
        .year-month {
            width: 300px;
            text-align: center;
            line-height: 1;
        }
        .nav {
            display: flex;
            border: 1px solid #333333;
            border-radius: 5px;
        }
    }
    .cal_wrap {
        padding-top: 40px;
        position: relative;
        margin: 0 auto;
        &::after {
            top: 368px;
        }
        .day {
            display:flex;
            align-items: center;
            justify-content: center;
            width: calc(100% / 7);
            text-align: left;
            color: #999;
            font-size: 12px;
            text-align: center;
            border-radius:5px;
            
            &.holiday{
                color: #ed2a61;
            }

            &.disable {
                color: #ddd;
            }
            
        }
         .dates {
            @include flex(flex-start, flex-start);
            height: auto;
            overflow-x: scroll;
            -ms-overflow-style: none;
            width: auto;
            .day {
                min-width: 3.8em;
                min-height: 30px;
            }
            &::-webkit-scrollbar{
                display:none;
            }
            
        }
      
    }

    .current.today {background: rgb(242 242 242);}

}
</style>

<script>    
export default {
    name: 'mypage',
    layout: 'mypage',
    data(){
        return{
            common:{},
            date: new Date(), // 현재 날짜(로컬 기준) 가져오기
            utc : null, // uct 표준시 도출
            today : null, // 한국 시간으로 date 객체 만들기(오늘)
            thisMonth : null,
            currentYear : null,
            currentMonth: null,

            // 이번 달의 마지막날 날짜와 요일 구하기
            endDay  : null,
            nextDate : null,
           
           // 스크롤 범위 구하기 위한 인덱스
           monthIndex: 0,
           showYear: new Date().getFullYear(),
           showMonth: new Date().getMonth() +1,
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.calendarInit();
    },
    watch:{
    },
    filters:{
    },
    methods:{
        calendarInit() {
            this.utc= this.date.getTime() + ( this.date.getTimezoneOffset() * 60 * 1000), // uct 표준시 도출
            this.today = new Date( this.utc +  9 * 60 * 60 * 1000), // 한국 시간으로 date 객체 만들기(오늘)
            
            this.thisMonth = new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate());
            // 달력에서 표기하는 날짜 객체
        
            this.currentYear = this.thisMonth.getFullYear(); // 달력에서 표기하는 연
            this.currentMonth = this.thisMonth.getMonth(); // 달력에서 표기하는 월
            // 캘린더 렌더링
            this.renderCalender(this.thisMonth);
        },
        renderCalender() {
            // 렌더링을 위한 데이터 정리
            this.currentYear = this.thisMonth.getFullYear();
            this.currentMonth = this.thisMonth.getMonth();

            // 이번 달의 마지막날 날짜와 요일 구하기
            this.endDay = new Date(this.currentYear, this.currentMonth + 1, 0);
            this.nextDate = this.endDay.getDate();

            // 렌더링 html 요소 생성
            var calendar = document.querySelector('.dates')
            var week = ['일', '월', '화', '수', '목', '금', '토']
            

            var startDay = (this.currentMonth == this.date.getMonth() ? this.today.getDate() : 1)

            for (var i = startDay; i <= this.nextDate; i++) {
                var dayOfWeek = week[new Date(this.currentYear+'-'+(this.currentMonth+1)+'-'+i).getDay()];
                calendar.innerHTML += '<div class="day current '+ (dayOfWeek=='토'||dayOfWeek=='일' ?'holiday' : '' )+'" year="'+ this.currentYear+'" month="'+(this.currentMonth+1) +'">' + dayOfWeek+ '<br>' + i +'</div>'
            }
            this.observer();
            this.monthIndex = this.monthIndex +1;
            if(( this.currentMonth == this.date.getMonth()) && (this.today.getDate() >= 20)){
                this.addMonth()
            }

        },
        addMonth(){
            this.currentMonth= this.currentMonth +1;
            this.thisMonth = new Date(this.currentYear, this.currentMonth, 1);
            this.renderCalender(this.thisMonth); 
        },
        checkScroll(e){
            var scrollX = e. target.scrollLeft;
         
            if(scrollX > 150*this.monthIndex){
                this.addMonth();
            }
            this.observer();
        },
        observer(){
             const io = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    // entry의 target으로 DOM에 접근합니다.
                    const $target = entry.target;

                    // 화면에 노출 상태에 따라 해당 엘리먼트의 class를 컨트롤 합니다.
                    if (entry.isIntersecting) {
                        $target.classList.add("screening");
                    } else {
                        $target.classList.remove("screening");
                    }
                });
            });
            const $items = this.$el.querySelectorAll(".day");
            $items.forEach((item) => {
                io.observe(item);
            });
            this.makeCalendarTitle();

        },
        makeCalendarTitle(){
            var screening = this.$el.querySelectorAll('.screening')
            screening.forEach(e=>{
                this.showYear = e.getAttribute('year');
                this.showMonth = Number(e.getAttribute('month'));
            })
        }


    },
    computed:{
    }
}


</script>