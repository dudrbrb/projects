<template>
    <swiper class="swiper" :options="swiperOption">
        <swiper-slide>Slide 1</swiper-slide>
        <swiper-slide>Slide 2</swiper-slide>
        <swiper-slide>Slide 3</swiper-slide>
        <swiper-slide>Slide 4</swiper-slide>
        <swiper-slide>Slide 5</swiper-slide>
        <swiper-slide>Slide 6</swiper-slide>
        <swiper-slide>Slide 7</swiper-slide>
        <swiper-slide>Slide 8</swiper-slide>
        <swiper-slide>Slide 9</swiper-slide>
        <swiper-slide>Slide 10</swiper-slide>
        <div class="swiper-pagination" slot="pagination"></div>
        <div class="swiper-button-prev" slot="button-prev"></div>
        <div class="swiper-button-next" slot="button-next"></div>
    </swiper>
</template>
<script>
export default {
     name: 'swiper-example-loop', 
     title: 'Loop mode / Infinite loop', 
     data() { 
         return { 
            swiperOption: { 
                slidesPerView: 3,
                spaceBetween: 30, 
                loop: true, 
                pagination: { 
                    el: '.swiper-pagination', 
                    clickable: true 
                }, 
                navigation: { 
                    nextEl: '.swiper-button-next', 
                    prevEl: '.swiper-button-prev' 
                } 
            } 
        } 
    } 
}
</script>
<style lang="scss" scoped>

.swiper { 
    height: 300px;
    width: 100%; 
    .swiper-slide {
         display: flex; 
         justify-content: center; 
         align-items: center;
          text-align: center;
          font-weight: font5;
    }
 }

</style>