<template>
    <div id="container">
        <header>
            <div>
                <div class="title">
                    <div>
                        <span>BEST</span>
                        <p class="font5">포토 후기 쓰고<br>혜택 받고!</p>
                    </div>
                    <h1>REVIEWER</h1>
                </div>
                <p class="font4">수강 후, 리뷰를 남겨주세요<br>
                    베스트 리뷰로 선정되면 100% 적립금이 충전됩니다!
                </p>
                <div class="title-img">
                    <img :src="require('@/assets/img/review/main.webp')" alt=" 재구매 의사 95%" class="phone" loading="lazy">
                    <div class="bubble bubble1">
                        <div>
                            <img  :src="require('@/assets/img/review/star.png')" loading="lazy">
                            <p>아이가 직접 보며 이야기하니<br>재밌어해요!</p>
                        </div>
                    </div>
                    <div class="bubble bubble2">
                        <div>
                            <img  :src="require('@/assets/img/review/star.png')" loading="lazy">
                            <p>스픽클 화상수업 선택하길 <br v-if="!$device.isMobile">잘<br v-if="$device.isMobile">한 것 같아요!</p>
                        </div>

                    </div>
                </div>
            </div>
        </header>
        <section id="swiper" class="bg-light">
            <div>
                <h2>화상영어 스픽클,<br v-if="common.width<=540"> 왜 선택할까요?</h2>
                <swiper class="swiper" :options="swiperOption">
                    <swiper-slide>
                        <img :src="require(`@/assets/img/review/swiper/1.webp`)" alt="솔직한 후기"  loading="lazy">
                        <div>
                            <h4>화상수업은 단연 스픽클!</h4>
                            <p>영어를 달달 외우는 식이 아니라 아이가 자연스럽게 문장으로 대답할 수 있도록 유도해주시니 너무 감사해요! 원어민 선생님께서 잘 이끌어주시기에 스픽클 화상수업 선택하길 잘한 것 같아요</p>
                            <div class="writer">작성자 <span class="font5">ooo님</span></div>
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <img :src="require(`@/assets/img/review/swiper/2.webp`)" alt="솔직한 후기" loading="lazy">
                        <div>
                            <h4>화상영어수업이 재미있대요~!</h4>
                            <p>수업이 끝났는데도 아이가 방에서 나오질 않아 들어가보니 다른 컨텐츠를 찾아 혼자 공부하고 있더라고요. 영어를 싫어하던 아이가 맞나? 싶을 정도로 깜짝 놀랐죠ㅎㅎ 왜 이제야 시작해줬나 미안하기도 했답니다</p>
                            <div class="writer">작성자 <span class="font5">ooo님</span></div>
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <img :src="require(`@/assets/img/review/swiper/3.webp`)" alt="솔직한 후기" loading="lazy">
                        <div>
                            <h4>스픽클 적극 추천해드려요</h4>
                            <p>필리핀 선생님께서 매우 친절히 지도해주셔서 아이도 거부감 없이 마음을 열어 수업에 집중할 수 있었어요. 원서를 읽다가 틀린 발음같은건 다시 잡아주시니 너무 좋네요. 딸이 계속 연장해서 하고싶다고 하여 쭉~ 수업 진행하려합니다</p>
                            <div class="writer">작성자 <span class="font5">ooo님</span></div>
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <img :src="require(`@/assets/img/review/swiper/4.webp`)" alt="솔직한 후기" loading="lazy">
                        <div>
                            <h4>수업방식이 아주 만족스러워요</h4>
                            <p>아이가 이해하기 쉽도록 그림에 대한 설명도 해주시고~ 막히는 부분은 충분히 기다려주시기도 하며 아이의 눈높이에 맞추어 수업을 진행해주셔요. 선생님과 영어로 대화하는게 신기하다고 말하는데 너무 뿌듯하네요</p>
                            <div class="writer">작성자 <span class="font5">ooo님</span></div>
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <img :src="require(`@/assets/img/review/swiper/5.webp`)" alt="솔직한 후기" loading="lazy">
                        <div>
                            <h4>초등화상영어 역시 스픽클!</h4>
                            <p>아이가 처음하는 영어에 대해 기가 죽을 수 있는데 선생님의 리액션이 너무 좋아요. 계속 용기를 북돋아주시고, cheer up 해줍니다. 그래서 아이가 기분좋게 수업을 할 수 있습니다.</p>
                            <div class="writer">작성자 <span class="font5">ooo님</span></div>
                        </div>
                    </swiper-slide>
                </swiper>
                <div class="swiper-button-prev" slot="button-prev"></div>
                <div class="swiper-button-next" slot="button-next"></div>
                <div class="swiper-pagination" slot="pagination"></div>
            </div>
        </section>
        <section id="review">
            <div>
                <h2>스픽클을 사용해본 분들의 <br v-if="common.width <= 1024">100% 솔직한 후기!</h2>
                <p>회원들이 직접 작성한 솔직한 학습 후기입니다.</p>
                <div class="table-wrapper">
                    <h4>전체 : 00건 <nuxt-link :to="'/login'" class="font3">글쓰기</nuxt-link></h4>
                    <table>
                        <thead>
                            <tr>
                                <th class="font4" v-if="!$device.isMobile">번호</th>
                                <th class="font4">제목</th>
                                <th class="font4">작성자</th>
                                <th class="font4" v-if="!$device.isMobile">작성일</th>
                                <th class="font4" v-if="!$device.isMobile">조회수</th>
                            </tr>
                        </thead>
                        <hr>
                        <tbody>
                            <tr v-for="(review, idx) in reviewList" :key="`review${idx}`" v-if="idx >= (12*(pagination-1)) && idx < (12*pagination) ">
                                <td class="font3" v-if="!$device.isMobile">{{(review.id).toString().padStart(4,'0')}}</td>
                                <td class="font3">{{review.title}}</td>
                                <td class="font3">{{review.reviewer}}</td>
                                <td class="font3" v-if="!$device.isMobile">{{review.date}}</td>
                                <td class="font3" v-if="!$device.isMobile">{{(review.views).toString().padStart(2,'0')}}</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="table-pagination">
                        <button @click="pagination=1" class="start-btn"></button>
                        <button @click="pagination==1 ?'':pagination--" class="prev-btn"></button>
                        <button v-for="i in Math.ceil(reviewList.length/12)" :key="`pagination btn ${i}`" @click="pagination = i" :class="{'active': pagination==i}">
                            {{i}}
                        </button>
                        <button @click="pagination==Math.ceil(reviewList.length/12)?'':pagination++" class="next-btn"></button>
                        <button @click="pagination=Math.ceil(reviewList.length/12)" class="fin-btn"></button>
                    </div>
                </div>
            </div>
        </section>
        <section id="banner">
            <div>
                <h2 class="font5">아직 고민중이신가요?<br>
                    그럼 가격까지 보고 결정하세요
                </h2>
                <nuxt-link :to="'/purchase'">가격 알아보기</nuxt-link>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        background-color: $baby-pink;
        height: 550px;
        >div{
            position: relative;
            .title{ 
                width: 340px;
                height: auto;
                div{
                    @include flex(space-between, center);
                    margin-bottom: -20px;
                }
                span{
                    font-size: 70px;
                    color: $pink;
                    font-family: "SCDream9";
                }
                h1{
                    line-height: 100px;
                    font-size: 64px;
                    font-family: "SCDream9";
                }
                p{
                    margin-top: 0;
                }
            }
            p{
                margin-top: 10px;
                color: $subText;
            }
            .title-img{
                margin: 0;
                right: 0;
                bottom: -170px;
                position: absolute;
                .phone{
                    margin-top: auto;
                    width: 400px;
                }
                .bubble{
                    position: absolute;
                    transform: scale(0);
                    transition: all 0.4s;
                    background-repeat: no-repeat;
                    background-size: contain;
                    width: 170px;
                    height: 160px;
                    padding-top: 28px;
                    @include flex(center, flex-start);
                    &.act{
                        transform: scale(1);
                    }
                    div{
                        @include flex(center, center, column);    
                        img{
                            width: 80px;
                        }                    
                    }
                    p{
                        font-size: 13px;
                        line-height: 18px;
                        text-align: center;
                    }
                }
                .bubble1{
                    left: -100px;
                    top: 35px;
                    transform-origin: bottom right;
                    background-image: url('@/assets/img/review/bubble1.webp');
                }
                .bubble2{
                    right: -125px;
                    top: 220px;
                    transform-origin: bottom left;
                    background-image: url('@/assets/img/review/bubble2.webp');
                    >img{
                        margin-right: 10px;
                    }
                }
            }
        }
    }
    #swiper{
        >div{
            .swiper-container{
                margin-top: 40px;
                max-width: 1000px;
                .swiper-wrapper{
                    padding-bottom: 20px;
                    .swiper-slide{
                        position: relative;
                        height: 480px;
                       img{
                           width: 100%;
                           margin-bottom: 10px;
                       }
                       >div{
                           h4{
                               font-size: 24px;
                           }
                           p{
                                font-size: 16px;
                                line-height: 24px;
                                margin-top: 20px;
                                color: $conText;
                           }
                           .writer{
                               font-size: 18px;
                               position: absolute;
                               bottom: 0;
                               right: 0;
                               span{
                                   font-size: 18px;
                               }
                           }
                       }
                    }
                }
            }
            .swiper-button-prev{
                left: -80px !important;
            }
            .swiper-button-next{
                right: -80px !important;
            }
            .swiper-button-prev, .swiper-button-next{
                color: $black !important;
            }
            .swiper-pagination{
                display: none;
            }
        }
    }
    #review{
        >div{
            .table-wrapper{
                margin-top: 40px;
                h4{
                    font-size: 18px;
                    position: relative;
                    a{
                        position: absolute;
                        font-size: 0.8em;
                        top: 0;
                        right: 0;
                        color: $pink;
                    }
                }
                table{
                    width: 100%;
                    margin-top: 20px;
                    border-top: 2px solid $pink;
                    border-bottom: 2px solid rgb(230, 230, 230);
                    thead{
                        tr{
                            th{
                                line-height: 34px;
                                font-size: 18px;
                                &:first-child{
                                    width: 70px;
                                }
                            }
                        }
                    }
                    tbody{
                        tr{
                            line-height: 34px;
                            cursor: pointer;
                            td{
                                font-family: "SCDream3";
                                text-align: center;
                                font-size: 18px;
                                line-height: 24px;
                                height: 30px;
                                &:first-child{
                                    width: 70px;
                                }
                                &:nth-child(2){
                                    width: 68%;
                                    text-align: left;
                                }
                                &:nth-child(3){
                                    width: 70px;
                                }
                                &:nth-child(4){
                                    width: 140px;
                                }
                                &:nth-child(5){
                                    width: 70px;
                                }
                            }
                        }

                    }
                    hr{
                        width: 100%;
                        position: absolute;
                    }
                }
                .table-pagination{
                     @include flex();
                    margin-top: 30px;
                    button{
                        background-color: $white;
                        border: 1px solid #d9d9d9;
                        width: 35px;
                        height: 35px;
                        margin: 0px;
                        color: #b4b4b4;
                        font-size: 16px;
                        &:hover{
                            border-color: #d9d9d9;
                        }
                        &.active{
                            color: rgb(109, 109, 109);
                            background-color: #d9d9d9;
                        }
                        &.prev-btn,
                        &.next-btn{
                            background-image: url('@/assets/img/review/arrow.png');
                            background-repeat: no-repeat;
                            background-position: center;
                            margin-right: 15px;
                        }
                        &.start-btn,
                        &.fin-btn{
                            background-image: url('@/assets/img/review/arrow-double.png');
                            background-repeat: no-repeat;
                            background-position: center;
                        }
                        &.next-btn{
                            transform: rotate(180deg);
                            margin-right: 0px;
                            margin-left: 15px;
                            border-left: none;
                        }
                        &.prev-btn{
                            border-left: none;
                        }
                        &.fin-btn{
                            transform: rotate(180deg);
                        }
                    }
                }
            }
        }
    }
    #banner{
        background-color: $pink-bg;
        background-image: url('@/assets/img/review/banner.webp');
        background-repeat: no-repeat;
        background-position: right 90%;
        height: 550px;
        >div{
            padding: 0;
            h2{
                color: $white;
                font-size: 40px;
                text-shadow: 1px 1px 7px #77777791;
            }
            a{
                background-color: $white;
                font-size: 20px;
                color: #e34887;
                padding: 15px 30px;
                border-radius: 10px;
                margin-top: 40px;
                display: inline-block;
                box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.4);
            }
        }
    }
}
@media screen and (max-width: 1024px){
#container{
    header{
        @include flex(flex-start,flex-start,column);
        height: 750px;
        >div{
            margin-bottom: 0;
            height: 100%;
            .title{
                margin-top: 80px;
            }
            .title-img{
                bottom: -70px;
                width: 310px;
                position: relative;
                margin: 0 auto;
                left: 0;
                .phone{
                    width: 280px;
                }
                .bubble1{
                    left: -165px;
                }
                .bubble2{
                    top: -40px;
                    right: -135px;
                }
            }
        }
    }
    #swiper{
        >div{
             h2{
                text-align: center;
            }
            .swiper-container{
                width: 100%;
                .swiper-wrapper{
                    .swiper-slide{
                        position: relative;
                        height: 490px;
                       >div{
                           h4{
                               font-size: 22px;
                           }
                           p{
                                font-size: 18px;
                                line-height: 26px;
                           }
                           .writer{
                               position: absolute;
                               bottom: 0;
                               right: 0;
                           }
                       }
                    }
                }
            }
            .swiper-button-prev, .swiper-button-next{
                display: none;
            }
            .swiper-pagination{
                display: block;
                width: 100%;
                margin-top: 10px;
            }
        }
    }
    #review{
        >div{
            h2,p{
                text-align: center;
            }
            .table-wrapper{
                h4{
                    font-size: 16px;
                }
                table{
                    thead{
                        tr{
                            th{
                                font-size: 16px;
                            }
                        }
                    }
                    tbody{
                        tr{
                            td{
                                font-size: 16px;
                                line-height: 22px;
                                &:nth-child(2){
                                    width: 55%;
                                }
                            }
                        }

                    }
                }
                .table-pagination{
                     @include flex();
                    margin-top: 30px;
                    button{
                        background-color: $white;
                        border: 1px solid #d9d9d9;
                        width: 35px;
                        height: 35px;
                        margin: 0px;
                        color: #b4b4b4;
                        &:hover{
                            border-color: #d9d9d9;
                        }
                        &.active{
                            color: rgb(109, 109, 109);
                            background-color: #d9d9d9;
                        }
                        &.prev-btn,
                        &.next-btn{
                            background-image: url('@/assets/img/review/arrow.png');
                            background-repeat: no-repeat;
                            background-position: center;
                            margin-right: 15px;
                        }
                        &.start-btn,
                        &.fin-btn{
                            background-image: url('@/assets/img/review/arrow-double.png');
                            background-repeat: no-repeat;
                            background-position: center;
                        }
                        &.next-btn{
                            transform: rotate(180deg);
                            margin-right: 0px;
                            margin-left: 15px;
                            border-left: none;
                        }
                        &.prev-btn{
                            border-left: none;
                        }
                        &.fin-btn{
                            transform: rotate(180deg);
                        }
                    }
                }
            }
        }
    }
    #banner{
        background-position: -380% 20%;
        height: 460px;
    }

}
}
@media screen and (max-width: 767px){
#container{
    header{
        >div{
            .title{
                margin-top: 40px;
                width:255px;
                span{
                    font-size: 52px;
                }
                h1{
                    font-size: 52px;
                    margin-bottom: 0;
                }
            }
            p{
                margin-top: 0;
            }
            .title-img{
                bottom: -95px;
                width: 100%;
                @include flex();
                .phone{
                    width: 280px;
                    margin: 0 auto;
                }
                .bubble{
                    padding-top: 10px;
                    >img{
                        display: none;
                    }
                    div{
                        p{
                            line-height: 16px;
                        }
                        img{
                            width: 70px;
                            margin-bottom: 5px;
                        }
                    }
                }
                .bubble1{
                    left: -10px;
                    width: 130px;
                    top: -5px;
                }
                .bubble2{
                    top: -70px;
                    right: -10px;
                    width: 130px;
                }
            }

        }
    }
    #swiper{
        >div{
            .swiper-container{
                width: 100%;
                .swiper-wrapper{
                    .swiper-slide{
                        background-color: $white;
                        border-radius: 20px;
                        overflow: hidden;
                        height: 480px;
                        >div{
                            h4, p, .writer{
                                text-align: center;
                                word-break: break-all;
                            }
                            h4{
                                margin-top: 5px;
                                font-size: 22px;
                            }
                            p{
                                padding: 0 12px;
                                margin-top: 10px;
                                font-size: 16px;
                                line-height: 24px;
                            }
                            .writer{
                                left: 0;
                                bottom: 10px;
                            }
                        }
                    }
                }
            }
        }
    }
    #review{
        >div{
            .table-wrapper{
                table{
                    thead{
                        tr{
                            th{
                                font-size: 14px;
                            }
                        }
                    }
                    tbody{
                        tr{
                            td{
                                font-size: 14px;
                                line-height: 20px;
                                height: 26px;
                                max-height: 26px;
                                &:nth-child(1){
                                    width: 80%;
                                    text-align: left;
                                }
                                &:nth-child(2){
                                    width: 20%;
                                    text-align: center;
                                }
                        }
                        }
    
                    }
                }
            }

        }
    }
    #banner{
        background-position: 100px bottom;
        height: 510px;
        background-size: 145%;
        margin-top: 70px;
        >div{
            margin: 70px auto auto;
        }

    }



}
}
</style>

<script>
export default {
    name: 'review',
    layout: 'default',
    data(){
        return{
            pagination: 1,
            swiperOption: { 
                slidesPerView: 1.1,
                spaceBetween: 15, 
                loop: true, 
                autoplay: { 
                    delay: 4000, 
                    disableOnInteraction: false 
                },
                pagination: { 
                    el: '.swiper-pagination', 
                    clickable: true 
                }, 
                navigation: { 
                    nextEl: '.swiper-button-next', 
                    prevEl: '.swiper-button-prev' 
                } ,
                breakpoints: {
                    1025: {
                        slidesPerView: 3,
                        spaceBetween: 25,
                    },
                    768:{
                        spaceBetween: 25,
                        slidesPerView: 2,
                    }
                },
            },
            reviewList: [
                {
                    id: 0,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 5
                },
                {
                    id: 1,
                    title: '화상영어 처음인데 잘 선택한것 같아서 만족이네요~',
                    reviewer: '작성자',
                    date: '2022.03.02',
                    views: 1
                },
                {
                    id: 2,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.04',
                    views: 8
                },
                {
                    id: 0,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 2
                },
                {
                    id: 3,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.07.01',
                    views: 73
                },
                {
                    id: 4,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2322.23.01',
                    views: 13
                },
                {
                    id: 5,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 32
                },
                {
                    id: 6,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 54
                },
                {
                    id: 7,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 23
                },
                {
                    id: 8,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 7
                },
                {
                    id: 9,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 4
                },
                {
                    id: 10,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 1
                },
                {
                    id: 11,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 12
                },
                {
                    id: 12,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 13
                },
                {
                    id: 13,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 19
                },
                {
                    id: 14,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 15
                },
                {
                    id: 15,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 31
                },
                {
                    id: 16,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 31
                },
                {
                    id: 17,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 12
                },
                {
                    id: 18,
                    title: 'title',
                    reviewer: '작성자',
                    date: '2022.03.01',
                    views: 34
                },
            ],
            common:[],
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.motion();
    },
    filters:{

    },
    methods:{
        motion(){
            this.addAct('.bubble')
        },
        addAct(element){
            var ele = this.$el.querySelectorAll(element);
            
            ele.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 200*idx);
            });
        },
    
    },
}

</script>
