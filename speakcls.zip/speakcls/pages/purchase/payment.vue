<template>
    <div id="container">
        <section id="payment">
            <div>
                <h1>결제하기</h1>

                <div class="product-wrapper" :class="{open: open.prod}">
                    <div class="title">
                        <h4>주문상품</h4>
                        <button @click="open.prod = !open.prod"></button>
                    </div>
                    <div class="contents">
                        <table>
                            <tbody>
                                <tr>
                                    <td>상품명</td>
                                    <td class="pink">주니어과정 {{prodData.course}} {{prodData.timeZone}} {{prodData.classTime}} {{prodData.numberOfClasses}}</td>
                                </tr>
                                <tr>
                                    <td>수업타입</td>
                                    <td>{{prodData.classTime}} 수업</td>
                                </tr>
                                <tr>
                                    <td>수업일</td>
                                    <td>{{prodData.numberOfClasses | numberOfClasses}} ({{prodData.numberOfClasses}})</td>
                                </tr>
                                <tr>
                                    <td>수업시간</td>
                                    <td>{{prodData.timeZone}} ({{prodData.timeZone | timeZone}})</td>
                                </tr>
                                <tr>
                                    <td>수업기간</td>
                                    <td>{{prodData.month}}개월 (총 20회 수업)<br>
                                        2022.04.01 ~ 2022.05.22<br>
                                        <span class="font3">- 수강 상태와 학사일정에 따라 기간이 조정될 수 있습니다.</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="point-wrapper" :class="{open: open.point}">
                    <div class="title">
                        <h4>적립금</h4>
                        <button @click="open.point=!open.point"></button>
                    </div>
                    <div class="contents">
                        <div><p>적립금</p> <p class="font3"><span class="font6">총 {{String(point.have) | comma}}</span>원 보유</p></div>
                        <div>
                            <div>
                                <input type="text" placeholder="0" v-model="point.use"  dir="rtl" @focusout="pointInputEvent">  
                                <span>원</span>
                                <button class="font3" @click="point.use = point.have">최대사용</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="coupon-wrapper" :class="{open: open.coupon}">
                    <div class="title">
                        <h4>할인쿠폰</h4>
                        <button @click="open.coupon=!open.coupon"></button>
                    </div>
                    <div class="contents">
                        <div><p>할인쿠폰</p> <p class="font3"><span class="font6">총 0</span>개 보유</p></div>
                        <div>
                            <input type="text" placeholder="할인쿠폰을 직접 등록해주세요." readonly @click="selectCoupon=true" class="select" v-model="coupon">
                            <div class="coupon-list" v-if="selectCoupon">
                                <ul>
                                    <li @click="selectCoupon=false; coupon=cp" v-for="(cp, idx) in couponList" :key="`coupon${idx}`">{{cp}}</li>
                                </ul>
                            </div>
                            <div><input type="text" placeholder="할인쿠폰코드" v-model="addCoupon"> <button @click="addCouponEvent" class="font3">등록</button></div>
                        </div>
                        <ul>
                            <li class="font3">할인쿠폰은 적립금이 적용된 결제금액에 적용됩니다.</li>
                            <li class="font3">할인쿠폰이 금액인 경우, 일부금액 사용은 불가하며 쿠폰금액이 결제금액보다 크면 남은 금액은 반환되지 않습니다.</li>
                            <li class="font3">할인쿠폰은 중복 사용이 불가합니다.</li>
                        </ul>
                    </div>
                </div>
                <div class="amount-wrapper" :class="{open: open.amount}">
                    <div class="title">
                        <h4>결제 금액</h4>
                        <button @click="open.amount=!open.amount"></button>
                    </div>
                    <div class="contents">
                        <table>
                            <tbody>
                                <tr>
                                    <td class="font4">할인쿠폰</td>
                                    <td class="font4">90,000원</td>
                                </tr>
                                <tr>
                                    <td class="font4">최종 결제금액</td>
                                    <td class="font4"><span class="pink">{{String(prodData.price) | comma}}원</span>
                                        <span>총 {{String(prodData.price) | comma}}원</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="method-wrapper" :class="{open: open.method}">
                    <div class="title">
                        <h4>결제 수단</h4>
                        <button @click="open.method=!open.method"></button>
                    </div>
                    <div class="contents">
                        <div>
                            <button :class="{act: (method=='card')}" @click="method='card'">신용/체크카드</button>
                            <button :class="{act: (method=='npay')}" @click="method='npay'"> <img :src="require('@/assets/img/purchase/npay.png')" alt="네이버페이 로고" loading="lazy">Pay</button>
                            <button :class="{act: (method=='account')}" @click="method='account'">실시간 계좌이체</button>
                        </div>
                        <nuxt-link :to="'/'" class="font3">최대 12개월 무이자 할부 안내 <img :src="require('@/assets/img/down-arrow.png')" alt="더보기" loading="lazy"></nuxt-link>
                    </div>
                </div>
                <div class="guide-wrapper" :class="{open: open.guide}">
                    <div class="title">
                        <h4>꼭 알아두세요</h4>
                        <button @click="open.guide=!open.guide"></button>
                    </div>
                    <div class="contents">
                        <ul>
                            <li class="font3">- 스픽클 수업은 강사님과 만나 1:1 수업이 진행됩니다.</li>
                            <li class="font3">- 수업시간은 선택한 수업시간 내에서 설정되며 결제 후 1일 1회에 한하여 변경할 수 있습니다.</li>
                            <li class="font3">- 수업시간은 주 단위를 기본으로 하며 1주 당 수업일에 따른 수업 횟수를 보장해드립니다. 예를 들어 센터 휴일로 인해 정규수업이 진행되지 않을 경우 상품에 포함된 수업 횟수를 모두 마칠 수 있는 기간으로 재설정됩니다.</li>
                            <li class="font3">- 상품환불 시 최종 결제된 금액에서 경과한 수업 횟수의 정가 금액을 차감하고 환불됩니다. 경과한 수업 횟수는 출석, 결석, 취소한 수업을 포함하며 자세한 환불 규정은 서비스 이용약관을 확인해주세요.</li>
                        </ul>
                    </div>
                </div>
                <div class="button">
                    <button @click="payment">결제하기<br>
                        <span class="font3">{{prodData.month}}개월 | 총 {{String(prodData.price) | comma}}원</span>
                    </button>
                </div>
            </div>

        </section>
        <div class="messagePopup" v-if="messagePopup.open">
            <div>
                <div>
                    {{messagePopup.message}}
                </div>
                <div>
                    <button @click="messagePopup.open = false">확인</button>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
#container{
    #payment{
        >div{
            justify-content: flex-start;
            h1{
                text-align: left;
                width: 100%;
            }
            >div{
                width: 100%;
                .title{
                    width: 100%;
                    height: 50px;
                    border-bottom: 2px solid $black;
                    @include flex(space-between);
                    h4{
                        font-size: 26px;
                        font-family: "SCDream4";
                    }
                    button{
                        width: 40px;
                        height: 30px;
                        background: url('@/assets/img/down-arrow.png') no-repeat center;
                        background-size: 20px;
                        margin: 0;
                    }
                }
                .contents{
                    margin: 30px 0 40px;
                    max-height: 0px;
                    overflow: hidden;
                }
                &.open{
                    .title{
                        button{
                            transform: rotate(180deg);
                        }
                    }
                    .contents{
                        max-height: 500px;
                    }
                }
            }
       
        }
        .product-wrapper{
            .contents{
                table{
                    tr{
                        vertical-align: top;
                        height: 50px;
                        font-size: 20px;
                        td:first-child{
                            width: 110px;
                            line-height: 30px;
                            color: #606060;
                            font-family: "SCDream4";
                        }
                        td:last-child{
                            font-family: "SCDream4";
                            line-height: 30px;
                            &.pink{
                                color: $pink;
                            }
                            span{
                                display: inline-block;
                                margin-top: 10px;
                                font-size: 16px;
                                color: $grayOnGray;
                            }
                        }
                    }
                }
            }

        }
        .point-wrapper{
            .contents{
                div{
                    position: relative;
                    input{
                        padding-right: 40px;
                    }
                    input+span{
                        position: absolute;
                        top: 17px;
                        right: 150px;
                    
                    }
                }
            }
        }
        .point-wrapper,
        .coupon-wrapper{
            .contents{
                >div{
                    width: 100%;
                    @include flex(space-between);
                    margin-bottom: 15px;
                    p{
                        font-size: 20px;
                        &:last-child{
                            font-size: 18px;
                            span{
                                font-size: 1em;
                            }
                        }
                    }
                    &:nth-child(2){
                        @include flex(space-between, center, column);
                        div{
                            width: 100%;
                            @include flex(flex-start, flex-start);
                        }
                    }
                }
                input{
                    position: relative;
                    &.select{
                        cursor: pointer;
                        background-image: url('@/assets/img/down-arrow.png') ;
                        background-repeat: no-repeat;
                        background-position: 97%;
                        background-size: 16px;
                    }
                }
                input::placeholder{
                    color: $gray;
                }
                button{
                    background-color: $black;
                    color: $white;
                    width: 35%;
                    height: 55px;
                    line-height: 55px;
                    margin: 0 0 0 15px;
                    border-radius: 5px;
                    font-size: 18px;
                }
                >ul{
                    width: 420px;
                    li{
                        color: $grayOnGray;
                        font-size: 16px;
                        line-height: 24px;
                        margin-bottom: 5px;
                        padding-left: 13px;
                        position: relative;
                        &::before{
                            content: '- ';
                            position: absolute;
                            left: 0;
                        }
                    }
                }
                .coupon-list{
                    position: absolute;
                    z-index: 1;
                    flex-direction: column;
                    background-color: $white;
                    border-radius: 10px;
                    padding: 10px 10px 10px 0;
                    width: 100%;
                    max-width: 540px;
                    box-shadow: 0px 2px 4px rgb(51 51 51 / 40%);
                    ul{
                        padding: 0 10px;
                        max-height: 210px;
                        overflow-y: scroll;
                        width: 100%;
                        li{
                            border-radius: 5px;
                            padding: 5px 25px;
                            color: #707070;
                            cursor: pointer;
                            &:hover{
                                background-color:#707070 ;
                                color: $white;
                                &::before{
                                    content: '✔';
                                    position: absolute;
                                    left: 18px;
                                }
                            }
                        }
                    }
                }
            }
        }
        .amount-wrapper{
            .contents{
                table{
                    width: 100%;
                    border-collapse : collapse;
                    tr{
                        height: 40px;
                        td{
                            vertical-align: top;
                            padding-bottom: 15px;
                            font-size: 20px;
                        }
                        td:last-child{
                            text-align: right;
                        }
                        &:last-child{
                            border-top: 1px solid $black;
                            td{
                                padding-top: 15px;

                            }
                            td:last-child{
                                span{
                                    display: block;
                                    font-weight: 400;
                                    font-size: 16px;
                                }
                                span.pink{
                                    color: $pink;
                                    font-size: 22px;
                                    margin-bottom: 8px;
                                }
                            }

                        }
                    }
                }
            }
        }
        .method-wrapper{
            .contents{
                div{
                    @include flex(space-between);
                    button{
                        @include flex();
                        border: 1px solid $grayOnGray;
                        width: 31%;
                        height: 80px;
                        border-radius: 5px;
                        line-height: 30px;
                        font-size: 20px;
                        margin-top: 0;
                        img{
                            margin-right: 10px;
                        }
                        &.act{
                            border: 2px solid $pink;
                        }
                    }
                }
                a{
                    display: block;
                    margin-top: 20px;
                    @include flex(flex-start);
                    font-size: 16px;
                    img{
                        width: 15px;
                        margin-left: 5px;
                        transform: rotate(-90deg);
                    }
                }
            }
        }
        .guide-wrapper{
            .title h4{
                font-size: 20px;
            }
            ul{
                li{
                    color: $grayOnGray;
                    margin-bottom: 10px;
                    font-size: 16px;
                }
            }
        }
        .button{
            margin-bottom: 50px;
            button{
                width: 100%;
                height: 100px;
                color: $white;
                font-size: 24px;
                border-radius: 10px;
                padding: 20px 0;
                line-height: 24px;
                margin: 0;
                background: linear-gradient(to left, #ec2d8a, #6f4fe1);
                span{
                    color: $white;
                    font-size: 16px;
                    letter-spacing: -0.5px;
                }
            }
        }
    }
    .messagePopup{
        position:fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: #0000005d;
        z-index: 99999;
        @include flex();
        >div{
            background-color: $white;
            width: 350px;
            height: 180px;
            border-radius: 10px;
            text-align: center;
            @include flex(center, center, column);
            padding: 0 15px;
            >div{
                font-size: 20px;
                margin-top: 20px;
                button{
                    background-color: $pink;
                    color: $white;
                    padding: 10px 20px;
                    border-radius: 10px;
                    font-size: 18px;
                }
            }
        }

    }
}
@media screen and (max-width: 767px){
#container{
    #payment {
        >div{
            >div{
                .title{
                    border-bottom: 1px solid #747474;
                    h4{
                        font-size: 24px;
                    }
                }
                .contents{
                    padding: 30px 0;
                    margin: 0;
                }
            }
        }
        .product-wrapper{
            .contents{
                table{
                    tr{
                        td{
                            font-size: 18px;
                            line-height: 26px;
                            &:first-child{
                                width: 90px;
                            }
                            &:last-child{
                                font-size: 16px;
                                line-height: 22px;
                            }
                        }
                    }
                }
            }
        }
        .point-wrapper{
            .title{
                div{
                    font-size: 16px;
                }
            }
        }
        .coupon-wrapper{
            .contents{
                >div{
                    p:last-child{
                        font-size: 16px;
                    }
                }
                button{
                    margin-left: 10px;
                    font-size: 16px;
                }
            }
        }
        .amount-wrapper{
            .contents{
                table{
                    tr{
                        td{
                            font-size: 18px;
                            .pink{
                                margin-bottom: 10px;
                            }
                        }
                    }
                }
            }
        }
        .method-wrapper{
            .contents{
                div{
                    button{
                        width: auto;
                        height: 60px;
                        font-size: 16px;
                        line-height: 24px;
                        padding: 0 10px;
                        img{
                            margin-right: 5px;
                            width: 25px;
                            height: 25px;
                        }
                    }
                }
            }
        }
    }   
}
}
</style>

<script>
export default {
    name: 'payment',
    layout: 'form',
    data(){
        return{
            prodData: '',
            point: {have: 1000, use: null},
            coupon: null,
            addCoupon: null,
            selectCoupon: false,
            method: null,
            open:{
                prod: true,
                point: true,
                coupon: true,
                amount: true,
                method: true,
                guide: true,
            },
            couponList: [
                '할인쿠폰을 직접 등록해주세요.'
            ],
            messagePopup:{
                open: false,
                message: null
            },
            common:[],
            today: null
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
        
    },
    mounted(){
        this.getParams();
    },
    filters:{
        numberOfClasses(v){
            if(v=='주2회') return v = '화,목'
            if(v=='주3회') return v = '월,수,금'
            if(v=='주5회') return v = '월,화,수,목,금'
        },
        timeZone(v){
            if(v=='열공타임') return v = '18:00~22:55'
            if(v=='실속타임') return v = '14:00~17:30'
        },
        comma(v){
            return v = v.replace(/[^0-9]/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        }
    },
    methods:{
        getDate(){
          var today = new Date(),
                year = today.getFullYear(),
                month = ('0' + (today.getMonth() + 1)).slice(-2),
                day = ('0' + today.getDate()).slice(-2);

            this.today =  year + '.' + month  + '.' + day;
        },
        getParams(){
            var data = this.$route.query;
            this.prodData = data;
        },
        pointInputEvent(){
            if(this.point.use > this.point.have) this.point.use = this.point.have;
            this.prodData.price = this.prodData.price - this.point.use;
        },
        addCouponEvent(){
            if(this.addCoupon == null || String(this.addCoupon).length < 1){
                return this.messagePopupEvent('쿠폰 번호를 정확히 입력해주세요.')
            } else{
                 this.messagePopupEvent(`${this.addCoupon} 쿠폰을 등록했습니다.`)
                this.couponList.push(this.addCoupon)
                this.addCoupon = null
            }
        },
        messagePopupEvent(msg){
            this.messagePopup.open = true;
            this.messagePopup.message = msg;
        },
        // async payment(){
        //     this.prodData.regDay = this.today;
        //     this.$router.go().push({ path: '/' });
            
        //     await this.$axios.post('/api/add/class', this.prodData)
        //     .then( (response) => {
        //     })
        //     .catch( (error) => {
        //         console.log(error);
        //     });
        // }
        payment(){
            var clientKey = 'test_ck_D5GePWvyJnrK0W0k6q8gLzN97Eoq'
            var tossPayments = TossPayments(clientKey)

            tossPayments.requestPayment('카드', {
                amount: String(this.prodData.price) ,
                orderId: '6n3nO958BEfuFW2brAdHz',
                orderName: `주니어과정 ${this.prodData.course} ${this.prodData.timeZone} ${this.prodData.classTime} ${this.prodData.numberOfClasses}`,
                customerName: '스픽클',
                successUrl: 'http://localhost:8080/success',
                failUrl: 'http://localhost:8080/fail',
            })
            
        }
    }

}

</script>
