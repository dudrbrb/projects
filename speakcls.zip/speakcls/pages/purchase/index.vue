<template>
    <div id="container">
        <header>
            <div>
                <h1>첫 수강 회원님을 위해 준비했습니다!</h1>
                <p>첫 수강이니까 10만원 할인 쿠폰을 드려요!</p>
                <nuxt-link :to="'/'">할인 쿠폰 받기</nuxt-link>
                <img :src="require('@/assets/img/purchase/icon.png')" alt="스픽클아이콘"  loading="lazy">
            </div>
        </header>
        <section id="recommend">
            <div>
                <div class="reco-title">
                    <h2>수강권 추천</h2>
                    <nuxt-link to="/">수강권 추천 받기</nuxt-link>
                </div>
                <div class="reco-wrapper">
                    <div class="reco-bg">
                        <div class="reco-box">
                            <h4>북토킹 24회</h4>
                            <p class="cancle font5">334,000원</p>
                            <div class="price-box">
                                <p class="price font6">234,000원 <span class="font5">(월 78,000원)</span></p>
                                <div class="discount font3"><span class="font5">30% 할인</span>25분/3개월</div>
                            </div>
                            <div class="set">
                                AI학습 + 원서 + 화상수업
                            </div>
                            <div class="benefit">
                                <p class="font5">추가혜택</p>
                                <ul>
                                    <li>SR테스트 1회 이용권</li>
                                    <li>웅진빅박스 3개월 이용권</li>
                                    <li>화상수업 25분</li>
                                    <li></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="reco-bg">
                        <div class="reco-box">
                            <h4>북토킹 36회</h4>
                            <p class="cancle font5">364,000원</p>
                            <div class="price-box">
                                <p class="price font6">264,000원 <span class="font5">(월 88,000원)</span></p>
                                <div class="discount font3"><span class="font5">28% 할인</span>25분/3개월</div>
                            </div>
                            <div class="set">
                                AI학습 + 원서 + 화상수업
                            </div>
                            <div class="benefit">
                                <p class="font5">추가혜택</p>
                                <ul>
                                    <li>SR테스트 1회 이용권</li>
                                    <li>웅진빅박스 3개월 이용권</li>
                                    <li>화상수업 25분</li>
                                    <li>교재 제공</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="reco-bg">
                        <div class="reco-box">
                            <h4>북토킹 60회</h4>
                            <p class="cancle font5">394,000원</p>
                            <div class="price-box">
                                <p class="price font6">294,000원 <span class="font5">(월 98,000원)</span></p>
                                <div class="discount font3"><span class="font5">25% 할인</span>25분/3개월</div>
                            </div>
                            <div class="set">
                                AI학습 + 원서 + 화상수업
                            </div>
                            <div class="benefit">
                                <p class="font5">추가혜택</p>
                                <ul>
                                    <li>SR테스트 1회 이용권</li>
                                    <li>웅진빅박스 3개월 이용권</li>
                                    <li>화상수업 25분</li>
                                    <li>교제 2권 제공</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="Application" class="bg-light">
            <div>
                <h2>수강권 신청</h2>
                <div class="prod-wrapper">
                    <table>
                        <tbody>
                            <tr>
                                <th>수업 과정</th>
                                <td>
                                    <input type="radio" name="수업과정" id="북토킹"  v-model="prodSelect.course" value="북토킹">
                                    <label for="북토킹">북토킹(원서스피킹 수업)</label>
                                    
                                    <input type="radio" name="수업과정" id="모든과정" v-model="prodSelect.course" value="모든과정">
                                    <label for="모든과정">모든 과정(코스북, 쉐도잉)</label>
                                </td>
                            </tr>
                            <tr>
                                <th>시간대</th>
                                <td>
                                    <input type="radio" name="시간대" id="실속타임" v-model="prodSelect.timeZone" value="실속타임">
                                    <label for="실속타임">실속타임(14 ~ 17시 30분)</label>
                                    
                                    <input type="radio" name="시간대" id="열공타임" v-model="prodSelect.timeZone" value="열공타임">
                                    <label for="열공타임">열공타임(18 ~ 22시 55분)</label>
                             
                                </td>
                            </tr>
                            <tr>
                                <th>수업 시간</th>
                                <td>
                                    <input type="radio" name="수업시간" id="25분" v-model="prodSelect.classTime" value="25분">
                                    <label for="25분">25분</label>
                                    
                                    <input type="radio" name="수업시간" id="50분" v-model="prodSelect.classTime" value="50분">
                                    <label for="50분">50분</label>
                                </td>
                            </tr>
                            <tr>
                                <th>수업 횟수</th>
                                <td>
                                    <input type="radio" name="수업횟수" id="주2회" v-model="prodSelect.numberOfClasses" value="주2회">
                                    <label for="주2회">주 2회 (화,목)</label>

                                    <input type="radio" name="수업횟수" id="주3회" v-model="prodSelect.numberOfClasses" value="주3회">
                                    <label for="주3회">주 3회 (월,수,금)</label>

                                    <input type="radio" name="수업횟수" id="주5회" v-model="prodSelect.numberOfClasses" value="주5회">
                                    <label for="주5회">주 5회 (월,화,수,목,금)</label>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="prod-select">
                        <div class="prod-box" v-for="(prod, idx) in prodList" :key="`prod${idx}`">
                            <h5 class="font5">{{prod.month}}개월</h5>
                            <span>{{prod.discount}}% <span>할인</span></span>
                            <div>
                                <p class="cancle">{{String(prod.originPrice)|comma}}원</p>
                                <p class="font6">{{String(prod.price)|comma}}원</p>
                            </div>

                            <nuxt-link :to="{path: '/purchase/payment', query:{course: prodSelect.course, timeZone: prodSelect.timeZone, classTime: prodSelect.classTime, numberOfClasses: prodSelect.numberOfClasses, price: prod.price, month: prod.month}}">
                                신청하기
                                <span>{{prod.month}}개월 | 총 {{String(prod.price)|comma}}원</span>
                            </nuxt-link>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        height: 700px;
        background: url('@/assets/img/purchase/bg.gif') no-repeat center;
        background-size: cover;
        >div{
            @include flex(center, center, column);
            p{
                margin-top: 8px;
            }
            a{
                font-size: 20px;
                background-color: $pink;
                color: $white;
                padding: 10px 25px;
                border-radius: 30px;
                margin: 30px 0 50px;
            }
            img{
                width: 60%;
            }
        }
    }
    #recommend{
        >div{
            .reco-title{
                width: 100%;
                @include flex(space-between);
                border-bottom: 1px solid rgb(220, 220, 220);
                padding-bottom: 10px;
                margin-bottom: 40px;
                a{
                    width: 145px;
                    font-size: 18px;
                    background: url('@/assets/img/arrow.png') no-repeat right center;
                    background-size: 10px;
                }
            }
            .reco-wrapper{
                @include flex(space-between, flex-start);
                width: 100%;
                .reco-bg{
                    width: 31.2%;
                    border-radius: 20px;
                    position: relative;
                    padding-top: 25px;
                    box-shadow: 3px 3px 8px rgba(63, 63, 63, 0.3);
                    &:first-child{
                        background-color: #fbb300;
                        h4{
                            color: #fbb300;
                        }
                        .benefit li{
                            color: #fbb300;
                            background-color: #fffbf2;
                            &::before{
                                content: url('@/assets/img/purchase/file-y.png');
                            }
                            &:last-child{
                                background: none;
                                &::before{
                                    content: '';
                                }
                            }
                        }
                    }
                    &:nth-child(2){
                        background-color: #e80b73;
                        h4{
                            color: #e80b73;
                        }
                        .benefit li{
                            color: #e80b73;
                            background-color: #fff7fb;
                            &::before{
                                content: url('@/assets/img/purchase/file-p.png');
                            }
                        }
                    }
                    &:nth-child(3){
                        background-color: #8773cf;
                        h4{
                            color: #8773cf;
                        }
                        .benefit li{
                            color: #8773cf;
                            background-color: #f9f7fd;
                            &::before{
                                content: url('@/assets/img/purchase/file-b.png');
                            }
                        }
                    }
                    .reco-box{
                        background-color: $white;
                        // position: absolute;
                        width: 100%;
                        border-radius: 20px;
                        padding: 20px;
                        box-shadow: 0px -3px 5px rgba(130, 130, 130, 0.2);
                        @include flex(center, flex-start, column);
                        h4{
                            font-size: 32px;
                            margin-bottom: 20px;
                        }
                        span{
                            display: block;
                        }
                        .cancle{
                            position: relative;
                             &:after{
                                content: "";
                                width: 110%;
                                height: 3px;
                                position: absolute;
                                background-color: #e90b73;
                                left: -4px;
                                top: 15px;
                            }
                        }
                        .price-box{
                            @include flex(flex-start);
                            .price{
                                color: $pink;
                                margin-right: 5px;
                                span{
                                    font-size: 18px;
                                    color: $pink;
                                    text-align: center;
                                }
                            }
                            .discount{
                                font-size: 13px;
                                text-align: center;
                                span{
                                    background-color: $pink;
                                    color: $white;
                                    font-size: 14px;
                                    padding: 0 12px;
                                    border-radius: 20px;
                                    margin-bottom: 5px;
                                }
                            }
                        }
                        .set{
                            margin: 20px 0 10px;
                            font-size: 18px;
                            width: 100%;
                            padding: 20px 0;
                            border-top: 1px solid rgb(220, 220, 220);
                            border-bottom: 1px solid rgb(220, 220, 220);
                        }
                        .benefit{
                            width: 100%;
                            p{
                                width: 75px;
                                font-size: 15px;
                                color: rgb(131, 131, 131);
                                margin-bottom: 10px;
                                background: url('@/assets/img/down-arrow.png') no-repeat right center;
                                background-size: 15px;
                            }
                            ul{
                                width: 100%;
                                li{
                                    width: 100%;
                                    height: 40px;
                                    font-size: 16px;
                                    border-radius: 13px;
                                    padding-left: 10px;
                                    @include flex(flex-start);
                                    &+li{
                                        margin-top: 4px;
                                    }
                                    &::before{
                                        margin-right: 10px;
                                        margin-bottom: -4px;
                                    }
                                   
                                }
                            }
                        }
                        
                    }
                }
            }
        }
    }
    #Application{
        >div{
            .prod-wrapper{
                width: 100%;
                margin-top: 30px;
                table{
                    width: 100%;
                    border-collapse : collapse;
                    tr{
                        border-top: 1px solid rgb(220, 220, 220);
                        height: 70px;
                        &:last-child{
                            border-bottom:  1px solid rgb(220, 220, 220);
                        }
                        th{
                            font-size: 22px;
                            text-align: left;
                            width: 20%;
                        }
                        td{
                            input{
                                width: 1px;
                                height: 1px;
                                opacity: 0;
                            }
                            label{
                                font-size: 18px;
                                font-family: "SCDream4";
                                border: 2px solid #f5f5fb;
                                padding: 3px 18px;
                                border-radius: 20px;
                            }
                            input[type=radio]:checked+label{
                                font-family: "SCDream5";
                                color: $pink;
                                border-color: $pink;
                            }
                        }
                    }
                }
                .prod-select{
                    @include flex(space-between);
                    margin: 60px 0 0;
                    .prod-box{
                        width: 32%;
                        background-color: $white;
                        border: 1px solid rgb(220, 220, 220);
                        border-radius: 20px;
                        text-align: center;
                        padding: 35px 20px;
                        @include flex(center, center, column);
                        cursor: default;
                        position: relative;
                        overflow: hidden;
                        h5{
                            font-size: 34px;
                        }
                        span{
                            font-size: 15px;
                            background-color: $pink;
                            color: $white;
                            padding: 2px 15px;
                            border-radius: 20px;
                            margin: 10px 0 40px;
                            span{
                                margin: 0;
                                padding: 0;
                            }

                        }
                        .cancle{
                            font-size: 16px;
                            position: relative;
                            display: inline-block;
                            &:after{
                                content: "";
                                width: 110%;
                                height: 3px;
                                position: absolute;
                                background-color: #e90b73;
                                left: -4px;
                                top: 14px;
                            }
                        }
                        a{
                            position: absolute;
                            width: 85%;
                            background: linear-gradient(to left, #ec2d8a, #6f4fe1);
                            font-size: 22px;
                            color: $white;
                            border-radius: 10px;
                            padding: 20px 0;
                            bottom: 20px;
                            transition: all 0.3s;
                            transform: translateY(130px);
                            span{
                                background: none;
                                display: block;
                                font-size: 16px;
                                margin: 0;
                            }
                        }
                        &:hover{
                            a{
                                transform: translateY(0px);

                            }
                        }
                    }
                }
            }
        }
    }
}
@media screen and (max-width: 960px){
 #container{
     #recommend{
            >div{
                .reco-wrapper{
                    .reco-bg{
                        width: 32%;
                        padding-top: 15px;
                        .reco-box{
                            padding: 15px 10px;
                            h4{
                                font-size: 26px;
                                margin-bottom: 10px;
                            }
                            .cancle{
                                 &:after{
                                    top: 11px;
                                }
                            }
                            .price-box{
                                width: 100%;
                                .price{
                                    margin-right: 10px;
                                    font-size: 20px;
                                    p{
                                        font-size: 18px;
                                        line-height: 24px;
                                    }
                                    span{
                                        font-size: 15px;
                                    }
                                }
                                .discount{
                                    font-size: 14px;
                                    span{
                                        font-size: 14px;
                                        padding: 2px 12px;
                                        margin-bottom: 3px;
                                    }
                                }
                            }
                            .set{
                                font-size: 16px;
                                text-align: center;
                            }
                            .benefit{
                                p{
                                    width: 80px;
                                    font-size: 16px;
                                }
                                ul{
                                    li{
                                        height: 35px;
                                        font-size: 14px;
                                    }
                                }
                            }
                            
                        }
                    }
                }
            }
        }
        #Application{
            >div{
                .prod-wrapper{
                    table{
                        tr{
                            height: 70px;
                            th{
                                width: 18%;
                            }
                        }
                    }
                    .prod-select{
                        .prod-box{
                            h5{
                                font-size: 30px;
                            }
                            span{
                                font-size: 16px;
                                padding: 3px 15px;
                                margin: 8px 0 25px;
                            }
                            .cancle{
                                line-height: 24px;
                                &:after{
                                    top: 10px;
                                }
                            }
                            a{
                                width: 90%;
                                font-size: 20px;
                                padding: 15px 0 10px;
                                span{
                                    font-size: 16px;
                                }
                            }
                            &:hover{
                                a{
                                    transform: translateY(0px);

                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
 }
@media screen and (max-width: 767px){
 #container{
    header{
        background-size: 300%;
        background-repeat: repeat-y;
        background-position: bottom center;
        >div{
            @include flex(flex-start, center, column);
            margin-bottom: auto;
            h1, p{
                margin-top: 8px;
                text-align: center;
            }
            h1{
                margin-top: 40px;
            }
            a{
                margin:60px 0px 99px;
            }
            img{
                width: 100%;
            }
        }
    }
     #recommend{
            >div{
                .reco-title{
                    border-bottom: none;
                    margin-bottom: 10px;
                    h2{
                        width: 100%;
                        text-align: center;
                    }
                    a{
                        display: none;
                    }
                }
                .reco-wrapper{
                    flex-direction: column;
                    .reco-bg{
                        width: 100%;
                        padding-top: 25px;
                        margin-bottom: 20px;
                        .reco-box{
                            padding: 15px 10px;
                            h4{
                                margin: 10px 0 20px;
                            }
                            .cancle{
                                font-size: 22px;
                            }
                            .price-box{
                                width: 100%;
                                .price{
                                    margin-right: 10px;
                                    font-size: 22px;
                                    margin-right: 15px;
                                    span{
                                        font-size: 16px;
                                    }
                                }
                                .discount{
                                    font-size: 16px;
                                    span{
                                        font-size: 16px;
                                        padding: 2px 14px;
                                        margin-top: -2px;
                                    }
                                }
                            }
                            .set{
                                font-size: 20px;
                            }
                            .benefit{
                                p{
                                    width: 90px;
                                    font-size: 18px;
                                }
                                ul{
                                    li{
                                        height: 40px;
                                        font-size: 16px;
                                    }
                                }
                            }
                            
                        }
                    }
                }
            }
        }
        #Application{
            >div{
                .prod-wrapper{
                    table{
                        tr{
                            height: auto;
                            th{
                                width: 100px;
                                font-size: 18px;
                            }
                            td{
                                @include flex(center, flex-start, column);
                                padding: 10px 0;
                                label{
                                    font-size: 16px;
                                    padding: 2px 13px;
                                }
                            }
                        }
                    }
                    .prod-select{
                        flex-direction: column;
                        .prod-box{
                            width: 100%;
                            position: static;
                            flex-direction: row;
                            padding: 15px 20px;
                            margin-bottom: 15px;
                            border-radius: 10px;
                            h5{
                                font-size: 22px;
                                margin-right: auto;
                            }
                            span{
                                font-size: 22px;
                                padding: 0;
                                margin: 0 ;
                                background:none;
                                color: $pink;
                                span{
                                    display: none;
                                }
                            }
                            div{
                                text-align: left;
                                margin-left: 20px;
                                p{
                                    font-size: 20px;
                                }
                            }
                            .cancle{
                                line-height: 20px;
                                &:after{
                                    top: 8px;
                                }
                            }
                            a{
                                width: 100%;
                                border-radius: 0;
                                font-size: 22px;
                                padding: 25px 0;
                                position: fixed;
                                bottom: 0;
                                span{
                                    font-size: 18px;
                                    color: $white;
                                    margin-top: 5px;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
 }
</style>

<script>
export default {
    name: 'purchase',
    layout: 'default',
    data(){
        return{
            prodList:[
                {
                    month: 3,
                    discount: 5,
                    originPrice: 150000,
                    price: 100000
                },
                {
                    month: 6,
                    discount: 10,
                    originPrice: 250000,
                    price: 200000
                },
                {
                    month: 12,
                    discount: 15,
                    originPrice: 350000,
                    price: 300000
                }
            ],
            prodSelect: {
                course: '북토킹',
                timeZone: '열공타임',
                classTime: '25분',
                numberOfClasses: '주5회',
            },
            common: [],

        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
           this.common = data;
       });
    },
    mounted(){
    },
    filters:{
        comma(v){
            return v = v.replace(/[^0-9]/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        }
    },
    methods:{
    }
}

</script>
