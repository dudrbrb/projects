<template>
    <div id="container">
        <header class="bg-light">
            <div>
                <img :src="require(`@/assets/img/tutor/main/teacher1.png`)" class="teacher1">
                <img :src="require(`@/assets/img/tutor/main/teacher2.png`)" class="teacher2">
                <img :src="require(`@/assets/img/tutor/main/child1.png`)" class="child1">
                <img :src="require(`@/assets/img/tutor/main/child2.png`)" class="child2">
                <img :src="require(`@/assets/img/tutor/main/book.png`)" class="book">
                <img :src="require(`@/assets/img/tutor/main/pen.png`)" class="pen">
                <img :src="require(`@/assets/img/tutor/main/A.png`)" class="a">
                <img :src="require(`@/assets/img/tutor/main/B.png`)" class="b">
                <img :src="require(`@/assets/img/tutor/main/C.png`)" class="c">
                <article>
                    <h1>아이의 레벨과 성향에<br v-if="$device.isMobile">  맞는 <br v-if="!$device.isMobile">선생님을<br v-if="$device.isMobile">  찾아드립니다. </h1>
                    <p>초등학생 전문 선생님과 노하우로 <br v-if="$device.isMobile">즐겁게 배우는<br>1:1 화상영어 맞춤수업</p>
                    <nuxt-link :to="'/'" class="font6">수강권 문의하기</nuxt-link>
                </article>
            </div>
        </header>
        <section id="swiper"> 
            <swiper :options="swiperOption" >
                <swiper-slide>
                    <h4>꼼꼼한 초등 전문 선생님</h4>
                    <p>테솔을 보유한 전문적인 선생님들이<br>초등영어학원 학생들 티칭 경험 다수</p>
                    <img :src="require(`@/assets/img/tutor/swiper/1.png`)">
                </swiper-slide>
                <swiper-slide>
                    <h4>센터 직접 운영 및 트레이닝</h4>
                    <p>대학교 교수가 센터에서 선생님들을<br>지속적으로 모니터링 및 트레이닝 진행</p>
                    <img :src="require(`@/assets/img/tutor/swiper/2.png`)">
                </swiper-slide>
                <swiper-slide>
                    <h4>1:1 담임 선생님과 유대</h4>
                    <p>매번 예약이 아닌 전담 수업을 통해<br>좋은 유대관계를 맺고 체계적인 관리</p>
                    <img :src="require(`@/assets/img/tutor/swiper/3.png`)">
                </swiper-slide>
                <swiper-slide>
                    <h4>자신감 있는 선생님들의 실력</h4>
                    <p>모든 선생님의 스펙과 영상이 공개되며<br>언제든지 무료체험 가능</p>
                    <img :src="require(`@/assets/img/tutor/swiper/4.png`)">
                </swiper-slide>
                <div class="swiper-pagination" slot="pagination"></div>
            </swiper>
            <div class="swiper-button-next "></div>
            <div class="swiper-button-prev"></div>
        </section>
        <section id="class" class="bg-light">
            <div>
                <article>
                    <h2>스픽클만의 차별화된 선생님</h2>
                    <p>초등학생들이 수업을 지겨워 하나요? <br>오랫동안 재밌게 수업할 수 있게 하는 핵심은 <br>"맞는" 선생님과의 유대관계입니다.</p>
                </article>
                <article class="card-wrapper">
                    <div>
                        <h4>미국식<br> 발음 교육</h4>
                        <p>특유의 필리핀 발음을 없애는<br v-if="$device.isMobile"> 발음 교육 진행</p>
                        <img :src="require(`@/assets/img/tutor/class/1.png`)">
                    </div>
                    <div>
                        <h4>전 선생님 <br>테솔 보유</h4>
                        <p>모든 선생님이 교육자격증(테솔) 보유, 영어교육과 위주로 채용</p>
                        <img :src="require(`@/assets/img/tutor/class/2.png`)">
                    </div>
                    <div>
                        <h4>칭찬과<br> 밝은 성격</h4>
                        <p>학생들과의 원활한 유대 관계를 위해 성격 평가 비중이 가장 높음</p>
                        <img :src="require(`@/assets/img/tutor/class/3.png`)">
                    </div>
                    <div>
                        <h4>체계적인<br> 선생님 교육</h4>
                        <p>교수 출신의 헤드 선생님이 매주 모니터링 후 피드백 및 교육 진행</p>
                        <img :src="require(`@/assets/img/tutor/class/4.png`)">
                    </div>
                </article>
            </div>
        </section>
        <section id="feedback" class="bg-pink">
            <div>
                <article>
                    <h2>스피킹 향상 포인트는<br style="display: block;">말하게 유도하는 스킬과 첨삭</h2>
                    <p>학생들에게 지속적인 칭찬은 말하게 만들고, <br style="display: block;">
                        실시간 첨삭으로 어떻게 말할지 느끼게합니다.</p>
                </article>
                <article>
                    <div class="tablet-wrapper">
                        <img :src="require(`@/assets/img/tutor/feedback/tablet.${format}`)" alt="피드백 받는 모습" class="tablet">
                    </div>
                    <div class="eff-img eff1">
                        <img :src="require(`@/assets/img/tutor/feedback/eff2.webp`)" alt="피드백 그림 2">
                        <h4>말하게 유도하는 스킬</h4>
                        <p>학생들에게 반복된 패턴으로<br> 질문하고 답변 유도</p>
                    </div>
                    <div class="eff-img eff2">
                        <img :src="require(`@/assets/img/tutor/feedback/eff1.webp`)" alt="피드백 그림 1">
                        <h4>문제 복습 및 실시간 피드백</h4>
                        <p>스토리를 정확히 이해했는지 <br>파악하고 복습하여 장기기억화</p>
                    </div>
                    <div class="eff-img eff3">
                        <img :src="require(`@/assets/img/tutor/feedback/eff3.webp`)" alt="피드백 그림 3">
                        <h4>자신감 상승 스킬</h4>
                        <p>지속적인 칭찬으로<br> 스피킹 자신감 상승</p>
                    </div>
                </article>
            </div>
        </section>
        <section id="tutor">
            <div>
                <h2>우리 아이에게 딱 맞는<br style="display: block">
                    <span class="font6"> 검증된 선생님을 소개합니다.</span>
                </h2>
                <article>
                    <div>
                        <input type="text" placeholder="튜터의 이름" v-if="!$device.isMobile">
                    </div>
                    <div class="tutor-wrapper">
                        <div class="tutor-box" v-for="(tutor, idx) in tutorData" :key="`tutor${idx}`" v-if="idx >= (12*(pagination-1)) && idx < (12*pagination) ">
                            <div class="tutor-img"></div>
                            <h4>{{tutor.id}}{{tutor.tutor}}</h4>
                            <ul>
                                <li v-for="(hash, idx2) in tutor.hash" :key="`tutor hash ${idx2}`">
                                    {{hash}}
                                </li>
                            </ul>
                            <div class="buttons">
                                <nuxt-link :to="{path:'/tutor/detail', query:{id: tutor.id}}">자세히보기</nuxt-link>
                                <a href="">소개 영상</a>
                            </div>
                        </div>
                    </div>
                    <div class="tutor-pagination">
                        <button @click="pagination==1 ?'':pagination--" class="prev-btn"></button>
                        <button v-for="i in Math.ceil(tutorData.length/12)" :key="`pagination btn ${i}`" @click="pagination = i" :class="{'active': pagination==i}">
                            {{i}}
                        </button>
                        <button @click="pagination==Math.ceil(tutorData.length/12)?'':pagination++" class="next-btn"></button>
                    </div>
                </article>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        text-align: center;
        height: 700px;
        h1{
            margin-top: 60px;
        }
        a{
            width: 230px;
            height: 60px;
            line-height: 60px;
            text-align: center;
            color: $white;
            border-radius: 40px;
            background: linear-gradient(-50deg, #d508df, $pink);
        }
        p{
            margin: 40px 0 50px;
        }
        >div{
            top: 0;
            left: 0;
            width: 100%;
            max-width: 3000px;
            height: 100%;
            overflow: hidden;
            >img{
                position: absolute;
                &.teacher1{
                    top: 120px;
                    left: 100px;
                }
                &.teacher2{
                    bottom: 0px;
                    right: 170px;
                }
                &.child1{
                    top: 430px;
                    left: 200px;
                    width: 220px;
                }
                &.child2{
                    top: 100px;
                    right: 120px;
                }
                &.book{
                    top: 110px;
                    left: 305px;
                }
                &.pen{
                    top: 490px;
                    right: 490px;
                }
                &.a{
                    top: 340px;
                    right: 100px;
                }
                &.b{
                    top: 100px;
                    right: 400px;
                }
                &.c{
                    top: 360px;
                    left: 400px;
                }
                
            }
            article{
                height: 100%;
                @include flex(center, center, column);
            }
        }
    }
    #swiper{
        >div{
            max-width: 3000px;
        }
        .swiper-container{
            width:100%;
            position: relative;
            padding: 50px 0 60px;
            margin-bottom: 80px;
            .swiper-slide {
                max-width: 650px;
                width: 90%;
                padding: 30px 0 20px;
                opacity: 0.4;
                box-shadow: 3px 3px 8px rgba(63, 63, 63, 0.2);
                @include flex(center, center, column);
                h4{
                    font-family: 'SCDream4';
                    font-size: 34px;
                    margin-bottom: 10px;
                    text-align: center;
                }
                p{
                    margin-bottom: 30px;
                    text-align: center;
                    color: $conText;
                }
                img{
                    margin-top: auto;
                    width: 240px;
                }
                &.swiper-slide-active{
                    opacity: 1;
                    
                }
            }
            .swiper-pagination{
                bottom: 0;
            }
        }
        .swiper-button-next,
        .swiper-button-prev{
            position: absolute;
            margin-top: -30px;
            width: 60px;
            top: 48%;
            z-index: 1;
            color: rgb(181, 181, 181);
        }
        .swiper-button-next{
            left: 750px;
        }
        .swiper-button-prev{
            right: 750px;
        }
    }
    #class{
        >div{
            flex-direction: column;
            article{
                &.card-wrapper{
                    display: flex;
                    margin-top: 50px;
                    div{
                        background-color: $white;
                        border-radius: 20px;
                        box-shadow: 3px 3px 8px rgba(63, 63, 63, 0.2);
                        overflow: hidden;
                        padding: 30px 10px 200px 15px;
                        position: relative;
                        flex: 1;
                        &+div{
                            margin-left: 15px;
                        }
                        h4{
                            font-size: 32px;
                            line-height: 42px;
                        }
                        p{
                            margin-top: 20px;
                            padding-right: 15px;
                            font-size: 18px;
                            color: $conText;
                            line-height: 24px;
                        }
                        img{
                            position : absolute;
                            bottom: 10px;
                            right: 10px;
                        }
                        &:nth-child(3){
                            img{
                                right: 0;
                            }
                        }
                    }
                }
            }
        }
    }
    #feedback{
        >div{
            padding-bottom: 200px;
            h2, p{
                color: $white;
            }
            article{
                position: relative;
                .tablet-wrapper{
                    background-color: $white;
                    border-radius: 20px;
                    margin-top: 50px;
                    padding: 10px 20px;
                    box-shadow:3px 3px 8px rgba(63, 63, 63, 0.4);
                    width: 100%;
                    z-index: 3;
                    position: relative;
                    img{
                        z-index: 3;
                        width: 100%;
                    }
                }
                .eff-img{
                    position: absolute;
                    background-color: $white;
                    border-radius: 15px;
                    padding: 20px 15px 0;
                    box-shadow: 3px 3px 8px rgba(63, 63, 63, 0.4);
                    transform: translateY(50px);
                    transition: all 0.4s;
                    opacity: 0;
                    p{
                        color: $conText;
                        margin: 5px 0 0;
                    }
                    img{
                        margin: 0 auto 10px;
                    }
                    &.act{
                        transform: translateY(0px);
                        opacity: 1;
                    }
                    &.eff1{
                        top: -90px;
                        right: -150px;
                        z-index: 5;
                        width: 240px;
                        padding: 15px;
                        h4{
                            font-size: 18px ;
                        }
                        p{
                            font-size: 16px;
                            line-height: 22px;
                        }
                        img{
                            width: 60%;
                            margin-left: 37px;
                            margin: 5px 0 0 42px;
                        }
                    }
                    &.eff2{
                        bottom: -140px;
                        left: -150px;
                        z-index: 5;
                        width: 290px;
                        padding: 20px;
                        h4{
                            font-size: 23px;
                        }
                        p{
                            font-size: 18px;
                            line-height: 25px;
                        }
                        img{
                            width: 100%;
                        }
                    }
                    &.eff3{
                        bottom: -200px;
                        right: -130px;
                        z-index: 1;
                        width: 240px;
                        padding: 15px;
                        h4{
                            font-size: 20px ;
                        }
                        p{
                            font-size: 16px;
                            line-height: 22px;
                        }
                        img{
                            width: 70%;
                            margin-left: 20px;
                            margin-bottom: 0;
                        }
                    }
                }

            }
        }
    }
    #tutor{
        >div{
            h2 span{
                color: $pink;
                font-size: 1em;
            }
            article{
                div{
                    width: 100%;
                    @include flex(space-between, center);
                    flex-wrap: wrap;
                    input{
                        background-color: $white;
                        border: 1px solid #ccc;
                        background-image: url('@/assets/img/tutor/search.png');
                        background-repeat: no-repeat;
                        background-position:5px center;
                        background-size: 22px;
                        border-radius: 8px;
                        padding: 5px 5px 5px 40px;
                        margin: 10px 0.5% 20px auto;
                        width: 24%;
                        height: 50px;
                        font-size: 18px;
                        &::placeholder{
                            color: #ccc;
                        }
                    }
                    .tutor-box{
                        width: 24%;
                        @include flex(center, center, column);
                        border: 1px solid #ccc;
                        border-radius: 10px;
                        padding: 30px 10px 15px;
                        margin: 0.5%;
                        box-shadow: $shadow;
                        &:last-child{
                            margin-right: auto;
                        }
                        .tutor-img{
                            width: 100px;
                            height: 100px;
                            background-color: #ccc;
                            border-radius: 50%;
                        }
                        h4{
                            margin: 5px 0 7px;
                            font-size: 22px;
                        }
                        ul, .buttons{
                             @include flex();
                        }
                        ul{
                            li{
                                font-size: 14px;
                                &::before{
                                    content: '#';
                                    margin-right: -3px;
                                }
                                &+li{
                                    margin-left: 5px;
                                }
                            }
                        }
                        .buttons{
                            margin-top: 15px;
                            width: 100%;
                            a, div{
                                font-size: 14px;
                                border: 1px solid #ccc;
                                padding: 2px 0;
                                border-radius: 10px;
                                width: 48%;
                                cursor: pointer;
                                text-align: center;
                                &:hover{
                                    background-color: $pink;
                                    border-color: $pink;
                                    color: $white;
                                }
                            }
                            a{
                                margin-left: 3px;
                            }
                        }
                    }
                    &.tutor-pagination{
                        justify-content: center;
                        margin-top: 30px;
                        button{
                            background-color: $white;
                            border: 1px solid rgb(228, 228, 228);
                            color: $pink;
                            width: 40px;
                            height: 40px;
                            margin: 0px;
                            font-family: 'SCDream4';
                            font-size: 16px;
                            &:hover{
                                border-color: $pink;
                            }
                            &.active{
                                background-color: $pink;
                                border-color: $pink;
                                color: $white;
                            }
                            &.prev-btn,
                            &.next-btn{
                                background-image: url('@/assets/img/tutor/arrow.webp');
                                background-repeat: no-repeat;
                                background-position: center;
                            }
                            &.prev-btn{
                                transform: rotate(180deg);
                            }
                        }
                    }
                }
            }
        }
    }
}
@media screen and (max-width: 1500px) {
#container{
    header{
        >div{
            >img{
                &.teacher1{
                    left: 40px;
                }
                &.teacher2{
                    right: 120px;
                }
                &.child1{
                    left: 140px;
                }
                &.child2{
                    right: 60px;
                }
                &.book{
                    left: 255px;
                }
                &.pen{
                    right: 490px;
                }
                &.a{
                    right: 50px;
                }
                &.b{
                    right: 340px;
                }
                &.c{
                    left: 370px;
                }
            }
        }
    }
}
}

@media screen and (max-width: 1370px) {
#container{
   header{
         >div{
            >img{
                &.teacher1{
                    width: 220px;
                }
                &.teacher2{
                    right: 40px;
                    width: 410px;
                }
                &.child1{
                    left: 110px;
                    width: 200px
                }
                &.child2{
                    width: 230px;
                }
                &.book{
                    left: 185px;
                    width: 120px;
                }
                &.pen{
                    right: 320px;
                    width: 90px;
                }
                &.a{
                    right: 30px;
                }
                &.b{
                    right: 240px;
                }
                &.c{
                    left: 290px;
                }
            }
        }
    }
    #feedback{
        >div{
            padding-bottom: 0;
            article:last-child{
                flex-wrap: wrap;
                @include flex(space-between, center);
                .tablet-wrapper{
                    width: 100%;
                }
                .eff-img{
                    position: relative;
                    top: 0;
                    left: 0;
                    right: 0;
                    width: 30%;
                    margin-top: 30px;
                    &.eff1,
                    &.eff2,
                    &.eff3{
                        top: 0;
                        left: 0;
                        right: 0;
                        width: 32%;
                        height: auto;
                        z-index: 5;
                        padding: 10px 10px 10px 20px;
                        h4{
                            font-size: 22px;
                            margin-top: 10px;
                        }
                        p{
                            font-size: 18px;
                            line-height: 26px;
                            margin: 5px 0 10px;
                            width: 250px;
                        }
                        img{
                            width: auto;
                            max-width: 50%;
                            min-width: 100px;
                            height: 150px;
                            object-fit: contain;
                            margin: 10px auto 0 ;
                            left: 48%;
                            transform: translateX(-50%);
                            position: relative;
                        }
                    }
                }
            }
        }
    }
}
}
@media screen and (max-width: 1165px) {
#container{
    header{
        >div{
            >img{
                &.teacher1{
                    width: 180px;
                }
                &.teacher2{
                    right: 40px;
                    width: 400px;
                }
                &.child1{
                    left: 60px;
                    width: 200px
                }
                &.child2{
                    width: 200px;
                    right: 0;
                }
                &.book{
                    left: 165px;
                    width: 100px;
                }
                &.pen{
                    right: 320px;
                    width: 90px;
                }
                &.a{
                    width: 60px;
                    right: 100px;
                }
                &.b{
                    width: 60px;
                    right: 220px;
                }
                &.c{
                    left: 220px;
                    width: 70px;
                }
            }
        }
    }
}
}
@media screen and (max-width: 1024px){
    #container{
        header{
            >div{
                >img{
                    &.teacher1{
                        display: none;
                    }
                    &.teacher2{
                        right: auto;
                        width: 470px;
                        left: -90px;
                        transform: scaleX(-1);
                    }
                    &.child1{
                        display: none;
                    }
                    &.child2{
                        width: 230px;
                        top: auto;
                        bottom: 190px;
                        right: 30px;
                    }
                    &.book{
                        top: 90px;
                        left: 120px;
                        right: auto;
                        width: 100px;
                    }
                    &.pen{
                        top: auto;
                        right: 40px;
                        bottom: 80px;
                        transform: rotate(260deg);
                    }
                    &.a{
                       width: 50px;
                        top: auto;
                        left: 30px;
                        right: auto;
                        bottom: 350px;
                    }
                    &.b{
                        width: 60px;
                        right: 30px;
                        top: 200px;
                    }
                    &.c{
                        top: auto;
                        left: 390px;
                        bottom: 50px;
                        width: 50px;
                    }
                }
            }
        }
         #swiper {
            .swiper-container{
                .swiper-slide{
                   max-width: 570px;
               }

            }
             .swiper-button-next{
                left: 660px;
                &:after{
                    font-size: 38px;
                }
            }
            .swiper-button-prev{
                right: 660px;
                &:after{
                    font-size: 38px;
                }
            }
        }
        #tutor {
            > div{
                article{
                    div{
                        input{
                            width: 32.33%;
                        }
                        .tutor-box{
                            width: 32.33%;
                        }
                    } 
                } 
            } 
        }
    }
}
@media screen and (max-width: 920px){
    #container{
        header{
            >div{
                >img{
                    &.teacher2{
                        width: 380px;
                    }
                    &.child2{
                        width: 160px;
                        right: 10px;
                    }
                    &.book{
                        top: 130px;
                        left: 30px;
                        width: 80px;
                    }
                    &.pen{
                        width: 70px;
                        right: 90px;
                        bottom: 120px;
                    }
                    &.a{
                        bottom: 310px;
                    }
                    &.b{
                        width: 50px;
                        top: 270px;
                    }
                    &.c{
                        top: auto;
                        left: 390px;
                        bottom: 50px;
                        width: 50px;
                    }
                }
            }
        }
         #class{
            >div{
                article{
                    &.card-wrapper{
                        @include flex(center,center, column);
                        div{
                            padding: 35px 0 35px 150px;
                            width: 100%;
                            max-width: 550px;
                            margin-bottom: 10px;
                            &+div{
                                margin-left: 0;
                            }
                            h4{
                                font-size: 28px;
                                br{
                                    display: none;
                                }
                            }
                            p{
                                font-size: 20px;
                                margin-top:10px;
                                padding-right: 30px;
                            }
                            img{
                                position : absolute;
                                top: 0;
                                bottom: 0;
                                right: auto;
                                left: 10px;
                                width: 120px;
                                margin: auto 0;
                            }
                            &:nth-child(1),&:nth-child(2){
                                margin-bottom: 10px;
                            }
                            &:nth-child(3){
                                img{
                                    transform: scaleX(-1);
                                    left: 0;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        #feedback{
            > div {
                article:last-child {
                    .eff-img{
                        &.eff1, &.eff2, &.eff3{
                            padding: 10px;
                            h4{
                                font-size: 20px;
                            }
                            p{
                                font-size: 16px;
                                line-height: 24px;
                                width: 100%;
                            }
                            img{
                                height: 110px;
                            }
                        }
                    }
                }

            }
        } 
    }
}
@media screen and (max-width: 767px) {
#container{
    header{
        height: 940px;
        >div{
            text-align: left;
            align-items: flex-start;
            article{
                justify-content: flex-start;
                align-items: flex-start;
                h1{
                    width: 420px;
                    margin-top: 120px;
                }
                p{
                    width: 450px;
                    margin: 40px 0 30px;
                    br{
                        display: none;
                        &:first-child{
                            display: block;
                        }
                    }
                }
            }
            
            >img{
                &.child2{    
                    width: 240px;
                    bottom: 292px;
                }
                &.teacher2{
                    left: 0;
                }
                &.book{
                    left: 140px;
                    bottom: 330px;
                    top: auto;
                    width: 100px;
                }
                &.pen{
                    right: 70px;
                    width: 100px;
                }
                &.a{
                    bottom: 250px;
                    left: 40px;
                    width: 65px;
                }
                &.b{    
                    width: 65px;
                    top: 330px;
                }
                &.c{    
                    width: 60px;
                }
            }
        }
    }
    #swiper{
        padding-bottom: 30px;
         .swiper-container{
            .swiper-slide{
                width: 98%;
                h4{
                    font-size: 28px;
                }
                p{
                    font-size: 18px;
                    line-height: 26px;
                    margin-bottom: 15px;
                }
                img{
                    width: 140px;
                }
            }
        }
        .swiper-button-next,
        .swiper-button-prev{
            display: none;
        }
    }
     #tutor{
        > div {
            article {
                div {
                    input{
                        display: none;
                    }
                    .tutor-box {
                        width: 49%;
                        ul {
                            flex-wrap: wrap;
                        }
                    }
                    
                }
            }
        }
    } 
    #feedback{
        >div{
            h2{
                margin-bottom: 10px;
            }
            article:last-child{
                flex-direction: column;
                .eff-img.eff1,.eff-img.eff2,.eff-img.eff3{
                    width: 100%;
                    position: relative;
                    padding-left: 150px;
                    height: 130px;
                    margin-top: 10px;
                    img{
                        width: 110px;
                        position: absolute;
                        left: 70px;
                            top: 4px;
                    }
                }   
            }
        }
    }
}
}
@media screen and (max-width: 540px) {
#container{
    header{
        height: 800px;
        >div{
            article{
                a{
                    width: 180px;
                    height: 50px;
                    line-height: 50px;
                }
            }
            img{
                &.child2{    
                    width: 150px;
                    bottom: 250px;
                }
                &.teacher2{
                   width: 310px;
                   left:-20PX;
                }
                &.book{
                    left: 80px;
                    bottom: 260px;
                    width: 80px;
                }
                &.pen{
                    right: 50px;
                    width: 70px;
                }
                &.a{
                    bottom: 190px;
                    left: 30px;
                    width: 45px;
                }
                &.b{    
                    width: 45px;
                    top: 370px;
                    right: 20px;
                }
                &.c{    
                    width: 60px;
                }

            }
        
        }
    }
    #swiper{
        .swiper-container{
            padding: 5px 0 60px;
            margin-bottom: 20px;
            .swiper-slide{
                h4{
                    font-size: 24px;
                }
                p{
                    font-size: 16px;
                    line-height: 24px;
                }
            }
        }
    }
    #class{
        >div{
            article{
                &.card-wrapper{
                    div{
                        padding: 15px 0 15px 110px;
                        h4{
                            font-size: 22px;
                        }
                        p{
                            font-size: 16px;
                            margin-top: 0;
                            padding-right: 20px;
                        }
                        img{
                            width: 90px;
                        }
                    }
                }
            }
        }
    }
    #feedback{
        >div{
            h2{
                font-size: 28px;
                line-height: 36px;
            }
            article{
                &:last-child{
                    .eff-img.eff1, .eff-img.eff2, .eff-img.eff3{
                        padding-left: 110px;
                        height: auto;
                        img{
                            width: 84px;
                            height: 84px;
                            left: 59px; 
                        }
                    }
                }
            }
        }
    }
    #tutor{
        >div{
            h2, h2 span{
                font-size: 28px;
                line-height: 36px;
            }
            article{
                margin-top: 50px;
                div{
                    .tutor-box{
                        padding: 10px 6px 10px;
                        h4{
                            font-size: 20px;
                        }
                        ul li{
                            line-height: 20px;
                        }
                        .button a{
                            padding: 4px 0;
                        }
                    }
                }
            }
        }
    }

}
}

</style>
<style lang='scss'>
.swiper-pagination{
    .swiper-pagination-bullet{
        width: 10px;
        height: 10px;
    }
    .swiper-pagination-bullet-active{
        background: $pink;
    }
}
@media screen and (max-width: 890px) {
.swiper-pagination{
    .swiper-pagination-bullet{
        width: 8px;
        height: 8px;
    }
}
}
</style>

<script>
export default {
    name: 'tutor',
    layout: 'default',
    data(){
        return{
            format: 'webp',
            pagination: 1,
            swiperOption:{
                loop: true,
                spaceBetween: 20,
                slidesPerView: "auto",
                direction: 'horizontal',
                centeredSlides: true,
                observer: true,
                observeParents: true,
                autoplay: { 
                    delay: 4000, 
                    disableOnInteraction: false 
                },
                pagination: { 
                    el: '.swiper-pagination', 
                    clickable: true 
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                breakpoints: {
                    768: {
                        spaceBetween: 80,
                    },
                   540: {
                        spaceBetween:20,
                    },
                },
            },
            tutorData:[
                {
                    tutor: 'Anne', id:0,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 2,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 3,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 4,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 5,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 6,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 7,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 8,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 9,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 10,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 11,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 12,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 13,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 14,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 15,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 16,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 17,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 18,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 19,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 20,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 21,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 22,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 23,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 24,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 25,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
            ],
            common: {},
            eff1Offset: null,
            eff2Offset: null,
            eff3Offset: null,
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    beforeMount(){
        window.addEventListener('scroll', this.motion);
    },
    mounted(){
        this.gifLoad();
        this.getOffset();
        this.getSelectTutor();
    },
    filters:{},
    computed: {},
    methods:{   
        gifLoad(){
            this.format = 'gif';
        },
        getSelectTutor(){
            var tutorDiv = this.$el.querySelector('#tutor input');

            if(this.$route.query.tutor) tutorDiv.scrollIntoView({behavior: 'smooth',block :'center'})
        },
        addAct(element){
            var ele = this.$el.querySelectorAll(element);
            
            ele.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 200*idx);
            });
        },
        getOffset(){
           this.eff1Offset = this.$el.querySelector('.eff1').getBoundingClientRect().top + window.pageYOffset - 600,
           this.eff2Offset = this.$el.querySelector('.eff2').getBoundingClientRect().top + window.pageYOffset - 600,
           this.eff3Offset = this.$el.querySelector('.eff3').getBoundingClientRect().top + window.pageYOffset - 600;

            this.motion()
        },

        motion(){
            var myScroll = window.scrollY,
                screenWidth = window.innerWidth;

            if(screenWidth > 1390){ 
                if(myScroll >= this.eff1Offset) this.addAct('.eff1');
                if(myScroll >= this.eff2Offset) this.addAct('.eff2');
                if(myScroll >= this.eff3Offset) this.addAct('.eff3');
            } else{
                if(myScroll >= this.eff1Offset) this.addAct('.eff-img');
            };
        }
    },
    beforeDestroy(){
        window.addEventListener('scroll', this.motion);
    }
}

</script>
