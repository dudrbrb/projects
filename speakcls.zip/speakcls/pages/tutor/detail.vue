<template>
    <div id="container" class="bg-light">
        <section id="tutor">
            <div>
             <div class="img-box">
                    <div class="image"></div>
                    <div>
                        <h4>{{selectTutor.id}}{{selectTutor.tutor}}</h4>
                        <a :href="`${selectTutor.video}`">소개 영상</a>
                    </div>
                </div>
                <div class="txt-box">
                    <div>
                        <h3>경력 및 특이사항</h3>
                        <ul>
                            <li v-for="(career, idx) in selectTutor.career" :key="`select tutor hash ${idx}`">
                                {{career}}
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h3>자기소개</h3>
                        <p>{{selectTutor.introduction}}</p>
                    </div>
                </div>
                <nuxt-link :to="'/tutor'" class="back">뒤로가기</nuxt-link>
            </div>
        </section>
        <section id="recommend">
            <div>
                <p class="font5">다른 고객이 함께 본 튜터, 추천드려요 !</p>
                <div class="tutor-box" v-for="(tutor, idx) in tutorData" :key="`tutor${idx}`" v-if="tutor.id < 5">
                    <div class="tutor-img"></div>
                    <h4>{{tutor.id}}{{tutor.tutor}}</h4>
                    <ul>
                        <li v-for="(hash, idx2) in tutor.hash" :key="`tutor hash ${idx2}`">
                            {{hash}}
                        </li>
                    </ul>
                    <div class="buttons">
                        <nuxt-link :to="{path:'/tutor/detail', query:{id: tutor.id}}">자세히보기</nuxt-link>
                        <a href="">소개 영상</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    #tutor{
        >div{
            background-color: $white;
            @include flex(center, flex-start);
            padding: 20px 30px;
            border-radius: 15px;
            margin-top: 130px;
            div{
                &.img-box{
                    border: 1px solid #ccc;
                    border-radius: 15px;
                    box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
                    width: 230px;
                    min-width: 230px;
                    padding: 30px 0 0;
                    margin-right: 10px;
                    overflow: hidden;
                    @include flex(center, center, column);
                    .image{
                        width: 100px;
                        height: 100px;
                        border-radius: 50%;
                        background-color: #b2b2b2;
                        margin-bottom: 10px;
                    }
                    div{
                        background-color: #fafafa;
                        width: 100%;
                        text-align: center;
                        padding-bottom: 15px;
                    }
                    h4{
                        font-size: 32px;
                        margin: 10px 0 10px;
                    }
                    a{
                        font-size: 16px;
                        border: 1px solid #ccc;
                        width: auto;
                        padding: 5px 15px 6px;
                        border-radius: 10px;
                        &:hover{
                            background-color: $pink;
                            border-color: $pink;
                            color: $white;
                        }
                    }
                }
                &.txt-box{
                    border: 1px solid #ccc;
                    border-radius: 15px;
                    padding: 15px;
                    >div{
                        margin-bottom: 40px;
                    }
                    h3{
                        background-color: #c455a4;
                        color: $white;
                        padding: 4px 5px;
                        margin-bottom: 20px;
                        font-size: 20px;
                    }
                    ul li, p{
                        font-size: 18px;
                        font-family: 'SCDream4';
                        line-height: 26px;
                        position: relative;
                    }
                    ul li{
                        padding-left: 15px;
                    }
                    ul li:before{
                        content: '* ';
                        position: absolute;
                        left: 0;
                        top: 0;
                    }
                }
               
            }
            .back{
                position: absolute;
                font-size: 16px;
                border: 1px solid #ccc;
                width: auto;
                padding: 0 15px;
                border-radius: 10px;
                bottom: 20px;
                left: 30px;
                &:hover{
                    background-color: $pink;
                    border-color: $pink;
                    color: $white;
                }

            }
        }
    }
    #recommend{
        >div{
            background-color: $white;
            padding: 20px 30px;
            border-radius: 15px;
            @include flex(flex-start, center);
            flex-wrap: wrap;
            margin-top: 0;
            >p{
                width: 100%;
                font-size: 24px;
                margin-bottom: 20px;
            }
           
            .tutor-box{
                width: 24%;
                @include flex(center, center, column);
                border: 1px solid #ccc;
                border-radius: 10px;
                padding: 30px 10px 15px;
                margin: 0.5%;
                box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
                .tutor-img{
                    width: 100px;
                    height: 100px;
                    background-color: #ccc;
                    border-radius: 50%;
                }
                h4{
                    margin: 5px 0 7px;
                    font-size: 22px;
                }
                ul, .buttons{
                        @include flex();
                }
                ul{
                    li{
                        font-size: 14px;
                        &::before{
                            content: '#';
                            margin-right: -3px;
                        }
                        &+li{
                            margin-left: 5px;
                        }
                    }
                }
                .buttons{
                    margin-top: 15px;
                    width: 100%;
                    a, div{
                        font-size: 14px;
                        border: 1px solid #ccc;
                        padding: 2px 0;
                        border-radius: 10px;
                        width: 48%;
                        cursor: pointer;
                        text-align: center;
                        &:hover{
                            background-color: $pink;
                            border-color: $pink;
                            color: $white;
                        }
                    }
                    a{
                        margin-left: 3px;
                    }
                }
            }
        }
    }
}
@media screen and (max-width: 960px){
#container{
    #tutor{
        >div{
            padding: 10px;
            margin-bottom: 50px;
            div{
                margin-bottom: 30px;
                &.img-box{
                    width: 200px;
                    min-width: 200px;
                    padding: 20px 0 0;
                    
                    div{
                        margin-bottom: 0;
                    }
                    h4{
                        font-size: 28px;
                    }
                }
            }
            .back{
                display: none;
            }
        }
    }
    #recommend{
        >div{
            padding: 15px 10px 8px;
            >p{
                margin-bottom: 10px;
            }
           
            .tutor-box{
                padding: 20px 5px 15px;
                ul{
                    flex-direction: column;
                    li{
                        line-height: 20px;
                    }
                }
            }
        }
    }
}
}
@media screen and (max-width: 540px){
#container{
    #tutor{
        >div{
            flex-direction: column;
            div{
                margin-bottom: 10px;
                &.img-box{
                    width: 100%;
                    margin-right: 0;
                    h4{
                        font-size: 28px;
                    }
                }
      
               
            }
  
        }
    }
    #recommend{
        >div{
            flex-direction: column;
            >p{
                margin-bottom: 10px;
                line-height: 30px;
            }
           
            .tutor-box{
                width: 100%;
                margin-bottom: 5px;
                &:last-child{
                    margin-bottom: 0;
                }
                ul{
                    flex-direction: row;
                }
                .buttons{
                    a{
                        padding: 6px 0;
                    }
                }
            }
        }
    }
}
}

</style>

<script>
export default {
    name: 'tutor-detail',
    layout: 'default',
    data(){
        return{ 
            selectTutor: '',
            tutorData:[
                {
                    tutor: 'Anne', id:0,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 2,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 3,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 4,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 5,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 6,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 7,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 8,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 9,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 10,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 11,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 12,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 13,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 14,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 15,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 16,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 17,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 18,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 19,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 20,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 21,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 22,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 23,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 24,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
                {
                    tutor: 'Anne', id: 25,
                    hash: ['열정적인', '자신감을 주는 선생님'],
                    vedio: 'https://www.youtube.com/watch?v=FH_yGTAOSa0',
                    career: [
                        'Licensed Professional Teacher',
                        'Tenured English as Second Language (ESL) Teacher',
                        'Box English Tutorial (Korean students) : September 2016 - Decenber 2016',
                        'ITalk English (Chinese student) : June 2017 - October 2019',
                        'Talk915 (Chinese students) : February 2020 - Agust 2020',
                    ],
                    introduction: "Hello! I am Teacher Aileen and I love teaching English.<br> I've been an online teacher for almost four years.<br> I like singing, dancing and playing games in my clsss. <br> We will have fun learning English. I also enjoy learning from my students so we will be learning from each other.<br> What are you waiting for? Come and join my class!"
                },
            ],
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },  
    mounted(){
        this.getSelectTutor()
    },
    filters:{

    },
    computed: {},
    methods:{
        getSelectTutor(){
            var getParams = this.$route.query.id;
            this.selectTutor = this.tutorData[getParams]
        }
    },
    beforeDestroy(){
        // this.$router.push($route.path)
    }
}

</script>
