<template>
    <div id="container">
        <section id="findAccount">
            <div>
                <div class="select-how">
                    <div :class="{act: method=='id'}" @click="method='id'">아이디 찾기</div>
                    <div :class="{act: method=='selfCert'}" @click="method='selfCert'">본인인증으로 찾기</div>
                </div>
                <h2>아래의 아이디 찾기 수단 중<br style="display:block">하나를 선택하여 진행해주세요.</h2>
                <div class="findID" v-if="method=='id'">
                    <div class="select-method flex-wrapper">
                        <div>
                            <input type="radio" name="method" id="selectPhone" value="phone" v-model="select">
                            <label for="selectPhone" class="font3">휴대폰번호</label>
                        </div>
                        <div>
                            <input type="radio" name="method" id="selectEmail" value="email" v-model="select">
                            <label for="selectEmail" class="font3">이메일 주소</label>
                        </div>
                    </div>
                    <input type="text" placeholder="이름" v-model="confirmData.userName">
                    <input type="text" placeholder="휴대폰 인증 (번호만 입력)" v-if="select=='phone'" key="phone"  v-model="confirmData.userPhone">
                    <input type="text" placeholder="이메일 인증" v-else key="email" v-model="confirmData.userEmail">
                    <button @click="confirm" class="font6 gray" :class="{'pink': okBtn}" >확인</button>
                    <hr>
                    <div class="sns-list" >
                        <p>SNS 아이디로 가입하신 경우<br>각 SNS 간편 로그인을 이용해주세요</p>
                        <div id="kakao"><img :src="require('@/assets/img/login/kakao.webp')"></div>
                        <div id="naver"><img :src="require('@/assets/img/login/naver.webp')"></div>
                        <div id="facebook"><img :src="require('@/assets/img/login/facebook.webp')"></div>
                        <div id="apple"><img :src="require('@/assets/img/login/apple.webp')"></div>
                    </div>
                </div>
                <div class="selfCert" v-else>
                    <div>
                        <div class="method phone" >
                            <img :src="require('@/assets/img/login/find/phone.png')">
                            휴대폰 인증
                        </div>
                        <div class="method ipin">
                            <img :src="require('@/assets/img/login/find/ipin.png')">
                            아이핀 인증
                        </div>
                    </div>
                    <p class="font3">본인 명의의 휴대폰/아이핀 인증을 진행한 회원만 이용이 가능합니다.<br> (간편 회원 사용 불가)</p>
                </div>
            </div>

        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    #findAccount{
        >div{
            .findID{
                .sns-list{
                    p{
                        text-align: center;
                        margin: 0 0 40px;
                    }
                }
                hr{
                    width: 100%;
                    margin: 30px 0;
                }
            }
            .selfCert{
                width: 100%;
                div{
                     @include flex();
                    margin-bottom: 10px;
                    width: 100%;
                    .method{
                        flex-direction: column;
                        border: 1px solid $black;
                        border-radius: 10px;
                        height: 180px;
                        cursor: pointer;
                        img{
                            height: 90px;
                            margin-bottom: 15px;
                        }
                        +div{
                            margin-left: 35px;
                        }
                    }
                }
                p{
                    color:  $grayOnGray;
                }
            }
        }
    }
}
@media screen and (max-width: 767px){
#container{
    #findAccount{
        >div{
            .select-how{
                top: 50px;
            }
            .findID{
                hr{
                    margin: 20px 0;
                }
                .sns-list{
                    p{
                        margin : 0 0 20px
                    }
                }
            }
            .selfCert{
                div{
                    .method{
                        height: 160px;
                        img{
                            height:75px;
                            margin-bottom: 15px;
                        }
                        &+div{
                            margin-left: 15px;
                        }
                    }
                }  
            }
        }
    }
}
}
</style>

<script>
export default {
    name: 'findAccount',
    layout: 'form',
    data(){
        return{
            method:'id',
            select: 'phone',
            okBtn: false,
            confirmData:{
                userName: null,
                userPhone: null,
                userEmail: null,
            }
        }
    },
    created(){
    },
    mounted(){
    },
    watch:{
        select:{
            handler(e){
                console.log(e)
            }
        },
        confirmData:{
            deep: true,
            handler(e){
                var info = (this.select == 'phone' ? e.userPhone : e.userEmail)
                if(String(e.userName) !== 'null' && String(info) !== 'null'){
                    this.okBtn = true;
                }
                if(String(e.userName).length == 0 || String(info).length==0){
                    this.okBtn = false;
                }


                if(e.userPhone !== null){
                     e.userPhone = e.userPhone.replace(/[^0-9]/g, '');
                }
                if(e.userEmail !== null){
                     e.userEmail = e.userEmail.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, '');
                }

            }
        },
    },
    filters:{
    },
    methods:{
        confirm(){
            console.log(this.confirmData)
        }
    }
}

</script>
