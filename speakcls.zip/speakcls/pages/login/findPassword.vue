<template>
    <div id="container">
        <section id="findPassword">
            <div>
                <div class="select-how">
                    <div :class="{act: method=='info'}" @click="method='info'">회원등록 정보</div>
                    <div :class="{act: method=='selfCert'}" @click="method='selfCert'">본인인증</div>
                </div>
                <h2>아래의 비밀번호 재설정 수단 중<br style="display:block">하나를 선택하여 진행해주세요.</h2>
                <div class="findInfo" v-if="method=='info'">
                    <div class="select-method flex-wrapper">
                        <div>
                            <input type="radio" name="method" id="selectPhone" value="phone" v-model="select">
                            <label for="selectPhone" class="font3">휴대폰번호</label>
                        </div>
                        <div>
                            <input type="radio" name="method" id="selectEmail" value="email" v-model="select">
                            <label for="selectEmail" class="font3">이메일 주소</label>
                        </div>
                    </div>
                    <input type="text" placeholder="이름" v-model="confirmData.userName">
                    <input type="number" placeholder="휴대폰 인증 (번호만 입력)" v-if="select=='phone'" key="phone"  v-model="confirmData.userPhone"  :readonly="sendNum">
                    <input type="text" placeholder="이메일 인증" v-else key="email" v-model="confirmData.userEmail"  :readonly="sendNum">
                    <button id="numSendBtn" :class="{'pink': sendBtn}" @click="sendNumEvent">전송</button>
                    <input type="number" placeholder="인증번호" v-model="checkNum" :readonly="!sendNum">
                    <button @click="confirm" class="font6 gray" :class="{'pink': okBtn}" >확인</button>
                </div>
                <div class="selfCert" v-else>
                    <div>
                        <div class="method phone" >
                            <img :src="require('@/assets/img/login/find/phone.png')">
                            휴대폰 인증
                        </div>
                        <div class="method ipin">
                            <img :src="require('@/assets/img/login/find/ipin.png')">
                            아이핀 인증
                        </div>
                    </div>
                    <p class="font3">본인 명의의 휴대폰/아이핀 인증을 진행한 회원만 이용이 가능합니다.<br> (간편 회원 사용 불가)</p>
                </div>
            </div>
            <div class="confirmPopup" v-if="confirmPopup.open">
                <div>
                    <div>
                        {{confirmPopup.message}}
                    </div>
                    <div>
                        <button @click="closePopup">확인</button>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    #findPassword{
        >div{
            h2{
                width: 110%;
            }
            .findInfo{
                position: relative;
                #numSendBtn{
                    position: absolute;
                    top: 55px;
                    right: 10px;
                    width: auto;
                    background: none;
                    color: #747474;
                    font-size: 18px;
                    padding: 10px;
                    z-index: 1;
                    &.pink{
                        color: $pink;
                    }
                }
  
            }
            .selfCert{
                width: 100%;
                div{
                     @include flex();
                    margin-bottom: 10px;
                    width: 100%;
                    .method{
                        flex-direction: column;
                        border: 1px solid $black;
                        border-radius: 10px;
                        height: 180px;
                        cursor: pointer;
                        img{
                            height: 90px;
                            margin-bottom: 15px;
                        }
                        +div{
                            margin-left: 35px;
                        }
                    }
                }
                p{
                    color:  $grayOnGray;
                }
            }
        }
    
        
    }
}
@media screen and (max-width: 767px){
#container{
    #findPassword{
        >div{
            h2{
                margin-top: 80px;
            }
            .select-how{
                top: 50px;
            }
            .findInfo {
                #numSendBtn{
                    top: 85px;
                    font-size: 16px;
                }
            }
            .selfCert{
                div{
                    .method{
                        height: 160px;
                        img{
                            height:75px;
                            margin-bottom: 15px;
                        }
                        &+div{
                            margin-left: 15px;
                        }
                    }
                }  
            }
        }
    }
}
}
</style>

<script>
export default {
    name: 'findPassword',
    layout: 'form',
    data(){
        return{
            method:'info',
            select: 'phone',
            sendBtn: false,
            okBtn: false,
            sendNum:false,
            checkNum:null,
            confirmData:{
                userName: null,
                userPhone: null,
                userEmail: null,
            },
            confirmPopup: {
                open: false,
                message: null
            },
        }
    },
    created(){
    },
    mounted(){
    },
    watch:{
        select:{
            handler(e){
                console.log(e)
            }
        },
        confirmData:{
            deep: true,
            handler(e){
                var info = (this.select == 'phone' ? e.userPhone : e.userEmail)
                if(String(e.userName) !== 'null' && String(info) !== 'null' ){
                    this.sendBtn = true;
                }
                if(String(e.userName).length == 0 || String(info).length==0){
                    this.sendBtn = false;
                }


                if(e.userPhone !== null){
                     e.userPhone = e.userPhone.replace(/[^0-9]/g, '');
                }
                if(e.userEmail !== null){
                    e.userEmail = e.userEmail.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, '');
                }

            }
        },
        checkNum:{
            handler(e){
                if(e.length > 3){
                    this.okBtn = true;  
                }
            }
        }
    },
    filters:{
    },
    methods:{
        confirm(){
            console.log(this.confirmData)
        },
        sendNumEvent(){
            var em = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;
            if(this.sendBtn){
                if(!em.test(this.confirmData.userEmail)){
                    return this.confirmPopupEvent('이메일을 정확히 입력해주세요..')
                }
                this.confirmPopupEvent('인증번호를 전송했습니다.')
                this.sendNum = true;
            }
        },
        confirmPopupEvent(msg){
            this.confirmPopup.open = true;
            this.confirmPopup.message = msg;
        },
        closePopup(){
            this.confirmPopup.open = false;
            if(this.joinFinBtn == true){
                console.log(this.$route)
                this.$router.push({ path: '/' })
            }
        },
    }
}

</script>
