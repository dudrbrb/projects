<template>
    <div id="container">
        <section id="login">
            <div>
                <h1>로그인</h1>
                <span>스픽클 계정으로 로그인</span>
                <input type="text" placeholder="이메일 주소 또는 아이디" v-model="account.id">
                <input type="password" placeholder="비밀번호" v-model="account.pw">
                <div class="flex-wrapper">
                    <div>
                        <input type="checkbox" name="saveID" id="saveID" v-model="saveId">
                        <label for="saveID" class="checkbox"></label>
                        <label for="saveID" class="font3">아이디 저장</label>
                    </div>
                    <div>
                        <input type="checkbox" name="autoLogin" id="autoLogin" v-model="autoLogin">
                        <label for="autoLogin" class="checkbox"></label>
                        <label for="autoLogin" class="font3">자동 로그인</label>
                    </div>
                </div>
                <button class="font6 gray" :class="{'pink': loginBtn}" @click="login">로그인</button>
                <ul>
                    <li id="findId"><nuxt-link :to="'/login/findAccount'" class="font3">아이디 찾기</nuxt-link> </li>
                    <li id="resetPW"><nuxt-link :to="'/login/findPassword'" class="font3">비밀번호 재설정</nuxt-link></li>
                    <li id="join"><nuxt-link :to="'/join'" class="font3">회원가입</nuxt-link></li>
                </ul>

                <div class="border">
                    <p>또는 다른 서비스 계정으로 가입</p>
                    <hr>
                </div>
                <div class="sns-list" >
                    <div id="kakao"><img :src="require('@/assets/img/login/kakao.webp')"></div>
                    <div id="naver"><img :src="require('@/assets/img/login/naver.webp')"></div>
                    <div id="facebook"><img :src="require('@/assets/img/login/facebook.webp')"></div>
                    <div id="apple"><img :src="require('@/assets/img/login/apple.webp')"></div>
                    <p class="font3">SNS계정으로 간편하게 가입하며 서비스를 이용하실 수 있습니다. <br> 
                        기존 스픽클 계정과는 연동되지 않으니 이용에 참고하세요.
                    </p>
                </div>
            </div>

        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{  
    #login{
        >div{
            h1{
                margin-bottom: 10px;
            }
            span{
                color: #6b6a6f;
                margin-bottom: 20px;
                font-size: 14px;
            }
            ul{
                @include flex();
                margin-top: 10px;
                li{
                    padding: 0 10px;
                    line-height: 18px;
                    a{
                        line-height: 18px;
                    }
                    &+li {
                        border-left: 1px solid $black;
                    }
                } 
            }
            
        }
    }
}

</style>

<script>
export default {
    name: 'login',
    layout: 'form',
    data(){
        return{
            account:{
                id: null,
                pw: null
            },
            saveId: false,
            autoLogin: false,
            loginBtn: false
        }
    },
    created(){
    },
    mounted(){
    },
    watch:{
        account:{
            deep: true,
            handler(e){
                if(String(e.id) !== 'null' && String(e.pw) !== 'null'){
                    this.loginBtn = true;
                }
                if(String(e.id).length== 0|| String(e.pw).length==0){
                    this.loginBtn = false;
                }
            }
        }
    },
    filters:{
    },
    methods:{
        login(){
            if(this.account.id !== 'test') return alert('일치하는 ID가 없습니다.')
            if(this.account.pw !== 'test123') return alert('비밀번호를 다시 확인해주세요.')
             
            this.setCookie('login')
        },
        setCookie(v) {
            this.$cookies.set(v, true, {
                path: '/',
                maxAge: 60 * 60 * 24 * 7
            });
            this.$router.push({ path: '/' });
        }
    }
}

</script>
