<template>
    <div id="container">
        <header>
            <div>
                <h1>Speakcls 뉴스</h1>
            </div>
        </header>
        <section id="board">
            <div>
                <article class="category">
                    <ul>
                        <li v-for="cate in category" :key="'자주묻는질문 - '+ cate.title">
                            <div  @click="page=cate.page; nowCate=cate.dataName; openIdx=null;" :class="{'act': page==cate.page}">{{cate.title}}</div> 
                            <ul v-if="cate.subCate && $device.isMobile==false">
                                <li v-for="sub in cate.subCate" :key="'자주묻는질문 - ' + sub.title"  >
                                    <div @click="page=cate.page; nowCate=sub.dataName; openIdx=null;" :class="{'act': nowCate==sub.dataName}">{{sub.title}}</div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <div class="input-wrapper" v-if="$device.isMobile && page=='FAQ'">
                        <input type="text" placeholder="궁금한 점을 찾아보세요.">
                    </div>

                    <div class="qna-cate" v-if="$device.isMobile && page=='FAQ'">
                        <ul>
                            <li v-for="sub in category[1].subCate" :key="'자주묻는질문 - ' + sub.title"  >
                                <div @click="nowCate=sub.dataName; openIdx=null;" :class="{'act': nowCate==sub.dataName}">{{sub.title}}</div>
                            </li>
                        </ul>
                    </div>
                    
                </article>
                <article class="board">
                    <div class="board-title" v-if="$device.isMobile==false">
                        <h4>{{page|pageToKorean}}</h4> 
                        
                        <input type="text" placeholder="궁금한 점을 찾아보세요.">
                    </div>
                    <ul class="board-list">
                        <li class="list-item" v-for="(item, idx) in list[nowCate]" :key="`게시판 글${idx}`" :value="idx" :class="{open: idx==openIdx}">
                            <div class="list-title" @click="openIdx==idx ? openIdx=null : openIdx=idx ">
                                <b >{{item.class}}</b>
                                <div>
                                    <p >{{idx}}{{item.title}}</p>
                                </div>
                                <button class="arrow" :class="{open: idx==openIdx}"></button>
                            </div>
                            <div class="list-text">
                                <p>{{item.content}} </p>
                            </div>
                        </li>
                    </ul>
                </article>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        height: 260px;
        >div{
            height: 100%;
            position: relative;
            @include flex(flex-start, flex-start, column);
            h1{
                margin-top: 130px;
                margin-bottom: 0;
            }
        }
    }
    #board{
        >div{
            margin-top: 0;
            @include flex(flex-start, flex-start);
            article{
                &.category{
                    >ul{
                        width: 230px;
                        margin-top: 6px;
                        li{
                            cursor: pointer;
                            div.act{
                                color: $pink;
                            }
                        }
                        >li{
                            font-size: 22px;
                            line-height: 22px;
                            &+li{
                                margin-top: 30px;
                            }
                            >ul{
                                margin-top: 10px;
                                >li{
                                    div{
                                        font-size: 16px;
                                        line-height: 38px;
                                        font-family: "SCDream3"
                                    }
                                }
                            }
                        }
                    }
                    .input-wrapper{
                        input{
                            height: 45px;
                        }   
                    }
                }
                &.board{
                    width: 100%;
                    .board-title{
                        @include flex(space-between);
                        border-bottom: 1px solid #686868;
                        padding-bottom: 10px;
                        h4{
                            font-size: 26px;
                            line-height: 24px;
                        }
                        input{
                            background-color: $white;
                            border: 1px solid #ccc;
                            background-image: url('@/assets/img/tutor/search.png');
                            background-repeat: no-repeat;
                            background-position:5px center;
                            background-size: 22px;
                            border-radius: 8px;
                            padding: 5px 5px 5px 40px;
                            width: 270px;
                            height: 40px;
                            font-size: 16px;
                            &::placeholder{
                                font-size: 16px;
                                color: #ccc;
                            }
                        }   
                    }
                    .board-list{
                        .list-item{
                            height: auto;
                            max-height: 70px;
                            overflow: hidden;
                            &.open{
                                max-height: 1000px;
                                .list-title{
                                    height: auto;
                                    div{
                                        p{
                                            text-overflow: clip !important;
                                            -webkit-line-clamp: 10;
                                            overflow: visible;
                                            word-break: break-all;
                                            padding: 13px 0;
                                        }
                                    }
                                }
                            }
                            .list-title{
                                @include flex(flex-start);
                                width: 100%;
                                min-height: 70px;
                                height: 70px;
                                border-bottom: 1px solid #cdcdcd80;
                                cursor: pointer;
                                b{
                                    font-size: 16px;
                                    width: 140px;
                                    font-family: "SCDream4";
                                    letter-spacing: -0.6px;
                                }
                                div{
                                    width: 95%;
                                    margin-right: 20px;
                                    p{
                                        font-size: 16px;
                                        line-height: 22px;
                                        text-overflow: ellipsis;
                                        width: 100%;
                                        display: -webkit-box;
                                        overflow: hidden;
                                        -webkit-line-clamp: 2;
                                        -webkit-box-orient: vertical;
                                        word-break: break-all;
                                    }
                                }
                                button.arrow{
                                    width: 20px;
                                    min-width: 20px;
                                    height: 20px;
                                    background: url('@/assets/img/down-arrow.png') no-repeat center;
                                    background-size: contain;
                                    margin-left: auto;
                                    &.open{
                                        transform: rotate(180deg);
                                    }
                                }
                            }
                            .list-text{
                                padding: 20px 0 20px 115px;
                                width: 100%;
                                p{
                                    font-size: 15px;
                                    line-height: 24px;
                                }
                            }
                        }
                    }
                    
                }
            }
        }
    }
}
@media screen and (max-width: 1023px) {
#container{
    #board{
        >div{
            article{
                &.category{
                    ul{
                        width: 210px;
                    }
                }
            }
        }
    }
}
}
@media screen and (max-width: 820px) {
#container{
    #board{
        >div{
            article{
                &.category{
                    ul{
                        width: 190px;
                    }
                }
            }
        }
    }
}
}
@media screen and (max-width: 767px) {
#container{
    &.login{
        padding-top: 30px;
    }
    section{
        padding: 0;
    }
    header{
        height: 70px;
        h1{
            display: none;
        }
    }
    #board{
        >div{
            flex-direction: column;
            article{
                width: 100%;
                &.category{
                    margin-bottom: 5px;
                    ul{
                        padding: 0 20px;
                        width: 100%;
                        @include flex(center, flex-start);
                        >li{
                            width: 50%;
                            position: relative;
                            font-size: 18px;
                            div{
                                text-align: center;
                                height: 45px;
                                line-height: 45px;
                                &.act{
                                    border-bottom: 2px solid $pink;
                                }
                            }
                            &+li{
                                margin: 0;
                            }
                        }
                    }
                    .qna-cate{
                        width: 100%;
                        margin-top: 10px;
                        ul{
                            justify-content: flex-start;
                            overflow-x: scroll;
                            height: auto;
                            -ms-overflow-style: none;
                            &::-webkit-scrollbar{
                                display:none;
                            }
                            li{
                                margin: 0 5px;
                                width: auto;
                                div{
                                    background-color: #ececec;
                                    padding: 3px 10px;
                                    border-radius: 5px;
                                    white-space: nowrap;
                                    width: 100%;
                                    height: 40px;
                                    line-height: 38px;
                                    font-size: 16px;
                                    font-family: "SCDream4";
                                    &.act{
                                        border: none;
                                        background-color: $pink;
                                        color: $white;
                                    }
                                }
                            }
                        }
                    }
                    .input-wrapper{
                        background: #ececec;
                        padding: 15px 20px;
                        input{
                            background-color: $white;
                            border: 1px solid #ccc;
                            background-image: url('@/assets/img/tutor/search.png');
                            background-repeat: no-repeat;
                            background-position:5px center;
                            background-size: 22px;
                            border-radius: 8px;
                            padding: 5px 5px 5px 40px;
                            width: 100%;
                            height: 50px;
                            font-size: 16px;
                            &::placeholder{
                                font-size: 16px;
                                color: #ccc;
                            }
                        }   
                    }
                    
                }
                &.board{
                    padding: 0 20px;
                    .board-list{
                        .list-item{
                            max-height: 82px;
                            .list-title{
                                flex-wrap: wrap;
                                height: auto;
                                padding: 8px 0;
                                align-items: flex-start;
                                b{
                                    width: 100%;
                                    font-size: 16px;
                                    color: #686868;
                                }
                                div{
                                    width: 90%;
                                    margin-right: 0;
                                    height: auto;
                                    p{
                                        height: auto;
                                        font-size: 16px;
                                        line-height: 20px;
                                    }
                                }
                                .arrow{
                                    width: 10%;
                                }
                            }
                            .list-text{
                                padding: 10px 0;
                            }
                            &.open{
                                .list-title div p{
                                    padding: 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
</style>

<script>
export default {
    name: 'news',
    layout: 'default',
    data(){
        return{
            page: 'notice',
            nowCate: 'notice',
            openIdx: null,
            category:[
                {title: '공지사항',page:'notice', dataName:'notice'},
                {title: 'FAQ', page:'FAQ',dataName:'account', subCate:[
                    {title: '회원가입/계정', dataName: 'account'},
                    {title: '서비스 이용법', dataName: 'service'},
                    {title: '자막의뢰', dataName: 'caption'},
                    {title: '가격/마일리지/할인', dataName: 'price'},
                    {title: '결제/취소', dataName: 'payment'},
                    {title: 'Youtube 계정 연동', dataName: 'youtube'},
                    {title: '기타문의', dataName: 'etc'}
                ]},
            ],
            list:{
                notice:[
                    {title: '항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며 항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며 ',
                    class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                    class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                    {title: '공지사항 ',
                     class: '공지',
                    content: `안녕하세요.
                            자메이크 입니다.
    
                            항상 자메이크를 이용해주시는 고객 여러분들께 감사드리며,
                            프리미엄 옵션 일부 변경과 관련하여 안내 드립니다.👨🏻‍🏫
                            기존 운영하던 최상위 번역가 직접 선택은
                            납품 일정 관련하여 조율이 필요한 경우가 많고 동일한 작업자 분배가 어려운 경우가 많아
                            22년 05월 31일부로 자동 분배로 변경 예정입니다.
    
                            이전 작업자를 요청하신다면
                            프리미엄 요청사항 또는 고객센터로 문의 부탁드립니다.`
                    },
                ],
                account:[
                    {title: '한 개의 계정으로 여러 개의 채널을 연동할 수 있나요? ',
                    class: '계정',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '한 개의 계정으로 여러 개의 채널을 연동할 수 있나요? ',
                    class: '계정',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '한 개의 계정으로 여러 개의 채널을 연동할 수 있나요? ',
                    class: '계정',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '한 개의 계정으로 여러 개의 채널을 연동할 수 있나요? ',
                    class: '계정',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '외국인이나 해외에 거주하는 사람도 회원가입 할 수 있나요? ',
                    class: '회원가입',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '외국인이나 해외에 거주하는 사람도 회원가입 할 수 있나요? ',
                    class: '회원가입',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ],
                service:[
                    {title: '서비스 이용법 서비스 이용법 서비스 이용법 ',
                    class: '서비스 이용법',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '서비스 이용법 서비스 이용법 서비스 이용법 ',
                    class: '서비스 이용법',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '서비스 이용법 서비스 이용법 서비스 이용법 ',
                    class: '서비스 이용법',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '서비스 이용법 서비스 이용법 서비스 이용법 ',
                    class: '서비스 이용법',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '서비스 이용법 서비스 이용법 서비스 이용법 ',
                    class: '서비스 이용법',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '서비스 이용법 서비스 이용법 서비스 이용법 ',
                    class: '서비스 이용법',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ],
                caption:[
                    {title: '자막자막자막자막자막자막자막자막',
                    class: '자막 의뢰',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '자막자막자막자막자막자막자막자막',
                    class: '자막 의뢰',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ],
                price:[
                    {title: '가격',
                    class: '가격',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '마일리지',
                    class: '마일리지',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '할인',
                    class: '할인',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ],
                payment:[
                    {title: '결제결제결제결제결제결제결제',
                    class: '결제',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '결제결제결제결제결제결제결제',
                    class: '결제 취소',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ],
                youtube:[
                    {title: '계정연동계정연동계정연동계정연동계정연동 ',
                    class: '계정연동',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '계정연동계정연동계정연동계정연동계정연동 ',
                    class: '계정연동',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '계정연동계정연동계정연동계정연동계정연동 ',
                    class: '계정연동',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '계정연동계정연동계정연동계정연동계정연동 ',
                    class: '계정연동',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '계정연동계정연동계정연동계정연동계정연동 ',
                    class: '계정연동',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ],
                etc:[
                    {title: '기타기타기타기타기타',
                    class: '기타',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '기타기타기타기타기타',
                    class: '기타',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '기타기타기타기타기타',
                    class: '기타',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                    {title: '기타기타기타기타기타',
                    class: '기타',
                    content: `네, 가능합니다.
    
                            로그인 후, 
                            홈페이지 우측 상단의 '지금 시작하기' > '내 정보' > '연동채널 관리' > '채널 추가하기'
                            를 통해 하나의 계정에서 여러 개의 YouTube 채널을 연동 및 관리하실 수 있습니다. 
    
                            * 채널 연동 개수에는 제한이 없습니다. `
                    },
                ]
            },
            common: [],
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
		'$route' (to, from) {
            this.page = to.query.page;
            this.page == 'FAQ'? this.nowCate = 'account' :  this.nowCate ='notice'
		}
    },
    filters:{
        pageToKorean(v){
            if(v=='notice') return v = '공지사항'
            else return v
        }
    },
    methods:{
        getPagePath(){
            this.page = this.$route.query.page;
            this.page == 'FAQ'? this.nowCate = 'account' :  this.nowCate ='notice'
        }
    }
}

</script>
