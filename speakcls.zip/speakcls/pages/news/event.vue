<template>
    <div id="container">
        <header>
            <div>
                <h1>이벤트</h1>
                <ul class="status-tab">
                    <li @click="clickStatus('전체')" :class="{act: statusTab=='전체'}">전체</li>
                    <li @click="clickStatus('진행중')" :class="{act: statusTab=='진행중'}">진행중</li>
                    <li @click="clickStatus('종료')" :class="{act: statusTab=='종료'}">종료</li>
                    <div class="tab-bar"></div>
                </ul>
            </div>
        </header>
        <hr>
        <section id="eventList">
            <div>
                <div class="event-list" v-if="selectedEvents.length>0">
                    <div class="event" v-for="(event, idx) in selectedEvents" :key="`event${idx}`" v-if="idx >= (12*(pagination-1)) && idx < (12*pagination) ">
                        <div class="img-box">
                            <img :src="require(`@/assets/img/event/1.webp`)" alt="이벤트 이미지">
                        </div>
                        <div class="txt-box">
                            <div class="info">
                                <span class="status">{{event.status}}</span>
                                <span class="date">{{event.startDate}} ~ {{event.finishDate}}</span>
                            </div>
                            <div class="title">
                                {{idx}} {{event.title}}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="event-list" v-else>
                    <div class="event" v-for="(event, idx) in events" :key="`event${idx}`" v-if="idx >= (12*(pagination-1)) && idx < (12*pagination) ">
                        <div class="img-box">
                            <img :src="require(`@/assets/img/event/1.webp`)" alt="이벤트 이미지">
                            <!-- <img :src="require(`@/assets/img/event/${idx}.webp`)" alt="이벤트 이미지"> -->
                        </div>
                        <div class="txt-box">
                            <div class="info">
                                <b class="status">{{event.status}}</b>
                                <span class="date">{{event.startDate}} ~ {{event.finishDate}}</span>
                            </div>
                            <div class="title">
                                {{idx}} {{event.title}}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="event-pagination" v-if="selectedEvents.length>0">
                    <button @click="pagination==1 ?'':pagination--" class="prev-btn"></button>
                    <button v-for="i in Math.ceil(selectedEvents.length/12)" :key="`pagination btn ${i}`" @click="pagination = i" :class="{'active': pagination==i}">
                        {{i}}
                    </button>
                    <button @click="pagination==Math.ceil(events.length/12) >1 ?'':pagination++" class="next-btn"></button>
                </div>
                <div class="event-pagination" v-else>
                    <button @click="pagination==1 ?'':pagination--" class="prev-btn"></button>
                    <button v-for="i in Math.ceil(events.length/12)" :key="`pagination btn ${i}`" @click="pagination = i" :class="{'active': pagination==i}">
                        {{i}}
                    </button>
                    <button @click="pagination==Math.ceil(events.length/12)?'':pagination++" class="next-btn"></button>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        height: 260px;
        >div{
            height: 100%;
            position: relative;
            @include flex(flex-start, flex-start, column);
            h1{
                margin-top: 130px;
                margin-bottom: 0
            }
            .status-tab{
                @include flex(flex-start);
                width: auto;
                margin-top: auto;
                position: relative;
                li{
                    color: rgb(99, 100, 105);
                    padding: 10px 0;
                    width: 80px;
                    font-size: 20px;

                    text-align: center;
                    cursor: pointer;
                    &.act{
                        color: $pink;
                    }
                }
                .tab-bar{
                    position: absolute;
                    width: 80px;
                    height: 6px;
                    background-color: $pink;
                    bottom: 0;
                    transition: all 0.35s;
                }
            }
        }
    }
    hr{
        border: 0;
        height: 1px;
        background-color: $gray;
    }
    #eventList{
        >div{
            .event-list{
                @include flex(center, flex-start);
                flex-wrap: wrap;
                .event{
                    width: 290px;
                    overflow: hidden;
                    cursor: pointer;
                    margin-right: 5%;
                    &:nth-child(3n){
                        margin-right: 0;
                    }
                
                    &:last-child{
                        margin-right: auto;
                    }
                    .img-box{
                        width: 100%;
                        height: 300px;
                        img{
                            width: 100%;
                            height: 100%;
                            object-fit: cover;
                        }
                    }
                    .txt-box{
                        .info{
                            margin-top: 8px;
                            .status{
                                font-size: 16px;
                                color: $grayOnGray;
                                margin-right: 6px;
                                font-family: "SCDream4";
                            }
                            .date{
                                font-size: 16px;
                            }
                        }
                        .title{
                            width: 100%;
                            height: 120px;
                            font-size: 22px;
                        }
                        
                    }
                  
                }
            }
            .event-pagination{
                width: 100%;
                margin-top: 30px;
                @include flex();
                button{
                    background-color: $white;
                    border: 1px solid rgb(228, 228, 228);
                    color: $pink;
                    width: 40px;
                    height: 40px;
                    margin: 0px;
                    font-family: 'SCDream4';
                    font-size: 18px;
                    &:hover{
                        border-color: $pink;
                    }
                    &.active{
                        background-color: $pink;
                        border-color: $pink;
                        color: $white;
                    }
                    &.prev-btn,
                    &.next-btn{
                        background-image: url('@/assets/img/tutor/arrow.webp');
                        background-repeat: no-repeat;
                        background-position: center;
                    }
                    &.prev-btn{
                        transform: rotate(180deg);
                    }
                }
            }
            
        }
    }


}

@media screen and (max-width: 1024px) {
    #container{
        #eventList{
            >div{
                max-width: 620px;
                .event-list{
                    .event{
                        &:nth-child(3n){
                            margin-right:  5%;
                        }
                        &:nth-child(2n){
                            margin-right:  0;
                        }
                        &:last-child{
                            margin-right: auto;
                        }
                    }
                }
            }
        }
    }

}

@media screen and (max-width: 767px) {
    #container{
        &.login{
            padding-top: 30px;
        }
        header{
            height: 120px;
            h1{
                display: none;
            }
            >div{
                .status-tab{
                    width: 100%;
                    li{
                        width: 33%;
                        font-size: 18px;
                    }
                    .tab-bar{
                        width: 33%;
                        height: 3px;
                    }
                }
            }
        }
        #eventList{
            >div{
                max-width: 1000px;
                margin-top: 20px;
                .event-list{
                    .event{
                        margin-right: 0;
                        .txt-box{
                            .title{
                                font-size: 18px;
                                height: auto;
                                min-height: 60px;
                                margin-bottom: 10px;
                            }
                        }
                        &:nth-child(3n),
                        &:nth-child(2n),
                        &:last-child{
                            margin-right:  0;
                        }
                    }
                }
            }
        }
    }

}
</style>

<script>
export default {
    name: 'event',
    layout: 'default',
    data(){
        return{
            statusTab: 'all',
            pagination: 1,
            selectedEvents:[],
            events:[
                {
                    title: '이벤트입니다',
                    startDate: '2022.03.23',
                    finishDate: '2022.03.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.01.05',
                    finishDate: '',
                    status: '상시'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '종료'
                },
                {
                    title: '이벤트입니다이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '종료'
                },
                {
                    title: '이벤트입니다이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '종료'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '종료'
                },
                {
                    title: '이벤트입니다이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '종료'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
                {
                    title: '이벤트입니다',
                    startDate: '2022.04.23',
                    finishDate: '2022.06.28',
                    status: '진행중'
                },
            ],
            common:[]
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
        statusTab:{
            handler(e){
                var num;
                var bar = this.$el.querySelector('.tab-bar');

                if(e == '전체') num = 0
                else if(e == '진행중') num = 1
                else if(e == '종료') num = 2;

                
                bar.style.left = ( this.$device.isMobile? `${num*33}%` : `${num*80}px`)
            }
        }
    },
    methods:{
        clickStatus(t){
            this.statusTab = t;
            this.selectedEvents = [];
            this.pagination = 1;
            
            if(t=="전체") return this.selectedEvents = this.events;

            this.events.forEach(e => {
                if(t =='진행중'){
                    if(e.status=='상시')this.selectedEvents.push(e)
                }
                if(e.status == t) this.selectedEvents.push(e)
            });
        }
    }
}

</script>
