<template>
    <div class="daily-wrapper">
        <div class="daily-title">
            <h4>{{currentYear}}년 {{(currentMonth+1)}}월</h4>
            <div class="btn-wrap">
                <v-btn icon @click="addMonth('prev')">
                    <v-icon>mdi-chevron-left</v-icon>
                </v-btn>
                <v-btn icon @click="addMonth('next')">
                    <v-icon>mdi-chevron-right</v-icon>
                </v-btn>
            </div>
        </div>
        <div class="table-wrapper">
            <div class="cal_wrap">
                <div class="days">
                <div class="day">Sun</div>
                <div class="day">Mon</div>
                <div class="day">Tue</div>
                <div class="day">Wed</div>
                <div class="day">Thu</div>
                <div class="day">Fri</div>
                <div class="day">Sat</div>
                </div>
                <div class="dates">
                    <div class="day prev disable" v-for="(days, idx) in calendarDateBefore" :key="`day before${idx}`">
                        <span>{{days}}</span>
                    </div>
                    <div  v-for="(days, idx) in calendarDate" :key="`day${idx}`" :fulldate="`${days.year}-${days.month}-${days.day}`" :year="days.year" :month="days.month"
                        :class="['day', 'current', {'holiday': days.dayOfWeek=='토'||days.dayOfWeek=='일'},
                                {'today':(days.year ==  date.getFullYear()) && (days.month ==  date.getMonth()) &&(days.day ==  date.getDate())},
                                {'today-op': (days.year ==  date.getFullYear()) && (days.month ==  date.getMonth()) &&(days.day ==  date.getDate()) && (selectDay !== days.day)}, 
                                {'act': selectDay == days.day}
                            ]" 
                        @click="clickDay(days.year, days.month, days.day)">
                        <span :class=" [{'pd' : days.day >= 10}, {'pd2': days.day >=20}]">{{days.day}}</span>
                        <div class="point" v-if="days.point" :class="{purple : days.status == '정규 수업'}"></div>
                    </div>
                    <div class="day next disable" v-for="(days, idx) in calendarDateAfter" :key="`day after${idx}`">
                        <span>{{days}}</span>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</template>
<style lang="scss" scoped>
.daily-wrapper{
    padding: 20px;
    .daily-title{
        margin-bottom: 20px;
        @include flex(space-between);
        h4{
            font-size: 24px;
        }

    }
    .table-wrapper{
        width: 100%;
        max-width: 2000px;
        overflow:auto;
        .cal-title {
            @include flex(space-between);
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 10px;
            .year-month {
                text-align: left;
                line-height: 1;
            }
            .nav {
                display: flex;
                button{
                    border: 1px solid rgb(243, 243, 243);
                    width: 25px;
                    height: 25px;
                    background: url('@/assets/img/arrow.png') no-repeat center;
                    background-size: 7px;
                    &.prev-month{
                        transform: rotate(180deg);
                    }
                }
            }
        }
        .cal_wrap {
            padding-top: 20px;
            position: relative;
            margin: 0 auto;
            &::after {
                top: 368px;
            }
            .days{
                @include flex();
                border-bottom: 2px solid #f5f2fc;
                .day{
                    width:  calc(100% / 7);
                    height: 60px;
                    font-size: 16px;
                    text-align: center;
                    line-height: 60px;
                    background-color: $pink;
                    color: $white;
                }
            }
            .dates {
                @include flex(flex-start, flex-start);
                flex-wrap: wrap;
                .day {
                    width:  calc(100% / 7);
                    height: 70px;
                    min-width: 50px;
                    line-height:45px;
                    cursor: pointer;
                    span{
                        display: inline-block;
                        font-size: 16px;
                        border-radius: 50%;
                        width: 30px;
                        height: 30px;
                        line-height: 30px;
                        text-align: center;
                        &.pd{
                            padding: 0 3px 0 0px;
                        }
                        &.pd2{
                            padding: 0 2px 0 0px;
                        }
                    }
                    &.disable span{
                        color: $grayOnGray;
                        cursor: default;
                    }
                    &.prev,
                    &.next{
                        background-color: #f5f2fc;
                    }
                    &.act,
                    &.today{
                        span{
                            background-color: $pink;
                            coloR: $white;
                        }
                    }
                    &.today-op{
                        span{
                            color: #333;
                            background-color: #ebebeb;
                        }
                    }
                    .point{
                        width: 5px;
                        height: 5px;
                        background-color: $pink;
                        border-radius: 50%;
                        margin: -5px auto 0;
                        z-index: 1;
                        &.purple{
                                background-color: #6739e0;
                        }
                    }
                    
                    
                }
                &::-webkit-scrollbar{
                    display:none;
                }
                
            }
        }
    }
}
</style>
<script>

export default {
    name: 'AdminMember',
    layout: 'admin',
    components:{},
    data(){
        return {
            tutorData: null,
            date: new Date(), // 현재 날짜(로컬 기준) 가져오기
            utc : null, // uct 표준시 도출
            today : null, // 한국 시간으로 date 객체 만들기(오늘)
            thisMonth : null,
            currentYear : null,
            currentMonth: null,
            currentDayOfWeek: new Date().getDay(),

            // 이번 달의 마지막날 날짜와 요일 구하기
            endDay  : null,
            nextDate : null,
           
            // 스크롤 범위 구하기 위한 인덱스
            monthIndex: 0,
            showYear: new Date().getFullYear(),
            showMonth: new Date().getMonth() +1,

            calendarDate:[],
            calendarDateBefore:[],
            calendarDateAfter:[],

            todayTitle: null,
            selectDay: new Date().getDate(),

             userData:[
                {title:'정규 수업',
                 date: '2022-6-23',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'2022 지방선거',
                 date: '2022-6-30',
                 time: 'all',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-7-3',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-7-6',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'빨간날',
                 date: '2022-7-10',
                 time: 'all',
                 cancle: false,
                 question: false},
                  {title:'정규 수업',
                 date: '2022-6-30',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
               
            ],

        }
    },
    filters:{
    },
    
    async fetch() {
        await this.$axios.$get('api/tutor').then(data =>{
            this.tutorData = data;
        }).catch((error)=>{
            console.log(error.data)
        });
    },
    created(){
        this.$nuxt.$emit("pageTitle", '월간 스케쥴')
    },
    mounted(){
        this.calendarInit()
    },
    methods:{
        calendarInit() {
            this.utc= this.date.getTime() + ( this.date.getTimezoneOffset() * 60 * 1000), // uct 표준시 도출
            this.today = new Date( this.utc +  9 * 60 * 60 * 1000), // 한국 시간으로 date 객체 만들기(오늘)
            
            this.thisMonth = new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate());
            // 달력에서 표기하는 날짜 객체
        
            this.currentYear = this.thisMonth.getFullYear(); // 달력에서 표기하는 연
            this.currentMonth = this.thisMonth.getMonth(); // 달력에서 표기하는 월

            // 캘린더 렌더링
            this.renderCalender(this.thisMonth);
        },
        renderCalender() {
            // 렌더링을 위한 데이터 정리
            this.currentYear = this.thisMonth.getFullYear();
            this.currentMonth = this.thisMonth.getMonth();

            // 이번 달의 마지막날 날짜와 요일 구하기
            this.endDay = new Date(this.currentYear, this.currentMonth + 1, 0);
            this.nextDate = this.endDay.getDate();

            // 렌더링 html 요소 생성
            var calendar = document.querySelector('.dates')
            var week = ['일', '월', '화', '수', '목', '금', '토']
            
            // 지난달
            var startDay = new Date(this.currentYear, this.currentMonth, 0);
            var prevDate = startDay.getDate();
            var prevDay = startDay.getDay();
            
             // 이번 달의 마지막날 날짜와 요일 구하기
            var endDay = new Date(this.currentYear, this.currentMonth + 1, 0);
            var nextDate = endDay.getDate();
            var nextDay = endDay.getDay();

            // 지난달
            for (var i = prevDate - prevDay ; i <= prevDate; i++) {
                this.calendarDateBefore.push(i)
                if(this.calendarDateBefore.length >= 7) this.calendarDateBefore = [];
            }
            // 이번달
            for (var i = 1; i <= nextDate; i++) {
                var dayOfWeek = week[new Date(this.currentYear+'-'+(this.currentMonth+1)+'-'+i).getDay()];

                 this.calendarDate.push({'dayOfWeek': dayOfWeek, 'year': this.currentYear, 'month': this.currentMonth + 1, 'day': i, 'fulldate':this.currentYear +'-'+(this.currentMonth+1)+'-'+i})
            }
            // 다음달

            for (var i = 1; i <= (6 - nextDay == 7 ? 0 : 6 - nextDay); i++) {
                this.calendarDateAfter.push(i)
              
            }
           
            this.checkDate();
            this.monthIndex = this.monthIndex +1;
        },
        addMonth(v){
            this.calendarDate = [];
            this.calendarDateAfter = [];
            this.calendarDateBefore = [];
            this.selectDay = 1;
            
            this.currentMonth= this.currentMonth +(v == 'next'? 1 : -1);
            this.thisMonth = new Date(this.currentYear, this.currentMonth, 1);

            this.currentDayOfWeek = new Date(this.thisYear+'-'+this.thisMonth+'-'+1).getDay();
            
            this.renderCalender(this.thisMonth); 
        },
        checkScroll(e){
            var scrollX = e. target.scrollLeft;
         
            if(scrollX > 150*this.monthIndex){
                this.addMonth();
            }
        },

        checkDate(){
            var dates=[];
            this.userData.forEach(e=>{
                dates.push({date: e.date, title: e.title})
            });

            dates.forEach(e=>{
                this.calendarDate.forEach(d=>{
                    if(e.date == d.fulldate) {
                        d.point = true;
                        d.status = e.title
                    }
                })
            });
        },
        clickDay(year, month, day){
            // this.selectDay = day; 
            // this.currentDayOfWeek = new Date(year+'-'+month+'-'+day).getDay();

            this.$router.push({ path: '/admin/class/class' });
        },

    }

  }
</script>