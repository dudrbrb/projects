<template>
    <div class="weekly-wrapper">
        <div class="weekly-title">
            <h4>{{todayTitle}}</h4>
            <div class="btn-wrap">
                <v-btn icon @click="getDate('prev')">
                    <v-icon>mdi-chevron-left</v-icon>
                </v-btn>
                <v-btn icon @click="getDate('next')">
                    <v-icon>mdi-chevron-right</v-icon>
                </v-btn>
            </div>
        </div>
        <div class="table-wrapper">
            <table>
                <thead> 
                    <tr>
                        <th>Time</th>
                        <th v-for="days in thisWeek" :key="`${days.day}`">
                            {{days.day.split('-')[2]}}<br>
                            <span>{{days.week}}요일</span>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(time, idx) in time" :key="`time${idx}`">
                        <td> {{time}} </td>
                        <td v-for="(days, idx) in thisWeek" :key="`days${idx}`"></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>
<style lang="scss" scoped>
.weekly-wrapper{
    padding: 20px;
    .weekly-title{
        margin-bottom: 20px;
        @include flex(space-between);
        h4{
            font-size: 24px;
        }

    }
    .table-wrapper{
        width: 100%;
        max-width: 2000px;
        overflow:auto;
        table{
            white-space:nowrap;
            border-collapse:collapse;
            background-color: $white;
            tr{
                td, th{
                    text-align: center;
                    padding: 10px 15px;
                    border: 0;
                    border-collapse : collapse;
                    word-break: keep-all;
                    white-space: nowrap;
                    vertical-align: top;
                    &:first-child{
                        width: 100px;
                    }
                }
            }
    
            thead{
                border: 1px solid #ff469c;
                background-color: $pink;
                border-radius: 5px;
                tr{
                    th{
                        color: $white;
                        border-left: 1px solid #ff469c;
                        vertical-align: middle;
                        &:first-child{
                            padding: 10px;
                        }
                        span{
                            color: $white;
                            font-size: 16px;
                        }
                    }
                }
            }
            tbody{
                border: 1px solid #eaeaea;
                tr{
                    height: auto;
                    &:nth-child(even){
                        background-color: #f8f8f8e7;
                    }
                    td{
                        border-left: 1px solid #eaeaea;
                    }
                }
            }
        }
    }
}
</style>
<script>

export default {
    name: 'AdminMember',
    layout: 'admin',
    components:{},
    data(){
        return {
            today: null,
            todayTitle: null,
            thisWeek: [],
            gap: 0,
            tutorData: null,
            week: ['일', '월', '화', '수', '목', '금', '토'],
            time: ['14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30', ]
        }
    },
    async fetch() {
        await this.$axios.$get('api/tutor').then(data =>{
            this.tutorData = data;
        }).catch((error)=>{
            console.log(error.data)
        });
    },
    created(){
        this.$nuxt.$emit("pageTitle", '주간 스케쥴')
    },
    mounted(){
        this.makeTitle()
        this.getDate()
    },
    methods:{
        getDate(v){
            this.thisWeek = [];
            if (v == 'next') this.gap = this.gap + 7;
            else if (v == 'prev') this.gap = this.gap - 7;


            this.today = new Date(new Date().setDate(new Date().getDate() + this.gap)); 
            var theYear = this.today.getFullYear();
            var theMonth = this.today.getMonth();
            var theDate  = this.today.getDate();
            var theDayOfWeek = this.today.getDay();
            
 
    
            for(var i=0; i<7; i++) {
                var resultDay = new Date(theYear, theMonth, theDate + (i - theDayOfWeek));
                var yyyy = resultDay.getFullYear();
                var mm = Number(resultDay.getMonth()) + 1;
                var dd = resultDay.getDate();
                var ww = resultDay.getDay();
                
                mm = String(mm).length === 1 ? '0' + mm : mm;
                dd = String(dd).length === 1 ? '0' + dd : dd;
                
                this.thisWeek.push({day:  yyyy + '-' + mm + '-' + dd, week: this.week[ww]});
            }
            
        }, 
        makeTitle(){
            this.today = new Date(new Date().setDate(new Date().getDate() )); 
            var y = this.today.getFullYear();
            var m = this.today.getMonth();
            var d  = this.today.getDate();
            

            this.todayTitle = y + '년 ' + (m + 1) + "월 " + d + '일';
        }
    }

  }
</script>