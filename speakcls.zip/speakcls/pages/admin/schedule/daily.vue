<template>
    <div class="daily-wrapper">
        <div class="daily-title">
            <h4>{{todayTitle}}</h4>
            <div class="btn-wrap">
                <v-btn icon @click="getDate('prev')">
                    <v-icon>mdi-chevron-left</v-icon>
                </v-btn>
                <v-btn icon @click="getDate('next')">
                    <v-icon>mdi-chevron-right</v-icon>
                </v-btn>
            </div>
        </div>
        <div class="tool-wrapper">
            <div class="input-box">
                <label>강사 검색</label>
                <v-select :items="tutorNames" v-model="selectTutor"></v-select> 
                <button v-if="searchData !== null" class="red reset"  @click="searchData = null; selectTutor = null;" >초기화</button>
            </div>
        </div>
        <div class="table-wrapper">
            <table v-if="searchData == null">
                <thead> 
                    <tr>
                        <th>Time</th>
                        <th v-for="(tutor, idx) in tutorData" :key="`tutor${idx}`">{{tutor.tutorName}}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(time, idx) in time" :key="`time${idx}`">
                        <td> {{time}} </td>
                        <td v-for="(tutor, idx) in tutorData" :key="`tutor${idx}`"></td>
                    </tr>
                </tbody>
            </table>
            <table v-else>
                <thead> 
                    <tr>
                        <th>Time</th>
                        <th>{{searchData[0].tutorName}}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(time, idx) in time" :key="`time${idx}`">
                        <td> {{time}} </td>
                        <td></td>
                    </tr>
                </tbody>
            </table> 
        </div>
    </div>
</template>
<style lang="scss" scoped>
.daily-wrapper{
    padding: 20px;
    .daily-title{
        @include flex(space-between);
        h4{
            font-size: 24px;
        }
    }
    .tool-wrapper{
        margin-bottom: 20px !important;
        justify-content: flex-start !important;
        padding: 20px 0 !important;
        .input-box{
            @include flex();
            label{
                margin-right: 10px;
            }
            .v-input{
                max-width: 170px !important;
                .v-select__selection--comma{
                    margin-left: 10px !important;
                }
            }
            button{
                padding: 3px 10px;
                border-radius: 5px;
                margin-left: 10px;
            }
        }
    }
    .table-wrapper{
        width: 100%;
        max-width: 2000px;
        overflow:auto;
        table{
            white-space:nowrap;
            border-collapse:collapse;
            background-color: $white;
            tr{
                td, th{
                    text-align: center;
                    padding: 10px 15px;
                    border: 0;
                    border-collapse : collapse;
                    word-break: keep-all;
                    white-space: nowrap;
                    vertical-align: top;
                    &:first-child{
                        width: 100px;
                    }
                }
            }
    
            thead{
                border: 1px solid #ff469c;
                background-color: $pink;
                border-radius: 5px;
                tr{
                    th{
                        color: $white;
                        border-left: 1px solid #ff469c;
                        &:first-child{
                            padding: 10px;
                        }
                    }
                }
            }
            tbody{
                border: 1px solid #eaeaea;
                tr{
                    height: auto;
                    &:nth-child(even){
                        background-color: #f8f8f8e7;
                    }
                    td{
                        border-left: 1px solid #eaeaea;
                    }
                }
            }
        }
    }
}
</style>
<script>

export default {
    name: 'AdminMember',
    layout: 'admin',
    components:{},
    data(){
        return {
            today: null,
            todayTitle: null,
            gap: 0,
            tutorData: null,
            tutorNames: null,
            selectTutor: null,
            searchData: null,
            time: ['14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30', ]
        }
    },
    async fetch() {
        await this.$axios.$get('api/tutor').then(data =>{
            this.tutorData = data;
        }).catch((error)=>{
            console.log(error.data)
        });
    },
    created(){
        this.$nuxt.$emit("pageTitle", '오늘 스케쥴')
    },
    mounted(){
        this.getDate()
    },
    watch:{
        tutorData:{
            deep: true,
            handler(d){
                if(d == null) return
                this.tutorNames  = [];
                d.forEach(e => {
                    this.tutorNames.push(e.tutorName)
                    
                });
            }
        },
        selectTutor:{
            async handler(v){
                this.$axios.$get('/api/search/tutor',
                    {params:{tag: 'tutorName', text: v}},
                    { withCredentials: true }).then(data =>{
                    console.log(data)
                    this.searchData = data;
                    
                }).catch((error)=>{
                    console.log(error.data)
                });
            }
        }
    },
    methods:{
        getDate(v){
            if (v == 'next') this.gap++;
            else if (v == 'prev') this.gap--;
            
            this.today = new Date(new Date().setDate(new Date().getDate() + this.gap));

            var year = this.today.getFullYear(),
                month = ('0' + (this.today.getMonth() + 1)).slice(-2),
                day = ('0' + this.today.getDate()).slice(-2);

            this.todayTitle =  year + '년 ' + month  + '월 ' + day + '일';
        }, 
    }

  }
</script>