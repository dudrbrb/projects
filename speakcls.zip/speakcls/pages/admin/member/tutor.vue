<template>
    <div>
        <Popup v-if="popup.open" :path="'tutor'" :value="popup.value" :selectData="popup.data"></Popup>
        <div class="tool-wrapper">
            <div class="search-wrapper">
                <b>검색하기</b>
                <div class="search-box">
                    <div class="select-wrapper">
                        <input class="select" name="searchTag" id="searchTag" v-model="search.tagKor" readonly @click="search.open = !search.open" :class="{act: search.tagKor !== '선택'}">
                        <ul class="options" v-if="search.open">
                            <li v-for="(filter, idx) in filter" :key="`filter${idx}`" @click="selectOption(filter.text, filter.value)" >
                                {{filter.text}}
                            </li>
                        </ul>
                    </div>
                    <input type="text" id="searchText" v-model="search.text" :class="{act: search.text !== null}">
                    <button @click="searchEvent" class="search-btn">검색</button>
                    <button @click="searchData = null"  class="red reset" v-if="searchData !== null">초기화</button>
                </div>
                <div class="sub-menu-wrapper">
                    <nuxt-link  v-for="(menu, i) in subMenuList" :key="'schedule' + i" :to="menu.to">
                        <button>{{menu.menuName}}</button>
                    </nuxt-link >
                    <button>대체신청</button>
                    <button>접속 URL 연동</button>
                </div>
            </div> 
            <div class="button-wrapper">
                <button id="addMember" @click="openPopup($event, 'add', 'add')" class="blue">추가</button>
                <button id="deleteMember" @click="deleteMember" class="red">삭제</button>
            </div>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" :checked="selectData.length > 0 ? selectData.length == userData.length : ''" id="allCheck" @click="allCheck"></th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`data${idx}`">
                            {{data.text}}
                        </th>
                        <th>히스토리</th>
                    </tr>
                </thead>
                <tbody v-if="searchData == null">
                    <tr v-for="(user, idx) in userData" :key="`user${idx}`">
                        <td class="checkbox"><input type="checkbox" :name="`data${idx}`" :id="`user-data${idx}`" :value="user._id" @input="checkbox"></td>
                        <td><p>{{idx+1}}</p></td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="data.value">
                            <div  @click="openPopup($event, 'edit', data.value, user._id, )">
                                <p v-if="data.subValue ">
                                    {{data.subValue2 ?user[data.value][data.subValue][data.subValue2] : user[data.value][data.subValue]}}
                                </p>
                                <p v-else>
                                    {{user[data.value]}}
                                </p>
                            </div>
                        </td>
                        <td><button class="blue">보기</button></td>
                    </tr>
                </tbody>
                <tbody v-else>
                    <tr v-for="(user, idx) in searchData" :key="`user${idx}`">
                        <td class="checkbox"><input type="checkbox" :name="`data${idx}`" :id="`user-data${idx}`" :value="user._id" @input="checkbox"></td>
                        <td><p>{{idx+1}}</p></td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="data.value">
                            <div  @click="openPopup($event, 'edit', data.value, user._id, )">
                                <p v-if="data.subValue ">
                                    {{data.subValue2 ?user[data.value][data.subValue][data.subValue2] : user[data.value][data.subValue]}}
                                </p>
                                <p v-else>
                                    {{user[data.value]}}
                                </p>
                            </div>
                        </td>
                        <td><button class="blue">보기</button></td>
                    </tr>
                </tbody>
            </table>
        </div>

        
    </div>
</template>
<style lang="scss" scoped>
</style>
<script>
import Popup from '@/components/admin/Popup.vue'
import TopNav from '@/components/admin/TopNav.vue';

export default {
    name: 'AdminMember',
    layout: 'admin',
    components:{Popup, TopNav},
    data(){
        return {
            userData : null,
            searchData : null,
            selectData: [],
            search:{
                tag: 'null',
                tagKor: '선택',
                text: null,
                open: false
            },
            popup:{
                open: false,
                value: null,
                data: null
            },
            filter:[
                {text: '이름', value: 'tutorName'},
                {text: '소속', value: 'center'},
            ],
            tableData:[
               {text: '등록일', value: 'joinDay'},
               {text: '이름', value: 'tutorName'},
               {text: '아이디', value: 'id'},
               {text: '소속', value: 'center'},
               {text: '성별', value: 'sex'},
               {text: '수업시간', value: 'time'},
            ],
            subMenuList:[
                {menuName: '오늘 스케쥴', to: '/admin/schedule/daily'},
                {menuName: '주간 스케쥴', to: '/admin/schedule/weekly'},
                {menuName: '월간 스케쥴', to: '/admin/schedule/monthly'},
            ]
        }
    },
    async fetch() {
        await this.$axios.$get('api/tutor').then(data =>{
            this.userData = data;
        }).catch((error)=>{
            console.log(error.data)
        });
    },
    created(){
        this.$nuxt.$emit("pageTitle", '강사관리')
    },
    mounted() {
        this.$nuxt.$on("popup-close", v =>{
            this.popup.open = false;
        })
    },

    methods:{
         allCheck(){
            var inputs = this.$el.querySelectorAll("input[type='checkbox']")
            if( this.selectData.length == this.userData.length){ 
                this.selectData = [];
                inputs.forEach(i=>{
                    i.checked = false;
                })
            } else {
                this.selectData = [];
                this.userData.forEach(e => {
                    this.selectData.push(e._id)
                });
                inputs.forEach(i=>{
                    i.checked = 'checked';
                })
            } 
            console.log(this.selectData)
           
        },
        checkbox(e){
            if(e.target.checked){
                this.selectData.push(Number(e.target.value))
            }else{
                this.selectData = this.selectData.filter((element) => element !== Number(e.target.value));
            }
            console.log(this.selectData)
        },
        openPopup(e, v, t, id){
            if(e.target.classList.contains('disable')) return
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = id;
        },
        searchEvent(){
            if(this.search.tag == null) return alert('검색 필터를 선택해주세요.') 
            if(this.search.text == null) return alert('검색어를 입력해주세요.') 
           
            this.$axios.$get('/api/search/tutor',
                {params:{tag: this.search.tag, text: this.search.text}},
                { withCredentials: true }).then(data =>{
                console.log(data)
                this.searchData = data;
            }).catch((error)=>{
                console.log(error.data)
            });
        },
        async deleteMember(){
            if(this.selectData.lenght == 0) return;
            this.selectData.forEach(e=>{
                this.$axios.request(`/api/delete/user`, {
                    data: {
                        selectData: e
                    },
                    method: 'delete'
                }).then(()=>{
                    this.$router.go();
                });
            });
        },
        selectOption(t, v){
            this.search.tagKor = t;
            this.search.tag = v; 
            this.search.open = false;
        },



    }

  }
</script>