<template>
    <div>
        <Popup v-if="popup.open" :path="'student'" :value="popup.value" :selectData="popup.data"></Popup>
        <div class="tool-wrapper">
            <div class="search-wrapper">
                <b>검색하기</b>
                <div class="search-box">
                    <div class="select-wrapper">
                        <input class="select" name="searchTag" id="searchTag" v-model="search.tagKor" readonly @click="search.open = !search.open" :class="{act: search.tagKor !== '선택'}">
                        <ul class="options" v-if="search.open">
                            <li v-for="(filter, idx) in filter" :key="`filter${idx}`" @click="selectOption(filter.text, filter.value)" >
                                {{filter.text}}
                            </li>
                        </ul>
                    </div>
                    <input type="text" id="searchText" v-model="search.text" :class="{act: search.text !== null}">
                    <button @click="searchEvent" class="search-btn">검색</button>
                    <button @click="searchData = null"  class="red reset" v-if="searchData !== null">초기화</button>
                </div>
                <div class="sub-menu-wrapper">
                    <button  @click="newMember = !newMember" :class="{act: newMember}">신규 가입 회원</button>
                    <button  @click="message('엑셀')">엑셀로 저장하기</button>
                </div>
                
            </div> 
            <div class="button-wrapper">
                <button id="addMember" @click="openPopup($event, 'add', 'add')" class="blue">추가</button>
                <button id="deleteMember" @click="deleteMember" class="red">삭제</button>
            </div>
        </div>
        
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" :checked="(selectData.length > 0) && (selectData.length == userData.length)" id="allCheck" @input="allCheck"></th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`data${idx}`">
                            {{data.text}}
                        </th>
                        <th>수강상태</th>
                        <th>무료수업 신청</th>
                        <th>수강 신청</th>
                        <th>히스토리</th>
                    </tr>
                </thead>
                <tbody v-if="searchData == null">
                    <tr v-for="(user, idx) in userData" :key="`user${idx}`">
                        <td class="checkbox"><input type="checkbox" :name="`data${idx}`" :id="`user-data${idx}`" :value="user._id" @input="checkbox($event)"></td>
                        <td><p>{{idx+1}}</p></td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="data.value">
                            <ul v-if="data.value == 'coupon'" @click="openTarget($event)">
                                <li v-for="(cp, idx) in data.coupon" :key="`coupon${idx}`" :class="{use: cp.use == 'true'}">
                                    <p>{{cp.name}} {{cp.percentage}}% </p>   
                                    <span>~ {{cp.finDate}}</span> 
                                </li>
                            </ul>
                            <div v-else @click="openPopup($event, 'edit', data.value, user._id)">
                                <p v-if="data.subValue ">
                                    {{ user[data.value][data.subValue]}}
                                </p>
                                <p v-else>
                                    {{user[data.value]}}

                                </p>
                            </div>

                        </td>
                        <td>
                            <p v-if="user.class">{{user.class.status}}</p>
                            <p v-else>미접수</p>
                        </td>
                        <td><button class="mid-blue" @click="openPopup($event, 'leveltest', 'leveltest', user._id)" :class="{disable: user.levelTest}">신청</button></td>
                        <td><button class="sky-blue" @click="openPopup($event, 'class', 'class', user._id)">신청</button></td>
                        <td><button class="blue" @click="openPopup($event, 'history', 'history', user._id)">보기</button> </td>
                    </tr>
                </tbody>
                <tbody v-else>
                    <tr v-for="(user, idx) in searchData" :key="`user${idx}`">
                         <td class="checkbox"><input type="checkbox" :name="`data${idx}`" :id="`user-data${idx}`" :value="user._id" @input="checkbox($event)"></td>
                        <td><p>{{idx+1}}</p></td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="data.value">
                            <ul v-if="data.value == 'coupon'" @click="openTarget($event)">
                                <li v-for="(cp, idx) in data.coupon" :key="`coupon${idx}`" :class="{use: cp.use == 'true'}">
                                    <p>{{cp.name}} {{cp.percentage}}% </p>   
                                    <span>~ {{cp.finDate}}</span> 
                                </li>
                            </ul>
                            <div v-else @click="openPopup($event, 'edit', data.value, user._id)">
                                <p v-if="data.subValue ">
                                    {{ user[data.value][data.subValue]}}
                                </p>
                                <p v-else>
                                    {{user[data.value]}}

                                </p>
                            </div>

                        </td>
                        <td>
                            <p v-if="user.class">{{user.class.status}}</p>
                            <p v-else>미접수</p>
                        </td>
                        <td><button class="mid-blue" @click="openPopup($event, 'leveltest', 'leveltest', user._id)" :class="{disable: user.levelTest.regDay}">신청</button></td>
                        <td><button class="sky-blue" @click="openPopup($event, 'class', 'class', user._id)">신청</button></td>
                        <td><button class="blue" @click="openPopup($event, 'history', 'history', user._id)">보기</button> </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>
<style lang="scss" scoped>

</style>
<script>
import Popup from '@/components/admin/Popup.vue';

export default {
    name: 'AdminMember',
    layout: 'admin',
    components: {Popup},
    data(){
        return {
            userData : null,
            classData : null,
            leveltestData : null,
            searchData : null,
            selectData:[],     
            search:{
                tag: 'null',
                tagKor: '선택',
                text: null,
                open: false
            },
            popup:{
                open: false,
                value: null,
                data: null
            },
            filter:[
                {text: '이름', value: 'userName'},
                {text: '연락처', value: 'userTel'},
            ],

            tableData:[
                {text: '등록일자', value: 'joinData', subValue: 'day'},
                {text: '이름', value: 'userName'},
                {text: '아이디', value: 'id'},
                {text: '협력사', value: 'company'},
            ],
            newMember: false,
            today: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
        }
    },
    async fetch() {
        await this.$axios.$get('/api/user').then(data =>{
            this.userData = data;
        }).catch((error)=>{
            console.log(error.data)
        });

        await this.$axios.$get('/api/class').then(data =>{
            this.classData = data;
        }).catch((error)=>{
            console.log(error.data)
        });

        await this.$axios.$get('/api/leveltest').then(data =>{
            this.leveltestData = data;
        }).catch((error)=>{
            console.log(error.data)
        });
    },
    created(){
        this.$nuxt.$emit("pageTitle", '회원관리')
    },
    mounted() {
        this.$nuxt.$on("popup-close", v =>{
            this.popup.open = false;
        });
        this.getClassData();
    },
    watch:{
        newMember:{
            async  handler(e){
                this.searchData = null;
                if(e == false){
                    await this.$axios.$get('/api/user').then(data =>{
                        this.searchData = data;
                    }).catch((error)=>{
                        console.log(error.data)
                    });
                }
                if(e == true){
                    await this.$axios.$get('/api/search/user/today',
                        {params:{day: this.today}},
                        { withCredentials: true }).then(data =>{
                        this.searchData = data;
                    }).catch((error)=>{
                        console.log(error.data)
                    });
                }
            }
        }
    },
    methods:{
        openTarget(e){
            if(e.target.nodeName == "LI") e.target.parentNode.classList.toggle('open');
            else  e.target.classList.toggle('open');
        },
        allCheck(){
            var inputs = this.$el.querySelectorAll("input[type='checkbox']")
            if( this.selectData.length == this.userData.length){ 
                this.selectData = [];
                inputs.forEach(i=>{
                    i.checked = false;
                })
            } else {
                this.selectData = [];
                this.userData.forEach(e => {
                    this.selectData.push(e._id)
                });
                inputs.forEach(i=>{
                    i.checked = 'checked';
                })
            } 
           
        },
        checkbox(e){
            if(e.target.checked){
                this.selectData.push(Number(e.target.value))
            }else{
                this.selectData = this.selectData.filter((element) => element !== Number(e.target.value));
            }
        },
        openPopup(e, v, t, id){
            if(v == 'history') return alert('준비중입니다');
            if(e.target.classList.contains('disable')) return
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = id;
        
        },

        searchEvent(){
            if(this.search.tag == null) return alert('검색 필터를 선택해주세요.') 
            if(this.search.text == null) return alert('검색어를 입력해주세요.') 
           
            this.$axios.$get('/api/search/user',
                {params:{tag: this.search.tag, text: this.search.text}},
                { withCredentials: true }).then(data =>{
                this.searchData = data;
            }).catch((error)=>{
                console.log(error.data)
            });
        },
        async deleteMember(){
            if(this.selectData.lenght == 0) return;
            this.selectData.forEach(e=>{
                this.$axios.request(`/api/delete/user`, {
                    data: {
                        selectData: e
                    },
                    method: 'delete'
                }).then(()=>{
                    this.$router.go();
                });
            });
        },
        selectOption(t, v){
            this.search.tagKor = t;
            this.search.tag = v; 
            this.search.open = false;
        },
        message(v){
            if(v == '엑셀') alert('준비중입니다')
        },
        getClassData(){
        if(this.userData !== null){
            this.userData.forEach(e=>{
                if(e.class){
                    var data = this.classData.filter( (t)=> {
                        return t._id == e.class[(parseInt(e.class.length) - 1)]
                    });
                    e.class = data[0];
                }
                var levelD = this.leveltestData.filter( (t)=> {
                    return t._id == e.leveltest
                });
                e.leveltest = levelD[0]
            });
        }



        }

    }

  }
</script>