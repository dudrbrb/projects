<template>
    <div id="container">
        <header class="page-title">
            <button @click="$router.go(-1)" id="back"></button>
            <h2 v-if="$device.isMobileOrTablet">수강내역</h2>
            <div v-else>
                <h2 @click="selectClassMenu = null">수강내역</h2>
                <ul>
                    <li v-for="(list, idx) in clssMenuList" :key="`list${idx}`" @click="selectClassMenu = list.section"
                        :class="{act: selectClassMenu == list.section}">
                        {{list.title}}
                    </li>
                    <li v-if="classData && classData.status=='on'" @click="detailData.hold = true">장기홀드</li>
                    <li v-if="classData && classData.status=='on'" @click="detailData.time = true">시간변경</li>
                </ul>
            </div>
        </header>
        <List v-if="$device.isMobileOrTablet" ></List>
        <div v-else class="pc-wrapper">
            <List @selectList="selectList" v-if="selectClassMenu !== 'payment-manage'"></List>
            <div class="component" v-if="selectClassMenu==null"></div>
            <Detail :classData="classData" :detailData="detailData" v-if="selectClassMenu=='showDetail'" @popupData="closePopup" ></Detail>
            <Attendance :containerHeight="containerHeight" v-if="selectClassMenu=='attendance'"></Attendance>
            <PaymentDetail  v-if="selectClassMenu=='payment-detail'"></PaymentDetail>
            <PaymentManage  v-if="selectClassMenu=='payment-manage'" class="full"></PaymentManage>
        </div>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
       padding-bottom: 0;
        div{
            @include flex(flex-start);
            h2{
                width: auto;
                display: inline-block;
                margin-right: 100px;
                cursor: pointer;
            }
            ul{
                display: inline-block;
                @include flex(flex-start);
                li{
                    margin-right: 30px;
                    cursor: pointer;
                    font-size: 18px;
                    font-family: "SCDream4";
                    &.act,
                    &:hover{
                        color: $pink;
                    }
                }
            }
       }
    }
    .pc-wrapper{
        margin-top: 30px;
    }
}
</style>

<script>
import List from "@/components/mypage/class/List.vue";
import Detail from "@/components/mypage/class/Detail.vue";
import Attendance from "@/components/mypage/class/Attendance.vue";
import PaymentDetail from "@/components/mypage/payment/Detail.vue";
import PaymentManage from "@/components/mypage/payment/Manage.vue";

export default {
    name: 'mypage',
    layout: 'mypage',
    components: {List, Detail, Attendance, PaymentDetail, PaymentManage},
    data(){
        return{
            common: {
                'title': null, 
                'status': null,  
                'dateStart': null, 
                'dateFin': null, 
                'refund': null
            },
            clssMenuList:[
                {title: '출결내역', section: 'attendance'},
                {title: '결제내역', section: 'payment-detail'},
                {title: '결제관리', section: 'payment-manage'},
            ],
            classData: null,
            selectClassMenu: null,
            containerHeight: null,
            detailData:{
                hold: false,
                time: false,
                retake: false
            }
            
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.getContainerHeight();
    },
    watch:{

    },
    filters:{


    },
    methods:{
        selectList(v){
            this.classData = v;
            this.selectClassMenu = 'showDetail'
        },
        getContainerHeight(){
            this.containerHeight = document.querySelector('#container').clientHeight;
        },
        closePopup(){
             Object.entries(this.detailData).forEach(([key, value]) => {
                this.detailData[key] = false;
            });
        }
    }
}

</script>
