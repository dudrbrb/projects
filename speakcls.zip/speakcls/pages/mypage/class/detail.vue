<template>
    <div id="container">
        <header class="page-title">
           <button @click="$router.go(-1)" id="back"></button>
            <h2>나의 수강권</h2>
        </header>
        <Detail :classData="classData" :detailData="detailData" ></Detail>
    </div>
</template>

<style lang="scss" scoped>
</style>

<script>
import Detail from "@/components/mypage/class/Detail.vue";

export default {
    name: 'mypage',
    layout: 'mypage',
    components: {Detail},
    data(){
        return{
            common:{},           
            classData:{}, 
            openPopup: {
                retake: false
            }    ,
            detailData:{
                hold: null,
                time: null
            }
        }
    },
    created(){
        if(!this.$device.isMobileOrTablet) return this.$router.push('/mypage');
        
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.classData = this.$route.query
    },
    watch:{
    },
    filters:{
    },
    methods:{

    },
    beforeDestroy(){
    }
}

</script>
