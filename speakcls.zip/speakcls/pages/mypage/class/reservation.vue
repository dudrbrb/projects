<template>
    <div id="container">
        <header class="page-title">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>수업 예약하기</h2>
        </header>
        <Reservation></Reservation>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
       padding-bottom: 0;
    }
}
</style>

<script>
import Reservation from "@/components/mypage/class/Reservation.vue";

export default {
    name: 'mypage',
    layout: 'mypage',
    components: {Reservation},
    data(){
        return{
            
        }
    },
    created(){
        if(!this.$device.isMobileOrTablet) return this.$router.push('/mypage');
        
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{

    },
    methods:{
    }
}

</script>
