<template>
    <div id="container">
        <header class="page-title">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>프로필 수정</h2>
        </header>
       <EditProfile></EditProfile>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        margin-bottom: 50px;
    }
}
</style>

<script>
import EditProfile from "@/components/mypage/EditProfile.vue";

export default {
    name: 'mypage',
    layout: 'mypage',
    components:{EditProfile},
    data(){
        return{
            common:{},
            user:{
                name:'김이름'
            }
           
        }
    },
    created(){
        if(!this.$device.isMobileOrTablet) return this.$router.push('/mypage');

        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{

    },
    methods:{
    }
}

</script>
