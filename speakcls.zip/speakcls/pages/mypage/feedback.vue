<template>
    <div id="container" :class="{'feedback-pc': !$device.isMobileOrTablet}">
        <header class="page-title" v-if="$device.isMobileOrTablet">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>튜터 피드백</h2>
        </header>
        <section class="attend-wrapper">
            <span class="start-date font4">2022.01.04 ~</span>
            <h4>주 2회 48주 수강권으로 <br v-if="$device.isMobileOrTablet">수업 40회 완료했어요.</h4>
            <div class="bar-box">
                <span>수강중 | 결석 0회 | 주 2회 48주 수업 목표</span>
                <div class="bar-bg">
                    <div class="bar pink" :style="{width: (attendance.total/100) * attendance.progress + '%'}"></div>
                    <div class="score">{{attendance.progress}}<span>/{{attendance.total}}</span></div>
                </div>
            </div>
        </section>
        <Graph></Graph>
            
        <section class="feedback-wrapper">
            <h5>선생님 코멘드</h5>
            <div class="feedback">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae adipisci vel dicta quidem. Iure illo voluptates nam tenetur laboriosam ipsam?</p>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>

#container{
    section{
        h4{
            font-size: 28px;
            margin-top: 10px;
        }
        h5{
            font-size: 20px;
            position: relative;
            span{
                position: absolute;
                font-size: 16px;
                color:#b4b4b4;
                right: 0;
            }
        }
        
        .bar-bg{
            width: 100%;
            min-height: 18px;
            background-color: #f7f7f7;
            position: relative;
            border-radius: 5px;
            overflow: hidden;
            .bar{
                position: absolute;
                border-radius: 7px;
                height: 100%;
                left: 0;
                top: 0;
                &.pink{ background-color: $pink; }
            }
        }
        &.attend-wrapper{
            padding: 0 20px 50px;
        
            .bar-box{
                margin-top: 30px;
                .bar-bg{
                    height: 30px;
                    margin-top: 10px;
                }
                .score{
                    position: absolute;
                    right: 0;
                    top: 0;
                    line-height: 34px;
                    span{
                        color: #b4b4b4;
                    }
                }
            }
        }
        &.feedback-wrapper{
            .feedback{
                margin-top: 10px;
                background-color: #f7f7f7;
                padding: 30px 10px;
            }
        }
    }
    &.feedback-pc{
        section{
            h4{
                margin-top: 3px;
            }
            &.attend-wrapper .bar-box .score{
                right: 10px;
                line-height: 31px;
            }
            &.feedback-wrapper{
                .feedback{
                    border-radius: 10px;
                    padding: 30px;
                }
            }
            
        }
    }
}

</style>

<script>
import Graph from "@/components/mypage/class/Graph.vue";


export default {
    name: 'mypage',
    layout: 'mypage',
    components:{Graph},
    data(){
        return{
            common:{},
            attendance: {total: 96, progress: 40},
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{

    },
    methods:{

    }
}

</script>
