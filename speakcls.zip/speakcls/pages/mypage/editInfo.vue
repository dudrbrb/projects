<template>
    <div id="container">
        <section id="editInfo">
            <div>
                <h2>회원정보 수정하기</h2>

                <div class="info-wrapper">
                    <div>
                        <div>이메일(아이디)</div>
                        <div>
                            {{userInfo.id}}<br>
                            <button>이메일(아이디) 변경하기</button>
                        </div>
                    </div>
                    <div>
                        <div>비밀번호</div>
                        <div>
                            <button>비밀번호 변경하기</button>
                        </div>
                    </div>
                    <div>
                        <div>이름</div>
                        <div>{{userInfo.name}}</div>
                    </div>
                    <div>
                        <div>성별</div>
                        <div>{{userInfo.sex}}</div>
                    </div>
                    <div>
                        <div>생년월일</div>
                        <div>{{userInfo.birth}}</div>
                    </div>
                    <div>
                        <div>핸드폰 번호</div>
                        <div>
                            <input type="text" :value="userInfo.phone" >
                        </div>
                    </div>
                    <div>
                        <div>이메일 주소</div>
                        <div>
                            <input type="text" :value="userInfo.email">
                        </div>
                    </div>
                    <div>
                        <div>SKT 혜택 인증</div>
                        <div>
                            <button>SKT 부가서비스 <br v-if="$device.isMobile">혜택 인증하기</button>
                        </div>
                    </div>
                    <div>
                        <div>빠른결제 카드관리</div>
                        <div>
                            <button>빠른결제 카드관리</button>
                        </div>
                    </div>
                </div>

                <div class="agree-wrapper">
                    <div class="agree-box">
                        <input type="checkbox" name="emailCheck" id="emailCheck" v-model="userInfo.agree.email">
                        <label for="emailCheck" class="checkbox"></label>
                        <label for="emailCheck">이메일 수신동의 <span>(선택)</span></label>
                    </div>
                    <div class="agree-box">
                        <input type="checkbox" name="smsCheck" id="smsCheck" v-model="userInfo.agree.sms">
                        <label for="smsCheck" class="checkbox"></label>
                        <label for="smsCheck">SMS 수신동의 <span>(선택)</span></label>
                    </div>
                    <div class="agree-box">
                        <input type="checkbox" name="customCheck" id="customCheck" v-model="userInfo.agree.custom">
                        <label for="customCheck" class="checkbox"></label>
                        <label for="customCheck">맞춤형 서비스 제공을 위한<br v-if="$device.isMobileOrTablet"> 제3자 제공 동의 <span>(선택)</span></label>
                    </div>
  
                </div>
                <div class="btn-wrapper">
                    <button id="cancel">취소</button>
                    <button id="edit" class="pink">수정</button>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    #editInfo{
        >div{
            .info-wrapper{
                width: 100%;
                @include flex(flex-start, flex-start, column);
                >div{
                    @include flex(space-between);
                    width: 100%;
                    div{
                        margin-bottom: 20px;
                        line-height: 43px;
                        &:first-child{
                            width: 300px;
                            color: #6a6a6c;
                        }
                        &:last-child{
                            width: 100%;
                            color: #6a6a6c;
                            input{
                                width: 100%;
                                background-color: $white;
                                border-radius: 10px;
                                padding: 10px;
                            }
                        }
                        br+button{
                            line-height: 40px;
                        }
                        button{
                            padding-right: 20px;
                            background: url('@/assets/img/arrow.png') no-repeat right;
                            background-size: 12px;
                            margin: 0;
                            font-size: 18px;
                            line-height: 24px;
                            width: auto;
                            height: auto;

                        }
                        input{
                            margin-bottom: 0
                        }
                    }
                }
            }
            .agree-wrapper{
                @include flex(flex-start, flex-start, column);
                background-color: $white;
                border-radius: 10px;
                margin: 30px 0 50px;
                width: 100%;
                .agree-box{
                    width: 100%;
                    height: 60px;
                    padding: 0 20px;
                    @include flex(flex-start);
                        border-bottom: 2px solid #f6f5fb;
                    &:last-child{
                        border-bottom: 0;
                    }

                }
            }
            .btn-wrapper{
                width: 100%;
                display: flex;
                justify-content: center;
                margin-bottom: 30px;
                button{
                    width: 48%;
                    margin: 0;
                    font-size: 18px;
                    &#cancel{
                        background-color: #eaeaf2;
                        margin-right: 15px;
                    }
                }
            }
            
        }
    }
}
@media screen and (max-width: 767px){
#container{
    #editInfo{
        >div{
            .info-wrapper{
                >div{
                    div{
                        line-height: 34px;
                        &:first-child{
                            width: 250px;
                        }
                        .btn-wrapper{
                            margin-bottom: 0;
                        }
                        button{
                            background-size: 10px;
                            text-align: left;
                            font-size: 16px;
                        }
                    }
                }
            }
            .agree-wrapper .agree-box{
                padding: 0 10px;
            }
        }
    }
}
}
</style>

<script>
export default {
    name: 'editInfo',
    layout: 'form',
    data(){
        return{
            userInfo:{
                name: '김원석',
                sex: '남',
                birth: '1991년 12월 30일',
                phone: '01012345678',
                id: 'speakcls',
                password: 'asdf123!',
                email: 'speakcls@example.com',
                agree: {
                    email: true,
                    sms: true,
                    custom: false
                }
            }
        }
    },
    created(){
    },
    mounted(){
    },
    watch:{

    },
    filters:{
    },
    methods:{
    }
}

</script>
