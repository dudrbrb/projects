<template>
    <div id="container" :class="{'pc': !$device.isMobileOrTablet}">
        <header class="page-title" v-if="$device.isMobileOrTablet">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>레벨테스트 결과보기</h2>
        </header>
        <div class="wrap">
            <section class="level">
                <h4>레벨 및 백분율</h4>
                <article>
                    <div class="speech-bubble">
                        <p>나의 레벨</p>
                        <b class="font4">Grade 3</b>
                    </div>
                    <div class="bar-wrapper">
                        <div class="bar" v-for="(per, i) in barPercentage" :key="`per${i}`"
                            :style="{height: per+'px'}">
                            <div class="pink motion-bar" v-if="i == 7"></div>
                        </div>
                    </div>
                    <div class="percent"> 
                        <p>0%</p>
                        <p>100%</p>
                    </div>
                    <div class="result">
                        <b>Level Grade 3</b>
                        <span>나의 레벨</span>
                    </div>
                </article>
            </section>
            <div>
                <section class="evaluation" v-if="!$device.isMobileOrTablet">
                    <h4>전체 평가 <span @click="openPopup('comment')">자세히보기</span></h4>
                    <article>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui deleniti ex nobis ipsam nihil, totam itaque odio tempore, corporis eveniet optio voluptatibus. Voluptatem beatae placeat quaerat reiciendis voluptatum laboriosam incidunt.
                        </p>
                    </article>
                </section>
                <section class="comment" v-if="!$device.isMobileOrTablet">
                    <h4>선생님 코멘트 <span @click="openPopup('comment')">자세히보기</span></h4>
                    <article>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui deleniti ex nobis ipsam nihil, totam itaque odio tempore, corporis eveniet optio voluptatibus. Voluptatem beatae placeat quaerat reiciendis voluptatum laboriosam incidunt.
                        </p>
                    </article>
                </section>
            </div>
        </div>
        <section class="area-level">
            <h4>영역별 진단</h4>
            <div :class="{wrap: !$device.isMobileOrTablet}">
                <div>
                    <div class="area-title">
                        <p class="font5">
                            <img :src="require('@/assets/img/level/result/ar.png')"  />
                            AR
                            <span>/</span>
                            <img :src="require('@/assets/img/level/result/sr.png')" />
                            SR 레벨
                        </p>
                        <p class="pink font5">{{userScore.arsr}}</p>
                    </div>
                    <article class="arer-score">
                        <div class="dot"></div>
                        <div v-for="(score, idx) in arsr" :key="`arsr${idx}`" :class="{act: score == userScore.arsr}">
                            <p>{{score}}</p>
                            <div class="round"></div>
                        </div>
                    </article>
                </div>
                <div>
                    <div class="area-title">
                        <p class="font5">
                            <img :src="require('@/assets/img/level/result/cefr.png')" class="large"/>
                            CEFR 레벨
                        </p>
                        <p class="pink font5">{{userScore.cefr}}</p>
                    </div>
                    <article class="arer-score">
                        <div class="dot"></div>
                        <div v-for="(score, idx) in cefr" :key="`cefr${idx}`" :class="{act: score == userScore.cefr}">
                            <p>{{score}}</p>
                            <div class="round"></div>
                        </div>
                    </article>
                </div>
                <div>
                    <div class="area-title">
                        <p class="font5">
                            <img :src="require('@/assets/img/level/result/lexile.png')" class="large"/>
                            Lexile 레벨
                        </p>
                        <p class="pink font5">{{userScore.lexile}}</p>
                    </div>
                    <article class="arer-score">
                        <div class="dot"></div>
                        <div v-for="(score, idx) in lexile" :key="`lexile${idx}`" :class="{act: score == userScore.lexile}">
                            <p>{{score}}</p>
                            <div class="round"></div>
                        </div>
                    </article>
                </div>
                <div>
                    <div class="area-title">
                        <p class="font5"> 평균 학년 수준 </p>
                        <p class="pink font5">{{userScore.gradeLevel}}</p>
                    </div>
                    <article class="arer-score">
                        <div class="dot"></div>
                        <div v-for="(score, idx) in gradeLevel" :key="`gradeLevel${idx}`" :class="{act: score == userScore.gradeLevel}">
                            <p>{{score}}</p>
                            <div class="round"></div>
                        </div>
                    </article>
                </div>
            </div>
        </section>
        <section class="evaluation" v-if="$device.isMobileOrTablet">
            <h4>전체 평가</h4>
            <article>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui deleniti ex nobis ipsam nihil, totam itaque odio tempore, corporis eveniet optio voluptatibus. Voluptatem beatae placeat quaerat reiciendis voluptatum laboriosam incidunt.
                </p>
            </article>
        </section>
        <section class="comment" v-if="$device.isMobileOrTablet">
            <h4>선생님 코멘트</h4>
            <article>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui deleniti ex nobis ipsam nihil, totam itaque odio tempore, corporis eveniet optio voluptatibus. Voluptatem beatae placeat quaerat reiciendis voluptatum laboriosam incidunt.
                </p>
            </article>
        </section>
        <section class="area-score"  v-if="$device.isMobileOrTablet">
            <h4>영역별 점수</h4>
            <article v-for="(area, idx) in areaScore" :key="`area${idx}`">
                <div class="score-title">
                    <h5>{{area.title}}</h5>
                    <span class="pink font5">{{area.title | eng}}</span>
                    <span class="score font6">{{area.myScore}}점</span>
                </div>
                <div class="score-bar-wrapper">
                    <div class="bar-wrapper">
                        <p>나의 점수</p>
                        <div class="bar-bg">
                            <div class="bar pink" :style="{width: area.myScore + '%'}"></div>
                        </div>
                        <p class="font3">{{area.myScore}} <span>/ 100</span></p>
                    </div>
                    <div class="bar-wrapper">
                        <p>평균 점수</p>
                        <div class="bar-bg">
                            <div class="bar" :style="{width: area.average + '%'}"></div>
                        </div>
                        <p class="font3">{{area.average}} <span>/ 100</span></p>
                    </div>
                </div>
                <div class="score-comment">
                    <p>aaa</p>
                </div>
            </article>
        </section>
        <section class="area-score pc"  v-else>
            <h4>영역별 점수  <span @click="openPopup('score')">자세히보기</span></h4>
            <article>
                <div v-for="(area, idx) in areaScore" :key="`area${idx}`">
                    <div class="score-title">
                        <h5 class="font4">{{area.title}}</h5>
                        <span class="score font4">{{area.myScore}}점</span>
                    </div>
                    <div class="score-bar-wrapper">
                        <div class="bar-wrapper">
                            <div class="bar-bg">
                                <div class="bar pink" :style="{width: area.myScore + '%'}"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </article>
        </section>
        <div class="popup-wrapper" v-if="popup.open">
             <section class="area-score popup" v-if="popup.score" >
               
                <h4>영역별 점수 <button class="close" @click="popupClose"></button></h4>
                <article v-for="(area, idx) in areaScore" :key="`area${idx}`">
                    <div class="score-title">
                        <h5>{{area.title}}</h5>
                        <span class="pink font5">{{area.title | eng}}</span>
                        <span class="score font6">{{area.myScore}}점</span>
                    </div>
                    <div class="score-bar-wrapper">
                        <div class="bar-wrapper">
                            <p>나의 점수</p>
                            <div class="bar-bg">
                                <div class="bar pink" :style="{width: area.myScore + '%'}"></div>
                            </div>
                            <p class="font3">{{area.myScore}} <span>/ 100</span></p>
                        </div>
                        <div class="bar-wrapper">
                            <p>평균 점수</p>
                            <div class="bar-bg">
                                <div class="bar" :style="{width: area.average + '%'}"></div>
                            </div>
                            <p class="font3">{{area.average}} <span>/ 100</span></p>
                        </div>
                    </div>
                    <div class="score-comment">
                        <p>aaa</p>
                    </div>
                </article>
            </section>
            <div class="popup" v-if="popup.comment">
                <section class="evaluation">
                    <h4>전체 평가 <button class="close" @click="popupClose"></button></h4>
                    <article>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui deleniti ex nobis ipsam nihil, totam itaque odio tempore, corporis eveniet optio voluptatibus. Voluptatem beatae placeat quaerat reiciendis voluptatum laboriosam incidunt.
                        </p>
                    </article>
                </section>
                <section class="comment">
                    <h4>선생님 코멘트</h4>
                    <article>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui deleniti ex nobis ipsam nihil, totam itaque odio tempore, corporis eveniet optio voluptatibus. Voluptatem beatae placeat quaerat reiciendis voluptatum laboriosam incidunt.
                        </p>
                    </article>
                </section>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
$gray: #bfbfbf;
#container{
    background-color: #f7f7f7;
    &.pc{
        background-color: $white;
        >.wrap{
            @include flex(space-between, flex-start);
            margin-bottom: 20px;
            section{
                padding: 0;
                margin-bottom: 0;
            }
            >*{
                width: 48.5%;
            }
        }
        section{
            padding: 0 20px;
            margin-bottom: 20px;

            h4{
                margin-bottom: 20px; 
                width: 100%;
                @include flex(space-between);

                span{
                    color:#7a7a7a;
                    font-size: 16px;
                    cursor: pointer;
                }
            }
            article{
                background-color: #faf9fc;
                box-shadow: none;
            }

        }
        .level{
            article{
                padding: 20px 0 ;
            }
            .percent{
                width: 350px;
            }
            .result{
                margin-top: -10px;
                b{
                    font-size: 36px;
                }
            }
        }
        .evaluation, .comment{
            article{
                padding: 20px 20px;
            }
        }
        .comment{
            margin-top: 20px;
        }
        .area-level{
            h4{
                width: 100%;
            }
            .wrap{
                background-color: #faf9fc;
                @include flex(space-between, flex-end);
                flex-wrap: wrap;
                padding: 20px;
                border-radius: 10px;
                >div{
                    width: 48.5%;
                    &:nth-child(3),
                    &:nth-child(4){
                        margin-top: 20px;
                    }
                    article{
                        background: $white;
                        box-shadow: 1px 1px 5px rgba(63, 63, 63, 0.2);

                    }
                }
            }
        }
        .area-score.pc{
            article{
                @include flex(space-between);
                padding: 20px;
                >div{
                    width: 16%;
                }
                .score-title{
                    margin-bottom: 10px;
                    h5{
                        font-weight: 300;
                        font-size: 20px;
                    }
                    span.score{
                        font-size: 20px;
                        margin-left: 0px;
                    }
                }
                .score-bar-wrapper {
                    padding-bottom: 0;
                    border-bottom: 0;
                    .bar-wrapper .bar-bg{
                        width: 100%;
                        height: 8px;
                        background: $white;
                        box-shadow: 1px 1px 5px rgba(63, 63, 63, 0.2);

                    }
                }
            }
        }
        .popup-wrapper{
            background-color: $popupBg;
            position: fixed;
            width: 100%;
            height: 100%;
            z-index: 99999;
            top: 0;
            left: 0;
            .popup{
                background-color: $white;
                border-radius: 20px;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 90%;
                max-width: 800px;
                max-height: 600px;
                overflow-y: scroll;
                padding-top: 10px;
                .close{
                    width: 50px;
                    height: 50px;
                    background: url('@/assets/img/close.png') no-repeat center;
                    background-size: 20px;
                    position: absolute;
                    right: 20px;
                    top: 10px;
                }
                .evaluation{
                    .close{
                        margin-top: -20px;
                    }
                }
            }
        }

    }
    section{
        padding-top: 50px;
        position: relative;
        padding: 50px 20px 0;
        h4{
            font-size: 28px;
            margin-top: 10px;
            margin-bottom: 30px;
        }
        article{
            position: relative;
            background-color: $white;
            box-shadow: 1px 1px 5px rgba(63, 63, 63, 0.2);
            border-radius: 10px;
        }
    }
    .level{
        article{
            padding: 30px 0;
            @include flex(center, center, column)
        }
        .speech-bubble {
            position: relative;
            background: $pink;
            border-radius: 40px;
            display: inline-block;
            padding: 10px 30px;
            transform: scale(0);
            transition: all 0.4s;
            transform-origin: center bottom;
            &.act{
                transform: scale(1);
            }
            
            p,b{
                display: block;
                width: auto;
                color: $white;
                text-align: center;
                line-height: 22px;
            }
            p{
                font-size: 16px;
            }
            b{
                font-size: 20px;
            }
            &:after {
                content: "";
                position: absolute;
                bottom: 0;
                left: 50%;
                width: 0;
                height: 0;
                border: 13px solid transparent;
                border-top-color: #e90b73;
                border-bottom: 0;
                margin-left: -13px;
                margin-bottom: -9px;
            }
        }
        .bar-wrapper{
            @include flex(center, flex-end);
            margin-top: 30px;
            .bar{
                width: 14px;
                margin: 0 4px;
                background-color: $gray;
                border-radius: 10px 10px 0 0 ;
                position: relative;
                overflow: hidden;
                .pink{
                    position: absolute;
                    background-color: $pink;
                    width:100%;
                    height: 100%;
                    transform: scaleY(0);
                    transition: all 0.4s;
                    transform-origin: center bottom;

                    &.act{
                        transform: scaleY(1);
                    }
                }
            }
        }
        .percent{
             @include flex(space-between);
             width: 100%;
             padding: 0 5px;
             font-size: 14px;
             margin-top: 10px;
            p{
                color: $gray;
            }
        }
        .result{
            margin-top: 20px;
            b{
                display: block;
                color: $pink;
                font-size: 40px;
            }
            span{
                text-align: center;
                display: block;
                color: $gray;
                width: 100%;
            }
        }

    }
    .area-level{
        >div{
            margin-bottom: 20px;
            &:last-child{
                margin-bottom: 0;
            }
        }
        .area-title{
            width: 100%;
            position: relative;
            p{
                @include flex();
                span{
                    color: $gray;
                    font-size: 22px;
                    margin: 0 5px;
                }
                &.pink{
                    position: absolute;
                    right: 0;
                    bottom: 0;
                    top: 0;
                    margin: auto 0;
                    color: $pink;
                }
                img{
                    height: 16px;
                    margin-right: 5px;
                    &.large{
                        height: 32px;
                    }
                }
            }
        }
        .arer-score{
            @include flex(space-between);
            position: relative;
            margin-top: 10px;

            >div{
                @include flex(center, center, column);
                padding: 10px 5px;
                &.act{
                    p{
                        color: $pink;
                    }
                    .round{
                        background: url('@/assets/img/checkbox.png') no-repeat center;
                        background-size: contain;
                    }
                }
                p{
                    font-size: 10px;
                }
                .round{
                    width: 20px;
                    height: 20px;
                    background-color: $gray;
                    border-radius: 50%;
                    margin-top: 5px;
                }
                &.dot{
                    position: absolute;
                    width: 90%;
                    border-top: 1px dotted $gray;
                    bottom: 0;
                    margin: 0 20px;
                }
            }
        }
    }
    .evaluation, .comment{
        article{
            padding: 20px 10px;
        }
    }
    .area-score{    
        article{
            margin-bottom: 20px;
            padding: 20px 10px;
            .score-title{
                @include flex();
                margin-bottom: 30px;
                h5{
                    font-size: 24px;
                    margin-right: 10px;
                }
                span{
                    font-size: 24px;
                    color: $pink;
                    &.score{
                        margin-left: auto;
                    }
                }
            }
            .score-bar-wrapper{
                border-bottom: 1px solid #e7e7e7;
                padding-bottom: 20px;
                .bar-wrapper{
                    @include flex(space-between);
                    p{
                        font-size: 14px;
                        &.font3{
                            font-size: 13px;
                        }
                        span{
                            font-size: 1em;
                            color: $gray;
                        }
                    }
                    .bar-bg{
                        width: 65%;
                        height: 6px;
                        border-radius: 10px;
                        background-color: #efefef;
                        .bar{
                            height: 100%;
                            border-radius: 10px;
                            background-color: #dddddd;
                            &.pink{
                                background-color: $pink;
                            }
                        }
                    }
                }
            }
            .score-comment{
                padding-top: 20px;
            }
        }
    }
}

</style>

<script>
export default {
    name: 'mypage',
    layout: 'mypage',
    data(){
        return{
            common:{},
            popup:{
                open: false,
                score: false,
                comment: false
            },
            userScore:{
                arsr: '1.6 ~ 1.8',
                cefr: 'A2',
                lexile: '300 ~ 425',
                gradeLevel: '초3 ~ 초4'
            },
            barPercentage:[20,40,60,80,110,140,170,200,170,140,110,80,60,40,20],
            barPercentage:[20,40,60,80,100,120,140,160,140,120,100,80,60,40,20],
            arsr:['0 ~ 1', '1.1 ~ 1.2', '1.3 ~ 1.4', '1.6 ~ 1.8', '2.3 ~ 2.6', '2.6 ~ 2.7', '2.9 ~ 3.0' ],
            cefr:['~ A1', 'A1', 'A1+', 'A2', 'A2+', 'A2+', 'A2+ ~ B1' ],
            lexile:['0 ~ 100','100 ~ 150', '150 ~ 300', '300 ~ 425', '425 ~ 475', '475 ~ 525', '525 ~ 650' ],
            gradeLevel:['미취학아동', '초1 ~ 초2', '초2 ~ 초3', '초3 ~ 초4', '초4 ~ 초5','초5 ~ 초6', '초6 ~ 중1' ],
            areaScore:{
                Pronunciation:{
                    title: '발음',
                    myScore: 62,
                    average: 75,
                    comment: 'text'
                },
                Grammer:{
                    title: '문법',
                    myScore: 79,
                    average: 85,
                    comment: 'text'
                },
                Vocabulary:{
                    title: '어휘',
                    myScore: 88,
                    average: 94,
                    comment: 'text'
                },
                Understanding:{
                    title: '이해',
                    myScore: 91,
                    average: 81,
                    comment: 'text'
                },
                Fluency:{
                    title: '유창성',
                    myScore: 77,
                    average: 85,
                    comment: 'text'
                },
            }
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        setTimeout(() => {
            this.addAct();
        }, 200);
    },
    watch:{
    },
    filters:{
        eng(v){
            if(v == '발음'){ return v='Pronunciation'}
            if(v == '문법'){ return v='Grammer'}
            if(v == '어휘'){ return v='Vocabulary'}
            if(v == '이해'){ return v='Understanding'}
            if(v == '유창성'){ return v='Fluency'}
        }

    },
    methods:{
        addAct(){
            var ele1 = this.$el.querySelector('.motion-bar') ;
            var ele2 = this.$el.querySelector('.speech-bubble') ;

            var eleArr = [ele1, ele2]
            
            eleArr.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 400*idx);
            });
        },
        openPopup(v){
            this.popup.open = true;
            if(v== 'score') this.popup.score = true;
            if(v== 'comment') this.popup.comment = true;
        },
        popupClose(v, i){
            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
        }
    }
}

</script>
