<template>
    <div id="container">
        <div v-if="$device.isMobileOrTablet">
            <header>
                <div class="image"></div>
                <div class="name">
                    <h1>김이름</h1>
                    <p>Kim Erum</p>
                </div>
            </header>
            <MyClass :login="common.login" :width="common.width" ></MyClass>
            <section class="coupon">
                <ul>
                    <li>
                        <p>수업쿠폰<br>
                            <span>0</span>장
                        </p>
                    </li>
                    <li>
                        <p>적립금<br>
                            <span>0</span>원
                        </p>
                    </li>
                    <li>
                        <p>할인쿠폰<br>
                            <span>0</span>장
                        </p>
                    </li>
                </ul>
            </section>
            <section class="notice">
                <h3>공지</h3>
                <ul>
                    <li><nuxt-link :to="'/mypage'">친구추천</nuxt-link>
                        <span class="font5">적립금 10,000원 받기</span>
                    </li>
                    <li><nuxt-link :to="'/mypage'">이용안내</nuxt-link></li>
                    <li><nuxt-link :to="'/mypage'">문의하기</nuxt-link></li>
                </ul>
            </section>
        </div>
        <div v-else class="pc-wrapper">
            <div class="column-wrapper">
                <CalendarDefault :login="common.login"></CalendarDefault>
                <Graph  :login="common.login" ></Graph>
            </div>
            <MyClass :login="common.login" ></MyClass>
            <div class="popup-wrapper" v-if="popup.open"  :class="{pc: !$device.isMobile}">
                <div class="popup">
                    <EditProfile v-if="query.editProfile" @changeProfile="popupClose('profile')" ></EditProfile>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        height: 120px;
        @include flex(flex-start);
        .image{
            background: url('@/assets/img/profile/sample.png') no-repeat center;
            background-size: cover;
            min-width: 80px;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .name{
            h1{
                font-size: 28px;
            }
        }
    }
    section{
        &.coupon{
            border-bottom: 2px solid #e7e7e7;
            padding: 0;
            ul{
                @include flex();
                li{
                    width: 33%;
                    padding: 20px 0;
                    p{
                        text-align: center;
                        font-size: 15px;
                        line-height: 30px;
                        span{
                            font-size: 22px;
                            font-family: "SCDream6";
                            line-height: 30px;
                            margin-right: 3px;
                        }
                    }
                }
            }

        }
    }
    .popup-wrapper{
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color:  $popupBg;
        z-index: 99999;
        &.pc{
             .popup{
                width: 100%;
                max-width: 450px;
                .txt-wrapper{
                    h5{
                        font-size: 20px;
                        font-family: "SCDream5";
                    }
                    p{
                        font-size: 16px;
                    }
                }
            }
        }
        .popup{
            position: absolute;
            background-color:  $white;
            margin: 0 auto;
            padding: 30px;
            top: 50%; 
            left: 50%;
            transform: translate(-50%, -50%);  
            width: 90%;
            max-width: 430px;
            border-radius: 15px;
            .component{
                width: 100%;
            }
        }
    }
    
}
</style>

<script>
import CalendarDefault from "@/components/mypage/calendar/Default.vue";
import EditProfile from "@/components/mypage/EditProfile.vue";
import MyClass from "@/components/mypage/MyClass.vue";
import Graph from "@/components/mypage/class/Graph.vue";


export default {
    name: 'mypage',
    layout: 'mypage',
    components: {MyClass, CalendarDefault, EditProfile, Graph},
    data(){
        return{
            common: {},
            query: {
                editProfile: null
            },
            popup:{
                open: false
            },
            date: {
                month: new Date().getMonth() + 1,
                day: new Date().getDate()
            },
            score:{
                speaking: {kor:'말하기', progress: 80, color: 'green'},
                listeneing: {kor:'듣기', progress: 90, color: 'mint'},
                writing: {kor:'쓰기', progress: 80, color: 'blue'},
                reading: {kor:'읽기', progress: 70, color: 'purple'},
            }
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.getParams()
    },
    watch:{

    },
    filters:{
        zero(v){
            if(v<10) return v = '0'+ String(v);
            else return v = v
        }
        
    },
    methods:{
        getParams(){
            this.query = this.$route.query;
            if( this.query.editProfile == 'true') this.popup.open = true;
        },
        popupClose(v){
            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
            if(v=="profile"){
                this.$router.push({ query: {editProfile: false } })
            }
        }

    }
}

</script>
