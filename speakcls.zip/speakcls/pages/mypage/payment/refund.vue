<template>
    <div id="container">
        <header class="page-title">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>환불 신청</h2>
        </header>
        <Refund></Refund>
    </div>
</template>

<style lang="scss" scoped>

</style>

<script>
import Refund from "@/components/mypage/payment/Refund.vue";
export default {
    name: 'mypage',
    layout: 'mypage',
    components:{Refund},
    data(){
        return{
            common:{},
        }
    },
    setup() {
    },
    created(){
        if(!this.$device.isMobileOrTablet) return this.$router.push('/mypage');
        
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{
    },
    methods:{
    },
}

</script>
