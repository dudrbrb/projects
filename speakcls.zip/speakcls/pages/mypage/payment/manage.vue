<template>
    <div id="container">
        <header class="page-title">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>결제관리</h2>
        </header>
        <Manage></Manage>
    </div>
</template>

<style lang="scss" scoped>
</style>

<script>
import Manage from "@/components/mypage/payment/Manage.vue";
export default {
    name: 'mypage',
    layout: 'mypage',
    components: {Manage},
    data(){
        return{
            common:{}
        }
    },
    created(){
        if(!this.$device.isMobileOrTablet) return this.$router.push('/mypage');
        
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{
    },
    methods:{
    },
}

</script>
