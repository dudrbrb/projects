<template>
    <div id="container" :class="{'calendar-wrapper' : !$device.isMobileOrTablet}">
        <header class="page-title">
            <button @click="$router.go(-1)" id="back"></button>
            <h2>스케쥴</h2>
        </header>
        <CalendarHoriz v-if="$device.isMobileOrTablet"></CalendarHoriz>
        <CalendarDefault v-if="!$device.isMobileOrTablet"></CalendarDefault>
        
    </div>
</template>

<style lang="scss">
#container.calendar-wrapper{
    @include flex(space-between, flex-start);
    flex-wrap: wrap;
    overflow: hidden;
    position: relative;
    header{
        width: 100%;
    }
}
</style>
<script>
import CalendarHoriz from "@/components/mypage/calendar/Horizontal.vue";
import CalendarDefault from "@/components/mypage/calendar/Default.vue";

export default {
    name: 'mypage',
    layout: 'mypage',
    components: {CalendarHoriz, CalendarDefault},
    data(){
        return{
            common:{},
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{
       
    },
    methods:{
      
    },
    computed:{
    }
}


</script>