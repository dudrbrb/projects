<template>
    <div id="header">
         <h1>커리큘럼 페이지</h1>
    </div>
</template>

<style lang="scss" scoped>
header{
    section{
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    h1{
        margin-top: 200px;
    }
}
</style>

<script>
export default {
    name: 'introduce',
    layout: 'default',
    data(){
        return{
        }
    },
    created(){
    },
    mounted(){
    },
    methods:{
    }
}

</script>
