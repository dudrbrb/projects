<template>
    <div id="container">

        <header>
            <div>
                <h1>스픽클로 달라지는<br style="display:block">우리아이 영어 자신감</h1>
            </div>
        </header>
        <section id="text">
            <div>
                <h3>우리아이 <span>영어 첫걸음 <br class="mb">어떻게 시작할지</span> 고민이신가요?<br> 환경이 달라진 만큼, <span>영어를 배우는 방식</span>도<br class="mb"> 달라져야 합니다.<br style="display='none'">
                    <span>자신감</span> 있게 <span>말하는 영어</span>를 하고 싶다면 <br style="display='none'">
                    시작은  <span>스픽클</span>이어야 합니다. 
                </h3>
            </div>
        </section>
        <section id="form" class="bg-light">
            <div>
                <h2 class="font5">무료 수업신청</h2>

                <div class="radio-wrapper">
                    <h4>학습 수준</h4>
                    <p>레벨에 맞는 수업이 진행될거에요.</p>
                    <div>
                        <input type="radio" name="level" id="level1">
                        <label for="level1">기초 단어를 따라 말할 수 있어요.</label>
                    </div>
                    <div>
                        <input type="radio" name="level" id="level2">
                        <label for="level2">간단한 문장을 말할 수 있어요.</label>
                    </div>
                    <div>
                        <input type="radio" name="level" id="level3">
                        <label for="level3">자유롭게 프리토킹이 가능해요.</label>
                    </div>
                </div>
                <div class="input-wrapper">
                    <h4>정보 입력</h4>
                    <input type="text" id="userName" placeholder="이름" v-model="confirmData.userName">
                    <input type="text" id="userGrade" placeholder="학년" readonly v-model="confirmData.userGrade" @click="openSelectGrade=!openSelectGrade">
                    <div class="select-grade" v-if="openSelectGrade">
                        <ul>
                            <li v-for="grade in gradeData" :key="`${grade}`" :value="`${grade}`" @click="openSelectGrade=!openSelectGrade; confirmData.userGrade=grade;">
                                <span>✔</span> {{grade}}
                            </li>
                        </ul>
                    </div>
                    <div>
                        <input type="text" id="userTime" placeholder="수업일시" readonly v-model="classDate" @click="openSelectTime=!openSelectTime">
                        <button id="timeBtn" class="pink font5" @click="openSelectTime=!openSelectTime">시간선택</button>
                    </div>
                    <div class="select-time" v-if="openSelectTime">
                        <div>
                            <img :src="require('@/assets/img/close.png')" alt="닫기" class="close" @click="openSelectTime = false" loading="lazy">
                            <h3>시간 선택</h3>
                            <p>14시부터 21시30분까지 자유롭게 선택하세요!</p>
                            <div v-for="date in dateData" :key="`${date}`">
                               <p class="font4">{{date.month|dayFilter}}/{{date.day|dayFilter}} ({{date.kor}})</p> 
                                <ul>
                                    <li class="font3" v-for="time in timeDate" :key="`${time}`" :value="`${time}`" @click="openSelectTime=!openSelectTime; confirmData.userTime=time; confirmData.userDay=date">
                                        {{time}}
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div>
                        <input type="text" id="userPhone" placeholder="전화번호" v-model="confirmData.userPhone"  maxLength="11" >
                        <button id="authNumBtn" @click="checkPhoneNumber">인증번호 받기</button>
                    </div>
                    <div class="authNumberPopup" v-if="alert.popup">
                        <div>
                            <div v-if="alert.sendAuth" class="font4">
                                {{confirmData.userPhone | hyphen}} 으로 <br> 인증번호를 전송했습니다.
                            </div>
                            <div v-if="alert.phoneErr" class="font4">
                                전화번호를 정확히 입력해주세요.
                            </div>
                            <div>
                                <button @click="closeAlert('editPhone')" class="font4">전화번호 수정</button>
                                <button @click="closeAlert('ok')" v-if="alert.sendAuth" class="font4">확인</button>
                            </div>
                        </div>
                    </div>
                    <input type="text" id="authNumber" placeholder="인증번호 입력" disabled>
                    <div class="agree-wrapper">
                        <div class="all-agree">
                            <input type="checkbox" name="all-agree" id="allAgree" v-model="agreeAll" @input="agreeAllEvent($event)">
                            <label for="allAgree" class="checkbox"></label>
                            <label for="allAgree " class="font5">전체 약관 동의</label>
                        </div>
                        <div>
                            <input type="checkbox" name="agree1" id="agree1" v-model="agree.agr1" @input="agreeEvent($event)">
                            <label for="agree1" class="checkbox"></label>
                            <label for="agree1" class="font4">개인정보 수집 및 이용동의 (필수)</label>
                            <button>내용보기</button>
                        </div>
                        <div>
                            <input type="checkbox" name="agree2" id="agree2" v-model="agree.agr2" @input="agreeEvent($event)">
                            <label for="agree2" class="checkbox"></label>
                            <label for="agree2" class="font4">영어 콘텐츠 제공, 할인/이벤트 안내 동의 (선택)</label>
                            <button>내용보기</button>
                        </div>
                    </div>
                    <div class="confirmPopup" v-if="confirmPopup.open">
                        <div>
                            <div class="font4">
                                {{confirmPopup.message}}
                            </div>
                            <div>
                                <button @click="confirmPopup.open = false" class="font4">확인</button>
                            </div>
                        </div>
                    </div>
                    <button id="confirmBtn" class="pink font5" @click="confirm">신청하기</button>
                </div>
            </div>
        </section>
        <section id="banner">
            <div>
                <h5>우리 아이의 레벨과 성향에 맞춰 <br>수업 가능한 스픽클로 시작해보세요</h5>
                <span>지금 문의하기</span>
            </div>
        </section>
        <section id="QnA">
            <div>
                <h4>자주 묻는 질문 및 답변</h4>
                <div>
                    <div class="qna-box">
                        <div class="qna-title" >
                            <div class="question"></div>
                            <h6>무료 레벨 테스트는 어떻게 하나요?</h6>
                            <div class="arrow" @click="openQnA($event)"></div>
                        </div>
                        <div class="qna-text">
                            <hr>
                            <p class="font4">홈페이지 오른쪽 하단에 무료레벨 테스트 신청하기 팝업을 클릭하면 해당 페이지로 자동 넘어가게 됩니다.<br>
                            모든 정보를 입력한 후 신청하기를 누르면 순차적으로 상담 진행 후 레벨 테스트를 받아보실 수 있습니다.</p>
                        </div>
                    </div>
                    <div class="qna-box">
                        <div class="qna-title">
                            <div class="question"></div>
                            <h6>화상 수업은 어떻게 이용하나요?</h6>
                            <div class="arrow" @click="openQnA($event)"></div>
                        </div>
                        <div class="qna-text">
                            <hr>
                            <p class="font4">홈페이지 오른쪽 하단에 무료레벨 테스트 신청하기 팝업을 클릭하면 해당 페이지로 자동 넘어가게 됩니다.<br>
                            모든 정보를 입력한 후 신청하기를 누르면 순차적으로 상담 진행 후 레벨 테스트를 받아보실 수 있습니다.</p>
                        </div>
                    </div>
                    <div class="qna-box">
                        <div class="qna-title">
                            <div class="question"></div>
                            <h6>수업 연기 및 취소는 어떻게 하나요?</h6>
                            <div class="arrow" @click="openQnA($event)"></div>
                        </div>
                        <div class="qna-text">
                            <hr>
                            <p class="font4">홈페이지 오른쪽 하단에 무료레벨 테스트 신청하기 팝업을 클릭하면 해당 페이지로 자동 넘어가게 됩니다.<br>
                            모든 정보를 입력한 후 신청하기를 누르면 순차적으로 상담 진행 후 레벨 테스트를 받아보실 수 있습니다.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <section id="info">
            <div>
                <h4>스픽클의 더 다양한 정보를 확인해보세요</h4>
                <div class="info-wrapper">
                    <nuxt-link :to="'/'">
                        <img :src="require('@/assets/img/level/info1.png')"  loading="lazy">
                        <p>스픽클</p>
                        <h5>바로가기</h5>
                    </nuxt-link>
                    <nuxt-link :to="'/curriculum'">
                        <img :src="require('@/assets/img/level/info2.png')"  loading="lazy">
                        <p>스픽클 과정</p>
                        <h5>커리큘럼 바로가기</h5>
                    </nuxt-link>
                    <nuxt-link :to="'/tutor'">
                        <img :src="require('@/assets/img/level/info3.png')"  loading="lazy">
                        <p>스픽클 원어민</p>
                        <h5>선생님 바로가기</h5>
                    </nuxt-link>
                    <nuxt-link :to="'/purchase'">
                        <img :src="require('@/assets/img/level/info4.png')"  loading="lazy">
                        <p>스픽클 수강권</p>
                        <h5>가격비교 바로가기</h5>
                    </nuxt-link>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        position: relative;
        @include flex();
        background: url('@/assets/img/level/bg.webp') no-repeat;
        background-position: center;
        background-size: cover;
        height: 700px;
        h1{
            color: $white;
            text-align: right;
            margin-left: auto;
            text-shadow: 1px 1px 7px #77777791;
            letter-spacing: -4px;
        }
    }
    #text{
        @include flex();
        h3{
            color: #a199b1;
            padding: 70px 0;
            line-height: 50px;
            font-size: 32px;
            br.mb{
                display: none;
            }
            span{
                font-size: 1em;
                font-family: "SCDream6";
                color: #a199b1;
                transition: all 0.3s;
                &.act{
                    color: #b63168;
                }
            }
        }
    }
    #form{
        @include flex(flex-start, center, column);
        >div {
            > *{
                margin-bottom: 40px;
            }
            h4{
                font-size: 30px;
                margin-bottom: 5px;
            }
            p{
                color: #919092;
                font-weight: 600;
                margin-bottom: 20px;
            }
        }
        .radio-wrapper{
            >div{
                margin-top: 5px;
                @include flex(flex-start, center);
                input[type='radio'],
                input[type='radio']:checked {
                    appearance: none;
                    width: 23px;
                    height: 23px;
                    border-radius: 100%;
                    margin-right: 10px;
                }
                input[type='radio'] {
                    background:none;
                    border: 1px solid #919092;
                }
                input[type='radio']:checked {
                    border: 7px solid $pink;
                }
                input + label{
                    font-family: 'SCDream3';
                    color: #919092;
                }
                input[type='radio']:checked + label {
                    font-family: 'SCDream4';
                    font-weight: 800;
                    color: $black;
                }
            }
        }
        .input-wrapper{
            margin-bottom: 0;
            h4{
                margin-bottom: 10px;
            }
            >*{
                width: 100%;
                margin-bottom: 8px;
                @include flex(flex-start);
                position: relative;
            }
            input{
                height: 60px;
                padding-left: 10px;
                border-radius: 10px;
                width: 100%;
                position: relative;
                background-color: $white;
                font-family: 'SCDream4';
                font-size: 20px;
            }
            input::placeholder{
                color: #a199b1;
            }
            input:disabled{
                background-color: #eeeeee;
            }
            input#userGrade {
                background-image: url('@/assets/img/level/arrow-gray.png');
                background-repeat: no-repeat;
                background-size: 20px;
                background-position: 98% center;
                cursor: pointer;
            }
            input#userTime{
                cursor: pointer;
            }
            input[type=number]::-webkit-outer-spin-button,
            input[type=number]::-webkit-inner-spin-button{
                -webkit-appearance: none;
            }
            .select-grade{
                position: absolute;
                z-index: 1;
                flex-direction: column;
                background-color: $white;
                border-radius: 10px;
                padding: 10px  10px 10px 0;
                width: 100%;
                max-width: 770px;
                box-shadow: 0px 2px 4px rgba(51, 51, 51, 0.4);
                ul{
                    padding: 0 10px ;
                    height: 210px;
                    overflow-y: scroll;
                    width: 100%;
                    li{
                        border-radius: 5px;
                        padding: 5px 10px;
                        color: #707070;
                        cursor: pointer;
                        font-size: 18px;
                        span{
                            color: $white;
                        }
                        &:hover{
                            background-color:#707070 ;
                            color: $white;
                        }
                    }
                    &::-webkit-scrollbar{ 
                        width: 6px; 
                    }
                    &::-webkit-scrollbar-thumb{ 
                        height: 17%;
                        border-radius: 20px;
                        background-color: #707070; 
                    } 
                    &::-webkit-scrollbar-track{ 
                        border-radius: 20px;
                        background-color: rgb(255, 255, 255); 
                        box-shadow: 0px 0px 3px rgba(67, 67, 67, 0.4);
                    }

                }

            }
            .select-time{
                position: fixed;
                width: 100%;
                height: 100%;
                background-color: #0000005d;
                top:0;
                left: 0;
                z-index: 99999;
                >div{
                    background-color: #f9f9f9;
                    width: 95%;
                    max-width: 600px;
                    position: relative;
                    margin: auto;
                    padding: 45px 30px;
                    border-radius: 15px;
                    position: relative;
                    h3{
                        font-size: 23px;
                        padding-left: 5px;
                    }
                    p{
                        margin-top: 5px;
                        padding-left: 5px;
                        font-size: 20px;
                    }
                    .close{
                        position: absolute;
                        right: 20px;
                        top: 20px;
                        cursor: pointer;
                        padding: 10px;
                    }
                    >div{
                        margin-top: 30px;
                        p{
                            color: $pink;
                            margin-bottom: 5px;
                        }
                        ul{
                            flex-wrap: wrap;
                            @include flex(flex-start, center);
                            li{
                                background-color: $white;
                                border: 2px solid #e8e8ef;
                                border-radius: 4px;
                                padding: 6px 19px;
                                margin: 5px 3px;
                                font-size: 16px;
                                cursor: pointer;
                                &:hover{
                                    border-color: $pink;
                                    color: $pink;
                                }
                            }
    
                        }
                    }
                }
            }
        
            button{
                font-size: 20px;
                &.pink{
                    background-color: $pink;
                    color: $white;
                    border-radius: 15px;
                    height: 60px;
                }
                &#timeBtn{
                    width: 170px;
                    margin-left: 5px;
                }
                &#authNumBtn{
                    position: absolute;
                    right: 10px;
                    top: 0;
                    bottom: 0;
                    margin: auto 0;
                    color: #a199b1;
                    text-decoration: underline;
                    text-underline-position: under;
                }
            }
            .agree-wrapper{
                flex-direction: column;
                margin: 20px 0 40px;
                div{
                    width: 100%;
                    @include flex( flex-start);
                    margin-top: 10px;
                    input[type=checkbox]{
                        display: none;
                     }
                    input[type=checkbox]+label.checkbox{
                        width: 24px;
                        height: 24px;
                        margin-right: 10px;
                        border-radius: 5px;
                        background: url('@/assets/img/level/check1.png') no-repeat center;
                        background-size: contain;
                    }
                    input[type=checkbox]:checked+label.checkbox{
                        background: url('@/assets/img/level/check2.png') no-repeat center;
                        background-size: contain;
                    }
                    label{
                        font-size: 18px;
                    }
                    button{
                        font-size: 18px;
                        margin-left: auto;
                        color: #a199b1;
                        text-decoration: underline;
                        text-underline-position: under;
                    }
                    &.all-agree{
                        border-bottom: 2px solid #a199b1;
                        padding: 0 0 10px;
                        label{
                            font-size: 20px;
                            font-family: "SCDream6";
                        }
                    }
                }
            }
            .authNumberPopup,.confirmPopup{
                position:fixed;
                width: 100%;
                height: 100%;
                top: 0;
                left: 0;
                background-color: #0000005d;
                z-index: 99999;
                @include flex();
                >div{
                    background-color: $white;
                    width: 350px;
                    height: 180px;
                    border-radius: 10px;
                    text-align: center;
                    @include flex(center, center, column);
                    padding: 0 15px;
                    >div{
                        font-size: 20px;
                        margin-top: 20px;
                        button{
                            background-color: $pink;
                            color: $white;
                            padding: 10px 20px;
                            border-radius: 10px;
                            font-size: 18px;
                            font-weight: 600;
                        }
                    }
                }

            }
            #confirmBtn{
                text-align: center;
                height: 70px;
                @include flex();
                margin-top: 30px;
                font-size: 22px;
            }
        }
    }
    #banner{
        margin-top: 50px;
        >div {
            height: 240px;
            background: url('@/assets/img/level/banner.webp') no-repeat center;
            background-size: contain;
            @include flex(center, center, column);
            text-align: center;
            padding: 0;
            margin: 0 30px;
        }
        h5{
            text-align: center;
            font-size: 22px;
            margin-bottom: 7px;
            br{
                display: none;
            }
        }
        span{
            font-size: 18px;
        }
    }
    #QnA{
        h4{
            text-align: center;
            font-size: 30px;
            margin-bottom: 20px;
        }
        >div{
            width: 100%;
            .qna-box{
                width: 100%;
                margin-bottom: 5px;
                padding: 0 30px;
                background-color: #f9f9f9;
                .qna-title{
                    display: flex;
                    justify-content: flex-start;
                    align-items: center;
                    padding: 15px 0;
                    h6{
                        font-size: 22px;
                    }
                    .question{
                        background: url('@/assets/img/level/question.png') no-repeat center;
                        width: 40px;
                        height: 40px; 
                        background-size: contain;
                        margin-right: 15px;
                    }
                    .arrow{
                        background: url('@/assets/img/level/arrow.png') no-repeat center;
                        width: 30px;
                        height: 30px; 
                        margin-left: auto;
                        cursor: pointer;
                        padding: 20px;
                        background-size: 20px 13px;
                        transition: all 0.4s;
                        &.open{
                            transform: rotate(180deg);
                        }
                    }
                }
                .qna-text{
                    height: auto;
                    max-height: 0px;
                    overflow: hidden;
                    transition: all 0.6s;
                    hr{
                        border: 0;
                        height: 5px;
                        background: #f1f1f1;
                    }
                    p{
                        font-size: 20px;
                        line-height: 28px;
                        padding: 20px 0 25px;
                        color: #707070;
                        width: 100%;
                    }
                    &.open{
                        max-height: 500px;
                    }
                }

            }
        }
    }
    #info{
        margin-bottom: 100px;
        h4{
            text-align: center;
            font-size: 30px;
            margin-bottom: 40px;
        }
        .info-wrapper{
            @include flex(space-between);
            a{
                width: 23%;
                background-color: #f9f9f9;
                @include flex(center, center, column);
                padding: 20px 0;
                &+a{
                    margin-left: 1%;
                }
                img{
                    margin-bottom: 15px;
                }
                p, h5{
                    font-size: 18px;
                    line-height: 24px;
                }
            }
            
        }
    }
}

@media screen and (max-width: 1024px) {
#container{
    header{
        background-position: 40% 50%;
        height: 50vh;
    }
    #text{
        text-align: center;
        h3{
            font-size: 28px;
            line-height: 45px;
            padding: 30px 0;
            span{
                font-size: 28px;
                line-height: 45px;

            }
        }
    }
    #form{
        h2{
            text-align: center;
        }
    }
    #banner{
        >div{
            margin: 0 10px;
            h5{
                br{display: block;}
            }
        }
    }
    #QnA{
        >div{
            .qna-box{
                .qna-title{
                    font-size: 24px;
                }
            }
        }
    }
    #info{
        .info-wrapper{
            a{
                width:24%;
                &+a{
                    margin-left: 0.5%;
                }
            }
            
        }
    }
}
}
@media screen and (max-width: 767px) {
#container{
    header{
        height: 50vh;
        >div{
            margin-top: auto;
            margin-bottom: 20px;
        }
        h1{
            text-align: left;
            margin-left: 0;
            margin-right: auto;
            margin-top: auto;
        }
    }
    #text{
        h3{
            font-size: 20px;
            line-height: 32px;
            padding: 30px 0;
            text-align: left;
            br.mb{
                display: block;
            }
            span{
                font-size: 20px;
                line-height: 32px;
            }
        }
    }
    #form{
        >div{
            h2{
                text-align: left;
                font-size: 28px;
            }
            p{
                font-size: 20px;
            }
            h4{
                font-size: 24px;
            }
            .radio-wrapper{
                >div{
                    margin-top: 5px;
                    input[type=radio]{
                        margin-right: 6px;
                        width: 20px;
                        height: 20px;
                    }
                    input + label{
                        font-size: 18px;
                    }
                }
            }
            .input-wrapper{
                input{
                    height: 50px;
                    font-size: 18px;
                }
                button{
                    font-size: 16px;
                }
                button.pink{
                    height: 50px;
                }
                .agree-wrapper{
                    >div{
                        flex-wrap: wrap;
                        align-items: flex-start;
                        margin-bottom: 5px;
                        input[type=checkbox] + label.checkbox{
                            width: 24px;
                            height: 24px;
                            margin-right: 8px;
                        }
                        label.font4{
                            font-size: 16px;
                            width: 90%;
                        }
                        button{
                            font-size: 16px;
                            text-align: left;
                            margin-left: 30px;
                            margin-top: -3px;

                        }
                        &.all-agree{
                            label{
                                font-size: 18px;
                            }
                        }
                    }
                }
                #confirmBtn{
                    height: 60px;
                    font-size: 20px;
                }
                .select-time{
                    >div{
                        overflow-y: scroll;
                        padding: 35px 15px;
                        max-width: 335px;
                        p{
                            font-size: 15px;
                        }
                        div{
                            margin-top: 20px;
                            ul li{
                                padding: 8px 15px;
                                margin: 3px 3px;
                                font-size: 15px;
                            }
                        }
                        .close{
                            top: 5px;
                            right: 5px;
                        }
                    }
                }
                
            } 
        }
    }
    #banner{
        h5{
            font-size: 18px;
            margin-bottom: 15px;
        }
        span{
            font-size: 16px;
        }
        >div{
            background-size: cover;
            height: 140px;
            border-radius: 20px;
            margin: 0;
        }
    }
    #QnA{
        h4{
            font-size: 28px;
        }
        >div{
            .qna-box{
                padding: 0 10px;
                .qna-title{
                    h6{
                        font-size: 18px;
                    }
                   
                    .question{
                        margin-right: 8px;
                        width: 34px;
                        height: 34px;
                    }
                    .arrow{
                        padding: 0px;
                        background-size: 13px 8px;
                        width: 15px;
                    }
                } 
                .qna-text{
                    p{
                        font-size: 16px;
                        line-height: 24px;
                    }
                }
            }
        }
    }
    #info{
        >div{
            margin: 0;
        }
        h4{
            font-size: 28px;
        }
        .info-wrapper{
            flex-wrap: wrap;
            a{
                width: 49%;
                min-width: 100px;
                &+a{
                    margin-bottom: 8px;
                }
            }
        }
    }
}
}
</style>

<script>
export default {
    name: 'level-test',
    layout: 'default',
    data(){
        return{
            openSelectGrade: false,
            openSelectTime: false,
            gradeData:["미취학", "초등학교 1학년", "초등학교 2학년", "초등학교 3학년", "초등학교 4학년", "초등학교 5학년", "초등학교 6학년", "중학교 2학년", "중학교 3학년", "고등학교 1학년", "고등학교 2학년", "고등학교 3학년", "성인"],
            dateData:{today:{month: null, day: null, kor: '오늘'}, tomorrow:{month: null, day: null, kor: '내일'}},
            timeDate:['14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30'],
            confirmData:{
                userName: null,
                userGrade: null,
                userDay: null,
                userTime: null,
                userPhone: null
            },
            agreeAll: false,
            agree:{ agr1: false, agr2: false},
            classDate: null,
            alert: {
                popup: false,
                sendAuth: false,
                phoneErr: false
            },
            confirmPopup: {
                open: false,
                message: null
            },
            common:[]
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.getDate();
        this.motion();
        window.addEventListener('scroll', this.motion);
    },
    filters:{
        dayFilter(v){
            return v = (v<10?'0'+v:v)
        },
        hyphen(v){
            return String(v).replace(/^(\d{2,3})(\d{3,4})(\d{4})$/, `$1-$2-$3`);
        }
    },
    watch:{
        confirmData:{
            deep: true,
            handler(e){
                if(e.userDay !== null){
                    console.log(e)
                    var month = e.userDay.month,
                        day = e.userDay.day;

                    if(month < 10) month = '0'+month;
                    if(day < 10) day = '0'+day;

                    this.classDate = `${month}/${day} (${e.userDay.kor}) ${e.userTime}`
                }
                if(e.userPhone !== null){
                    return e.userPhone = e.userPhone.replace(/[^0-9]/g, '');
                }
            }
        },
    },
    methods:{
        getDate(){
            var today = new Date();
            var tomorrow = new Date(today.setDate(today.getDate() +1));
            
            this.dateData.today.month = today.getMonth()+1;
            this.dateData.today.day = today.getDate()-1;

            this.dateData.tomorrow.month = tomorrow.getMonth()+1;
            this.dateData.tomorrow.day = tomorrow.getDate();
        },
        openQnA(e){
            var textBox = e.target.parentElement.nextElementSibling;
            textBox.classList.toggle('open');
            e.target.classList.toggle('open');
        },
        checkPhoneNumber(){
            var phone = String(this.confirmData.userPhone);
            this.alert.popup = true; 
            (phone.length == 11) ? this.alert.sendAuth = true : this.alert.phoneErr = true
        },
        closeAlert(status){
            this.alert.popup = false; 
            this.alert.sendAuth = false;
            this.alert.phoneErr = false;

            var phoneInput = this.$el.querySelector('#userPhone'),
                authInput = this.$el.querySelector('#authNumber');


            if(status == 'editPhone'){
                phoneInput.disabled = false;
                authInput.disabled = true;
            }
            if(status == 'ok'){
                phoneInput.disabled = true;
                authInput.disabled = false;
            }
        },
        agreeAllEvent(e){    
            if(e.target.checked == true){
                Object.entries(this.agree).forEach(([key, value]) => {
                    this.agree[key] = true;
                });
            }else{
                Object.entries(this.agree).forEach(([key, value]) => {
                    this.agree[key] = false;
                });
            }
        },
        agreeEvent(e){
            if(e.target.checked == false){
                this.agreeAll = false;
            }else{
                var count = 1;

                Object.entries(this.agree).forEach(([key, value]) => {
                    if(value == true) count++
                });

                if(count == Object.values(this.agree).length) this.agreeAll = true;
            }
        },
        confirm(){
            var data = this.confirmData;

            console.log(data)
            if(data.userName == null || data.userName.length<2){
                return this.confirmPopupEvent('이름을 정확히 입력해 주세요.')
            }
            if(data.userGrade == null){
                return this.confirmPopupEvent('학년을 선택해 주세요.')
            }
            if(data.userTime == null){
                return this.confirmPopupEvent('수업 일시를 선택해 주세요.')
            }
            if(data.userPhone == null){
                return this.confirmPopupEvent('전화번호 인증을 완료해 주세요.')
            }
            if(this.agree.agr1 == false){
                return this.confirmPopupEvent('필수 약관에 동의해 주세요.')
            }
            return this.confirmPopupEvent('신청이 완료되었습니다.')

        },
        confirmPopupEvent(msg){
            this.confirmPopup.open = true;
            this.confirmPopup.message = msg;
        },
        motion(){
            var myScroll = window.scrollY;
            var offset = window.innerWidth < 767 ? 300 : 500
            
            var textOffset = this.$el.querySelector('#text h3').getBoundingClientRect().top + window.pageYOffset - offset;
            if(myScroll >= textOffset) this.addAct('#text h3 span');
 
        },
        addAct(element){
            var ele = this.$el.querySelectorAll(element);
            
            ele.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 200*idx);
            });
        },
    

    },
    beforeDestroy () {
        window.removeEventListener('scroll', this.motion);
    }
}

</script>
