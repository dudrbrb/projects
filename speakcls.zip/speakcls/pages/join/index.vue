<template>
    <div id="container">
        <section id="join" v-if="agreePage==false">
            <div>
                <div class="progress-bg">
                    <div class="progress"></div>
                </div>
                <h1>이메일로 회원가입하기</h1>
                <div class="input-wrapper" :class="{'error': error.email}">
                    <input type="text" placeholder="speakcls@example.com" v-model="userInfo.email" @input="checkEmail">
                    <p class="font3 email-text">로그인, 비밀번호 찾기, 알림에 사용되니 정확한 이메일을 입력해 주세요.</p>
                </div>
                <div class="input-wrapper" :class="{'error': error.password}">
                    <input :type="openPW ?'text':'password'" placeholder="스픽클 비밀번호 설정" v-model="userInfo.password" id="password"  @input="checkpassword">
                    <button id="openPW" @click="openPW=!openPW"><img :src="require('@/assets/img/login/eye-icon.png')" alt="비밀번호 보이기/가리기 버튼"></button>
                    <p class="font3 password-text">비밀번호는 8~20자 이내로 영문 대소문자, 숫자, 특수문자 중 3가지 이상 혼용하여 입력해 주세요.</p>
                </div>
                <button :class="{'pink': joinBtn}"  class="font6 gray" @click="join">스픽클 회원가입</button>
                <div class="border">
                    <p>또는 다른 서비스 계정으로 가입</p>
                    <hr>
                </div>
                <div class="sns-list" >
                    <div id="kakao"><img :src="require('@/assets/img/login/kakao.webp')"></div>
                    <div id="naver"><img :src="require('@/assets/img/login/naver.webp')"></div>
                    <div id="facebook"><img :src="require('@/assets/img/login/facebook.webp')"></div>
                    <div id="apple"><img :src="require('@/assets/img/login/apple.webp')"></div>
                    <p class="font3">SNS계정으로 간편하게 가입하며 서비스를 이용하실 수 있습니다. <br> 
                        기존 스픽클 계정과는 연동되지 않으니 이용에 참고하세요.
                    </p>
                </div>
            </div>

        </section>
        <section id="agree" v-else>
             <div>
                <h2>스픽클 이용약관에 동의하시면<br>
                    가입이 완료됩니다.</h2>
                <div class="input-box">
                    <input type="checkbox" name="all-agree" id="allAgree" v-model="agreeAll" @input="agreeAllEvent">
                    <label for="allAgree" class="checkbox"></label>
                    <label for="allAgree" class="font5">전체 약관에 동의합니다.</label>
                </div>
                <div class="input-wrapper">
                    <div class="input-box">
                        <input type="checkbox" name="all-agree" id="agr1" v-model="agree.agr1" @input="agreeEvent($event)">
                        <label for="agr1" class="checkbox"></label>
                        <label for="agr1" class="font5">만 14세 이상입니다. <span class="font5">(필수)</span></label>
                    </div>
                    <div class="input-box">
                        <input type="checkbox" name="agr2" id="agr2" v-model="agree.agr2" @input="agreeEvent($event)">
                        <label for="agr2" class="checkbox"></label>
                        <label for="agr2" class="font5">서비스 이용약관 <span class="font5">(필수)</span></label>
                    </div>
                    <div class="input-box">
                        <input type="checkbox" name="agr3" id="agr3" v-model="agree.agr3" @input="agreeEvent($event)">
                        <label for="agr3" class="checkbox"></label>
                        <label for="agr3" class="font5">개인정보 수집, 이용 동의 <span class="font5">(필수)</span></label>
                    </div>
                    <div class="input-box">
                        <input type="checkbox" name="agr4" id="agr4" v-model="agree.agr4" @input="agreeEvent($event)">
                        <label for="agr4" class="checkbox"></label>
                        <label for="agr4" class="font5">프로필정보 수집 추가 동의 (선택)</label>
                    </div>
                </div>
                <button :class="{'pink': joinFinBtn}" class="font6 gray" @click="joinFin">회원가입 완료</button>
            </div>

        </section>
        <div class="confirmPopup" v-if="confirmPopup.open">
            <div>
                <div>
                    {{confirmPopup.message}}
                </div>
                <div>
                    <button @click="closePopup">확인</button>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
#container.form{
    #join{
        h1{
            text-align: left;
            width: 100%;
        }
        >div{
            .progress-bg{
                width: 100%;
                height: 5px;
                background-color: #dcdcdc;
                position: absolute;
                top: 0;
                left: 0;
                .progress{
                    width: 30%;
                    height: 100%;
                    background-color: $pink;
                }
            }
            .input-wrapper{
                width: 100%;
                margin-bottom: 20px;
                position: relative;
                &.error{
                    input{
                        border: 1px solid $pink;
                    }
                    p{
                        color: $pink;
                        &::before{
                            border-color: $pink;
                        }
                    }
                }
                #openPW{
                    position: absolute;
                    width: 30px;
                    height: 30px;
                    padding: 0;
                    margin: 0;
                    top:15px;
                    right: 20px;
                    line-height: 0;
                    background: none;
                }
                p{
                    position: relative;
                    padding-left: 25px;
                    &::before{
                        content: '!';
                        border: 2px solid #6b6a6f;
                        border-radius: 50%;
                        font-size: 12px;
                        position: absolute;
                        top: 2px;
                        left: 0;
                        width: 15px;
                        height: 15px;
                        text-align: center;
                        line-height: 15px;
                    }
                
                }
            }

        }
    }
    #agree{
        >div{
            .input-box{
                display: flex;
                justify-content: flex-start;
                align-items: center;
                width: 100%;
                height: 60px;
                padding: 0 15px;
                &+.input-box{
                    border-top: 1px solid $gray;
                }
                input[type=checkbox]{
                    display: none;
                }
                input[type=checkbox]+label.checkbox{
                    width: 20px;
                    height: 20px;
                    margin-right: 10px;
                    border: 2px solid $gray;
                }
                input[type=checkbox]:checked+label.checkbox{
                    background: url('@/assets/img/login/checkbox.png') no-repeat center;
                    background-size: contain;
                    border: none;
                }
                label{
                    span{
                        color: $pink;
                    }
                }
            }
            .input-wrapper{
                width: 100%;
                margin-bottom: 20px;
                background-color: $white;
                border-radius: 10px;
            }


        }
    }
}

@media screen and (max-width: 767px){
#container.form{
    #join{
        >div{
            h1{
                font-size: 28px;
            }
            .progress-bg{
               display: none;
            }
            .input-wrapper{
                margin-bottom: 20px;
            }
            .border{
                margin-top: 20px;
            }
        }
    }
    #agree{
        width: 100%;
        margin: 0;
        padding: 70px 20px;
        >div{
            width: 100%;
            h2{
                width: 100%;
                font-size: 26px;
            }
        }
    }
}
}

</style>

<script>
export default {
    name: 'join',
    layout: 'form',
    data(){
        return{
            openPW: false,
            confirmPopup: {
                open: false,
                message: null
            },
            userInfo:{
                email: null,
                password: null
            },
            joinBtn: false,
            joinFinBtn: false,
            agreePage: false,
            agreeAll: false,
            agree: {
                agr1: false,
                agr2: false,
                agr3: false,
                agr4: false
            },
            error:{
                email: false,
                password: false

            }
        }
    },
    created(){
    },
    mounted(){
    },
    watch:{
        userInfo:{
            deep: true,
            handler(e){
                if(String(e.email) !== 'null' && String(e.password) !== 'null'){
                    if(this.error.email == false && this.error.password == false){
                        return this.joinBtn = true;
                    }else{
                        return this.joinBtn = false;
                    }
                }else{
                    return this.joinBtn = false;
                }
            }
        },
        agree:{
            deep: true,
            handler(e){
                if(e.agr1 && e.agr2 && e.agr3) this.joinFinBtn = true
                else this.joinFinBtn = false
            }
        }
    },
    filters:{
    },
    methods:{
        checkEmail(){
            var em = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i,
                textbox= this.$el.querySelector('.email-text');

            if(em.test(this.userInfo.email)){
                textbox.innerHTML = '로그인, 비밀번호 찾기, 알림에 사용되니 정확한 이메일을 입력해 주세요.';
                this.error.email=false;
            }else{
                textbox.innerHTML = '이메일을 정확히 입력해 주세요.';
                this.error.email=true;
            }
        },
        checkpassword(){
            var num = this.userInfo.password.search(/[0-9]/g),
                eng = this.userInfo.password.search(/[a-z]/ig),
                spe = this.userInfo.password.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi),
                textbox = this.$el.querySelector('.password-text');
            
            // console.log(pw.test(this.userInfo.password))
            if(this.userInfo.password == null || this.userInfo.password.length < 8 || this.userInfo.password.length > 20){
                textbox.innerHTML = '비밀번호는 8~20자 이내로 입력해 주세요.';
                return this.error.password=true;
            }else if(this.userInfo.password.search(/\s/) != -1){
                textbox.innerHTML = '비밀번호는 공백 없이 입력해주세요.';
                return this.error.password=true;
            }else if(num < 0 || eng < 0 || spe < 0){
                textbox.innerHTML = '비밀번호는 8~20자 이내로 영문 대소문자, 숫자, 특수문자 중 3가지 이상 혼용하여 입력해 주세요.';
                this.error.password=true;
            }else{
                textbox.innerHTML = '비밀번호는 영문 대소문자, 숫자, 특수문자 중 3가지 이상 혼용하여 입력해 주세요.';
                this.error.password=false;
            }
        },

        join(){
            if(this.joinBtn == false) return
            this.agreePage = true;
        },
        joinFin(){
            if(this.joinFinBtn == false) {
                return this.confirmPopupEvent('필수 약관에 동의해주세요')
            } else {
                this.confirmPopupEvent('회원가입이 완료되었습니다.')
            }
        },
        agreeAllEvent(e){    
            if(e.target.checked == true){
                Object.entries(this.agree).forEach(([key, value]) => {
                    this.agree[key] = true;
                });
            }else{
                Object.entries(this.agree).forEach(([key, value]) => {
                    this.agree[key] = false;
                });
            }
        },
        agreeEvent(e){
            if(e.target.checked == false){
                this.agreeAll = false;
            }else{
                var count = 1;

                Object.entries(this.agree).forEach(([key, value]) => {
                    if(value == true) count++;
                });

                if(count == Object.values(this.agree).length) this.agreeAll = true;
            }
        },
        confirmPopupEvent(msg){
            this.confirmPopup.open = true;
            this.confirmPopup.message = msg;
        },
        closePopup(){
            this.confirmPopup.open = false;
            if(this.joinFinBtn == true){
                console.log(this.$route);
                this.$router.push({ path: '/' });
            }
        }
    }
}

</script>
