<template>
    <div id="container">
        <header>
            <div>
                <article style="z-index: 1;">
                    <p v-if="$device.isMobile " class="mb">체험해보면 그 차이를 알 수 있습니다!</p>
                    <h1 v-if="$device.isMobile ">초등전문 <br>화상영어 스픽클</h1>
                    <h1 v-else>초등전문 화상영어, 스픽클 <br>체험해보면 그 차이를 알 수 있습니다!
                    </h1>
                    <p>아이가 말 한마디를 못한다구요?<br>
                        영어에 재미를 느끼면 언어는 <br v-if="$device.isMobile">알아서 향상됩니다.
                    </p>
                    <nuxt-link :to="'/level-test'" class="font6">무료레벨테스트</nuxt-link>
                </article>
                <article>
                    <img :src="require('@/assets/img/main/main.webp')"  alt="스픽클 수업을 듣는 학생"/>
                </article>
            </div>
        </header>

        <section id="point" class="bg-light">
            <div>
                <h2>스픽클이 특별한 이유 5가지</h2>
                <p>비교할수록 자신있는 특별함</p>
                <article  v-if="$device.isMobile">
                    <div class="card card1">
                        <h5>직영센터운영10년</h5>
                        <p>2012년부터 어학원, 영어 캠프로 시작하여 화상영어까지 직접 운영 중 입니다.</p>
                    </div>
                    <div class="card card2">
                        <h5>초등전문 커리큘럼</h5>
                        <p>100개 이상 초등영어학원 원장님들이 선택한 초등 전문 화상영어입니다.</p>
                    </div>
                    <div class="card card3">
                        <h5>비교할 수 없는 가격</h5>
                        <p>중간 마진 없이 직접 고객에게 서비스하여 합리적인 가격으로 제공합니다.</p>
                    </div>
                    <div class="card card4">
                        <h5>체계적인 커리큘럼</h5>
                        <p>피닉스부터 원서, 영자신문까지 아이 수준에 맞는 학습과정을 구성하였습니다.</p>
                    </div>
                    <div class="card card5">
                        <h5>테솔 선생님만 채용</h5>
                        <p>마인드, 발음, 밝은 성격, 테솔 등 하나라도 부합하지 않으면 채용하지 않습니다.</p>
                    </div>
                </article>
                <article v-else>
                    <swiper :options="swiperOption">
                        <swiper-slide>
                            <div class="card card1">
                                <h5>직영센터운영<br>10년</h5>
                                <p>2012년부터 어학원, 영어 캠프로 시작하여 화상영어까지 직접 운영 중 입니다.</p>
                            </div>
                            <div class="card card2">
                                <h5>초등전문<br>커리큘럼</h5>
                                <p>100개 이상 초등영어학원 원장님들이 선택한 초등 전문 화상영어입니다.</p>
                            </div>
                            <div class="card card3">
                                <h5>비교할 수 없는<br>가격</h5>
                                <p>중간 마진 없이 직접 고객에게 서비스하여 합리적인 가격으로 제공합니다.</p>
                            </div>
                        </swiper-slide>
                        <swiper-slide>
                            <div class="card card4">
                                <h5>체계적인<br>커리큘럼</h5>
                                <p>피닉스부터 원서, 영자신문까지 아이 수준에 맞는 학습과정을 구성하였습니다.</p>
                            </div>
                            <div class="card card5">
                                <h5>테솔 선생님만<br>채용</h5>
                                <p>마인드, 발음, 밝은 성격, 테솔 등 하나라고 부합하지 않으면 채용하지 않습니다.</p>
                            </div>
                        </swiper-slide>
                        <div class="swiper-pagination" slot="pagination"></div>
                    </swiper>
                </article>
            </div>
        </section>

        <section id="video" class="bg-pink">
            <div>
                <article>
                    <p>우리 아이가 달라졌어요!</p>
                    <h2 v-if="$device.isMobile" >초등학생 맞춤 스피킹 유도수업</h2>
                    <h2 v-else>초등학생에게 맞는 스피킹 유도수업!</h2>
                    <div class="video-wrapper">

                    </div>
                    <p class="font4 ment" v-if="$device.isMobile" >초등학생에게 중요한 <span class="font6">스피킹 자신감!<br>"재미"와 "칭찬"으로 수업</span>진행
                        <img :src="require(`@/assets/img/main/line1.webp`)" class="line1" alt="동그라미 체크"  loading="lazy">
                        <img :src="require(`@/assets/img/main/line2.webp`)" class="line2" alt="밑줄" loading="lazy">
                    </p>
                    <p class="font4 ment"  v-else>초등학생들에게 가장 중요한 건 <span class="font6">스피킹 자신감! <br>"재미"와 "칭찬"을 기반으로 수업</span>을 진행합니다.
                        <img :src="require(`@/assets/img/main/line1.webp`)" class="line1" alt="동그라미 체크"  loading="lazy">
                        <img :src="require(`@/assets/img/main/line2.webp`)" class="line2" alt="밑줄" loading="lazy">
                    </p>
                </article>
            </div>
        </section>

        <section id="career" class="bg-light">
            <div  v-if="common.width>980">
                <article>
                    <div>
                        <img :src="require(`@/assets/img/main/career/1.webp`)" alt="2021년 초등화상영어 교육 만족도 1위" loading="lazy">
                    </div>
                    <div class="career-txt">
                        <h3>1위</h3>
                        <p class="font4">2021년 초등화상영어<br>교육 만족도 1위</p>
                    </div>
                </article>
                <article>
                    <div>
                        <img :src="require(`@/assets/img/main/career/2.webp`)" alt="2012년직영센터 운영" loading="lazy">
                    </div>
                    <div class="career-txt">
                        <h3>10년</h3>
                        <p class="font4">2012년<br>직영센터 운영</p>
                    </div>
                </article>
                <article>
                    <div>
                        <img :src="require(`@/assets/img/main/career/3.webp`)" alt="협약된 초등영어학원 수 100곳" loading="lazy">
                    </div>
                    <div class="career-txt">
                        <h3>100곳</h3>
                        <p class="font4">협약된<br>초등영어학원 수</p>
                    </div>
                </article>
                <article>
                    <div>
                        <img :src="require(`@/assets/img/main/career/4.webp`)" alt="스픽클과 함께한 학생들 1.5만명" loading="lazy">
                    </div>
                    <div class="career-txt">
                        <h3>1.5만명</h3>
                        <p class="font4">스픽클과<br>함께한 학생들</p>
                    </div>
                </article>
            </div>
            <div v-else class="mb">
                  <article>
                       <p class="career-txt">교육 만족도 <span class="font6">1위</span></p>
                  </article>
                  <article>
                       <p class="career-txt"><span class="font6">10년</span> 직영센터 운영</p>
                  </article>
                  <article>
                       <p class="career-txt">협약 영어학원 <span class="font6">100곳</span></p>
                  </article>
                  <article>
                        <p class="career-txt"><span class="font6">1.5만명</span> 함께한 학생들</p>
                  </article>
            </div>
        </section>

        <section id="compare" class="bg-gray">
            <div>
                <article  v-if="$device.isMobile" class="itemlist">
                    <ul>
                        <li @click="compareItem='스픽클'" :class="{'act': compareItem == '스픽클'}">스픽클</li>
                        <li @click="compareItem='학원'" :class="{'act': compareItem == '학원'}">학원</li>
                    </ul>
                </article>
                <article v-else>
                    <ul class="list-header">
                        <li class="font5">스피킹시간</li>
                        <li class="font5">수업인원</li>
                        <li class="font5">주3회 회비</li>
                        <li class="font5">수업방식</li>
                    </ul>
                </article>
                <article v-if="!$device.isMobile">
                    <h3>
                        <img :src="require(`@/assets/img/main/logo1.webp`)" alt="스픽클 아이콘" loading="lazy">
                        스픽클
                    </h3>
                    <ul class="speakcls-list"> 
                        <li>수업당 25분</li>
                        <li>1:1</li>
                        <li>8만원</li>
                        <li>원서읽고 대화</li>
                    </ul>
                </article>
                <article v-if="!$device.isMobile">
                    <h3>
                        <img :src="require(`@/assets/img/main/logo2.webp`)" alt="학원 아이콘" loading="lazy">
                        학원
                    </h3>
                    <ul class="etc-list">
                        <li class="font3">5분</li>
                        <li class="font3">그룹수업</li>
                        <li class="font3">20만원</li>
                        <li class="font3">단어외우고 문법</li>
                    </ul>
                </article>
                <article v-else class="campare-swiper">
                    <swiper :options="compareSwiperOption"  ref="mySwiper" @slideChange="slideChange">
                        <swiper-slide>
                            <h3>
                                <img :src="require(`@/assets/img/main/logo1.webp`)" alt="스픽클 아이콘" loading="lazy">
                                스픽클
                            </h3>
                            <ul class="speakcls-list"> 
                                <li>수업당 25분</li>
                                <li>1:1</li>
                                <li>8만원</li>
                                <li>원서읽고 대화</li>
                            </ul>
                        </swiper-slide>
                        <swiper-slide>
                            <h3>
                                <img :src="require(`@/assets/img/main/logo2.webp`)" alt="학원 아이콘" loading="lazy">
                                학원
                            </h3>
                            <ul class="etc-list">
                                <li>5분</li>
                                <li>그룹수업</li>
                                <li>20만원</li>
                                <li>단어외우고 문법</li>
                            </ul>
                        </swiper-slide>
                    </swiper>
                </article>
            </div>
        </section>

        <section id="class" class="bg-light">
            <div>
                <article class="sticky-box">
                    <h2>모두 의미가 있는 <br>25분 화상수업</h2>
                    <p>핵심을 자신있게 공개하는 이유는<br>
                        모두 이렇게 가르칠 수 있는건 아닙니다.<br>
                        지루하지 않는 수업 "커리큘럼"<br v-if="common.width > 1024 || common.width < 600">
                        계속 진행하기 위한 "흥미요소"<br><br>
                        2가지 모두 잡기 위한 스픽클의 노력입니다.
                    </p>
                </article>
                <article class="intro-box">
                    <div>
                        <div class="gif-wrapper">
                            <!-- <img :src="require(`@/assets/img/main/guide/1.gif`)" alt="예습의 힘 - 레슨플랜 제공" loading="lazy"/> -->
                            <img :src="require(`@/assets/img/main/guide/1.${format}`)" alt="예습의 힘 - 레슨플랜 제공" loading="lazy"/>
                        </div>
                        <div class="text-wrapper">
                            <div class="num-box font6">01</div>
                            <div class="txt-box">
                                <span>예습의 힘 - 레슨플랜 제공</span>
                                <h4>수업 전 미리 이해하면<br>더 잘 듣고 말한다!</h4>
                                <ul>
                                    <li class="font3">정해진 레슨플랜으로 미리 원서를 듣고 따라 말하며 내용을 알면 수업에 3배 적극적입니다.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="gif-wrapper">
                            
                            <img :src="require(`@/assets/img/main/guide/2.${format}`)" alt="반복의 힘 - 준비와 자신감 유도" loading="lazy"/>
                        </div>
                        <div class="text-wrapper">
                            <div class="num-box font6">02</div>
                            <div class="txt-box">
                                <span>반복의 힘 - 준비와 자신감 유도</span>
                                <h4>매일 같은 질문은<br>준비하게 한다!</h4>
                                <ul>
                                    <li class="font3">같은 질문으로 대답을 미리 생각하게 하고 반복을 통해 인지 → 단어 → 문장으로 성장시키고 대답한 질문은 다른 질문으로 변경됩니다.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div>
                          <div class="gif-wrapper">
                            <img :src="require(`@/assets/img/main/guide/3.${format}`)"  alt="뇌 친화력 : 이미지 트레이닝" loading="lazy"/>
                        </div>
                        <div class="text-wrapper">
                            <div class="num-box font6">03</div>
                            <div class="txt-box">
                                <span>뇌 친화력 : 이미지 트레이닝</span>
                                <h4>뜻은 외우는게 아니라<br>이미지로 인지해야 한다!</h4>
                                <ul>
                                    <li class="font3">내용에 들어가기 전 단어와 이미지를 매칭하며 본문에 나왔을 때 이미지 반복 연상이 가능합니다.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div>
                          <div class="gif-wrapper">
                            <!-- <img :src="require(`@/assets/img/main/guide/4.gif`)"  alt="질문의 힘 : 스피킹 트레이닝" loading="lazy"/> -->
                            <img :src="require(`@/assets/img/main/guide/4.${format}`)"  alt="질문의 힘 : 스피킹 트레이닝" loading="lazy"/>
                        </div>
                        <div class="text-wrapper">
                            <div class="num-box font6">04</div>
                            <div class="txt-box">
                                <span>질문의 힘 : 스피킹 트레이닝</span>
                                <h4>계속적인 말하기 유도는<br>스피킹에 가장 효과적이다!</h4>
                                <ul>
                                    <li class="font3">본문을 따라 말하며 내용을 인지시키고, 그림을 통해 유도질문하며 계속 스피킹을 합니다. 많은 질문으로 부담을 느끼는 학생은 칭찬과 병행하여 진행합니다.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div>
                          <div class="gif-wrapper">
                            <img :src="require(`@/assets/img/main/guide/5.${format}`)"  alt="피드백의 힘 : 기억의 장기화" loading="lazy"/>
                            <!-- <img :src="require(`@/assets/img/main/guide/5.gif`)"  alt="피드백의 힘 : 기억의 장기화" loading="lazy"/> -->
                        </div>
                        <div class="text-wrapper">
                            <div class="num-box font6">05</div>
                            <div class="txt-box">
                                <span>피드백의 힘 : 기억의 장기화</span>
                                <h4>문제풀기와 칭찬은<br>장기기억으로 전환된다!</h4>
                                <ul>
                                    <li class="font3">4~5가지 유형의 문제들로 정확하게 이해했는지 파악하고 피드백을 통해<br v-if="common.width <= 540"> 장기 기억으로 변환합니다.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
        </section>

        <section id="cost">
            <div v-if="common.width>980">
                <article>
                    <h2>비교하면 할수록 놀라운 수강료!</h2>
                    <div class="price">
                        <p>월 <span class="font7 price-count">{{count | comma}}</span>원</p>
                        <span>(실속타임 주 2회 12개월 96회 기준)</span>
                    </div>
                    <p class="font5">좋은 서비스는 결국 가격까지 포함해서 결정!</p>
                    <p>직접 센터를 운영하고 바로 학생과 만나<br>화상영어 시장의 가격을 혁신하였습니다.</p>
                </article>
                <article class="bar-wrapper">
                    <div class="bubble">
                        <p class="font5">회당 3,920원</p>
                    </div>
                    <div class="bar speakcls">
                        <h4>스픽클</h4>
                        <div class="bar-cover">
                            <img :src="require(`@/assets/img/main/price/bar1.webp`)" alt="스픽클 비용 월 3920원" loading="lazy">
                            <span class="font4">회당 3,920원</span>
                        </div>
                    </div>
                    <div class="bar">
                        <h4>I사</h4>
                        <div class="bar-cover">
                            <img :src="require(`@/assets/img/main/price/bar2.webp`)" alt="I사 비용 월 6800원" loading="lazy">
                            <span class="font4">회당 6,800원</span>
                        </div>
                    </div>
                    <div class="bar">
                        <h4>M사</h4>
                        <div class="bar-cover">
                            <img :src="require(`@/assets/img/main/price/bar3.webp`)" alt="M사 비용 월 10692원" loading="lazy">
                            <span class="font4">회당 10,692원</span>
                        </div>
                    </div>
                    <p> (초등 화상영어 서비스 1회 수업 가격 비교)<br>
                    12개월, 주 5회, 25분 기준</p>
                </article>
            </div>
            <div v-else class="mb">
                <article>
                    <h2>비교하면 할수록 놀라운 수강료!</h2>
                    <p class="font5">좋은 서비스는 결국 가격까지 포함!</p>
                    <p>직접 센터를 운영하고 바로 학생과 만나<br>화상영어 시장의 가격을 혁신하였습니다.</p>
                </article>
                <article class="bar-wrapper">
                    <div class="bubble">
                        <p class="font5">회당 3,920원</p>
                    </div>
                    <div class="bar speakcls">
                        <h4>스픽클</h4>
                        <div class="bar-cover">
                            <img :src="require(`@/assets/img/main/price/bar1.webp`)" alt="스픽클 비용 월 3920원" loading="lazy">
                            <span class="font6">회당 3,920원</span>
                        </div>
                    </div>
                    <div class="bar">
                        <h4>I사</h4>
                        <div class="bar-cover">
                            <img :src="require(`@/assets/img/main/price/bar2.webp`)" alt="I사 비용 월 6800원" loading="lazy">
                            <span class="font6">회당 6,800원</span>
                        </div>
                    </div>
                    <div class="bar">
                        <h4>M사</h4>
                        <div class="bar-cover">
                            <img :src="require(`@/assets/img/main/price/bar3.webp`)" alt="M사 비용 월 10692원" loading="lazy">
                            <span class="font6">회당 10,692원</span>
                        </div>
                    </div>
                    <p>(12개월, 주 5회 25분 기준 1회 수업 가격 비교)</p>

                    <div class="price">
                        <p>월 <span class="font7 price-count">{{count | comma}}</span>원</p>
                        <span>(실속타임 주 2회 12개월 96회 기준)</span>
                    </div>

                </article>
            </div>
        </section>

        <section id="review" class="bg-light">
            <div>
                <article>
                    <h2>스픽클을 믿고 선택해주신<br>
                    회원님들의 솔직한 후기</h2>
                    <p v-if="$device.isMobile">엄마가 신경쓰지 않아도 주도적인 영어공부! <br>
                    담임 선생님과의 깊은 유대관계가 핵심</p>
                    <p v-else>엄마가 신경쓰지 않아도 아이가 주도적으로 영어공부! <br>
                    담임 선생님과의 깊은 유대관계가 핵심</p>
                </article>
                <article class="mb review-wrapper" v-if="common.width<=980 || $device.isMobile">
                    <swiper :options="reviewSwiperOption">
                        <swiper-slide v-for="(reviewer, idx) in review" :key="`review${idx}`">
                            <div>
                                <div class="review-img"><img :src="require(`@/assets/img/main/review/${idx+1}.png`)" loading="lazy"></div>
                                <p class="font5">{{reviewer.childName}} 학부모님</p>
                                <span>{{reviewer.month}}개월 차</span>
                                <p>{{reviewer.text}}</p>
                        
                                <img :src="require(`@/assets/img/main/stars.webp`)"  alt="별점" loading="lazy">
                            </div>
                        </swiper-slide>
                        <div class="review-swiper-pagination" slot="pagination"></div>
                    </swiper>
                </article>

                <article class="review-wrapper" v-else>
                    <div v-for="(reviewer, idx) in review" :key="`review${idx}`">
                        <div class="review-img"><img :src="require(`@/assets/img/main/review/${idx+1}.png`)" loading="lazy"></div>
                        <p class="font5">{{reviewer.childName}} 학부모님</p>
                        <span>{{reviewer.month}}개월 차</span>
                        <p>{{reviewer.text}}</p>
                
                 
                        <img :src="require(`@/assets/img/main/stars.webp`)"  alt="별점" loading="lazy">

                    </div>
                </article>
            </div>
        </section>

        <section id="partner">
            <div>
                <article>
                    <h2>초등학원도<br>
                        주목하는<br>
                        스픽클학습
                    </h2>
                    <p>대부분의 초등학원들이 스픽클과 함께합니다.</p>
                </article>
                <article>
                    <div class="logo-wrapper">
                        <div class="logos"></div>
                    </div>
                </article>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
#container{
    header{
        height: 700px;
        overflow: hidden;
        background-color: $baby-pink;
        >div{
            height: 100%;
            position: relative;
            @include flex(flex-start, flex-start);
            article{
                @include flex(center, flex-start, column);
                height: 100%;
                &:last-child{
                    position: absolute;
                    right: -100px;
                    bottom: 0;
                    height: 100%;
                    img{
                        margin-top: auto;
                        width: 730px;
                    }
                }
            }
            p{
                font-family: "SCDream4";
                margin: 20px 0 80px;
            }
            p.mb{
                margin-bottom: 30px;
            }
            a{
                width: 230px;
                height: 60px;
                line-height: 60px;
                text-align: center;
                color: $white;
                border-radius: 40px;
                background: linear-gradient(-50deg, #d508df, $pink);
            
            }
        }
    }
    #point{
        h2{
             letter-spacing: -3px;
        }
        h2, p{
            text-align: center;
        }
    
        article{
            .swiper-container{
                width:100%;
                max-width: 1000px;
                padding: 50px 0;
                .swiper-slide {
                     @include flex();
                     overflow: hidden;
                    .card{
                        border-radius: 10px;
                        box-shadow: $shadow;
                        background-color: $white;
                        width: 30.5%;
                        height: 460px;
                        padding: 30px 20px;
                        margin-bottom: 10px;
                        &+div{
                            margin-left: 30px;
                        }
                        h5{
                            font-size: 34px;
                            line-height: 42px;

                        }
                        p{
                            text-align: left;
                            margin-top: 20px;
                            font-size: 20px;
                            line-height: 28px;
                            color: $conText;
                        }
                    }
                    @for $i from 1 through 5{
                        .card.card#{$i}{
                            background-image: url(@/assets/img/main/point/#{$i}.webp);
                            background-size: 80%;
                            background-position: right bottom;
                            background-repeat: no-repeat;
                        }
                    }  
                    .card.card1{
                        background-position: right 95%;
                    } 
                    .card.card5{
                        background-size: 70%;
                    } 
                }
                .swiper-pagination{
                    bottom: 0;
                }
            }
        }

    }

    #video{
        >div{
            flex-direction: column;
            h2, p{
                text-align: center;
                color: $white;
            }
            h2{
                margin: 10px auto 40px;
            }
            .video-wrapper{
                width: 100%;
                max-width: 1000px;
                height: 500px;
                background-color: $white;
                margin: 30px auto 20px;
            }
            article{
                @include flex(center, center, column);
                .ment{
                    position: relative;
                    line-height: 40px;
                    font-size: 26px;
                    width: auto;
                    display: inline-block;
                    span{
                        font-size: 26px;
                        color: $white;
                    }
                }
                img{
                    position: absolute;
                    transition: all 0.7s;
                    &.line1{
                        top: -7px;
                        right: 0;
                        // left: 50%;
                        // margin-left: 90px;
                        width: 180px;
                        clip-path: ellipse(140px 0px at 10% 60%);
                        &.act{
                            clip-path: ellipse(170px 60px at 10% 60%);
                        }
                    }
                    &.line2{
                        bottom: 0;
                        left: 0;
                        width: 100%;
                        // top: 77px;
                        // left: 50%;
                        // margin-left: -270px;
                        // width: 544px;
                        clip: rect(0px, 0px, 200px, 0px);
                        &.act{
                            clip: rect(0px, 544px, 200px, 0px);
                        }
                    }
                }

            }
        }
    }

    #career{
        >div{
            @include flex();
            margin: 50px auto;
            article{
                padding: 0px 30px;
                @include flex();
                width: 25%;
                &+article{
                    border-left: 1px solid #dadadf;
                }
                h3{
                    font-size: 35px;
                    margin-bottom: 5px;
                    
                }
                p{
                    font-size: 16px;
                    line-height: 24px;
                    padding-left: 3px;
                }
                div+div{
                    margin-left: 10px;
                }
                img{
                    width: 50px;

                }
                &:first-child{
                    img{
                        width: 43px;
                    }
                }
                .career-txt{
                    opacity: 0;
                    transform: translateY(30px);
                    transition: all 0.4s;
                    &.act{
                        opacity: 1;
                        transform: translateY(0px);
                    }
                }
                &:first-child{
                    padding-left: 0;
                }
                &:last-child{
                    padding-right: 0;
                }
            }
            &.mb{
                article{
                    width: 50%;
                    p{
                        font-size: 18px;
                        line-height: 18px;
                        width: 100%;
                        padding: 0 10px;
                    }
                    &:nth-child(odd) p{
                        text-align: right;
                    }
                    &:nth-child(even) p{
                        text-align: left;
                    }
                    &:nth-child(3){
                        border: none;
                    }
                    &+article{
                        border-left: 3px solid #e8e8ef
                    }
                }
            }
        }
    }

    #compare{
        >div{
            @include flex(center, flex-end);
            margin-bottom: 150px;
            article{
                position: relative;
                width: 375px;
                height: 330px;
                &:first-child{
                    width: 220px;
                    height: 236px;
                }
                &:last-child{
                    margin-left: 15px;
                }
                h3{
                    font-size:  35px;
                    @include flex(center, cente);
                    margin-bottom: 30px;
                    height: 65px;
                    img{
                        width: 45px;
                        height: 50px;
                        margin-right: 10px;
                    }
                }
                ul{
                    position:absolute;
                    width: 100%;
                    li{
                        width: 100%;
                        height: 65px;
                        line-height: 65px;
                        background-color: $white;
                        border-radius: 10px;
                        text-align: center;
                        margin-bottom: 8px;
                        opacity: 0;
                        transition: all 0.4s;
                        transform: translateY(-40px);
                        &.act{
                            opacity: 1;
                            transform: translateY(0px);
                        }
                        &:last-child{
                            margin-bottom: 0;
                        }
                    }
                    &.list-header {
                        li{
                            background: none;
                            text-align: left;
                            font-size: 24px;
                        }
                    }
                    &.speakcls-list{
                        margin-right: 5px;
                        transition: all 0.5s;
                        z-index: 1;
                        li{
                            color: $pink;
                        }
                        &.act{
                            border: 3px solid $pink;
                            border-radius: 10px; 
                            padding: 5px;
                            transform: translate(0, -7px)  scale(1.1);
                            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.4);
                            background-color: rgba(0, 0, 0, 0.1);
                            li{
                                font-family: "SCDream5";
                                font-size: 22px;
                            }
                        }
                    }
                }
            }
        }
    }
    #class{
        >div{
            max-width: 1040px;
            max-height: 2840px;
            width: auto;
            article{
                display: inline-block;
                &+article{
                    margin-left: 70px;
                }
                &.sticky-box{
                    position: sticky;
                    top:0;
                    left: 0;
                    right: 0;
                    bottom : 0;
                    width: 370px;
                    height: 80vh;
                    transition: all 0.3s;
                    p{
                        font-size: 20px;
                        line-height: 30px;
                    }
                 
                }
                >div{
                    margin-bottom: 50px;
                    img{
                        width:100%;
                        max-width: 550px;
                    }
                    .text-wrapper{
                        @include flex(flex-start, flex-start);
                        position: relative;
                        margin-top: 20px;
                        .num-box{
                            font-size: 54px;
                            color: $pink;
                            margin: 26px 20px 0 10px;
                        }
                        .txt-box{
                            span{
                                font-size: 17px;
                                line-height: 26px;
                                color:$pink;
                            }
                            h4{
                                font-size: 25px;
                                line-height:30px;
                                margin: 10px 0 15px;
                            }
                            p{
                                display: none;
                            }
                            ul{
                               
                                li{
                                    font-size: 18px;
                                    line-height: 24px;
                                    width: 380px;
                                    position: relative;
                                    color: #6e6e6e;
                                    &+li{
                                        margin-top: 6px;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    #cost{
        >div{
            @include flex(center, flex-start);
            article{
                @include flex(center, center, column);
                h2{
                    margin-bottom: 80px;
                }
                p{
                    font-size: 20px;
                    color: $conText;
                }
                p.font5{
                    margin-bottom: 30px;
                    font-size: 24px;
                }
              
                .price{
                    margin-bottom: 30px;
                    text-align: center;
                    width: 400px;
                    p{
                        margin-bottom: 20px;
                        font-size: 30px;
                        span{
                            font-size: 85px;
                            color:$pink;
                        }
                    }
                    span{
                        font-size: 16px;
                    }
                }
                &.bar-wrapper{
                    margin-left: 30px;
                    padding-top: 90px;
                    width: 350px;
                    position: relative;
                    @include flex(flex-start, flex-start, column);
                    p{
                        font-size: 16px;
                        line-height: 24px;
                        text-align: center;
                        margin-left: auto;
                        right: 0;
                        margin-top: 20px;
                    }
                    .bar{
                        @include flex(flex-start, flex-start);
                        position: relative;
                        height: 110px;
                        h4{
                            margin-top: 13px;
                            margin-right: 15px;
                            text-align: right;
                            width: 100px;
                            font-size: 24px;
                        }
                        span{
                            font-size: 18px;
                            bottom: 0px;
                            position: absolute;
                            right: 0;
                        }
                        &.speakcls{
                            h4{
                                color: $pink;
                                font-size: 31px;
                            }
                        }
                        &:nth-of-type(2) .bar-cover{
                            width: 135px;
                        }
                        &:nth-of-type(3) .bar-cover{
                            width: 185px;
                        }
                        &:nth-of-type(4) .bar-cover{
                            width: 255px;
                        }
                        .bar-cover{
                            height: 100px;
                            position: relative;
                            img{
                                position: absolute;
                                clip: rect(0px, 0px, 200px, 0px);
                                transition: all 0.6s;
                                &.act{
                                    clip: rect(0px, 260px, 200px, 0px);
                                }
                            }
                        
                        }
                    }
                    .bubble{
                        position: absolute;
                        width: 160px;
                        height: 170px;
                        background-image: url('@/assets/img/main/price/bubble.png');
                        background-size: contain;
                        background-repeat: no-repeat;
                        right: -60px;
                        top: -30px;
                        transform: scale(0);
                        transform-origin: bottom left;
                        transition: all 0.5s;
                        p{
                            color: $white;
                            font-size: 24px;
                            line-height: 100px;
                            text-align: center;
                        }
                        &.act{
                            transform: scale(1);
                        }
                    }

                }
            }
        }
    }
    #review{
        >div{
            @include flex(center, center, column);
            text-align: center;
            article{
                &.review-wrapper{
                    display: flex;
                    margin: 100px 0 0;
                    height: 100%;
                    >div{
                        @include flex(flex-start, center, column);
                        background-color: $white;
                        border-radius: 15px;
                        box-shadow: $shadow;
                        padding: 60px 20px 60px;
                        position: relative;
                        width: 32%;
                        &+div{
                            margin-left: 20px;
                        }
                        .review-img{
                            width: 100px;
                            height: 100px;
                            border-radius: 50%;
                            position: absolute;
                            overflow: hidden;
                            top: -50px;
                            img{
                                width: 100%;
                                height: 100%;
                            }
                        }
                        
                        >img{
                            position: absolute;
                            bottom: 20px;
                        }
                        p{
                            font-size: 16px;
                            line-height: 24px;    
                            color: $conText;                  
                            &.font5{
                                font-size:19px;
                                height: auto;
                                min-height: 0;
                                color: $black;
                            }
                        }
                        span{
                            font-size:16px;
                            margin-bottom: 10px
                        }
                    }
                }
            }
        }
    }
    #partner{
        >div{
            @include flex(center, center, column);
            max-width: 10000px;
            article{
                @include flex(center, center, column);
                width: 100%;
                .logo-wrapper{
                    width: 100%;
                    overflow: hidden;
                    .logos{
                        width: 50000px;
                        height: 140px;
                        margin: 100px 0 30px;
                        background: url('@/assets/img/main/logo.webp') repeat-x;
                        background-size: contain;
                        animation: movingLogos 1500s linear infinite;
                    }
    
                    @keyframes movingLogos {
                        100% { 
                            transform: translateX(-48080px);  
                        }
                    }
                }
            }
        } 

    }
}
@media screen and (max-width: 1024px){
#container{
    #point{
        article{
            .swiper-container{
                .swiper-slide {
                    .card{
                        &+div{
                            margin-left: 10px;
                        }
                       
                    }
                }
            }
        }
    }
    #compare{
        > div{
            article:first-child{
                width: 180px;
            }
        } 
    } 


    #class{
        >div {
            max-height: 10000px;
            width: 100%;
            article {
                display: block;
                width: 100%;
                &+article{
                    margin-left: 40px;
                }
                &.sticky-box{
                    position: relative;
                    width: 100%;
                    height: auto;
                    margin: 0 auto 50px;
                    text-align: left;
                }
                &.intro-box{
                    margin-left: 0;
                }
                div{
                    img{
                        max-width: 1000px;
                    }
                    .text-wrapper{
                        .txt-box{
                            span{
                                font-size: 16px;
                            }
                            h4{
                                font-size: 28px;
                                line-height: 35px;
                                margin-bottom: 10px;
                            }
                            ul li{
                                font-size: 18px;
                                line-height: 24px;
                                margin-bottom: 7px;
                            }
                        }
                    }
                }
                
            }
        }
    }

    #cost {
        > div {
            article{
                &.bar-wrapper{
                    margin-left: -20px;
                    .bubble{
                        width: 130px;
                        height: 130px;
                        right: -25px;
                        top: -15px;
                        p{
                            font-size: 20px;
                            line-height: 77px;
                        }
                    }
                }
            }
        }
    }
    #review{
        >div{
            article p{
                font-size: 19px;
            }
        }
    }

}

}
@media screen and (max-width: 980px){
#container{
    header{
        > div {
            article:last-child{
                right: -60px;
                img{
                    width: 700px;
                }
            } 
        }
    } 
    #point{
        >div{
            article{
                .swiper-container .swiper-slide {
                    .card {
                        height: 400px;
                        padding: 30px 12px;
                        h5{
                            font-size: 32px;
                            line-height: 40px;
                        }
                        p{
                            font-size: 16px;
                            line-height: 23px;
                        }
                    }

                }
            }
        }
    }
    #career{
        >div.mb{
            flex-wrap: wrap;
            article{
                width: 50%;
                padding: 0;
                margin: 5px 0;
                p{
                    font-size: 22px;
                    padding: 0 20px;
                    span{
                        font-size: 26px;
                    }
                }
   
            }
        }
    }
    
    #video{
        > div {
            h2{
                margin-bottom: 0;
            }
            .video-wrapper{
                height: 400px;
            }
        }
    }
    
    #cost {
        >div{
            flex-direction: column;
            align-items: center;
            article{
                text-align: center;
                h2{
                    margin-bottom: 30px;
                }
                >p.font5{
                    color: $pink;
                    margin-bottom: 15px;
                }
                >p{
                    line-height: 26px;
                }
                &.bar-wrapper{
                    margin: 0 auto;
                    justify-content: center;
                    flex-direction: row;
                    flex-wrap: wrap;
                    width: 100%;
                    padding-top: 50px;
                    .bubble{
                        right: auto;
                        top: 50px;
                        left: 50%;
                        margin-left: -140px;
                        width: 135px;
                        height: 140px;
                        p{
                            font-size: 20px;
                            line-height: 82px;
                        }
                    }
                    .bar{
                        @include flex(flex-end, center, column);
                        height: 330px;
                        width: 140px;
                        h4{
                            text-align: center;
                            margin: auto 0 0 0;
                            font-size: 20px
                        }
                        .bar-cover{
                            @include flex(center, center, column);
                            img{
                                transform: rotate(-90deg);
                                margin-left: 40px;
                                margin-bottom: 0;
                            }
                            span{
                                right: auto;
                                bottom: -30px;
                                font-family: "SCDream5";
                            }
                        }
                        &:nth-of-type(2) {
                            h4{
                                font-size: 24px;
                            }
                            .bar-cover{
                                width: 100%;
                                height: 150px;
                            }

                        }
                        &:nth-of-type(3) .bar-cover{
                            width: 100%;
                            height: 200px;
                        }
                        &:nth-of-type(4) .bar-cover{
                            width: 100%;
                            height: 270px;
                        }
                        &+p{
                            margin-top: 50px;
                        }
                    }
                    .price{
                        margin-top: 40px;
                        margin-bottom: 10px;
                        width: 100%;
                        >span{
                            font-size: 16px;
                        }
                    }
                    >p{
                        width: 100%;
                        font-size: 17px;
                        line-height: 25px;
                    }

                }
            }
        }
    }
    #review{
        >div{
            article{
                &.review-wrapper.mb {
                    height: auto;
                    width: 100%;
                    margin-top: 50px;
                    >div{
                        width: 100%;
                        max-width: 500px;
                        height: auto;
                        width: 100%;
                        background: none;
                        box-shadow: none;
                        padding: 0;
                        display: flex;
                        .swiper-slide{
                            display: flex;
                            overflow: hidden;
                            width: 100%;
                            padding: 90px 20px 20px;
                            >div{
                                    @include flex(center, center, column);
                                background-color: $white;
                                border-radius: 5px;
                                box-shadow: 0px 2px 5px rgba(90, 90, 90, 0.3);
                                padding: 70px 30px;
                                position: relative;
                                width: 100%;
                                min-height: 330px;
                                &+div{
                                    margin-left: 30px;
                                }
                                .review-img{
                                    width: 140px;
                                    height: 140px;
                                    border-radius: 50%;
                                    position: absolute;
                                    top: -80px;
                                }
                                >img{
                                    position: absolute;
                                    bottom: 20px;
                                }
                                p.font5{
                                    font-size:24px;
                                    line-height: 34px;
                                    height: auto;
                                }
                                span{
                                    font-size:16px;
                                }
                                p{
                                    font-size: 18px; 
                                    line-height: 24px;               
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    #partner{
        >div{padding: 0;}
    }
}
}
@media screen and (max-width: 767px) {
    #container{
        header{
            height: 780px;
            >div{
                article:first-child{
                    justify-content: flex-start;
                    p{
                        margin: 30px 0 70px;
                    }
                    p.mb{
                        margin: 120px 0 20px;
                        color: $subText;
                    }
                }
                article:last-child{
                    width: 640px;
                    margin-right: 120px;
                }
            }
        }
        #point{
            >div{
                h2{
                    text-align: left;
                }
                p{
                    text-align: left;
                    margin-bottom: 30px;
                }
                article{
                    @include flex(center, center, column);
                    position: relative;
                    .card{
                        border-radius: 10px;
                        box-shadow: 3px 3px 3px rgba(63, 63, 63, 0.4);
                        background-color: $white;
                        width: 100%;
                        max-width: 350px;
                        height: 350px;
                        padding: 30px 20px;
                        margin-bottom: 13px;
                        h5{
                            font-size: 32px;
                            line-height: 48px;
                        }
                        p{
                            text-align: left;
                            margin-top: 8px;
                            font-size: 16px;
                            line-height: 24px;
                        }
                    }
                    @for $i from 1 through 5{
                        .card.card#{$i}{
                            background-image: url(@/assets/img/main/point/#{$i}.webp);
                            background-size: 75%;
                            background-position: right bottom;
                            background-repeat: no-repeat;
                        }
                    } 
                    .card.card1{
                        background-size: 80%;
                    }
                    .card.card3{
                        background-size: 65%;
                    }
                    .card.card5{
                        background-size: 55%;
                        background-position: 85% bottom;
                    } 
                }
            }
        }
        #compare{
            >div{
                flex-wrap: wrap;
                margin-bottom: 80px;
                article.itemlist{
                    width: 100%;
                    height: 60px;
                    @include flex();
                    ul{
                        @include flex();
                        width: auto;
                        margin-bottom: 60px;
                        border-bottom: 2px solid $black;
                        margin-right: 0;
                        li{
                            width: 120px;
                            background: none;
                            opacity: 1;
                            transform: translateY(0);
                            font-size: 24px;
                            margin-bottom: 0;
                            border-radius: 0;
                            height: 45px;
                            line-height: 45px;
                            cursor: pointer;
                            &.act{
                                color: $pink;
                                border-bottom: 3px solid $pink;
                            }
                        }

                    }
                }
                article.campare-swiper{
                    width: 100%;
                    height: 400px;
                    margin-left: 0;
                    .swiper-container{
                        height: 100%;
                        .swiper-slide{
                            @include flex(flex-start, center, column);
                            ul{
                                width: 90%;
                                margin: 90px auto 0;
                                &.speakcls-list.act{
                                    box-shadow: none;
                                    background: none;
                                }
                            }
                        }
                    }
                }
            }
        }
        
    }
    
}


@media screen and (max-width: 540px){
#container{
    header{
        height: 700px;
        >div{
            article{
                &:first-child{
                    h1{
                        margin-bottom: 0;
                    }
                    p{
                        margin-top: 20px;
                    }
                    a{
                        width: 180px;
                        height: 50px;
                        line-height: 50px;
                    }
                }
                &:last-child{
                    width: 100%;
                    margin-right: 70px;
                    img{
                        width: 100%;
                        margin-left: 30px;
                    }
                }
            }
        }
    }
     #point{
            >div{
                h2{
                    text-align: center;
                }
                p{
                    text-align: center;
                }
                article{
                    
                    .card{
                        h5{
                            font-size: 24px;
                            line-height: 34px;
                        }
                        p{
                            font-size: 16px;
                        }
                    }
                    @for $i from 1 through 5{
                        .card.card#{$i}{
                           background-size: 65%;
                        }
                    } 
                    .card.card1{
                        background-size: 72%;
                    }
                    .card.card3{
                        background-size: 65%;
                    }
                    .card.card4{
                        background-size: 70%;
                    }
                    .card.card5{
                        background-size: 55%;
                        background-position: 85% bottom;
                    } 


               
              
                }
            }
        }
    #video{
        >div{
            h2{
                overflow: visible;
                width: 110%;
                text-align: center;
                margin-left: -5%;
            }
            article{
                img.line1{
                    width: 138px;
                    top: -5px;
                }
                img.line2{
                    left: 26px;
                    width: 280px;
                }
                .ment, .ment span{
                    font-size: 22px;
                    line-height: 30px;
                }
            }
            .video-wrapper{
                height: 220px;
            }
        }
    }
    #career > div.mb {
        margin: 30px auto;
        article p{
            font-size: 16px;
            padding: 0px 4px;
            span{
                font-size: 18px;
            }
        }
    }
    #compare {
        height: 560px;
        > div {
            margin: 0;
            article{
                h3{
                    font-size: 22px;
                    margin-bottom: 0;
                    img{
                        width: 28px;
                        height: 30px;
                    }
                }
                ul.speakcls-list li,
                ul.etc-list li{
                    font-size: 16px;
                    height: 53px;
                    line-height: 53px;
                }
                ul.speakcls-list.act{
                    border-width: 2px;
                }
                ul.speakcls-list.act li{
                    font-size: 17px;
                }
                &.campare-swiper{
                    height: 360px;
                    .swiper-container .swiper-slide{
                        ul{
                            margin-top: 70px;
                        }
    
                    }
                }
            }
        }
    }
    #class > div article{
        &.sticky-box p{
            font-size: 18px;
            line-height: 24px;
        }
        > div{
            .text-wrapper{
                .num-box{
                    font-size: 38px;
                    margin: 28px 15px 0 0px;
                }
                .txt-box{
                    span{
                        font-size: 17px;
                    }
                    h4{
                        font-size: 24px;
                        line-height: 32px;
                        margin: 5px 0 10px;
                    }
                    ul{
                        padding-left: 0px;
                        li{
                           font-size: 16px;
                           line-height: 24px;
                           width: 270px;
                           font-family: "SCDream4";
                           &+li{
                               margin-top: 8px;
                           }
                       }
                    }
                }
            }
    
        }

    }
    #cost > div {
        padding: 0;
        article{
            h2{
                margin-bottom: 20px;
            }
            p{
                font-size: 16px;
                line-height: 22px;
            }
            p.font5{
                font-size: 18px;
                font-family: "SCDream6";
            }
            &.bar-wrapper {
                .bubble{
                    width: 33%;
                    height: 110px;
                    top: 50px;
                    margin-left: -120px;
                    p{
                        font-size: 16px;
                        line-height: 62px;
                    }
                }
                .bar{
                    width: 111px;
                    height: 280px;
                    &.speakcls h4{
                        font-size: 20px;
                    }
                    h4{
                        font-size: 18px;
                    }
                    span{
                        font-size: 17px;
                        font-family: "SCDream4";
                    }
                    .bar-cover{
                        img{
                            height: 80px;
                            margin-left: 30px;
                        }
                    }
                    &:nth-of-type(2) .bar-cover{
                        height: 130px;
                    }
                    &:nth-of-type(3) .bar-cover{
                        height: 168px;
                    }
                    &:nth-of-type(4) .bar-cover{
                        height: 220px;
                    }
                    
                }
                .price{
                    margin-top: 30px;
                    p{
                        margin-bottom: 10px;
                        font-size: 24px;
                    }
                    p span{
                        font-size: 60px;
                    }
                    >span{
                        font-size: 14px;
                    }
                }
                >p{
                    font-size: 14px;
                    line-height: 20px;
                    margin-top: 50px;
                }
            }

        } 
    }
    #review{
        >div{
            article{
                p{
                    font-size: 18px;
                }
                &.review-wrapper.mb {
                    margin-top: 0;
                    >div{
                        padding: 40px 10px 0;
                        .swiper-slide{
                            padding: 90px 0 20px;
                            >div{
                                padding: 50px 10px;
                                p.font5{
                                    margin-top: 0;
                                    font-size: 20px;
                                }
                                p{
                                    font-size: 15px;
                                    padding: 0 10px;
                                    width: 100%
                                }
                                .review-img{
                                    width: 120px;
                                    height: 120px;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    #partner{
        padding: 0;
        >div{
            p{
                margin-bottom: 50px;
            }
            article .logo-wrapper {
                
                .logos{
                    height: 80px;
                    margin-top: 0;
                }
            }
        }
    }
}
}



</style>
<style lang='scss'>
.swiper-pagination, 
.review-swiper-pagination{
    .swiper-pagination-bullet{
        width: 10px;
        height: 10px;
    }
    .swiper-pagination-bullet-active{
        background: $pink;
    }
}
@media screen and (max-width: 890px) {
.swiper-pagination{
    .swiper-pagination-bullet{
        width: 8px;
        height: 8px;
        margin: 0 4px;
    }
}
}
</style>

<script>
export default {
    name: 'hompage',
    layout: 'default',
    data(){
        return{
            swiperOption:{
                loop: true,
                slidesPerView: 1,
                speed: 800,
                allowtouchmove:true,
                observer: true,
                autoplay: { 
                    delay: 4000, 
                    disableOnInteraction: false 
                },
                pagination: { 
                    el: '.swiper-pagination', 
                    clickable: true 
                }
            },
            reviewSwiperOption: {
                loop: true,
                slidesPerView: 1,
                spaceBetween: 20,
                allowtouchmove:true,
                observer: true,
                autoplay: { 
                    delay: 4000, 
                    disableOnInteraction: false 
                },
                pagination: { 
                    el: '.review-swiper-pagination', 
                    clickable: true 
                }
            },
            compareSwiperOption:{
                slidesPerView: 1,
                spaceBetween: 0,
                allowtouchmove:true,
                observer: true,
                navigation: {
                    nextEl: ".itemlist ul li:last-child",
                    prevEl: ".itemlist ul li:first-child",
                },
           

            },
            review:[
                {
                    childName: '박진주',
                    month: 18,
                    text: '처음에는 알파벳만 아는 정도였는데 지금은 선생님이 하는 얘기도 이해하고 단어로 얘기할 정도는 되어서 정말 스픽클에 감사한 마음이에요. 다른 것 보다 외국인이 있으면 아는 척 하며 무서워하지 않는 것만 해도 성공인 것 같아 정말 만족해요.'
                },
                {
                    childName: '김진경',
                    month: 24,
                    text: '코로나로 아이들이 집에 있는 시간이 많아지면서 집에서 영어수업을 하려고 10곳 이상 비교하며 고민했는데 스픽클은 지금까지 재수강을 고민해본 적 없을 정도로 오랫동안 만족하고 있어요. 무엇보다 아이들이 수업을 기다리고 스피킹 실력도 늘어서 주변 지인들은 다 추천하고 있어요.'
                },
                {
                    childName: '이정석',
                    month: 12,
                    text: '체험수업을 해보고 마음에 들어 진행하였고, 지금까지 잘 하고 있습니다. 확실히 다른 곳보다 실력이 좋다고 느낀건 선생님들이 초등학생에게 어떻게 수업해야할지 알고 있고 활기차고 밝게 진행해주셔서 어느정도 대화가 가능한 정도로 발전한 것 같습니다. 중학교 가더라도 꾸준히 시킬 예정입니다.'
                },
            ],
            format: 'webp',
            count: 0,
            compareItem: '스픽클',
            common: [],
            lineOffset : null,
            careerOffset : null,
            compareOffset: null,
            priceOffset : null,
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
     beforeMount () {
        window.addEventListener('scroll', this.motion);
    },
    mounted(){
        this.gifLoad();
        this.getOffset();
    },
    watch:{
        compareItem(v){
            if(v == '스픽클'){
                this.addAct('.speakcls-list li')
                setTimeout(() => this.addAct('.speakcls-list'), 800);
            }
            if(v == '학원'){
                this.addAct('.etc-list li')
                setTimeout(() => this.addAct('.etc-list'), 800);
            }
            
        }
    },
    filters:{
        comma(v){
            return String(v).replace(/[^0-9]/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    },
    methods:{
        getOffset(){
            this.lineOffset = this.$el.querySelector('.line1').getBoundingClientRect().top + window.pageYOffset - 600,
            this.careerOffset = this.$el.querySelector('#career').getBoundingClientRect().top + window.pageYOffset - 600,
            this.compareOffset = this.$el.querySelector('#compare').getBoundingClientRect().top + window.pageYOffset - 600,
            this.priceOffset = this.$el.querySelector('#cost').getBoundingClientRect().top + window.pageYOffset - 600;

            this.motion()
        },
        motion(){
            var myScroll = window.scrollY;
            
            
            if(myScroll >= this.lineOffset) this.addAct('.line1, .line2');
            if(myScroll >= this.careerOffset) this.addAct('.career-txt');
            if(myScroll >= this.compareOffset) {
                if(this.$device.isMobile ==false){
                    this.addAct('.list-header li')
                    this.addAct('.speakcls-list li')
                    setTimeout(() => this.addAct('.etc-list li'), 800);
                    setTimeout(() => this.addAct('.speakcls-list'), 2000);
                }else{
                    this.addAct('.speakcls-list li')
                    setTimeout(() => this.addAct('.speakcls-list'), 800);
                    
                }
            };
            if(myScroll >= this.priceOffset) this.priceMotion();
        },
        addAct(element){
            var ele = this.$el.querySelectorAll(element);
            
            ele.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 200*idx);
            });
        },
    
        priceMotion(){
            var ele = this.$el.querySelectorAll('.bar img'),
                bubble = this.$el.querySelector('.bubble');

            ele.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 150*idx);
            });
            setTimeout(() => {
                bubble.classList.add('act');
            }, 600);

            var counting = setInterval(()=>{
                if (this.count == 56160) {
                    clearInterval(counting);
                    return false;
                }
                this.count += 1755;
            }, 20);
        },

        gifLoad(){
            setTimeout(() => {
                this.format = 'gif'
            }, 2000);
        },
        slideChange() { 
            var index = this.$refs.mySwiper.$swiper.activeIndex;
            index==0?this.compareItem='스픽클':this.compareItem='학원';
        } 
    },
    beforeDestroy () {
        window.removeEventListener('scroll', this.motion);
    }
}

</script>
