const { Router } = require('express');
const router = Router();
const MongoClient = require('mongodb').MongoClient; // mongoDB호출
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var db;
MongoClient.connect("mongodb://speakcls:speakcls123@speakcls-shard-00-00.lxv5s.mongodb.net:27017,speakcls-shard-00-01.lxv5s.mongodb.net:27017,speakcls-shard-00-02.lxv5s.mongodb.net:27017/?ssl=true&replicaSet=atlas-2w0fmt-shard-0&authSource=admin&retryWrites=true&w=majority", (err, client) => {
    // DB연결 성공하면 할 일
    if(err) return console.log('에러', err)
    
    // speakcls 이라는 database에 연결
    db = client.db('speakcls');
});



router.post('/user', (req, res) => {
    db.collection('counter').findOne({target: 'user'}, function(err, count){
        var userData = {
            _id: count.number + 1,
            userName: req.body.userName,
            engName: req.body.engName,
            age: req.body.age,
            birthday: req.body.birthday,
            id: req.body.id,
            pw: req.body.pw,
            sex: req.body.sex,
            userTel: req.body.userTel,
            address: req.body.address,
            membership: req.body.membership,
            joinData: {
                root: req.body.joinData.root,
                day: req.body.joinData.day,
                recommendPerson:{
                    name: req.body.joinData.recommendPerson.name,
                    tel: req.body.joinData.recommendPerson.tel,
                }
            },
            coupon: req.body.coupon,
            levelTest:{
                status: '미접수',
                consulting: false,
                date:{
                    want: null,
                    fixed: null
                },
                tutor: null,
                level: null,
                result:{
                    average:null,
                    pronunciation:null,
                    grammer:null,
                    vocabulary:null,
                    understanding:null,
                    fluency:null,
                },
                toTutor: null,
                request: null,
                note: null
            }
        };

        db.collection('user').insertOne(userData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'user'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                })
            }
        });

    });
});

router.post('/tutor', (req, res) => {
    db.collection('counter').findOne({target: 'tutor'}, function(err, count){
        var userData = {
            _id: count.number + 1,
            tutorName: req.body.tutorName,
            birthday: req.body.birthday,
            id: req.body.id,
            pw: req.body.pw,
            sex: req.body.sex,
            country: req.body.country,
            joinDay: req.body.joinDay,
            center: req.body.center,
            class:{
                payPerClass: req.body.payPerClass,
                breakTime: req.body.breakTime,
            },
            gpa: req.body.gpa,
            zoomUrl: req.body.zoomUrl,
            youtube: req.body.youtube,
            introduce: req.body.introduce,
            profile: req.body.profile,
            memo: req.body.memo,
        };

        db.collection('tutor').insertOne(userData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'tutor'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                })
            }
        });

    });
});


router.post('/class', (req, res) => {
    db.collection('counter').findOne({target: 'class'}, function(err, count){
        var classData = {
            _id: count.number + 1,
            title: '주니어과정' + req.body.course + req.body.timeZone + req.body.classTime + req.body.numberOfClasses,
            timeZone:  req.body.timeZone,
            classTime: req.body.classTime ,
            numberOfClasses: req.body.numberOfClasses,
            price:  req.body.price,
            month:  req.body.month,
            tutor: 'Anne',
            student: {
                userName: '테스트',
                id: 'test123',
            }
        };

        db.collection('class').insertOne(classData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'class'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                })
            }
        });

    });
});

module.exports = router;
