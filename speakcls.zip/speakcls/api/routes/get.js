const { Router } = require('express');
const router = Router();
const MongoClient = require('mongodb').MongoClient; // mongoDB호출
const bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());


var db;
MongoClient.connect("mongodb://speakcls:speakcls123@speakcls-shard-00-00.lxv5s.mongodb.net:27017,speakcls-shard-00-01.lxv5s.mongodb.net:27017,speakcls-shard-00-02.lxv5s.mongodb.net:27017/?ssl=true&replicaSet=atlas-2w0fmt-shard-0&authSource=admin&retryWrites=true&w=majority", (err, client) => {
    // DB연결 성공하면 할 일
    if(err) return console.log('에러', err)
    
    // speakcls 이라는 database에 연결
    db = client.db('speakcls');
});


// 정보 불러오기

router.get('/user', (req, res) => {
    db.collection('user').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

router.get('/tutor', (req, res) => {
    db.collection('tutor').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

router.get('/class', (req, res) => {
    db.collection('class').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

router.get('/leveltest', (req, res) => {
    db.collection('leveltest').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});



module.exports = router;