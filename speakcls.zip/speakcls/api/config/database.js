const MongoClient = require('mongodb').MongoClient; // mongoDB호출

var db;
MongoClient.connect("mongodb://speakcls:speakcls123@speakcls-shard-00-00.lxv5s.mongodb.net:27017,speakcls-shard-00-01.lxv5s.mongodb.net:27017,speakcls-shard-00-02.lxv5s.mongodb.net:27017/?ssl=true&replicaSet=atlas-2w0fmt-shard-0&authSource=admin&retryWrites=true&w=majority", (err, client) => {
    // DB연결 성공하면 할 일
    if(err) return console.log('에러', err)
    
    // speakcls 이라는 database에 연결
    db = client.db('speakcls');
});


module.exports = db;