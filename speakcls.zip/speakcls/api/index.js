const MongoClient = require('mongodb').MongoClient; // mongoDB호출
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var db;
MongoClient.connect('mongodb://speakcls:speakcls123@speakcls-shard-00-00.lxv5s.mongodb.net:27017,speakcls-shard-00-01.lxv5s.mongodb.net:27017,speakcls-shard-00-02.lxv5s.mongodb.net:27017/?ssl=true&replicaSet=atlas-2w0fmt-shard-0&authSource=admin&retryWrites=true&w=majority', (err, client) => {
    // DB연결 성공하면 할 일
    if(err) return console.log('에러', err)
    
    // speakcls 이라는 database에 연결
    db = client.db('speakcls');
});

// app.use('/add', require('./routes/add'));


// 정보 불러오기

app.get('/user', (req, res) => {
    db.collection('user').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

app.get('/tutor', (req, res) => {
    db.collection('tutor').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

app.get('/class', (req, res) => {
    db.collection('class').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

app.get('/leveltest', (req, res) => {
    db.collection('leveltest').find().toArray((err, data) => {
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});



// 하나의 정보만 불러오기

app.get('/detail/user/:id', (req, res) =>{
	db.collection('user').findOne({ _id : parseInt(req.params.id) }, (err, data)=>{
        if(data) res.json(data)
	})
});

app.get('/detail/tutor/:id', (req, res) =>{
	db.collection('tutor').findOne({ _id : parseInt(req.params.id) }, (err, data)=>{
        if(data) res.json(data)
	})
});

app.get('/detail/class/:id', (req, res) =>{
	db.collection('class').findOne({ _id : parseInt(req.params.id) }, (err, data)=>{
        if(data) res.json(data)
	})
});
app.get('/detail/class/bystudent/:id', (req, res) =>{
	db.collection('class').findOne({ student : parseInt(req.params.id) }, (err, data)=>{
        if(data) res.json(data)
	})
});

app.get('/detail/leveltest/:id', (req, res) =>{
	db.collection('leveltest').findOne({ _id : parseInt(req.params.id) }, (err, data)=>{
        if(data) res.json(data)
	})
});


// 새로운 DB 추가하기

app.post('/add/user', (req, res) => {
    db.collection('counter').findOne({target: 'user'}, function(err, count){
        var userData = {
            _id: count.number + 1,
            userName: req.body.userName,
            engName: req.body.engName,
            age: req.body.age,
            birthday: req.body.birthday,
            id: req.body.id,
            pw: req.body.pw,
            sex: req.body.sex,
            userTel: req.body.userTel,
            address: req.body.address,
            membership: req.body.membership,
            joinData: {
                root: req.body.joinData.root,
                day: req.body.joinData.day,
                recommendPerson:{
                    name: req.body.joinData.recommendPerson.name,
                    tel: req.body.joinData.recommendPerson.tel,
                }
            },
            coupon: req.body.coupon,
            levelTest:{
                status: '미접수',
                consulting: false,
                date:{
                    want: null,
                    fixed: null
                },
                tutor: null,
                level: null,
                result:{
                    average:null,
                    pronunciation:null,
                    grammer:null,
                    vocabulary:null,
                    understanding:null,
                    fluency:null,
                },
                toTutor: null,
                request: null,
                note: null
            }
        };

        db.collection('user').insertOne(userData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'user'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                })
            }
        });

    });
});

app.post('/add/tutor', (req, res) => {
    db.collection('counter').findOne({target: 'tutor'}, function(err, count){
        var userData = {
            _id: count.number + 1,
            tutorName: req.body.tutorName,
            birthday: req.body.birthday,
            id: req.body.id,
            pw: req.body.pw,
            sex: req.body.sex,
            country: req.body.country,
            joinDay: req.body.joinDay,
            center: req.body.center,
            classInfo:{
                payPerClass: req.body.classInfo.payPerClass,
                breakTime: req.body.classInfo.breakTime,
            },
            gpa: req.body.gpa,
            zoomUrl: req.body.zoomUrl,
            youtube: req.body.youtube,
            introduce: req.body.introduce,
            profile: req.body.profile,
            memo: req.body.memo,
        };

        db.collection('tutor').insertOne(userData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'tutor'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                })
            }
        });

    });
});


app.post('/add/class', (req, res) => {
    db.collection('counter').findOne({target: 'class'}, function(err, count){
        var classData = {
            _id: count.number + 1,
            title: '주니어과정' + req.body.course + req.body.timeZone + req.body.classTime + req.body.numberOfClasses,
            timeZone:  req.body.timeZone,
            classTime: req.body.classTime ,
            numberOfClasses: req.body.numberOfClasses,
            price:  req.body.price,
            month:  req.body.month,
            tutor: 4,
            student: 2,
            time: '12:00 ~ 12:30',
            regDay:  req.body.regDay,
            company: '협력사',
            cancle: null,
            payment: {
                method: '무통장',
                status: '결제완료',
                refund: 'x',
            },
            attendance:{
                total: 50,
                remain: 50,
                checked: 0
            }
        };

        db.collection('class').insertOne(classData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'class'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                })
            }
        });

    });
});

app.post('/add/leveltest', (req, res) => {
    db.collection('counter').findOne({target: 'leveltest'}, function(err, count){
        var classData = {
            _id: count.number + 1,
            student:{
                userName: req.body.userName,
                id: req.body.id,
            },
            level: null,
            result: {
                average: null,
                pronunciation: null,
                grammer: null,
                vocabulary: null,
                understanding: null,
                fluency: null
            },
            regDay: req.body.levelTest.regDay,
            testDay: req.body.levelTest.date.fixed,
            time: req.body.levelTest.time,
            tutor: req.body.levelTest.tutor,
            testMethod: req.body.levelTest.testMethod,
            testLevel: req.body.levelTest.testLevel,
            toTutor: req.body.levelTest.toTutor,
            company: '협력사',
            consulting: '무',
            status: '접수',

        };

        db.collection('leveltest').insertOne(classData, (err, result) => {
            if(err) return console.log(err)
            if(result) {
                db.collection('counter').updateOne({target: 'leveltest'}, {$inc: {number: 1}}, function(에러, 결과){
                    if(에러) return console.log(에러)
                    db.collection('user').updateOne(
                        {_id: parseInt(req.body._id)},
                        {$set:{  
                            levelTest:{
                                status: '접수',
                                consulting: false,
                                regDay: req.body.levelTest.regDay,
                                time: req.body.levelTest.time,
                                date:{
                                    want: null,
                                    fixed: req.body.levelTest.date.fixed,
                                },
                                tutor: null,
                                level: null,
                                result:{
                                    average:null,
                                    pronunciation:null,
                                    grammer:null,
                                    vocabulary:null,
                                    understanding:null,
                                    fluency:null,
                                },
                                testMethod: req.body.levelTest.testMethod,
                                testLevel: req.body.levelTest.testLevel,
                                toTutor: req.body.levelTest.toTutor,
                                request: null,
                                note: null
                            }
                        }}, (err, 결과) => {
                            if(err) console.log(err)
                        }
                    )
                })
            }
        });

    });
});


// DB 삭제하기

app.delete('/delete/user', (req, res) => {
    var deleteData = {_id: parseInt(req.body.selectData)}

    db.collection('user').deleteOne(deleteData, (err, result) => {
        if(err) console.log(err)
        res.status(200).send({message: '성공했습니다'});

        db.collection('counter').findOne({target: 'tutor'}, function(err, count){
            db.collection('counter').updateOne({target: 'user'}, {$inc: {remove: 1}}, function(에러, 결과){
                if(에러) return console.log(에러)
            })

        });
    
    })
});

app.delete('/delete/tutor', (req, res) => {
    var deleteData = {_id:  parseInt(req.body.selectData)}
    
	db.collection('tutor').deleteOne(deleteData, (err, result) => {
        if(err) console.log(err)
        res.status(200).send({message: '성공했습니다'});

        db.collection('counter').findOne({target: 'tutor'}, function(err, count){
            db.collection('counter').updateOne({target: 'tutor'}, {$inc: {remove: 1}}, function(에러, 결과){
                if(에러) return console.log(에러)
            })

        });
        
  	});
});

app.delete('/delete/leveltest', (req, res) => {
    var deleteData = {_id:  parseInt(req.body.selectData)}
    
    db.collection('leveltest').findOne(deleteData, (err, result) => {
        db.collection('user').updateOne(
            {id: result.student.id},
            {$set:{  
                levelTest:{
                    status: '미접수',
                    consulting: false,
                    date:{
                        want: null,
                        fixed: null
                    },
                    tutor: null,
                    level: null,
                    result:{
                        average:null,
                        pronunciation:null,
                        grammer:null,
                        vocabulary:null,
                        understanding:null,
                        fluency:null,
                    },
                    toTutor: null,
                    request: null,
                    note: null
                }
            }},
            (err, 결과) => {
                if(err) console.log(err)
            }

        )
    });

	db.collection('leveltest').deleteOne(deleteData, (err, result) => {
        if(err) console.log(err)
        res.status(200).send({message: '성공했습니다'});

        db.collection('counter').findOne({target: 'tutor'}, function(err, count){
            db.collection('counter').updateOne({target: 'tutor'}, {$inc: {remove: 1}}, function(에러, 결과){
                if(에러) return console.log(에러)
            })

        });
        
  	});
});



// DB 수정하기

app.put('/edit/user', (req, res) => {
    db.collection('user').updateOne(
        {_id: parseInt(req.body._id)},
        {$set:{  
            userName: req.body.userName,
            engName: req.body.engName,
            age: req.body.age,
            birthday: req.body.birthday,
            id: req.body.id,
            pw: req.body.pw,
            sex: req.body.sex,
            userTel: req.body.userTel,
            address: req.body.address,
            membership: req.body.membership,
            joinData: {
                root: req.body.joinData.root,
                day: req.body.joinData.day,
                recommendPerson:{
                    name: req.body.joinData.recommendPerson.name,
                    tel: req.body.joinData.recommendPerson.tel,
                }
            },
            coupon: req.body.coupon,
            levelTest:{
                status: '미접수',
                consulting: false,
                date:{
                    want: null,
                    fixed: null
                },
                tutor: null,
                level: null,
                result:{
                    average:null,
                    pronunciation:null,
                    grammer:null,
                    vocabulary:null,
                    understanding:null,
                    fluency:null,
                },
                toTutor: null,
                request: null,
                note: null
            }
        }},
        (err, 결과) => {
            if(err) console.log(err)
        }
    )
});



app.put('/edit/tutor', (req, res)=>{
    db.collection('tutor').updateOne(
        {_id: parseInt(req.body._id)},
        {$set:{  
            tutorName: req.body.tutorName,
            birthday: req.body.birthday,
            id: req.body.id,
            pw: req.body.pw,
            sex: req.body.sex,
            country: req.body.country,
            joinDay: req.body.joinDay,
            center: req.body.center,
            classInfo:{
                payPerClass: req.body.classInfo.payPerClass,
                breakTime: req.body.classInfo.breakTime,
            },
            gpa: req.body.gpa,
            zoomUrl: req.body.zoomUrl,
            youtube: req.body.youtube,
            introduce: req.body.introduce,
            profile: req.body.profile,
            memo: req.body.memo,
        }},
        (err, 결과) => {
            if(err) console.log(err)
        }
    )
});


app.put('/edit/class', (req, res)=>{
    db.collection('class').updateOne(
        {_id: parseInt(req.body._id)},
        {$set:{  
            payment: {
                method: '무통장',
                status: '환불완료',
                refund: 'o',
            },
        }},
        (err, 결과) => {
            if(err) console.log(err)
        }
    )
});

app.put('/edit/leveltest', (req, res)=>{
    db.collection('leveltest').updateOne(
        {_id: parseInt(req.body._id)},
        {$set:{  
            tutor: {
                tutorName: req.body.tutor.tutorName,
                id: req.body.tutor.id,
            },
            status: '수업 확정'
        }},
        (err, 결과) => {
            if(err) console.log(err)
        }
    )
});


// 검색하기 

app.get('/search/user', (req, res) => {
    console.log(req.query)
    var searchData = [
        {
          $search: {
            index: 'userSearch',
            text: {
              query: req.query.text, // 실제 검색 부분
              path: [req.query.tag] // 제목날짜 둘다 찾고 싶으면 ['title', 'date']
            }
          }
        },
       { $sort : { _id : -1 } }, // 정렬, _id 순서로 정렬 (-1로 하면 반대순서로 정렬)
       { $limit : 10 }, // 제한걸기. 상위 10개만 가져와주세요
    //    { $project : { userName : 1, id : 1, _id : 1 } } // 검색 결과를 뭘 보여줄지 선택 (1은 가져옴, 0이면 안가져옴)
    ];

    db.collection('user').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});

app.get('/search/user/today', (req, res) => {
    var searchData = [
        { $match : {  regDay : req.query.day  }},
        { $sort : { _id : -1 } },
    ];
    db.collection('user').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
        console.log(data)
    });
});

app.get('/search/tutor', (req, res) => {
    var searchData = [
        {
          $search: {
            index: 'tutorSearch',
            text: {
              query: req.query.text, // 실제 검색 부분
              path: [req.query.tag] // 제목날짜 둘다 찾고 싶으면 ['title', 'date']
            }
          }
        },
        { $sort : { _id : -1 } }, // 정렬, _id 순서로 정렬 (-1로 하면 반대순서로 정렬)
        { $limit : 10 }, // 제한걸기. 상위 10개만 가져와주세요
    //    { $project : { userName : 1, id : 1, _id : 1 } } // 검색 결과를 뭘 보여줄지 선택 (1은 가져옴, 0이면 안가져옴)
    ];

    db.collection('tutor').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
    });
});



app.get('/search/leveltest/today', (req, res) => {
    var searchData = [
        { $match : {  testDay : req.query.day  }},
        { $sort : { _id : -1 } },
    ];
    db.collection('leveltest').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
        console.log(data)
    });
});

app.get('/search/leveltest/last', (req, res) => {
    console.log(req.query.day)
    var searchData = [
        { $match: {  testDay : {$ne: req.query.day  }}},
        {$sort : { _id : -1 }} 
    ];
    db.collection('leveltest').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
        console.log(data)
    });
});

app.get('/search/class/today', (req, res) => {
    var searchData = [
        { $match : {  regDay : req.query.day  }},
        { $sort : { _id : -1 } },
    ];
    db.collection('class').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
        console.log(data)
    });
});

app.get('/search/class/last', (req, res) => {
    var searchData = [
        { $match: {  regDay : {$ne: req.query.day  }}},
        {$sort : { _id : -1 }} 
    ];
    db.collection('class').aggregate(searchData).toArray((err, data)=>{
        if(err) return console.log('에러', err)
        if(data) res.json(data)
        console.log(data)
    });
});



module.exports = {
  path: '/api',
  handler: app
};