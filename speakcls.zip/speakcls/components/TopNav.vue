<template>
	<nav :class="{open : menuOpen, white: scroll>10, login: login, openMbList: openMbList}" class="nav-wrapper">
		<div class="logo">
			<nuxt-link :to="'/'" >
				<img :src="logo" id="logo" alt="speakcls">
			</nuxt-link>
			<div class="btns" v-if="$device.isMobile ">
				<nuxt-link :to="'/mypage'" class="font3 pinkBtn" v-if="login">마이페이지</nuxt-link>
				<nuxt-link :to="'/level-test'" class="font3 pinkBtn" v-else>무료 테스트시작</nuxt-link>
			</div>
		</div>
		<button id="menuBtn" @click="mbMenuOpen = !mbMenuOpen" v-if="$device.isMobile " :class="{open: mbMenuOpen}">
			<div></div>
			<div></div>
			<div v-if="mbMenuOpen"></div>
			<div></div>
		</button>

		<div class="menu-wrapper" v-if="!$device.isMobile ">
			<ul class="menu" >
				<li v-for="(menu , idx) in menuList" :key="'menu'+idx"  @mouseover="menuOpen=(subMenuList[menu.menuUrl]?true:false) " @mouseout="menuOpen = false" @click="mbMenuOpen = false">
					<nuxt-link :to="'/'+menu.menuUrl" :url="'/'+menu.menuUrl">{{ width<1080 ? menu.menuNameMB : menu.menuName}}</nuxt-link>
					<ul>
						<li v-if="subMenuList[menu.menuUrl]" v-for="(subMenu, idx) in subMenuList[menu.menuUrl]" :key="'sub menu'+idx"  @mouseover="menuOpen = true" @click="mbMenuOpen = false">
							<nuxt-link :to="{path:'/'+subMenu.menuUrl, query:{page: subMenu.path}}">{{(width<=1080 && width>767 && subMenu.menuNameMB) ? subMenu.menuNameMB : subMenu.menuName}}</nuxt-link>
						</li>
					</ul>
				</li>
			</ul>
			<div class="btns" v-if="login">
				<nuxt-link :to="'/mypage'">마이페이지</nuxt-link>
				<nuxt-link :to="'/mypage?editProfile=true'" class="pinkBtn" >김이름<div class="img"></div></nuxt-link>
			</div>
			<div class="btns" v-else>
				<nuxt-link :to="'/join'" >회원가입</nuxt-link>
				<nuxt-link :to="'/login'" class="pinkBtn" >지금 시작하기 </nuxt-link>
			</div>
		</div>


		<div class="line"></div>
		<div class="mb-menu-wrapper" v-if="$device.isMobile  && login">
			<div class="root" @click="openMbList = !openMbList">
				<p>스픽클<span></span>{{root}}</p>
				<img :src="require('@/assets/img/down-arrow.png')" >
			</div>
			<ul class="menu">
				<li v-for="(menu , idx) in menuList" :key="'menu'+idx"  @mouseover="menuOpen=(subMenuList[menu.menuUrl]?true:false) " @mouseout="menuOpen = false">
					<nuxt-link :to="'/'+menu.menuUrl" :url="'/'+menu.menuUrl" class="font4" :class="{act: root==menu.menuNameMB}">{{menu.menuNameMB}}</nuxt-link>
				</li>
			</ul>
		</div>
		<div class="dim" v-if="mbMenuOpen" :class="{show: mbMenuOpen}"></div>
		<div class="mb-mem-menu" v-if="$device.isMobile && login" :class="{show: mbMenuOpen}">
			<div>
				<nuxt-link :to="'/mypage/edit-profile'" class="setting" ></nuxt-link>
				<div class="after-login" >
					<div class="profile">
						<nuxt-link :to="'/mypage'">
							<div class="image"></div>
							<p class="name">김이름</p>
						</nuxt-link>
					</div>
					<ul class="menu">
						<li><nuxt-link :to="'/mypage/schedule'">스케쥴</nuxt-link></li>
						<li><nuxt-link :to="'/mypage/feedback'">튜터 피드백</nuxt-link></li>
						<li><nuxt-link :to="'/mypage/guide'">이용안내</nuxt-link></li>
					</ul>
					<ul class="menu">
						<li><nuxt-link :to="'/mypage/class/list/?retake=true'">재수강 신청</nuxt-link></li>
						<li><nuxt-link :to="'/mypage/free-class'">무료 수업</nuxt-link> <button class="arrow" @click="openMbMenu($event)"></button>
							<ul>
								<li><nuxt-link :to="'/level-test'">신청하기</nuxt-link></li>
								<li><nuxt-link :to="'/mypage/free-class/result'">결과확인</nuxt-link></li>
							</ul>
						</li>
						<li><nuxt-link :to="'/mypage/free-class/apply'">레벨 테스트</nuxt-link></li>
					</ul>
					<ul class="menu">
						<li @click="removeCookies"> <nuxt-link :to="'/'">로그아웃</nuxt-link> </li>
					</ul>
				</div>
			</div>
		</div>
		<div class="mb-menu-pop" v-if="mbMenuOpen && login!==true">
			<div class="before-login" >
				<b>24시간 언제나<br>당신만을 위한 1:1 영어 공부</b>
				<div class="btns">
					<nuxt-link :to="'/login'" class="pinkBtn">로그인</nuxt-link>	
					<nuxt-link :to="'/join'">회원가입</nuxt-link>	
				</div>
				<ul class="menu">
					<li v-for="(menu , idx) in menuList" :key="'menu'+idx"  @mouseover="menuOpen=(subMenuList[menu.menuUrl]?true:false) " @mouseout="menuOpen = false">
						<nuxt-link :to="'/'+menu.menuUrl" :url="'/'+menu.menuUrl" class="font4">{{menu.menuNameMB}}</nuxt-link>
					</li>
				</ul>
			</div>

		</div>
	</nav>
</template>

<style lang="scss" scope>
.nav-wrapper{
	width: 100%;
	height: auto;
	max-height: 80px;
	position: fixed;
	overflow: hidden;
	top: 0;
	left: 0;
	z-index: 9999;
	@include flex(center, flex-start);

	&.open{
		max-height: 500px;
	}
	&:hover, &.white{
		background-color: $white;
		.menu-wrapper .btns{
			a{
				&:last-child{
					background-color: $pink;
					border-color: $pink;
					color: $white;
				}
			}
		}
	}
	.pinkBtn{
		background-color: $pink !important;
		border-color: $pink !important;
		color: $white !important;
	}
	.logo{
		width: 160px;
		height: 80px;
		padding: 10px 0;
		img{
			width: 100%;
			height: 100%;
			object-fit: contain;
		}
	}
	.menu-wrapper{
		@include flex(center, flex-start);
		.menu{
			margin: 0 100px;
			@include flex(center, flex-start);
			>li{
				position: relative;
				line-height: 80px;
				font-size: 18px;
				>a{
					width:100%;
					padding: 0 15px;
					display: block;
					font-size: 16px;
					font-family: 'SCDream4';
					&:hover{
						color: $pink
					}
				}
				>ul{
					position: relative;
					width: 100%;
					margin-bottom: 20px;
					padding-top: 20px;
					li{
						width:100%;
						line-height: 34px;
						text-align: center;
						a{
							font-size: 16px;
							font-family: 'SCDream4';
						}
						a:hover{
							color: $pink
						}
					}
				}
			}
		}
		.btns{
			@include flex(center, flex-start);
			a{
				@include flex();
				padding: 8px 20px;
				border: 1px solid #919092;
				border-radius: 40px;
				margin-top: 20px;
				font-size: 15px;
				transition: all 0s;
				font-family: 'SCDream4';
				&+a{
					margin-left: 10px;
				}
				.img{
					width: 22px;
					height: 22px;
					margin-left: 5px;
					border-radius: 50%;
					background: url('@/assets/img/profile/sample.png') no-repeat center;
					background-size: cover;
				}
			}
		}
	}
	.line{
		position: absolute;
		width: 100%;
		max-width: 1200px;
		height: 1px;
		background-color: #ebebeb;
		top: 81px;
		left: 0;
		right: 0;
		margin: 0 auto;
	}
}

@media screen and (max-width: 1240px) {
	nav{
		padding: 0;
		.menu-wrapper{
			.menu{
				margin: 0 40px;
			}
		}
	}
}
@media screen and (max-width: 1080px) {
	nav{
		justify-content: space-between;
		padding: 0 20px;
		.menu-wrapper{
			.menu{
				justify-content: space-between;
				>li{
					width: auto;
					>a{
						padding: 0 10px;
					}			
				}
			}
			.btns{
				a{
					padding: 5px 12px;
				}
			}
		}
	}
}
@media screen and (max-width: 860px) {
	nav{
		.logo{
			width: 120px;
		}
		.menu-wrapper{
			.menu{
				margin: 0 20px;
				>li{
					>a{
						padding: 0 8px;
					}
				}
			}
			.btns{
				a{
					font-size: 14px;
					margin-top: 25px;
					&+a{
						margin-left: 5px;
					}
				}
			}
		}
	}
}

@media screen and (max-width: 767px) {
	nav{
		padding: 0 10px;
		height: auto;
		max-height: 60px;
		flex-wrap: wrap;
		background-color: $white;
		transition: all 0.4s;
		&.login{
			max-height: 105px;
			border-bottom: 1px solid #ebebeb;
		}
		&.openMbList{
			max-height: 400px;
			border-bottom: 1px solid #ebebeb;
		}
		.logo{
			width: 100%;
			height: 60px;
    		padding: 5px 0;
			@include flex(space-between);
			img{
				width: 110px;
			}
			.btns{
				@include flex(center);
				padding-right: 40px;
				a{
					padding: 5px 15px;
					border-radius: 40px;
					font-size: 14px;
					transition: all 0s;
					font-family: 'SCDream4';
				}
			}
		}
		#menuBtn{
			width: 37px;
    		height: 60px;
			cursor: pointer;
			margin-left: 10px;
			position: absolute;
			right: 0;
			top: 0;
			display: inline-block;
			z-index: 2;
			div{
				width: 26px;
				height: 3px;
				background-color: rgb(67, 67, 67);
				transform: scaleX(1);
				transition: all 0.3s;
				&:first-child{
					transform-origin: right center;
				}
				&:nth-child(2){
					margin: 4px 0;
				}
				&:last-child{
					transform-origin: left center;
				}
			}
			&.open{
				div{
					&:first-child{
						transform: scaleX(0);
					}
					&:last-child{
						transform: scaleX(0);

					}
					&:nth-child(2){
						animation: show1 0.3s 0.4s forwards;

					}
					&:nth-child(3){
						position: absolute;
						top: 29px;
						animation: show2 0.3s 0.4s forwards;

					}
					@keyframes show1 {
						0%{
							transform: rotate(0);
						}
						100%{
							transform: rotate(-45deg);
						}

					}
					@keyframes show2 {
						0%{
							transform: rotate(0);
						}
						100%{
							transform: rotate(45deg);
						}

					}
				}
			}
			
		}
		.line{
			top: 60px;
		}
		.mb-menu-wrapper{
			width: 100%;
			.root{
				height: 40px;
				width: 100%;
				@include flex(space-between);
				p{
					line-height: 40px;
					span{
						width: 20px;
						height: 10px;
						display: inline-block;
						margin: 0 5px ;
						background: url('@/assets/img/arrow.png') no-repeat center;
						background-size: 10px;
						opacity: 0.5;
					}
				}
				img{
					width: 15px;
				}
			}
			ul{
				padding-bottom: 10px;
				>li {
					line-height: 40px;
					>a{
						font-size: 15px;
						&.act{
							color: $pink;
						}
					}
				}
			}
		}
		.dim{
			position: fixed;
			width: 100%;
			height: 100%;
			top: 0;
			right: 0;
			background-color: $popupBg;
			opacity: 0;
			transform: translateX(100vw);
			transition: opacity 0.3s;
			&.show{
				opacity: 1;
				transform:translateX(0vw);
			}
		}
		.mb-mem-menu{
			position: fixed;
			width: 100%;
			height: 100%;
			top: 0;
			right: 0;
			transform: translateX(100vw);
			transition: all 0.3s;
			&.show{
				transform:translateX(0vw);
			}

		
			>div{
				width: 95%;
				height: 100%;
				top: 0;
				margin-left: auto;
				background-color: rgb(255, 255, 255);

			}
			.setting{
				width: 40px;
				height: 40px;
				top: 10px;
    			right: 40px;
				background: url('@/assets/img/setting.png') no-repeat center;
				position: absolute;
				background-size: 24px;
				opacity: 0.6;
			}
			.after-login{
				.profile{
					padding: 40px 0 10px 40px ;
					a{
						width: auto;
						display: inline-block;
					}
					.image{
						width: 70px;
						height: 70px;
						background: url('@/assets/img/profile/sample.png') no-repeat center;
						background-size: cover;
						border-radius: 50%;
					}
					.name{
						width: 70px;
						text-align: center;
						margin-top: 5px;
					}
				}
				.menu{
					margin-top: 20px;
					border-top: 1px solid #ebebeb;
					padding-top: 20px;
					>li{
						font-size: 18px;
						line-height: 40px;
						font-family: "SCDream4";
						position: relative;
						&.act{
							>a{
								background: $pink;
								color: $white;
							}
							button{
								filter: brightness(100);
								transform: rotate(180deg);
							}
						}
						a{
							padding-left: 40px;
							font-family: "SCDream4";
							width: 100%;
							height: 100%;
							display: inline-block;
						}
						button{
							background: url('@/assets/img/down-arrow.png') no-repeat center;
							background-size: 15px;
							width: 50px;
							height: 40px;
							top: 0;
							right: 0;
							position: absolute;
						}
						>ul{
							font-size: 16px;
							overflow: hidden;
							max-height: 0;
							line-height: 28px;
							&.open{
								max-height: 1000px;
							}
							>li {
								&:first-child{
									padding-top: 6px;
								}
								a{
									font-family: "SCDream3";
								}
							}
						}
					}
				}
			}
		}
		.mb-menu-pop{
			position: fixed;
			width: 100%;
			height: 100%;
			top: 0;
			left: 0;
			background-color: rgba(255, 255, 255, 0.9);
			@include flex();
			.before-login{
				text-align: center;
				b{
					display: block;
					font-size: 20px;
				}
				.btns{
					@include flex(center, flex-start);
					margin: 30px 0 50px;
					a{
						padding: 5px 15px;
						border: 1px solid #919092;
						border-radius: 40px;
						font-size: 15px;
						transition: all 0s;
						font-family: 'SCDream4';
						&+a{
							margin-left: 10px;
						}
					}
				}
				.menu{
					li{
						&+li{
							margin-top: 10px;
						}
					}
				}
			}
		}

	}
}


</style>
<script>
export default {
	data() {
		return {
			logo: require("@/assets/img/logo.png"),
			menuOpen: false,
			mbMenuOpen: false,
			openMbList: false,
			root: null,
			menuList: [
				{ menuName: "스픽클 소개",  menuNameMB: "소개" , menuUrl: "" },
				{ menuName: "튜터 소개",menuNameMB: "튜터소개", menuUrl: "tutor" },
				{ menuName: "커리큘럼", menuNameMB: "커리큘럼",menuUrl: "curriculum"},
				{ menuName: "후기", menuNameMB: "후기",menuUrl: "review" },
				{ menuName: "수강권 구매",menuNameMB: "수강권 구매", menuUrl: "purchase" },
				{ menuName: "Speakcls 뉴스",menuNameMB: "S 뉴스", menuUrl: "news" }
			],
			subMenuList:{
				curriculum:[
					{menuName: '북토킹', menuUrl: 'curriculum'},
				 
					{menuName: '쉐도잉', menuUrl: 'curriculum'},
					{menuName: '영자신문', menuUrl: 'curriculum'}
				],
				news:[
					{menuName: '이벤트', menuUrl: 'news/event'},
					{menuName: '공지사항', menuUrl: 'news', path: 'notice'},
					{menuName: '자주묻는 질문', menuNameMB: "FAQ", menuUrl: 'news', path: 'FAQ'}
				],
			},
			scroll:0,
		};
	},
	props:['width', 'login'],
	mounted(){
		this.getPath();
		this.handleScroll();
        window.addEventListener('scroll', this.handleScroll);

	},
	watch:{
		'$route' (to, from) {
			this.scroll = 0;
			this.getPath();

			setTimeout(() => {
				this.mbMenuOpen = false;
				this.openMbList = false;
			}, 200);
		}
    },
	methods: {
		handleScroll(){
			this.scroll = window.scrollY;
		},
		openMbMenu(e){
			var list =  e.target.parentElement;
			var ul =  e.target.nextElementSibling;
			list.classList.toggle('act')
			ul.classList.toggle('open')

		},
		removeCookies() {
            this.$cookies.remove('login');
            this.$router.push({ path: '/' });
			this.$router.go();
        },
		getPath(){
			var path = this.$route.path;
			this.menuList.forEach(e=>{
				if( path == '/'+ e.menuUrl){
					this.root = e.menuNameMB;
				}
				
			})
			
		}
	},
};
</script>