<template>
<div class="component">

    <section class="my-class">
        <div v-if="!$device.isMobileOrTablet">
            <p :class="'font6'">공지사항<nuxt-link :to="'/news'" class="font3">전체보기</nuxt-link></p>
            <div class="card notice">
                <div class="check"> <img :src="require('@/assets/img/check.png')" > </div>
                <ul>
                    <li>6월 1일 (수) 지방선거</li>
                    <li>6월 6일 (월) 현충일</li>
                </ul>
            </div>
        </div>
        <div v-if="haveClass==true && showInto">
            <p :class="$device.isMobileOrTablet  ? 'font5' : 'font6' ">수업 준비하기 <span>2022.01.01</span></p>
            <div class="card default">
                <b @click="removeCookies">Joaane 강사님과<br>19:30 수업 예정이에요</b>
                <nuxt-link :to="'/mypage'" :class="{pc: !$device.isMobileOrTablet}">입장하기</nuxt-link>
            </div>
        </div>

        <div v-if="haveClass==true">
            <p :class="$device.isMobileOrTablet  ? 'font5' : 'font6' ">나의 수강권 <nuxt-link :to="'/mypage/class/list'" class="font4">수강내역</nuxt-link></p>
            <div class="card class">
                <div>
                    <b><span class="font7">48</span>주</b>
                    <ul>
                        <li class="font4">주 2회</li>
                        <li class="font4">월,수,금</li>
                        <li class="font4">25분</li>
                    </ul>
                </div>
                <div class="date">
                    <p>2022.01.01 ~ 2023.01.10 주2회</p><b class="font4">진행중</b>
                </div>
            </div>
        </div>
        <div v-else>
            <p :class="$device.isMobileOrTablet  ? 'font5' : 'font6' ">나의 수강권</p>
            <div class="card default">
                <b @click="setCookie('class')">언제 어디서나 스픽클과 함께!<br>지금 시작하세요.</b>
                <nuxt-link :to="'/purchase'"  :class="{pc: !$device.isMobileOrTablet}">수강신청</nuxt-link>
            </div>
        </div>

    </section>
</div>
</template>
<style scoped lang="scss"> 
.my-class{
    padding: 0 20px 10px;
    div{
        margin-bottom: 15px;
        @include flex(center, flex-start, column);
        p{
            margin-bottom: 10px;
            position: relative;
            width: 100%;
            font-size: 20px;
            span,a{
                position: absolute;
                right: 0;
                font-size: 15px;
                opacity: 0.8;
            }
            a{
                padding-right: 15px;
                background: url('@/assets/img/arrow.png') no-repeat right center;
                background-size: 8px;
            }
        }
        .card{
            background-color: #fff5f9;
            border-radius: 0 20px 20px 20px;
            box-shadow: $shadow;
            padding: 20px 25px;
            width: 100%;
            height: 150px;
            a,span{
                display: inline-block;
                border: 1px solid $pink;
                border-radius: 20px;
                padding: 4px 15px;
                font-size: 16px;
                margin-top: auto;
                background-color: $pink;
            }
            a{
                color: $white;
                &.pc{
                    font-size: 18px
                }
            }
            >div{
                @include flex(space-between);
                width: 100%;
                b span{
                    font-size: 30px;
                    margin-right: 4px;
                    border: none;
                    padding: 0;
                    background: none;
                }
                ul{
                    @include flex();
                    li{
                        background-color: $white;
                        width: 60px;
                        height: 60px;
                        border-radius: 5px;
                        @include flex();
                        &+li{
                            margin-left: 5px;
                        }
                    }

                }
                
            }
            &.notice{
                @include flex(flex-start, flex-start);
                background-color: #fefaf2;
                .check{
                    @include flex();
                    background-color: #fef2da;
                    width: 50px;
                    height: 50px;
                    border-radius: 10px;
                    margin-right: 20px;
                    img{
                        width: 54%;
                    }
                }
                ul li{
                    font-size: 16px;
                    line-height: 22px;
                    font-family: "SCDream4";
                    margin-bottom: 10px;
                }
            }
            &.default{
                b{
                    font-size: 16px;
                    line-height: 22px;
                    font-family: "SCDream4";
                    font-weight: 300;
                }
            }
            &.class{
                padding: 20px 25px 10px;
                background-color: #f6f2ff;
                .date{
                    margin: auto 0 0;
                    border-top: 2px solid $white;
                    padding-top: 10px;
                    p, b{
                        font-size: 14px;
                        width: auto;
                        margin: 0;
                        font-family: "SCDream4"
                    }
                }
            }
        }
    }
}

@media screen and (max-width: 767px) {
.my-class{
    background-color: #fff5f9;
    padding: 30px 20px !important;
    div{
        p{font-size: 16px;}
        .card{
            background-color: $pink;
            height: 170px;
            a,span{
                color: $pink;
                background-color: $white;
                color: $pink;
            }
            b{
                color: $white;
            }
            >div{
                b span{
                    color: $white;
                }
                ul{
                    li{
                        color: $pink;
                    }

                }
                
            }
            &.default{
                b{
                    font-family: "SCDream6";
                    font-size: 20px;
                    line-height: 26px;
                }
            }
            &.class{
                background-color: $pink;
                .date{
                    padding-top: 5px;
                    p, b{
                        color: $white;
                    }
                }
            }
        }
    }
}
}
</style>


<script>

export default {
    name: 'MyClass',
    layout: 'mypage',
    props:['login'],
    data(){
        return{
            haveClass: false,
            userData:[
                {title:'정규 수업',
                 date: '2022-6-23',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'2022 지방선거',
                 date: '2022-6-30',
                 time: 'all',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-7-3',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-7-6',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-6-30',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'빨간날',
                 date: '2022-7-10',
                 time: 'all',
                 cancle: false,
                 question: false},
               
            ],
            showInto : false

        }
    },
    mounted(){
        this.getCookie();
        this.todayClassCheck();
    },
    watch:{
    },
    filters:{

    },
    methods:{
        setCookie(v) {
            this.$cookies.set(v, true, {
                path: '/',
                maxAge: 60 * 60 * 24 * 7
            });
            this.$router.go();
        },
         getCookie(){
			this.haveClass = this.$cookies.get('class');
		},
        removeCookies() {
            this.$cookies.remove('class');
			this.$router.go();
        },
        todayClassCheck(){
            var year = new Date().getFullYear(),    
                month = new Date().getMonth()+1,
                day = new Date().getDate();

            this.userData.forEach(e => {
                if(e.title == '정규 수업') {
                    if( e.date.split('-')[0] == year){
                        if( e.date.split('-')[1] == month){
                            if( e.date.split('-')[2] == day){
                                this.showInto = true
                            }
                        }
                    }
                }
            });

        }
    }
}
</script>
