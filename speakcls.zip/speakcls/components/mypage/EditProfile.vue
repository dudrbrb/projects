<template>
    <div class="component">
        <section>
            <div class="profile">
                <div class="image">
                    <button id="imageChange"></button>
                    <input type="file" >
                </div>
                <div class="name">{{user.name}}</div>
            </div>
            <div class="edit">
                <h4 class="font5">수업에서 사용하실 이름을 알려주세요.</h4>
                <p>강사님과 수업할 때 사용됩니다.</p>

                <label class="font4">닉네임</label>
                <input type="text" v-model="user.name" class="font3">
                <button class="black" @click="changeBtn">변경하기</button>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>

section{
    .profile{
        @include flex(center, center, column);
        margin-bottom: 50px;
        .image{
            width: 100px;
            height :100px;
            background: url('@/assets/img/profile/sample.png') no-repeat center;
            background-size: cover;
            border-radius: 50%;
            position: relative;
            margin-bottom: 5px;
            input{
                display: none;
            }
            button{
                width: 30px;
                height: 30px;
                border-radius: 50%;
                background-color: #f7f7f7;
                background-image: url('@/assets/img/setting.png');
                background-size: 20px;
                background-repeat: no-repeat;
                background-position: center;
                box-shadow: 2px 2px 3px rgba(0,0,0,0.2);
                position: absolute;
                right: 0;
                bottom: 0;
            }
        }
        .name{
            font-size: 20px;
        }
    }
    .edit{
        h4{
            font-size: 20px;
            margin-bottom: 5px;
        }   
        label{
            margin: 30px 0 10px;
            display: block;
            font-size: 16px;
        }
        input{
            width: 100%;
            height: 45px;
            background-color: #f6f5fb;
            border-radius: 5px;
            padding-left: 10px;
            font-size: 15px;
        }
       button.black{
            width: 100%;
            height: 55px;
            background-color: rgb(48, 48, 48);
            color: $white;
            border-radius: 5px;
            font-size: 18px;
            margin-top: 45px;
        }
    }
}

</style>

<script>
export default {
    name: 'EditProfile',
    layout: 'mypage',
    data(){
        return{
            user:{
                name:'김이름'
            }
           
        }
    },
    created(){
    },
    mounted(){
    },
    watch:{
    },
    filters:{

    },
    methods:{
        changeBtn(){
            this.$emit("changeProfile", 'close')
        }
    }
}

</script>
