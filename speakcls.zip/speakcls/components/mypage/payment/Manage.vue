<template>
    <div class="component payment-manage" :class="{pc: !$device.isMobileOrTablet }">
        <section class="message">
            <b class="font4">결제수단을 등록하면 간편 결제가 가능해요.<br>
            결제 정보는 암호화되어 안전하게 관리되니 안심하세요!</b>
        </section>
        <section class="manage-wrapper">
            <div class="manage">
                <div class="manage-title">
                    <h4 class="font4">결제 관리</h4>
                    <button @click="addCard= !addCard" :class="['font4', {act: addCard}]">+ 결제수단추가</button>
                </div>
                <div class="card" v-if="addCard">
                    <h4 class="card-title font4">새로운 카드 추가</h4>
                    <div class="card-content">
                        <div>
                            <div class="input-box">
                                <label>카드 번호</label>
                                <input type="text" placeholder="0000 0000 0000 0000">
                            </div>
                            <div class="input-box">
                                <label>유효기간 (월/년)</label>
                                <input type="text" placeholder="MM YY">
                            </div>
                            <div class="input-box">
                                <label>비밀번호 앞 2자리</label>
                                <input type="text" placeholder="**">
                            </div>
                            <div class="input-box">
                                <label>생년월일 6자리</label>
                                <input type="text" placeholder="YY MM DD">
                            </div>
                        </div>
                        <div class="input-box info">
                            <label>결제대행 서비스 약관</label>
                            <div>
                                <ul>
                                    <li>정기과금약관 <span>약관보기</span></li>
                                    <li>전자금융거래 이용약관 <span>약관보기</span></li>
                                    <li>재인정보 수집 및 이용약관 <span>약관보기</span></li>
                                    <li>개인정보 제 3자 제공 및 위탁약관 <span>약관보기</span></li>
                                </ul>
                            </div>
                        </div>
                        <button v-if="!$device.isMobileOrTablet" class="submit">카드 등록</button>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
.payment-manage.pc{
    section{
         &.message{
            font-size: 20px;
            padding: 10px 0 ;
            font-weight: 600;
        }
        &.manage-wrapper{
            background-color: #fefefe;
            min-height: 0;
            padding-top: 30px;
            .manage{
                .manage-title{
                    button{
                        background-color: #ffe9f3;
                    }
                }
                .card{
                    background-color: #faf9fc;
                    position: relative;
                    box-shadow: none;
                    margin: 20px 0;
                    .card-content{
                        @include flex(space-between, flex-start);
                        padding-bottom: 0;
                        >div{
                            width: 49%;
                            .input-box{
                                input{
                                    border: 1px solid #bebebe;
                                    height: 45px;
                                }
                            }
                        }
                        .info{
                            div{
                                background-color: #f9ecf2;
                                border-radius: 10px;
                                ul{
                                    li{
                                        color: #a6a6a5
                                    }
                                }
                            }
                        }
                        .submit{
                            position: absolute;
                            bottom: 20px;
                            right: 20px;
                            background-color: $pink;
                            color: $white;
                            height: 45px;
                            padding: 0 20px;
                            border-radius: 8px;
                            font-size: 16px;
                        }
                    }
                }
            }
        }
    }
}
section{
    &.message{
        font-size: 14px;
        padding: 30px 20px 50px;
    }
    &.manage-wrapper{
        background-color: #f7f5fa;
        padding-top: 40px;
        min-height: 80vh;
        .manage{
            .manage-title{
                @include flex(space-between);
                h4{
                    font-size: 20px;
                }
                button{
                    background-color: #fff5f9;
                    color: $pink;
                    padding: 5px 15px;
                    border-radius: 20px;
                    font-size: 18px;
                    &.act{
                        background-color: $pink;
                        color: $white;
                    }
                }
            }
            .card{
                background-color: $white;
                border-radius: 20px;
                box-shadow: $shadow;
                margin-top: 30px;
                .card-title{
                    font-size: 18px;
                    line-height: 60px;
                    padding-left: 20px;
                    border-bottom: 1px solid #ececec;
                }
                .card-content{
                    padding: 30px 20px;
                    .input-box{
                        margin-bottom: 20px;
                        label{
                            display: block;
                            margin-bottom: 5px;
                        }
                        input{
                            border: 1px solid #ececec;
                            width: 100%;
                            height: 50px;
                            padding-left: 10px;
                            border-radius: 5px;
                            font-family: "SCDream3";
                            &::placeholder{
                                color: #c9c9c9;
                            }
                        }
                    }
                    .info{
                        div{
                            background-color: #fff5f9;
                            ul{
                                padding: 15px 10px;
                                li{
                                    color: #a8a7a7;
                                    font-family: "SCDream3";
                                    font-size: 14px;
                                    @include flex(space-between);
                                    line-height: 26px;
                                    span{
                                        font-size: 1em;
                                        color: #a8a7a7;
                                        display: inline-block;
                                        margin-left: auto;
                                    }
                                }
                            }
                        }

                    }
                }
            }
        }
    }
}

</style>

<script>
export default {
    name: 'paymentManage',
    layout: 'mypage',
    data(){
        return{
            data:{},
            addCard: false
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{
    },
    methods:{
    },
}

</script>
