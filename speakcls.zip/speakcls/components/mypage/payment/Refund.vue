<template>
   <div class="component refund" :class="{pc: !$device.isMobileOrTablet }"  v-if="popup.pcLastMessage==false">
        <section class="pagination">
            <ul>
                <li v-for="n in 4" @click="page=n" :key="n" :class="{act:page==n }">{{n}}</li>
            </ul>
        </section>
        <section class="page1" data-id="1" v-if="page==1">
            <h4>환불 규정을 꼭 확인해주세요.</h4>
            <p>환불의 규정은 아래와 같으며 이는 평생교육 사업법에 의거하여 규정되었습니다.</p>
            <div>
                <b>1. 전화강의 서비스 이용료 징수기간이 1개월 이내인 경우</b>
                <table>
                    <tbody>
                        <tr>
                            <th colspan="2">수업 시작 전</th>
                            <th>기납입한 이용료 전액</th>
                        </tr>
                        <tr>
                            <td rowspan="3">수업<br>시작 후</td>
                            <td>총 수업시간의 1/3이 경과하기 전</td>
                            <td>기납입한 이용료의 2/3에 해당되는 금액</td>
                        </tr>
                        <tr>
                            <td>총 수업시간의 1/2이 경과하기 전</td>
                            <td>기납입한 이용료의 1/2에 해당되는 금액</td>
                        </tr>
                        <tr>
                            <td>총 수업시간의 1/2이 경과한 후</td>
                            <td>반납하지 아니함</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div>
                <b>2. 전화강의 서비스 이용료 징수기간이 1개월을 초과하는 경우</b>
                <table>
                    <tbody>
                        <tr>
                            <td>수업<br>시작 전</td>
                            <td>기납입한 이용료 전액</td>
                        </tr>
                        <tr>
                            <td>수업<br>시작 후</td>
                            <td>환불사유가 발생한 그 달의 환불 대상 이용료 (징수기간이 1개월 이내인 경우에 준하여 산출된 이용료)와 나머지 달의 이용료 전액을 합산한 금액</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <article class="next-btn-pc " v-if="!$device.isMobileOrTablet">
                <button @click="next">다음</button>
            </article>
            
        </section>
        <section class="page2" data-id="2" v-if="page==2">
            <h4>수강권을 환불하는<br>이유를 알려주세요</h4>
            <div>
                <ul>
                    <li :class="['font4', {act: reason.btn=='서비스불만족'}]" @click="reason.btn='서비스불만족'">서비스 불만족</li>
                    <li :class="['font4', {act: reason.btn=='기타'}]" @click="reason.btn='기타'">기타</li>
                    <textarea name="reason" id="reason" cols="30" rows="4" placeholder="취소 사유를 입력해주세요." v-if="reason.btn == '기타'" v-model="reason.text"></textarea>
                </ul>
            </div>
            <article class="next-btn-pc " v-if="!$device.isMobileOrTablet">
                <button @click="next">다음</button>
            </article>
        </section>
        <section class="page3" data-id="3" v-if="page==3">
            <h4>서비스 이용 중에 불편한<br>사항이 있었다면 알려주세요.</h4>
            <div>
                <b>말하기 수업</b>
                <ul>
                    <li v-for="(q, idx) in question.speaking" :key="`speaking qeustion ${idx}`">
                        <label :for="`speaking${idx}`">{{q}}</label>
                        <input type="checkbox" :name="`speaking${idx}`" :id="`speaking${idx}`">
                        <label :for="`speaking${idx}`" class="checkbox"></label>
                    </li>
                </ul>
            </div>
            <div>
                <b>학습 콘텐츠</b>
                <ul>
                    <li v-for="(q, idx) in question.contents" :key="`contents qeustion ${idx}`">
                        <label :for="`contents${idx}`">{{q}}</label>
                        <input type="checkbox" :name="`contents${idx}`" :id="`contents${idx}`">
                        <label :for="`contents${idx}`" class="checkbox"></label>
                    </li>
                </ul>
            </div>
            <div>
                <b>서비스 이용</b>
                <ul>
                    <li v-for="(q, idx) in question.service" :key="`service qeustion ${idx}`">
                        <label :for="`service${idx}`">{{q}}</label>
                        <input type="checkbox" :name="`service${idx}`" :id="`service${idx}`">
                        <label :for="`service${idx}`" class="checkbox"></label>
                    </li>
                </ul>
            </div>
            <article class="next-btn-pc " v-if="!$device.isMobileOrTablet">
                <button @click="next">다음</button>
            </article>
        </section>
        <section class="page4"  data-id="4" v-if="page==4">
            <h4>환불 처리를 위해 <br>
                010-1234-5678로<br>
                전화 드릴 예정입니다.</h4>
            <div>
                <b>상담은 학습컨설팅센터 업무시간에 따라 진행됩니다.</b>
                <ul>
                    <li>평일 오전 9시 ~ 오후 6시</li>
                    <li>점심시간 12시 ~ 1시 제외</li>
                    <li>주말, 공휴일, 법정 공휴일 휴무</li>
                </ul>
            </div>
            <div class="indo-wrapper">
                <b>상담은 학습컨설팅센터 업무시간에 따라 진행됩니다.</b>
                <ul>
                    <li>환불 신청 시 신청 완료 시점을 기준으로 모든 수업은 중지됩니다.</li>
                    <li>정기수강 중인 경우 환불 신청에 따라 다음으로 예전된 경제건도 중지됩니다.</li>
                    <li>환불 신청 취소 시 남은 수업 횟수에 따라 수강기간이 조정될 수 있습니다.</li>
                    <li>환불 처리된 수강권은 다시 복원되지 않으니 신중히 결정해주세요.</li>
                </ul>
                
            </div>
            <article class="next-btn-pc " v-if="!$device.isMobileOrTablet">
                <button @click="next">환불신청</button>
            </article>
        </section>
     
        <section class="next-btn" v-if="$device.isMobileOrTablet ">
            <button @click="next($device.isMobileOrTablet )" v-if="page==4">환불신청</button>
            <button @click="next" v-else>다음</button>
        </section>
        <section class="popup-wrapper" v-if="popup.open && $device.isMobileOrTablet ">
            <div class="popup">
                <div class="txt-wrapper" v-if="popup.err">
                    <p class="font5">{{popup.errMessage}}</p>
                </div>
                <div class="txt-wrapper" v-if="popup.lastMessage">
                    <h5>정말 환불 신청을 하시겠습니까?</h5>
                    <p>· 취소상품 : 주니어과정 2주회 25분 12개월 수강권</p>
                </div>
                <div class="btn-wrapper">
                    <button class="cancle" @click="popupClose" v-if="popup.lastMessage">취소</button>
                    <button class="confirm"
                        @click="popupClose('mb','ok'); popup.lastMessage? $router.push({ path: '/mypage/payment/detail', query: {'refund': true} }):'';"
                        :style="{marginLeft: (popup.err? 'auto' : '0')}">확인</button>
                </div>
            </div>
        </section>
    </div>
    <div v-else class="pc-last-message component">
        <div class="txt-wrapper">
            <h5>정말 환불 신청을 하시겠습니까?</h5>
            <p>· 취소상품 : 주니어과정 2주회 25분 12개월 수강권</p>
        </div>
        <div class="btn-wrapper">
            <button class="cancle" @click="popupClose('pc')">취소</button>
            <button class="confirm"  @click="popupClose('pc', 'ok')">확인</button>
        </div>
    </div>
</template>

<style lang="scss" scoped>

.refund.pc{
    padding: 0;
    background-color: $white;
    section{
        padding: 30px 0 0;
        max-height: 500px;
        overflow-y: scroll;
        &.pagination, &.next-btn{
            padding: 0;
            button{
                margin-top: 20px;
            }
        }
        .next-btn-pc{
            button{
                background-color: $pink;
                color: $white;
                margin-left: auto;
                display: block;
                padding: 10px 20px;
                margin-top: 20px;
                border-radius: 5px;
                font-size: 16px;
            }
        }
    }
}
.pc-last-message{
    width: 100%;
    .txt-wrapper{
        padding: 0;
        h5{
            font-size: 18px;
            margin-bottom: 20px;
        }
        p{
            font-size: 14px;
            margin-bottom: 70px;
        }
        p.font5{
            text-align: center;
            margin: 20px 0;
            font-size: 16px;
        }
    }
    .btn-wrapper{
        width: 100%;
        @include flex(space-between);
        border-top: 1px solid #e7e7e7;
        padding: 0;
        position: absolute;
        bottom:0;
        left: 0;
        button{
            padding: 10px 20px;
            font-size: 16px;
            &.confirm{
                color: $pink;
            }
        }
    }
}
section{
    padding: 0 20px 30px;
    h4{
        font-size: 20px;
    }
    b{
        font-size: 16px;
        font-family: "SCDream5";
        word-break: keep-all;
        display: inline-block;
        margin-bottom: 10px;
    }
    p{
        font-size: 16px;
    }
    >div{
        margin-top: 50px;
    }
}
.pagination{
    ul{
        @include flex();
        li{
            width: 25%;
            border-bottom: 2px solid #e7e7e7;
            text-align: center;
            padding: 10px 0 3px;
            &.act{
                border-color: $pink;
                color: $pink;
            }
        }
    }
}
.next-btn{
    button{
        width: 100%;
        height: 50px;
        background-color: $black;
        color: $white;
        border-radius: 10px;
        font-size: 18px;
        margin-top: 30px;
    }
}
.page1{
    table{
        border-collapse : collapse;
        border: 1px solid #5c5c5c;
        th, td {
            border: 1px solid #5c5c5c;
            font-family: "SCDream3";
            font-size: 14px;
            line-height: 18px;
            min-width: 56px;
            padding: 8px 5px;
            word-break: keep-all;
        }
    }
}
.page2{
    ul{
        width:100%;
        li{
            width:100%;
            text-align: center;
            border: 1px solid #5c5c5c;
            border-radius: 15px;
            padding: 10px 0;
            margin-bottom: 10px;
            &.act{
                border-color: $pink;
                color: $pink;
            }
        }
    }
    textarea{
        width: 100%;
        margin-top: 5px;
        padding: 10px;
        border-radius: 15px;
        resize: none;
    }
}
.page3{
    ul{
        li{
            border-bottom: 1px solid #e7e7e7;
            line-height: 40px;
            @include flex(space-between);
            label{
                font-family: "SCDream3";
                font-size: 14px;
            }
            input[type=checkbox]{
                display: none;
            }
            input[type=checkbox]+label.checkbox{
                width: 20px;
                min-width: 20px;
                height: 20px;
                margin-right: 5px;
                border: 2px solid #c9c9c9;
            }
            input[type=checkbox]:checked+label.checkbox{
                background: url('@/assets/img/login/checkbox.png') no-repeat center;
                background-size: cover;
                border: none;
            }
            
        }
    }
}
.page4{
    ul{
        li{
            font-family: "SCDream3";
            position: relative;
            padding-left: 10px;
            margin-bottom: 5px;
            &::before{
                content:'·';
                position: absolute;
                left: 0;
                top: 0;
            }
        }
    }
}
.popup-wrapper{
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    background-color:  $popupBg;
    z-index: 99999;
    .popup{
        position: absolute;
        background-color:  $white;
        margin: 0 auto;
        top: 50%; 
        left: 50%;
        transform: translate(-50%, -50%);  
        width: 90%;
        max-width: 430px;
        border-radius: 15px;
        .txt-wrapper{
            padding: 20px 25px;
            h5{
                font-size: 18px;
                margin-bottom: 20px;
            }
            p{
                font-size: 14px;
                margin-bottom: 30px;
            }
            p.font5{
                text-align: center;
                margin: 20px 0;
                font-size: 16px;
            }
        }
        .btn-wrapper{
            width: 100%;
            @include flex(space-between);
            border-top: 1px solid #e7e7e7;
            button{
                padding: 10px 20px;
                font-size: 16px;
                &.confirm{
                    color: $pink;
                }
            }
        }
    }
}
</style>

<script>
export default {
    name: 'PaymentRefund',
    layout: 'mypage',
    data(){
        return{
            page: 1,
            popup:{
                open: false,
                err: false,
                errMessage: null,
                lastMessage: false,
                pcLastMessage: false
            },
            question:{
                speaking:{
                    q1: '수업을 원하는 시간에 할 수 없어요.',
                    q2: '강사의 가르치는 능력이 부족해요.',
                    q3: '피드백, 수업 진행 방식이 나와 맞지 않아요.',
                    q4: '음질이 좋지 않아요.',
                    q5: '선택한 수업시간이 수업하기에 짧아요.',
                },
                contents:{
                    q1: '콘텐츠의 수가 적고 종류가 다양하지 않아요.',
                    q2: '콘텐츠의 내용이 도움이 안 되거나 재미있지 않아요.'
                },
                service:{
                    q1: '서비스 질문 1',
                    q2: '서비스 질문 2 '
                },
            },
            reason: {btn: null, text: null}
        }
    },
    setup() {
    },
    created(){
    },
    mounted(){
    },
    watch:{
    },
    filters:{
    },
    methods:{
        next(v){
            // if(this.reason.btn==null ) return this.popupOpen('err', '환불하시는 이유를 선택해주세요.')
            // if(this.reason.btn=='기타' && this.reason.text==null ) return this.popupOpen('err', '환불하시는 이유를 입력해주세요.')
            if(this.page==4) {
                if(v==true) return this.popupOpen('last');
                else return this.popupOpen('pcLastMessage');
            }
            this.page++
        },
        popupOpen(v, msg){
            this.popup.open = true;
            if(v=='err') {this.popup.err = true; this.popup.errMessage = msg;}
            if(v=='last') {this.popup.lastMessage = true;}
            if(v=='pcLastMessage') {this.popup.pcLastMessage = true;}
            
        },
        popupClose(v, s){
            if(v == 'pc') {
               return this.$emit("refund", 'close');
            }

            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
            
            if(s == 'ok') this.$router.push('/mypage');
        }
    }
}

</script>
