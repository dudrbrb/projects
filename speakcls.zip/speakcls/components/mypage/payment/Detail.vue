<template>
    <div class="component payment-detail" :class="{pc: !$device.isMobileOrTablet }">
        <section class="card-wrapper">
            <div class="card">
                <b>2022.01.01</b>
                <p>주니어과정 2주회 25분 12개월 수강권</p>
                <span>결제완료</span>
            </div>
        </section>
        <section class="detail">
            <div class="detail-title">
                <h4>결제내역</h4>
                <span>영수증</span>
            </div>
            <ul class="detail-content">
                <li><span>결제일자</span><p>2022.01.01</p></li>
                <li><span>결제수단</span><p>신용/체크카드 (KB국민카드)</p></li>
                <li><span>주문금액</span><p>190,000원</p></li>
                <li><span>총 할인 금액<br>
                        - 이벤트 할인(-10%)
                    </span>
                    <p>-19,000원<br>
                        <span>19,000원</span>
                    </p>
                </li>
            </ul>
            <div class="price">
                <h5 class="font4">최종 결제 금액</h5>
                <span class="font4">171,000 원</span>
            </div>
            <div class="info">
                <p>자동결제를 취소 하려면 <span @click="popup.open=true; popup.autopay=true">여기</span>를 통해 신청해주세요.</p>
                <p>수강권 환불을 하려면 <span @click="popup.open=true; popup.refund=true">여기</span>를 통해 신청해주세요.</p>
            </div>
        </section>
        <section class="popup-wrapper" v-if="popup.open" :class="{pc: !$device.isMobileOrTablet }">
            <div class="bottom" v-if="popup.lastMessage == false" :class="{show: popup.autopay || popup.refund }">
                <button class="x" @click="popupClose"></button>
                <div v-if="popup.autopay">
                    <h4>자동결제 취소 안내</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea beatae tempora quam nisi sequi</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea beatae tempora quam nisi sequi</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea beatae tempora quam nisi sequi</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea beatae tempora quam nisi sequi</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea beatae tempora quam nisi sequi</p>
                </div>
                <div v-if="popup.refund">
                    <h4>환불 신청 안내</h4>
                    <p>환불 절차는 1. 환불 규정 확인 > 2. 환불 사유 및 신청서 작성 > 3.신청하기 눌러서 신청 완료 > 4.학습 컨설팅센터와의 전화상담으로 진행됩니다.</p>
                    <p>환불 신청 시 <span>모든 수업은 중지</span>됩니다. <br>(예약된 쿠폰 수업 및 레벨테스트 포함)</p>
                    <p>정기 수강 중인 경우 환불 신청에 따라 다음으로 예정된 결제건도 중지됩니다.</p>
                    <p>환불 취소 신청 시 남은 수업 횟수에 따라 수강기간이 조정될 수 있습니다.</p>
                    <p>환불 처리된 수강권은 다시 복원되지 않으니 신중이 결정해주세요</p>
                    <span>상기 안내 내용을 확인하고 환불 신청을 진행해주세요.</span>
                </div>
                <button class="ok pink" @click="confirmBtn($device.isMobileOrTablet )">확인</button>
            </div>
            <div class="center" v-if="popup.lastMessage">
                <div class="txt-wrapper">
                    <h5>정말 자동결제를 취소하시겠습니까?</h5>
                    <p>· 취소상품 : 주니어과정 2주회 25분 12개월 수강권</p>
                </div>
                <div class="btn-wrapper">
                    <button class="cancle" @click="popupClose">취소</button>
                    <button class="confirm" @click="popupClose">확인</button>
                </div>
            </div>
            <div class="center refund-popup" v-if="popup.refundInfo">
                <button class="x" @click="popupClose"></button>
                <refundInfo @refund="popupClose"></refundInfo>
            </div>
           
        </section>
        <section class="refund-message" v-if="refund" >
            <b class="font4">환불 신청이 완료되었습니다.</b>
        </section>
    </div>
</template>

<style lang="scss" scoped>
    .payment-detail.pc{
        background-color: #faf9fc;
        border-radius: 20px;
        padding: 10px 20px 30px;
        .card-wrapper{
            padding: 10px 0 20px;
            .card{
                margin-top: 0;
                border-radius: 20px;
                @include flex(flex-start);
                flex-wrap: wrap;
                b{
                    width: 100%;
                    font-size: 18px;
                }
                span{
                    margin-top: 0;
                    margin-left: auto;
                }
            }
        }
        .detail{
            .detail-title{
                h4{
                    font-size: 20px;
                }
            }
        }
        .price{
            h5{
                font-size: 20px;
            }
        }
        .info{
            p{
                span{
                    cursor: pointer;
                }
            }
        }
    }
    section{
        &.card-wrapper{
            padding: 10px 20px 30px;
            .card{
                width: 100%;
                border-radius:0 20px 20px 20px;
                padding: 20px 15px;
                margin-top: 10px;
                background-color: #fff5f9;
                b{
                    font-size: 20px;
                    margin-bottom: 5px;
                    display: block;
                }
                span{
                    color: $pink;
                    margin-top: 15px;
                    font-weight: 600;
                    display: block;
                }
            }

        }
        &.detail{
            .detail-title{
                @include flex(space-between);
                padding: 15px 0;
                border-bottom: 2px solid #333;
                h4{
                    font-size: 24px;
                }
                span{
                    color: $grayOnGray;
                    text-decoration: underline;
                    text-underline-position: under;
                }
            }
            .detail-content{
                padding: 20px 0;
                li{
                    @include flex(space-between);
                    &+li{
                        margin-top: 10px;
                    }
                    p{
                        text-align: right;
                        line-height: 26px;
                    }
                    span{
                        line-height: 26px;
                        color:#5b5b5b;
                    }
                }
            }
            .price{
                @include flex(space-between);
                border-top: 2px solid #e7e7e7;
                border-bottom: 2px solid #e7e7e7;
                padding: 20px 0;
                h5{
                    font-size: 20px;
                }
                span{
                    font-size: 20px;
                    color: $pink;
                }
            }
            .info{
                margin-top: 10px;
                p{
                    font-size: 14px;
                    line-height: 26px;
                    color: #5b5b5b;
                    span{
                        font-size: 1em;
                        color: #5b5b5b;
                        text-decoration: underline;
                        text-underline-position: under;
                    }
                }
            }
        }
        &.popup-wrapper{
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color:  $popupBg;
            z-index: 99999;
            >div{
                position: absolute;
                background-color:  $white;
                &.center{
                    margin: 0 auto;
                    top: 50%; 
                    left: 50%;
                    transform: translate(-50%, -50%);  
                    width: 90%;
                    max-width: 430px;
                    border-radius: 15px;
                    .txt-wrapper{
                        padding: 20px 25px;
                        h5{
                            font-size: 18px;
                            margin-bottom: 20px;
                        }
                        p{
                            font-size: 14px;
                            margin-bottom: 30px;
                        }
                    }
                    .btn-wrapper{
                        width: 100%;
                        @include flex(space-between);
                        border-top: 1px solid #e7e7e7;
                        button{
                            padding: 10px 20px;
                            font-size: 16px;
                            &.confirm{
                                color: $pink;
                            }
                        }
                    }
                }
                &.bottom{
                    width: 100%;
                    bottom: 0;
                    left: 0;
                    padding: 40px 20px 100px;
                    border-radius: 20px 20px 0 0;
                    transform: translateY(100%);
                    transition: all 0.4s;
                    &.show{
                        animation: show 0.4s 0.2s forwards;
                    }
                    @keyframes show {
                        0%{
                            transform: translateY(100%);
                        }
                        100%{
                            transform: translateY(0%);
                        }

                    }
                    h4{
                        font-size: 20px;
                        margin-bottom: 20px;
                    }
                    p{
                        position: relative;
                        margin-bottom: 15px;
                        padding-left: 10px;
                        >span{
                            color: red;
                            font-size: 1em;
                        }
                        &::before{
                            content: '·';
                            position: absolute;
                            left: 0;
                        }
                    }
                    span{
                        color: #5b5b5b;
                        font-size: 14px;
                    }
                    button.ok{
                        width: 100%;
                        height: 60px;
                        background-color: $pink;
                        color: $white;
                        position: absolute;
                        bottom: 0;
                        left: 0;
                        font-size: 18px;
                    }
                    button.x{
                        width: 50px;
                        height: 50px;
                        position: absolute;
                        right: 0;
                        top:0;
                        background: url('@/assets/img/close.png') no-repeat center;
                    }
                }
            }
            &.pc{
                border-radius: 0px;
                >div{
                    .txt-wrapper{
                        h4{
                            font-family: "SCDream5";
                            font-size: 20px;
                        }
                        p{
                            font-size: 16px;
                        }
                    }

                    &.bottom{
                        width: 400px;
                        bottom: auto;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        animation: none;
                        border-radius: 20px;
                        overflow: hidden;
                        button.x{
                            right: 5px;
                            top: 5px;
                        }
                    }
                    &.center{
                        width: 400px;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        &.refund-popup{
                            border-radius: 20px;
                            padding: 30px 20px;
                            height: 597px;
                              button.x{
                                width: 50px;
                                height: 50px;
                                position: absolute;
                                right: 5px;
                                top: 5px;
                                background: url('@/assets/img/close.png') no-repeat center;
                                background-size: 20px;
                            }
                        }
                    }
                }
            }

        }
        &.refund-message{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 80px;
            background-color:  $popupBg;
            padding: 0;
            z-index: 8;
            transform: translateY(0);

            animation: showRefund 0.4s 2s forwards;
            
            @keyframes showRefund {
                0%{
                    transform: translateY(0);
                }
                100%{
                    transform: translateY(-100px);
                }

            }
                
            b{
                color: $white;
                text-align: center;
                width: 100%;
                margin-top: 30px;
                display: inline-block;
            }
        }
    }

</style>

<script>
import refundInfo from "@/components/mypage/payment/Refund.vue";

export default {
    name: 'PaymentDetail',
    layout: 'mypage',
    components:{refundInfo},
    data(){
        return{
            refund: false,
            popup:{
                open:false,
                info:false,
                autopay: false,
                refund: false,
                refundInfo:false,
                lastMessage: false,
            }
        }
    },
    created(){
    },
    mounted(){
        this.getParams();
    },
    watch:{
    },
    filters:{
    },
    methods:{
        popupClose(){
            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
        },
        getParams(){
            if(this.$route.query) this.refund = this.$route.query.refund;
        },
        confirmBtn(mobile){
            if(this.popup.refund){
                if(this.$device.isMobileOrTablet ){
                    this.$router.push({ path: '/mypage/payment/refund' })
                }else{
                    this.popup.refund = false; 
                    this.popup.refundInfo = true;
                }
            }
            if( this.popup.autopay){
                this.popup.lastMessage=true 
            }
            else{
            }
        }
    },
}

</script>
