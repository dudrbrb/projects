<template>
<div class="component">
    <section class="card-wrapper" :class="{'pc':!$device.isMobileOrTablet }">
        <div class="card" :class="classData.status" >
            <div class="card-title">
                <h4>{{classData.title}}</h4>
                <span class="status font3" v-if="$device.isMobileOrTablet">{{classData.status | status}}</span>
            </div>
            <div class="card-content">
                <table>
                    <tbody>
                        <tr>
                            <td>수업타입</td>
                            <td>25분 수업</td>
                        </tr>
                        <tr>
                            <td>수업일</td>
                            <td>화금 (주 2회)</td>
                        </tr>
                        <tr>
                            <td>수업시간</td>
                            <td>19:30 ~ 19:55</td>
                        </tr>
                        <tr>
                            <td>수강기간</td>
                            <td>12개월 (총 48주 수업)<br>{{classData.dateStart}} ~ {{classData.dateFin}} </td>
                        </tr>
                    </tbody>
                </table>
            </div>
           
        </div>
        <div class="refund-message" v-if="classData.status=='refund'">
            <p>환불 신청이 접수되었습니다.</p>
            <span>취소하기</span>
        </div>
    </section>
     <section class="notice" v-if="$device.isMobileOrTablet ">
        <h3>상세정보</h3>
        <ul>
            <li><nuxt-link :to="'/mypage/class/attendance'">출결내역</nuxt-link></li>
            <li><nuxt-link :to="'/mypage/payment/detail'">결제내역</nuxt-link></li>
            <li><nuxt-link :to="'/mypage/payment/manage'">결제관리</nuxt-link></li>
            <li v-if="classData.status=='on'" @click="openPopup('hold')">장기홀드</li>
            <li v-if="classData.status=='on'" @click="openPopup('time')">시간변경</li>
        </ul>
    </section>
    <section class="popup-wrapper" :class="{pc: !$device.isMobileOrTablet}" v-if="popup.open || detailData.hold == true || detailData.time == true">
        <div class="bottom" v-if="popup.last == false" 
        :class="{show: popup.open || detailData.hold == true || detailData.time == true}">
            <button class="x" @click="popupClose"></button>
            <div v-if="popup.hold || detailData.hold">
                <h4>장기 홀드 안내</h4>
                <p>환불 절차는 1. 환불 규정 확인 > 2. 환불 사유 및 신청서 작성 > 3.신청하기 눌러서 신청 완료 > 4.학습 컨설팅센터와의 전화상담으로 진행됩니다.</p>
                <p>환불 신청 시 <span>모든 수업은 중지</span>됩니다. <br>(예약된 쿠폰 수업 및 레벨테스트 포함)</p>
                <p>정기 수강 중인 경우 환불 신청에 따라 다음으로 예정된 결제건도 중지됩니다.</p>
                <p>환불 취소 신청 시 남은 수업 횟수에 따라 수강기간이 조정될 수 있습니다.</p>
                <p>환불 처리된 수강권은 다시 복원되지 않으니 신중이 결정해주세요</p>
                <span>상기 안내 내용을 확인하고 환불 신청을 진행해주세요.</span>
            </div>
            <div v-if="popup.time || detailData.time" >
                <h4>수업 시간 변경</h4>
                <p class="none">수업변경은 1일 1회 가능합니다.<br>
                    선택한 수업시간은 다음날부터 적용됩니다.</p>
                <div class="select-time">
                    <div class="time-title">
                        <p class="font4 none">현재 선택 가능한 시간</p>
                        <button class="arrow"></button>
                    </div>
                    <ul>
                        <li v-for="(time, idx) in timeList" :key="`time${idx}`" :class="{fin: time.full, act: timeSelect==time.time}" @click="time.full ? '' : timeSelect = time.time" class="font3">{{time.time}}</li>
                    </ul>
                </div>
            </div>
            <button class="ok pink" @click="popup.last=true" v-if="popup.hold || detailData.hold == true">확인</button>
            <button class="ok pink" @click="timeSelect==null ? '' : popup.last=true" v-if="popup.time || detailData.time == true">19:30에서 {{timeSelect?timeSelect+" 으로":''}} 변경하기</button>
        </div>
        <div class="center" v-if="popup.last">
            <div class="txt-wrapper" v-if="popup.hold || detailData.hold == true">
                <h5>정말 수강중인 수업을 장기 홀드 하시겠습니까?</h5>
                <p>선택상품 : 주니어과정 2주회 25분 12개월 수강권</p>
            </div>
            <div class="txt-wrapper" v-if="popup.time || detailData.time == true">
                <h5>수업시간을 변경하시겠습니까?</h5>
                <p class="pink">내일부터 수업시간이 변경됩니다.</p>
                <p>오늘까지는 변경전 시간이 적용되니, 오늘 수업이 있다면 잊지 말고 참여하세요.</p>
            </div>
            <div class="txt-wrapper" v-if="popup.timeErr">
                <h5>알려드립니다.</h5>
                <p>이미 시간 변경을 완료했습니다. 시간 변경은 1일 1회 가능합니다. </p>
            </div>
            <div class="txt-wrapper" v-if="popup.retake || detailData.retake == true">
                <h5>동일한 수강권으로 구매하시겠습니까?</h5>
                <p>동일한 수강권 : 주니어과정 2주회 25분 12개월 수강권 </p>
            </div>
            <div class="btn-wrapper">
                <button class="cancle" @click="popupClose('retake')" v-if="!popup.timeErr">취소</button>
                <button class="confirm" @click="popupClose('time');" v-if="popup.time || detailData.time == true">네, 변경할래요</button>
                <button class="confirm" @click="popupClose('retake')" v-if="popup.retake || detailData.retake == true">네, 예약할게요</button>
                <button class="confirm" @click="popupClose" v-if="popup.hold || detailData.hold == true || popup.timeErr" :style="{marginLeft: (popup.timeErr? 'auto' : '0')}">확인</button>
            </div>
        </div>
    </section>
</div>
</template>

<style lang="scss" scoped>
section{
    &.card-wrapper{
        padding: 10px 20px 30px;
        &.pc{
            padding: 0;
            .card{
                padding: 15px 20px;
                border-radius: 25px;
                margin-top: 0;
                .card-title{
                    @include flex(flex-start);
                    h4{
                        letter-spacing: -1px;
                        font-size: 18px;
                    }
                }
                .card-content{
                    table{
                        tr{
                            td{
                                padding: 8px 0;
                            }
                        }
                    }
                }
            }
        }
        .card{
            width: 100%;
            border-radius:0 20px 20px 20px;
            padding: 10px 15px;
            margin-top: 10px;
            .card-title{
                font-size: 16px;
                border-bottom: 2px solid #fefefe;
                padding-bottom: 10px;
                margin-bottom: 5px;
                @include flex();
                h4{
                    letter-spacing: -1.5px;
                }
            }
            .status{
                border-radius: 20px;
                padding: 1px 8px;
                font-size: 14px;
                margin-left: auto;
                display: inline-block;
                text-align: center;
            }
            .card-content{
                table{
                    tr{
                        vertical-align: top;
                        td{
                            font-size: 15px;
                            padding: 4px 0;
                        }
                        td:first-child{
                            width: 90px;
                            font-family: "SCDream3";
                        }
                        td:last-child{
                            font-family: "SCDream4";    
                        }
                    }
                }
            }
            &.wait{
                background: #f6f2ff;
                .status{
                    background: #8059e5;
                    color: $white;
                }
            }
            &.on{
                background: #fff5f9;
                .status{
                    background: #e90b73;
                    color: $white;
                }
            }
            &.fin{
                background: #f5f5f5;
                .status{
                    background: #e5e5e5;
                    color: $black;
                }
            }
            &.refund{
                background: #f5fff9;
                .status{
                    background: #aaf4e0;
                    color: $black;
                }
            }
        }
    }
    .refund-message{
        border: 1px solid rgb(71, 71, 71);
        border-radius: 20px;
        padding: 25px 20px;
        @include flex(space-between);
        font-size: 16px;
        margin-top: 25px;
        p{
            color : red;
        }
        span{
            text-decoration: underline;
            text-underline-position: under;
        }
    }
        &.popup-wrapper{
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color:  $popupBg;
        z-index: 99999;
        >div{
            position: absolute;
            background-color:  $white;
            &.center{
                margin: 0 auto;
                top: 50%; 
                left: 50%;
                transform: translate(-50%, -50%);  
                width: 90%;
                max-width: 430px;
                border-radius: 15px;
                .txt-wrapper{
                    padding: 20px 25px;
                    h5{
                        font-size: 18px;
                        margin-bottom: 20px;
                    }
                    p{
                        font-size: 14px;
                        margin-bottom: 30px;
                        padding-left: 10px;
                        position: relative;
                        &+p{
                            margin-top: -20px;
                        }
                        &::before{
                            content: '·';
                            position: absolute;
                            left: 0;
                        }
                    }
                    .pink{
                        color: $pink;
                    }
                }
                .btn-wrapper{
                    width: 100%;
                    @include flex(space-between);
                    border-top: 1px solid #e7e7e7;
                    button{
                        padding: 10px 20px;
                        font-size: 16px;
                        &.confirm{
                            color: $pink;
                        }
                    }
                }
            }
            &.bottom{
                width: 100%;
                bottom: 0;
                left: 0;
                padding: 40px 20px 100px;
                border-radius: 20px 20px 0 0;
                transform: translateY(100%);
                transition: all 0.4s;
                &.show{
                    animation: show 0.4s 0.2s forwards;
                }
                @keyframes show {
                    0%{
                        transform: translateY(100%);
                    }
                    100%{
                        transform: translateY(0%);
                    }

                }
                h4{
                    font-size: 24px;
                    margin-bottom: 20px;
                }
                p{
                    position: relative;
                    margin-bottom: 15px;
                    padding-left: 10px;
                    >span{
                        color: red;
                        font-size: 1em;
                    }
                    &::before{
                        content: '·';
                        position: absolute;
                        left: 0;
                    }
                    &.none{
                        padding-left: 0;
                        &::before{
                            content:'';
                        }
                    }
                }
                span{
                    color: #5b5b5b;
                    font-size: 14px;
                }
                .select-time{
                    margin-top: 40px;
                    .time-title{
                        p{
                            font-size: 18px;
                        }
                        
                        .arrow{
                            display: none
                        }
                    }
                    ul{
                        @include flex(flex-start);
                        flex-wrap: wrap;
                        li{
                            border: 1px solid #ff8ec2;
                            padding: 5px 25px;
                            margin: 3px 5px;
                            border-radius: 5px;;
                            cursor: pointer;
                            &.fin{
                                border-color: #e7e7e7;
                                color: #e7e7e7;
                            }
                            &.act{
                                border-color: $pink;
                                color: $white;
                                background-color:$pink ;
                            }
                        }
                    }

                }
                button.ok{
                    width: 100%;
                    height: 60px;
                    background-color: $pink;
                    color: $white;
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    font-size: 18px;
                }
                button.x{
                    width: 50px;
                    height: 50px;
                    position: absolute;
                    right: 0;
                    top:0;
                    background: url('@/assets/img/close.png') no-repeat center;
                }
            }
        }
         &.pc{
            border-radius: 0px;
            >div{
                .txt-wrapper{
                    h4, h5{
                        font-family: "SCDream5";
                        font-size: 20px;
                    }
                    p{
                        font-size: 16px;
                    }
                }
                &.bottom{
                    width: 450px;
                    bottom: auto;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    animation: none;
                    border-radius: 20px;
                    overflow: hidden;
                    button.x{
                        right: 5px;
                        top: 5px;
                    }
                }
                &.center{
                    width: 450px;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    &.refund-popup{
                        border-radius: 20px;
                        padding: 30px 20px;
                            button.x{
                            width: 50px;
                            height: 50px;
                            position: absolute;
                            right: 5px;
                            top: 5px;
                            background: url('@/assets/img/close.png') no-repeat center;
                            background-size: 20px;
                        }
                    }
                }
            }
        }
        
    }

}

</style>

<script>
export default {
    name: 'ClassDetail',
    layout: 'mypage',
    props: ['classData', 'detailData'],
    data(){
        return{      
            popup: {
                open: false,
                hold: false,
                time:false,
                retake: false,
                last: false
            },
            timeList:[
                {time: '14:00', full:false},
                {time: '14:30', full:false},
                {time: '15:00', full:true},
                {time: '15:30', full:false},
                {time: '16:00', full:false},
                {time: '16:30', full:false},
                {time: '17:00', full:true},
                {time: '17:30', full:false},
                {time: '18:00', full:true},
                {time: '18:30', full:true},
                {time: '19:00', full:false},
                {time: '19:30', full:false},
                {time: '20:00', full:false},
                {time: '20:30', full:true},
                {time: '21:00', full:false},
                {time: '21:30', full:false},
            ],
            timeSelect: null,
            timeChange: null
        }
    },
    created(){

    },
    mounted(){
        this.getParams();
    },
    watch:{
        '$route' (to, from) {
			this.getParams();
		}
    },
    filters:{
        status(v){
            if(v=='wait') return v='수강대기'
            if(v=='on') return v='수강중'
            if(v=='fin') return v='종강'
            if(v=='refund') return v='환불접수'
        }

    },
    methods:{
      
        openPopup(v){
            this.popup.open=true;
            if(v=='hold')  return this.popup.hold=true;
            if(v=='time') {
                if(this.timeChange==null){
                    return this.popup.time=true;
                } else{
                    this.popup.last=true;
                    this.popup.timeErr=true; 
                    return
                }
            }
            if(v=='retake'){
                this.popup.last=true;
                return this.popup.retake = true;
            }
        },
        popupClose(v){
            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
            this.$emit("popupData", 'close');

            if(v == 'time') return  this.timeChange = this.timeSelect;
            if(v == 'retake') {
                if(this.$device.isMobileOrTablet) {
                    this.$router.push({path:'/mypage/class/detail', query:{title: this.classData.title, status: this.classData.status,  dateStart: this.classData.dateStart, dateFin: this.classData.dateFin, refund:this.classData.refund}})
                    return
                } else{
                    this.$router.push({path: '/mypage/class/list' , query:{retake: false}});
                    return
                } 
            }
        },
        getParams(){
              if(this.$device.isMobileOrTablet) {
                this.classData = this.$route.query;
            }
            if(this.$route.query.retake == 'true'){
                setTimeout(() => {
                    this.openPopup('retake')
                    // this.$router.push({path: '/mypage/class/list' , query:{retake: true}});
                }, 800);
            }
        },


    }
}

</script>
