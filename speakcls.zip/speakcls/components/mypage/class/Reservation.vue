<template>
    <div class="component reservation"  :class="{pc: !$device.isMobileOrTablet}">
        <section v-if="!popup.pcOpen">
            <div class="my-ticket">
                <p>보유 수강권 <b>1</b>장</p>
            </div>
            <div class="info">
                <h4>원하는 시간을 <br>선택하고 수업하세요.</h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur numquam, delectus amet veritatis modi qui repellendus </p>
            </div>
        </section>
        <section class="select" :class="{pd: selectTime[1].length > 0}"  v-if="!popup.pcOpen">
            <div class="day-title"><p>오늘</p><hr></div>
            <div class="time-wrapper">
                <div class="time" v-for="(time, idx) in timeList.today" :key="`time${idx}`" 
                :class="{disable: time.full, act: selectTime[0]== time.time &&selectTime[1]=='today'}" 
                @click="time.full? '' : selectTime = [time.time, 'today']">{{time.time}}</div>
            </div>
            <div class="day-title"><p>내일</p><hr></div>
            <div class="time-wrapper">
                <div class="time" v-for="(time, idx) in timeList.tomorrow" :key="`time${idx}`" 
                :class="{disable: time.full, act: selectTime[0]== time.time &&selectTime[1]=='tomorrow'}"
                 @click="time.full? '' : selectTime = [time.time, 'tomorrow']">{{time.time}}</div>
            </div>

            <button class="more">더보기</button>
            <div class="checkTime" v-if="selectTime[1].length > 0">
                {{dateData[selectTime[1]].month}}.{{dateData[selectTime[1]].day}} {{dateData[selectTime[1]].week}} {{selectTime[0]}}
                <p>예약한 수업일정은 변경할 수 없습니다.</p>
            </div>
        </section>
        <button class="res"  v-if="selectTime[1].length > 0 && !popup.pcOpen" @click="openPopup ">수업 예약하기</button>
        <section class="popup-wrapper" v-if="popup.open">
            <div class="popup">
                <div class="txt-wrapper">
                    <h5>수업 예약을 하시겠습니까?</h5>
                    <p class="pink">· {{dateData[selectTime[1]].month}}.{{dateData[selectTime[1]].day}} {{dateData[selectTime[1]].week}} {{selectTime[0]}} </p>
                    <p>·  예약한 수업일정은 변경할 수 없습니다.</p>
                </div>
                <div class="btn-wrapper">
                    <button class="cancle" @click="popupClose">아니요</button>
                    <button class="confirm"  @click="popupClose">네, 예약할게요</button>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss" scoped>
.component.reservation{
    &.pc{
        section{
            .my-ticket{
                display: none;
            }
            .info{
                padding: 0 20px 30px;
                h4{
                    font-family: "SCDream5";
                }
            }
            &.select{
                height: 400px;
                overflow-y: scroll;
                &.pd{
                    padding-bottom: 140px;
                }
                .time-wrapper{
                    .time{
                        cursor: pointer;
                        padding: 6px 20px;
                        margin: 4px 8px;
                        font-size: 16px;

                    }
                }
            }
        }
        .popup-wrapper{
            .popup{
                width: 100%;
                max-width: 450px;
                .txt-wrapper{
                    h5{
                        font-size: 20px;
                        font-family: "SCDream5";
                    }
                    p{
                        font-size: 16px;
                        &:last-child{
                            margin-bottom: 15px;
                        }
                    }
                }
            }
        

        }
    }
    section{
        .my-ticket{
            width:100%;
            height: 50px;
            margin-top: 20px;
            border-bottom: 5px solid #f7f5fa;
            text-align: center;
            line-height: 50px;
            b{
                font-size: 22px;
                margin-left: 15px;
            }
        }
        .info{
            margin-top: 30px;
            h4{
                font-size: 20px;
                margin-bottom: 10px;
            }
        }
        &.select{
            .day-title{
                text-align: center;
                p{
                    width: auto;
                    background-color: $white;
                    z-index: 1;
                    display: inline-block;
                    padding: 0 10px;
                }
                hr{
                    margin-top: -11px;
                }
            }
            .time-wrapper{
                @include flex();
                flex-wrap: wrap;
                margin: 30px 0 ;
                .time{
                    border: 1px solid $pink;
                    padding: 6px 15px;
                    margin: 3px 4px;
                    font-size: 15px;
                    background-color: $white;
                    border-radius: 5px;
                    &.disable{
                        border: 1px solid #e8e8ef;
                        color: #e8e8ef;
                        text-decoration: line-through;
                    }
                    &.act{
                        background-color: $pink;
                        color:$white;
                    }
                }
            }
            .more{
                text-decoration: underline;
                text-underline-position: under;
                margin: 40px auto ;
                display: block;
                font-size: 18px;
            }
            .checkTime{
                border-top: 5px solid #f7f5fa;
                width: 100%;
                text-align: center;
                padding: 15px 0;
                font-size: 18px;
                position: fixed;
                bottom: 70px;
                left: 0;
                background-color: $white;
                p{
                    font-size: 16px;
                }
            }
        }
    }
    .res{
        position: fixed;
        bottom: 0;
        left:0;
        background-color: $pink;
        color: $white;
        width: 100%;
        heighT: 70px;
        font-size: 20px;
    }
    .popup-wrapper{
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color:  $popupBg;
        z-index: 99999;
        .popup{
            position: absolute;
            background-color:  $white;
            margin: 0 auto;
            top: 50%; 
            left: 50%;
            transform: translate(-50%, -50%);  
            width: 90%;
            max-width: 430px;
            border-radius: 15px;
            .txt-wrapper{
                padding: 20px 25px;
                h5{
                    font-size: 18px;
                    margin-bottom: 20px;
                }
                p{
                    font-size: 14px;
                    margin-bottom: 5px;
                    &.pink{
                        color: $pink;
                    }
                    &:last-child{
                        margin-bottom: 30px;
                    }
                }
                p.font5{
                    text-align: center;
                    margin: 20px 0;
                    font-size: 16px;
                }
            }
            .btn-wrapper{
                width: 100%;
                @include flex(space-between);
                border-top: 1px solid #e7e7e7;
                button{
                    padding: 10px 20px;
                    font-size: 16px;
                    &.confirm{
                        color: $pink;
                    }
                }
            }
        }
    }
}
</style>

<script>
export default {
    name: 'mypage',
    layout: 'mypage',
    data(){
        return{
            selectTime: ['',''],
            timeList:{
                today:[
                    {time: '14:00', full:false},
                    {time: '14:30', full:false},
                    {time: '15:00', full:true},
                    {time: '15:30', full:false},
                    {time: '16:00', full:false},
                    {time: '16:30', full:false},
                    {time: '17:00', full:true},
                    {time: '17:30', full:false},
                    {time: '18:00', full:true},
                    {time: '18:30', full:true},
                    {time: '19:00', full:true},
                    {time: '19:30', full:false},
                    {time: '20:00', full:false},
                    {time: '20:30', full:false},
                    {time: '21:00', full:false},
                    {time: '21:30', full:false},
                ],
                tomorrow:[
                    {time: '14:00', full:true},
                    {time: '14:30', full:true},
                    {time: '15:00', full:true},
                    {time: '15:30', full:false},
                    {time: '16:00', full:false},
                    {time: '16:30', full:false},
                    {time: '17:00', full:true},
                    {time: '17:30', full:false},
                    {time: '18:00', full:false},
                    {time: '18:30', full:true},
                    {time: '19:00', full:false},
                    {time: '19:30', full:false},
                    {time: '20:00', full:false},
                    {time: '20:30', full:true},
                    {time: '21:00', full:true},
                    {time: '21:30', full:false},
                ]
            },
            dateData:{
                today:{
                    month: null, 
                    day: null, 
                    week: null,
                    kor: '오늘'
                }, 
                tomorrow:{
                    month: null, 
                    day: null, 
                    week: null,
                    kor: '내일'
                }
            },
            popup:{
                open: false,
                pcOpen: false

            }
            
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.getDate()
    },
    watch:{
    },
    filters:{

    },
    methods:{
        getDate(){
            var today = new Date();
            var tomorrow = new Date(today.setDate(today.getDate() +1));
            var weekarr = ['일','월','화','수','목','금','토'];


            this.dateData.today.month = today.getMonth()+1;
            this.dateData.today.day = today.getDate()-1;
            this.dateData.today.week = weekarr[today.getDay()];

            this.dateData.tomorrow.month = tomorrow.getMonth()+1;
            this.dateData.tomorrow.day = tomorrow.getDate();
            this.dateData.tomorrow.week = weekarr[today.getDay()];
        },
        openPopup(){
            this.popup.open=true;
              if(this.$device.isMobileOrTablet !== true) {
                this.popup.pcOpen=true;
            }
        },
         popupClose(v){
            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
            if(this.$device.isMobileOrTablet !== true) {
                this.$emit("reservFin", 'close');
            }
        }
    }
}

</script>
