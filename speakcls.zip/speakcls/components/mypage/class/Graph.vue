<template>
<div class="component graph">
    <section class="graph-wrapper" :class="{'pc': !$device.isMobileOrTablet, 'main' : $route.path == '/mypage'}">
        <h5>총 학습량 <span class="font3">06.08 업데이트</span></h5>
        <div class="bar-wrapper" :class="{'main' : $route.path == '/mypage'}">
            <div v-for="(score, idx) in score" :key="`score${idx}`">
                <div class="score">{{score.progress}}<span>/100</span></div>
                <div class="bar-box">
                    <span class="font5">{{score.kor}}</span>
                    <div class="bar-bg">
                        <div class="bar" :class="score.color" :style="{width: score.progress+'%'}"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
</template>

<style lang="scss" scoped>
.graph.component{
    width: 100%;
}
section{
    h5{
        font-size: 20px;
        position: relative;
        span{
            position: absolute;
            font-size: 16px;
            color:#b4b4b4;
            right: 0;
        }
    }


   &.graph-wrapper{
       padding: 0 20px 50px;
       &.pc{
            padding: 0 0 50px;
            &.main{
                padding: 40px 0px 0;
                h5{
                    width: 85%;
                    font-size: 20px;
                    @include flex(space-between);
                    span{
                        color: #b9b9b9;
                        font-size: 0.7em;
                    }
                }
            }
            .bar-wrapper{
                    border: none;
                    background-color:#faf9fc ;
                    @include flex(space-between);
                    flex-wrap: wrap;
                    padding: 20px 30px;
                    >div{
                        width: 46%;
                        margin-bottom: 0px;
                        &:nth-child(1),
                        &:nth-child(2){
                            margin-bottom: 20px;
                        }
                        .bar-box{
                            .bar-bg{
                                background-color: #f3f1f8;
                            }
                        }
                    }
                    &.main{
                        width: 85%;
                        >div{
                            width: 100%;
                            margin-bottom: 10px;
                            .bar-box{
                                .bar-bg{
                                    min-height: 15px;
                                }
                            }
                        }
                    }
                }
        }
        .bar-wrapper{
            border: 2px solid $pink;
            border-radius: 10px;
            padding: 10px;
            margin-top: 16px;
            >div{
                margin-bottom: 10px;
            }
            .score{
                text-align: right;
                font-size: 14px;
                span{
                    color: #b4b4b4;
                }
            }
            .bar-box{
                @include flex(flex-start);
                span{
                    width: 70px;
                }
                .bar-bg{
                    width: 100%;
                    min-height: 18px;
                    background-color: #f7f7f7;
                    position: relative;
                    border-radius: 5px;
                    overflow: hidden;
                    .bar{
                        position: absolute;
                        border-radius: 7px;
                        height: 100%;
                        left: 0;
                        top: 0;
                        transform: scaleX(0);
                        transform-origin: left;
                        transition: all 0.4s;
                        &.pink{ background-color: $pink; }
                        &.green{ background-color: #acd598; }
                        &.mint{ background-color: #84ccc9; }
                        &.blue{ background-color: #88abda; }
                        &.purple{ background-color: #8f82bc; }
                         &.act{ transform: scaleX(1);  }
                    }
                }
                
            }
        }
    }
}

</style>

<script>
export default {
    name: 'Attendance',
    layout: 'mypage',
    props: [ 'containerHeight'],
    data(){
        return{
            score:{
                speaking: {kor:'말하기', progress: 80, color: 'green'},
                listeneing: {kor:'듣기', progress: 90, color: 'mint'},
                writing: {kor:'쓰기', progress: 80, color: 'blue'},
                reading: {kor:'읽기', progress: 70, color: 'purple'},
            }
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.addAct()
    },
    watch:{
    },
    filters:{
    },
    methods:{
        addAct(){
            var ele = this.$el.querySelectorAll('.graph-wrapper .bar');
            
            ele.forEach((e, idx) => {
                setTimeout(() => {
                    e.classList.add('act');
                }, 200*idx);
            });
        },
    },
}

</script>
