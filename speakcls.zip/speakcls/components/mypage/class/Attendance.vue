<template>
<div class="component">
    <section :class="{pc : !$device.isMobileOrTablet }" :style="{maxHeight : (containerHeight -130)+'px'}">
        <ul>
            <li v-for="(list, idx) in attData" :key="`list${idx}`">
                <div>
                    {{list.date}}({{list.day}}) {{list.time}}
                    <p>{{list.class}} <span v-if="list.trial" class="pink">체험수업</span></p>
                </div>
                <div :class="['value', {pink : (list.value=='결석'||list.value=='취소')}]">{{list.value}}</div>
            </li>
        </ul>
    </section>
</div>
</template>

<style lang="scss" scoped>
section{
    min-height: 100vh;
    height: auto;
    &.pc{
        min-height: 0;
        overflow-y: scroll;
        background-color: #faf9fc;
        border-radius: 20px;
        ul{
            li{
                font-size: 18px;
                padding: 20px;
            }
        }
    }
    ul{
        li{
            @include flex(space-between);
            padding: 20px 0;
            border-bottom: 1px solid #e7e7e7;
            font-size: 20px;
            
            p{
                display: block;
                color: $grayOnGray;
                font-size: 16px;
                span{
                    margin-left: 10px;
                }
            }
            .value{
                font-size: 16px;
            }
            .pink{
                color: $pink;
            }
        }
    }
}

</style>

<script>
export default {
    name: 'Attendance',
    layout: 'mypage',
    props: [ 'containerHeight'],
    data(){
        return{
            data:{},
            attData:[
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '결석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석',
                    trial: true
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '결석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '취소'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '결석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '취소'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '취소'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
                {
                    date: '2022.05.06',
                    day: '금',
                    time: '17:30',
                    class: '25분 수업',
                    value: '출석'
                },
            ]
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
    },
    watch:{
    },
    filters:{
    },
    methods:{
    },
}

</script>
