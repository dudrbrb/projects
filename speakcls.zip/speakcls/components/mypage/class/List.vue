<template>
<div class="component">

    <section>
        
        <ul v-if="$device.isMobileOrTablet ">
            <li v-for="(list, idx) in classList" :key="`class${idx}`">
                <nuxt-link :to="{path:'/mypage/class/detail', query:{title:list.title, status: list.status,  dateStart: list.dateStart, dateFin: list.dateFin, refund:list.refund }}">
                    <div class="status font3" :class="list.status">{{list.status|status}}</div>
                    <div class="info">
                        <p class="title font5">{{list.title}}</p>
                        <p class="date">
                            <span class="refund" v-if="list.status=='refund'">환불완료 <span>/ </span></span>
                            {{list.dateStart}} ~ {{list.dateFin}}
                        </p>
                    </div>
                </nuxt-link>
            </li>
        </ul>
        
        <div v-else class="pc">
            <ul>
                <li class="select-class" @click="selectList(classList[selectedList].id, classList[selectedList].title, classList[selectedList].status, classList[selectedList].dateStart, classList[selectedList].dateFin, classList[selectedList].refund )"> 
                    <div class="status font3" :class="classList[selectedList].status">{{classList[selectedList].status|status}}</div>
                    <div class="info">
                        <p class="title font5">{{classList[selectedList].title}}</p>
                        <p class="date">
                            <span class="refund" v-if="classList[selectedList].status=='refund'">환불완료 <span>/ </span></span>
                            {{classList[selectedList].dateStart}} ~ {{classList[selectedList].dateFin}}
                        </p>
                    </div>
                    <button class="font4" @click="openList = !openList">+</button>
                </li>
            </ul>
            <ul class="list" :class="{open: openList}">
                <li v-for="(list, idx) in classList" :key="`class${idx}`" 
                    @click="selectList(list.id, list.title, list.status, list.dateStart, list.dateFin, list.refund )"
                    :class="[list.status, {selected: selectedList==idx}]">
                
                    <div class="status font3" :class="list.status">{{list.status|status}}</div>
                    <div class="info">
                        <p class="title font5">{{list.title}}</p>
                        <p class="date">
                            <span class="refund" v-if="list.status=='refund'">환불완료 <span>/ </span></span>
                            {{list.dateStart}} ~ {{list.dateFin}}
                        </p>
                    </div>
                </li>
            </ul>
        </div>

    </section>
</div>
</template>

<style lang="scss" scoped>
section{
    padding: 0;
    ul{
        min-height: 100vh;
        height: auto;
        // max-width: 440px;
        li{
            border-bottom: 1px solid #e7e7e7;
            a{
                padding: 25px 0;
                @include flex(flex-start);
            }
            .status{
                width: 70px;
                height: 70px;
                border-radius: 50%;
                font-size: 14px;
                @include flex();
                margin-right: 10px;
                &.wait{
                    color: $white;
                    background-color: #8059e5;
                }
                &.on{
                    color: $white;
                    background-color: #e90b73;
                }
                &.fin, &.refund{
                    background-color: #e5e5e5;
                }
            }
            p{
                &.date{
                    font-size: 15px;
                }
                span.refund{
                    color:red;
                }

            }
        }
    }
    .pc{
        ul{
            @include flex(flex-start,flex-start,column);
            margin-bottom: 20px;
            min-height: 0;
            &.list{
                border-radius: 20px;
                overflow: hidden;
                max-height: 0;
                &.open{
                    max-height: 10000px;
                }
                
            }
            li{
                padding: 25px 20px;
                width: 100%;
                @include flex(flex-start);
                cursor: pointer;
                background-color: #faf9fc;
                position: relative;
               
                &.selected{
                    display: none;
                    
                }
                &.select-class{
                    border-radius: 20px;
                    border: 2px solid $pink;
                    position: relative;
                    button{
                        position: absolute;
                        right: 0;
                        bottom: -13px;
                        font-size: 40px;
                        padding: 10px;
                    }
                }
            }
        }
    }
}

</style>

<script>
export default {
    name: 'ClassList',
    layout: 'mypage',
    data(){
        return{
            selectedList: 0,
            openList:false,
            classList:[
                {status: 'on',
                title: '주니어과정 주2회 25분 12개월 수강권',
                dateStart: '2023.01.11',
                dateFin: '2024.01.17', id: 0},
                {status: 'wait',
                title: '주니어과정 주2회 25분 12개월 수강권',
                dateStart: '2023.01.11',
                dateFin: '2024.01.17', id: 1},
                {status: 'fin',
                title: '주니어과정 주3회 25분1개월 수강권',
                dateStart: '2023.01.11',
                dateFin: '2024.01.17', id: 2},
                {status: 'refund',
                title: '주니어과정 주3회 25분 1개월 수강권',
                dateStart: '2023.01.11',
                dateFin: '2024.01.17', id: 3},
            ],
            refund: false
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.getParams();
        if(!this.$device.isMobileOrTablet){
            this.openDetailOnPc()
        }
        
    },
    watch:{
        '$route' (to, from) {
			this.getParams();
		}
    },
    filters:{
        status(v){
            if(v=='wait') return v='수강대기'
            if(v=='on') return v='수강중'
            if(v=='fin' || v=='refund') return v='종강'
        }

    },
    methods:{
        getParams(){
            if(this.$route.query.retake == 'true') {
                if(this.$device.isMobileOrTablet) {
                    this.classList.forEach(e => {
                       if(e.status == 'on') this.$router.push({path:'/mypage/class/detail', query:{title:e.title, status: e.status,  dateStart: e.dateStart, dateFin: e.dateFin, refund:e.refund ,retake:true }})
                    });
                } else{
                    this.classList.forEach(e => {
                        if(e.status == 'on') this.selectList(e.id, e.title, e.status, e.dateStart,e.dateFin, e.refund)
                    })
                }
            }
        },
        selectList(idx, title, status, dateStart,dateFin, refund){
            this.selectedList = idx;
            this.$emit("selectList",{'title': title, 'status': status,  'dateStart': dateStart, 'dateFin': dateFin, 'refund': refund})
        },
        openDetailOnPc(){
            this.classList.forEach(e => {
                if(e.status == 'on') this.selectList(e.id, e.title, e.status, e.dateStart,e.dateFin, e.refund)
            })
        }
    }
}

</script>
