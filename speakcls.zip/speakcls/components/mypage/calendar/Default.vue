<template>
<div class="component" :class="{schedule :  $route.path == '/mypage/schedule'}">
  <section v-if="!$device.isMobileOrTablet" class="calendar" :class="{'main' : $route.path == '/mypage'}">
        <div class="calendar-wrapper">
        <div class="cal-title">
            <h3 class="year-month">{{currentYear}}.{{(currentMonth+1) | zero}}</h3>
            <div class="nav">
                <button class="prev-month" @click="addMonth('prev')"></button>
                <button class="next-month" @click="addMonth('next')"></button>
            </div>
        </div>
        <div class="cal_wrap">
                <div class="days">
                <div class="day">Sun</div>
                <div class="day">Mon</div>
                <div class="day">Tue</div>
                <div class="day">Wed</div>
                <div class="day">Thu</div>
                <div class="day">Fri</div>
                <div class="day">Sat</div>
            </div>
            <div class="dates">
                <div class="day prev disable" v-for="(days, idx) in calendarDateBefore" :key="`day before${idx}`">
                    <span>{{days}}</span>
                </div>
                <div  v-for="(days, idx) in calendarDate" :key="`day${idx}`" :fulldate="`${days.year}-${days.month}-${days.day}`" :year="days.year" :month="days.month"
                    :class="['day', 'current', {'holiday': days.dayOfWeek=='토'||days.dayOfWeek=='일'},
                            {'today':(days.year ==  date.getFullYear()) && (days.month ==  date.getMonth()) &&(days.day ==  date.getDate())},
                            {'today-op': (days.year ==  date.getFullYear()) && (days.month ==  date.getMonth()) &&(days.day ==  date.getDate()) && (selectDay !== days.day)}, 
                            {'act': selectDay == days.day}
                        ]" 
                    @click="clickDay(days.year, days.month, days.day)">
                    <span :class=" [{'pd' : days.day >= 10}, {'pd2': days.day >=20}]">{{days.day}}</span>
                    <div class="point" v-if="days.point" :class="{purple : days.status == '정규 수업'}"></div>
                </div>
                <div class="day next disable" v-for="(days, idx) in calendarDateAfter" :key="`day after${idx}`">
                    <span>{{days}}</span>
                </div>
            </div>
            
        </div>
         <div class="fixed-btn" 
            v-if="cancle.have" >
            <button  @click="popup.open =true; popup.reservation = true;"
            class=" font4">
                수업 예약하기
            </button>
        </div>
    </div>
    
</section>
<section class="daily-list"  v-if="!$device.isMobileOrTablet && ($route.path == '/mypage/schedule')">
    <div class="list-wrapper">
        <div class="date-info">
            {{currentMonth | monthEng}}. {{currentYear}}.  {{currentDayOfWeek | week}}
        </div>
        <div v-for="(days, idx) in calendarDate" :key="`daily-list${idx}`" v-if="(idx >= (selectDay - 1)) && (idx < (selectDay+3))" 
        :class="['list',{'holiday': days.dayOfWeek=='토'||days.dayOfWeek=='일'}]">
            <div class="date">
                {{days.dayOfWeek}}요일
                <b>{{days.day}}</b>
                <div class="line"></div>
            </div>
            <div class="note-wrapper"> 
                <div class="note pink" v-if="days.year==today.getFullYear() && days.month==(today.getMonth()+1) && days.day == today.getDate()" >
                    <p class="title" >무료수업</p>
                    <p class="time">지금 무료수업을 신청하고 <br v-if=" $route.path == '/mypage/schedule'">스픽클을 경험해보세요.</p>
                    <nuxt-link :to="'/level-test'">
                        무료수업 신청하기
                    </nuxt-link>
                </div>
                <div v-for="(list, idx) in userData" :key="`daily detail ${idx}`" v-if="days.fulldate == list.date">
                    <div class="note add" v-if="list.cancle" >
                        <p class="title" >추천 시간</p>
                        <p class="time">지금 바로 예약할 수 있는<br>시간을 추천 해드려요.</p>
                        <button class="res-btn" @click="popup.open =true; popup.reservation = true;">
                            18:30<br>예약하기
                        </button>
                    </div>
                    <div  :class="['note', {'purple': list.title=='정규 수업','red': list.time=='all', 'disable': list.cancle }]" >
                        <p class="title" v-if="list.cancle">취소한 정규 수업</p>
                        <p class="title" v-else>{{list.title}}</p>
                        <p class="time">{{list.time|time}}</p>
                        <div class="note-menu" @click="list.question= !list.question" v-if="list.title=='정규 수업' && list.cancle !== true"><div></div><div></div><div></div></div>
                        <div class="cancle-btn font4" v-if="list.question" @click="popup.open =true; popup.message = true; list.question=false;">예약취소</div>
                    </div>
                    <div class="popup-wrapper" v-if="popup.open" :class="{pc: !$device.isMobile}">
                        <div class="popup cancle" v-if="popup.message">
                            <div class="txt-wrapper">
                                <h5>정말 수업을 취소 하시겠습니까?</h5>
                                <p>수업 취소를 한 이후에는 다시 되돌릴 수 없습니다.</p>
                                <p>수업 취소 후에는 스케쥴 창에서 추천 시간을 선택해 다른 시간으로 재예약이 가능합니다.</p>
                            </div>
                            <div class="btn-wrapper">
                                <button class="cancle" @click="popupClose">아니요</button>
                                <button class="confirm"
                                    @click="popupClose('ok', idx);">네, 취소할래요</button>
                            </div>
                        </div>
                        <div class="popup reservation" v-if="popup.reservation">
                            <Reservation @reservFin="popupClose('res')"></Reservation>
                        </div>
                    </div>
                </div>
                

            </div>
        </div>
    </div>
</section>
</div>
</template>

<style lang="scss" scoped>
.component.schedule{
    width: 55%;
}
section{
    &.calendar{
        width: 100%;
        height: 572px;
        margin-top: 30px;
        &.main{
            margin-top: 0;
            height: 350px;
            .calendar-wrapper{
                width: 85%;
                .cal_wrap {
                    .days{
                        .day{
                             &:first-child,
                            &:last-child{
                                background-color: $white;
                            }
                        }
                    }
                    .dates{
                        .day{
                            height: 40px;
                            &.holiday,
                            &.prev:first-child,
                            &.next:last-child{
                                background-color: $white;
                            }
                         
                        }
                    }
                }
            }
        }
        .calendar-wrapper {
            width: 100%;
            height: 100%;
            position: relative;
        
            .cal-title {
                @include flex(space-between);
                font-size: 28px;
                font-weight: 600;
                margin-bottom: 10px;
                .year-month {
                    text-align: left;
                    line-height: 1;
                }
                .nav {
                    display: flex;
                    button{
                        border: 1px solid rgb(243, 243, 243);
                        width: 25px;
                        height: 25px;
                        background: url('@/assets/img/arrow.png') no-repeat center;
                        background-size: 7px;
                        &.prev-month{
                            transform: rotate(180deg);
                        }
                    }
                }
            }
            .cal_wrap {
                padding-top: 20px;
                position: relative;
                margin: 0 auto;
                &::after {
                    top: 368px;
                }
                .days{
                    @include flex();
                    border-bottom: 2px solid #f5f2fc;
                    .day{
                        width:  calc(100% / 7);
                        height: 40px;
                        font-size: 16px;
                        text-align: center;
                        line-height: 40px;
                        &:first-child,
                        &:last-child{
                            background-color: #f5f2fc
                        }
                    }
                }
                .dates {
                    @include flex(flex-start, flex-start);
                    flex-wrap: wrap;
                    .day {
                        width:  calc(100% / 7);
                        height: 45px;
                        min-width: 50px;
                        text-align: center;
                        line-height:45px;
                        cursor: pointer;
                        span{
                            display: inline-block;
                            font-size: 16px;
                            border-radius: 50%;
                            width: 30px;
                            height: 30px;
                            line-height: 30px;
                            text-align: center;
                            &.pd{
                                padding: 0 3px 0 0px;
                            }
                            &.pd2{
                                padding: 0 2px 0 0px;
                            }
                        }
                        &.disable span{
                            color: $grayOnGray;
                            cursor: default;
                        }
                        &.holiday,
                        &.prev:first-child,
                        &.next:last-child{
                            background-color: #f5f2fc;
                        }
                        &.act,
                        &.today{
                            span{
                                background-color: $pink;
                                coloR: $white;
                            }
                        }
                        &.today-op{
                            span{
                                color: #333;
                                background-color: #ebebeb;
                            }
                        }
                        .point{
                            width: 5px;
                            height: 5px;
                            background-color: $pink;
                            border-radius: 50%;
                            margin: -5px auto 0;
                            z-index: 1;
                            &.purple{
                                 background-color: #6739e0;
                            }
                        }
                        
                        
                    }
                    &::-webkit-scrollbar{
                        display:none;
                    }
                    
                }
            }
            .fixed-btn{
                border-top: 2px solid #e7e7e7;
                padding: 10px 0;
                position: absolute;
                bottom: 0;
                left: 0;
                width: 100%;
                button{
                    width: 100%;
                    height: 50px;
                    background-color: $pink;
                    color: $white;
                    font-size: 18px;
                    border-radius: 10px;
                }
            }
        }

    }
    &.daily-list{
        margin-top: 30px;
        width: 44%;
        height: 103%;
        top: -30px;
        right: -22px;
        position: absolute;
        background-color: $white;
        .list-wrapper{
            width: 100%;
            height: 100%;
            overflow-y: scroll;
            box-shadow: 0px -5px 5px  rgba(0, 0, 0, 0.3);
            .date-info{
                background-color: #fce6f0;
                padding: 15px 20px;
                font-size: 18px;
                margin-bottom: 50px;
            }
        }
        .list{
            display: flex;
            min-height: 100px;
            margin-bottom: 10px;
            overflow: hidden;
            margin-right: 40px;
            &.holiday{
                .date,
                .date b{
                    color: $pink;
                }
            }
            .date{
                font-size: 16px;
                margin-right: 5px;
                width: 24%;
                font-family: "SCDream4";
                text-align: center;
                height: auto;
                b{
                    font-size: 22px;
                    display: block;
                }
                .line{
                    width: 3px;
                    min-height: 60px;
                    height: 100%;
                    background-color: #f7f5fa;
                    margin: 10px auto ;

                }
            }
            .note-wrapper{
                width: 85%;
            }
            .note{
                width: 100%;
                border-radius: 0 15px 15px 15px;
                padding: 25px 20px;
                margin-bottom: 10px;
                position: relative;
                .title{
                    font-size: 18px;
                    font-weight: 600;
                    margin-bottom: 5px;
                    position: relative;
                }
                .time{
                    font-size: 14px;
                }
                .note-menu{
                    position: absolute;
                    right: 0;
                    top: 20px;
                    padding: 10px 20px;
                    cursor: pointer;
                    div{
                        width: 3px;
                        height: 3px;
                        margin-bottom: 4px;
                        border-radius: 50%;
                        background-color: $black;
                    }
                }
                .cancle-btn{
                    position: absolute;
                    background-color: $white;
                    border-radius: 5px;
                    border: 1px solid #e5dff2;
                    padding: 5px 8px;
                    right: 30px;
                    top: 20px;
                    font-size: 16px;
                    cursor: pointer;
                }
                
                &.pink{
                    background-color: #fff5f9;
                    .title{
                        color: $pink;
                    }
                    a{
                        background-color: $pink;
                        color: $white;
                        border-radius: 20px;
                        padding: 8px 20px;
                        font-size: 14px;
                        margin-top: 20px;
                        display: inline-block;
                    }
                }
                &.purple{
                    background-color: #eee9fa;
                    .title{
                        color: #8159e5;
                    }
                }
                &.red{
                    background-color: #fff5f5;
                    .title{
                        color: #e03a3a;
                    }
                }
                &.disable{
                    background-color: #ededed;
                    .time, .title{
                        color: #9b9b9b;
                        &::before{
                            display: none;
                        }
                    }
                }
                &.add{
                    background-color: #f4f7ff;
                    .title{
                        color: #3c72ff;
                    }
                    .res-btn{
                        border: 1px solid #3c72ff;
                        margin-top: 40px;
                        padding:10px 15px;
                        text-align: center;
                        font-size: 16px;
                        border-radius: 10px;
                    }
                }
            }
            
        }
        .popup-wrapper{
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color:  $popupBg;
            z-index: 99999;
            &.pc{
                .popup{
                    max-width: 450px;
                    .txt-wrapper{
                        h5{
                            font-size: 20px;
                            font-family: "SCDream5";
                        }
                        p{
                            font-size: 16px;
                        }
                    }
                }
            }
            .popup{
                position: absolute;
                background-color:  $white;
                margin: 0 auto;
                top: 50%; 
                left: 50%;
                transform: translate(-50%, -50%);  
                width: 90%;
                max-width: 430px;
                min-height: 200px;
                border-radius: 15px;
                &.cancle{
                    .txt-wrapper{
                        p{
                            position: relative;
                            padding-left: 10px;
                            &::before{
                                content: '·';
                                position: absolute;
                                left: 0;
                                top: 0;
                            }
                        }
                    }
                }
                .txt-wrapper{
                    padding: 20px 25px;
                    h5{
                        font-size: 18px;
                        margin-bottom: 20px;
                    }
                    p{
                        font-size: 14px;
                        margin-bottom: 5px;
                        letter-spacing: -0.5px;
                        &:last-child{
                            margin-bottom: 30px;
                        }
                    }
                    p.font5{
                        text-align: center;
                        margin: 20px 0;
                        font-size: 16px;
                    }
                }
                .btn-wrapper{
                    width: 100%;
                    @include flex(space-between);
                    border-top: 1px solid #e7e7e7;
                    button{
                        padding: 10px 20px;
                        font-size: 16px;
                        &.confirm{
                            color: $pink;
                        }
                    }
                }
                &.reservation{
                    max-width: 450px;
                    overflow: hidden;
                    padding-bottom: 20px;
                    .component{
                        width:100%;
                    }
                }
            }
        }
    }
}
</style>

<script>
import Reservation from "@/components/mypage/class/Reservation.vue";
export default {
    name: 'Calendar',
    layout: 'mypage',
    components:{Reservation},
    data(){
        return{
            common:{},
            date: new Date(), // 현재 날짜(로컬 기준) 가져오기
            utc : null, // uct 표준시 도출
            today : null, // 한국 시간으로 date 객체 만들기(오늘)
            thisMonth : null,
            currentYear : null,
            currentMonth: null,
            currentDayOfWeek: new Date().getDay(),

            // 이번 달의 마지막날 날짜와 요일 구하기
            endDay  : null,
            nextDate : null,
           
            // 스크롤 범위 구하기 위한 인덱스
            monthIndex: 0,
            showYear: new Date().getFullYear(),
            showMonth: new Date().getMonth() +1,

            calendarDate:[],
            calendarDateBefore:[],
            calendarDateAfter:[],
            userData:[
                {title:'정규 수업',
                 date: '2022-6-23',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'2022 지방선거',
                 date: '2022-6-30',
                 time: 'all',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-7-3',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'정규 수업',
                 date: '2022-7-6',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
                {title:'빨간날',
                 date: '2022-7-10',
                 time: 'all',
                 cancle: false,
                 question: false},
                  {title:'정규 수업',
                 date: '2022-6-30',
                 time: '19:30 - 19:55',
                 cancle: false,
                 question: false},
               
            ],
            selectDay: new Date().getDate(),
            cancle:{
                question: false,
                have: false
            },
            popup:{
                open: false,
                message:false,
                reservation: false
            },
        }
    },
    created(){
        this.$nuxt.$on('commonData', (data) => {
            this.common = data;
        });
    },
    mounted(){
        this.calendarInit();
    },
    watch:{
    },
    filters:{
        monthEng(v){
            var eng = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
            return v = eng[v]
        },
        time(v){
            if(v=='all') return v='휴무'
            else return v
        },
        week(v){
            var week = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
            return v= week[v]
        },
        zero(v){
            if(v<10) return v = '0'+ String(v);
            else return v = v
        }
    },
    methods:{
        calendarInit() {
            this.utc= this.date.getTime() + ( this.date.getTimezoneOffset() * 60 * 1000), // uct 표준시 도출
            this.today = new Date( this.utc +  9 * 60 * 60 * 1000), // 한국 시간으로 date 객체 만들기(오늘)
            
            this.thisMonth = new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate());
            // 달력에서 표기하는 날짜 객체
        
            this.currentYear = this.thisMonth.getFullYear(); // 달력에서 표기하는 연
            this.currentMonth = this.thisMonth.getMonth(); // 달력에서 표기하는 월

            // 캘린더 렌더링
            this.renderCalender(this.thisMonth);
        },
        renderCalender() {
            // 렌더링을 위한 데이터 정리
            this.currentYear = this.thisMonth.getFullYear();
            this.currentMonth = this.thisMonth.getMonth();

            // 이번 달의 마지막날 날짜와 요일 구하기
            this.endDay = new Date(this.currentYear, this.currentMonth + 1, 0);
            this.nextDate = this.endDay.getDate();

            // 렌더링 html 요소 생성
            var calendar = document.querySelector('.dates')
            var week = ['일', '월', '화', '수', '목', '금', '토']
            
            // 지난달
            var startDay = new Date(this.currentYear, this.currentMonth, 0);
            var prevDate = startDay.getDate();
            var prevDay = startDay.getDay();
            
             // 이번 달의 마지막날 날짜와 요일 구하기
            var endDay = new Date(this.currentYear, this.currentMonth + 1, 0);
            var nextDate = endDay.getDate();
            var nextDay = endDay.getDay();

            // 지난달
            for (var i = prevDate - prevDay ; i <= prevDate; i++) {
                this.calendarDateBefore.push(i)
                if(this.calendarDateBefore.length >= 7) this.calendarDateBefore = [];
            }
            // 이번달
            for (var i = 1; i <= nextDate; i++) {
                var dayOfWeek = week[new Date(this.currentYear+'-'+(this.currentMonth+1)+'-'+i).getDay()];

                 this.calendarDate.push({'dayOfWeek': dayOfWeek, 'year': this.currentYear, 'month': this.currentMonth + 1, 'day': i, 'fulldate':this.currentYear +'-'+(this.currentMonth+1)+'-'+i})
            }
            // 다음달

            for (var i = 1; i <= (6 - nextDay == 7 ? 0 : 6 - nextDay); i++) {
                this.calendarDateAfter.push(i)
              
            }
           
            this.observer();
            this.checkDate();
            this.monthIndex = this.monthIndex +1;
        },
        addMonth(v){
            this.calendarDate = [];
            this.calendarDateAfter = [];
            this.calendarDateBefore = [];
            this.selectDay = 1;
            
            this.currentMonth= this.currentMonth +(v == 'next'? 1 : -1);
            this.thisMonth = new Date(this.currentYear, this.currentMonth, 1);

            this.currentDayOfWeek = new Date(this.thisYear+'-'+this.thisMonth+'-'+1).getDay();
            
            this.renderCalender(this.thisMonth); 
        },
        checkScroll(e){
            var scrollX = e. target.scrollLeft;
         
            if(scrollX > 150*this.monthIndex){
                this.addMonth();
            }
            this.observer();
        },
        observer(){
             const io = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    // entry의 target으로 DOM에 접근합니다.
                    const $target = entry.target;

                    // 화면에 노출 상태에 따라 해당 엘리먼트의 class를 컨트롤 합니다.
                    if (entry.isIntersecting) {
                        $target.classList.add("screening");
                    } else {
                        $target.classList.remove("screening");
                    }
                });
            });
            const $items = this.$el.querySelectorAll(".day");
            $items.forEach((item) => {
                io.observe(item);
            });

        },
        checkDate(){
            var dates=[];
            this.userData.forEach(e=>{
                dates.push({date: e.date, title: e.title})
            });

            dates.forEach(e=>{
                this.calendarDate.forEach(d=>{
                    if(e.date == d.fulldate) {
                        d.point = true;
                        d.status = e.title
                    }
                })
            });
        },
        clickDay(year, month, day){
            this.selectDay = day; 
            this.currentDayOfWeek = new Date(year+'-'+month+'-'+day).getDay();
        },
        popupClose(v, i){
            Object.entries(this.popup).forEach(([key, value]) => {
                this.popup[key] = false;
            });
            if(v=='ok'){
                this.userData[i].cancle=true;
                this.cancle.have = true;
            }
            if(v== 'res'){
                
            }
        },

    },
    computed:{
    }
}


</script>