<template>
    <footer>
        <div>	
			<section>
				<div>
					<div>
						<p class="consulting"><b>컨설팅 센터</b><br v-if="$device.isMobile "> 오후 2시~10시 (주말, 공휴일 휴무) <br v-if="$device.isMobile"><span v-else>|</span><b>TEL : 0507-1391-1578</b></p>
						<ul class="menu-list" v-if="!$device.isMobile">
							<li>FAQ<span>|</span></li>
							<li>오류신고<span>|</span></li>
							<li @click="openTerms">이용약관<span>|</span></li>
							<li>개인정보처리방침</li>
						</ul>
					</div>
					<ul class="sns-list" v-if="!$device.isMobile">
						<li class="insta"></li>
						<li class="blog"></li>
						<li class="kakao"></li>
					</ul>

				</div>
			</section>
			<section v-if="!$device.isMobile">
				<div>
					<ul class="info-list">
						<li>상호명 : 스픽클 원격평생교육원 <span>|</span> 대표자 : 김정태 <span>|</span><b> TEL : 0507-1391-1578</b></li>
						<li>주소 : 서울특별시 강남구 선릉로 87길 12, 송경빌딩 9층 909호 <span>|</span> 이메일 : info@speakcls.com <span>|</span> 사업자등록번호 : 893-98-00883 <span>|</span> 통신판매업신고번호 : 제 2020-서울강남-03036 호</li>
						<li>copyright(c) 2022 speakcls. All rights reserved.</li>
					</ul>
				</div>
			</section>
		
			<section v-else>
				
				<div>
					<ul class="menu-list">
						<li>FAQ<span>|</span></li>
						<li>오류신고<span>|</span></li>
						<li>이용약관<span>|</span></li>
						<li>개인정보처리방침</li>
					</ul>
					
					<button @click="openInfo = !openInfo">스픽클 원격평생교육원 사업정보 <img :src="require('@/assets/img/down-arrow.png')" :class="{'open': openInfo}"></button>
					<ul class="info-list" v-if="openInfo">
						<li>상호명 : 스픽클 원격평생교육원 <br>대표자 : 김정태 <br><b>TEL : 0507-1391-1578</b></li>
						<li>주소 : 서울특별시 강남구 선릉로 87길 12,<br> 송경빌딩 9층 909호 <br> 이메일 : info@speakcls.com</li>
						<li>사업자등록번호 : 893-98-00883 <br> 통신판매업신고번호 : 제 2020-서울강남-03036 호</li>
						
					</ul>
					<ul class="sns-list">
						<li class="insta"></li>
						<li class="blog"></li>
						<li class="kakao"></li>
					</ul>
					<p>copyright(c) 2022 speakcls. All rights reserved.</p>
				</div>
			</section>
		
		</div>
    </footer>
</template>

<style lang="scss" scope>
footer{
	width: 100%;
	padding-bottom: 80px;
	>div{
		width: 100%;
		p, li, b, button{
			font-size: 14px;
			line-height: 26px;
			font-family: "SCDream3";
			color: #666;	
		}
		b{
			color: #555555;
		}
		section{
			width: 100%;
			max-width: 2000px;
			padding: 20px 0;
			border-top: 1px solid $gray;
			>div{
				width: 100%;
				max-width: 1080px;
				margin: 0 auto;
			}
			&:first-child{
				>div{
					@include flex(space-between);
				}
			}
			&:last-child{
				border-top: 1px solid rgb(241, 241, 241);
			}
			.consulting{
				b{
					margin-right: 10px;
				}
			}
			.sns-list, .menu-list{
				@include flex(flex-start);
				li{
					cursor: pointer;
				
				}
			}
			.menu-list li{
				font-weight: 600;
				color: #555555;
			}
			.sns-list li{
				border: 3px solid #a5a5a5;
				@include flex();
				width: 45px;
				height: 45px;
				border-radius: 50%;
				&+li{
					margin-left: 5px;
				}
				&.insta{
					background: url('@/assets/img/footer/instagram.webp') no-repeat center;
					background-size: 25px;
				}
				&.blog{
					background: url('@/assets/img/footer/blog.webp') no-repeat center;
					background-size: 25px;
				}
				&.kakao{
					background: url('@/assets/img/footer/kakaostory.webp') no-repeat center;
					background-size: 25px;
				}
			}
			.info-list{
				li{
					&:last-child{
						margin-top: 15px;
					}
				}
			}
			span{
				margin: 0 8px;
				font-size: 12px;
				color: #a5a5a5;
			}
		}
	}
}
@media screen and (max-width: 1080px){
	footer{
		>div{
			section{
				>div{
					padding: 0 20px;
				}
			}
		}
	}
}
@media screen and (max-width: 767px){
	footer{
		padding-bottom: 10px;
		>div{
			section{
				>div{
					*{
						text-align: center;
					}
					>*{
						width: 100%;
					}
					button{
						font-weight: 600;
						img{
							width: 15px;
						}
					}
					.consulting{
						b{
							margin-right: 0;
						}
					}
					.sns-list{
						justify-content: center;
						margin: 15px 0;
					}
					.menu-list{
						justify-content: center;
					}
					.info-list{
						li{
							line-height: 22px;
							&:last-child{
								margin-top: 0;
							}
						}
					}
				}
			}
		}
	}
}
</style>
<script>
export default {
	props:['width','login'],
	data() {
		return {
			openInfo: false
		};
	},
	mounted(){
	},
	watch:{
    },
	methods: {
		openTerms(){
			this.$nuxt.$emit("termsOpen", true)

		}
	},
};
</script>