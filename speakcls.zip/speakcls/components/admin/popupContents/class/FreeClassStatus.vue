<template>
<div  class="free-class-status" v-if="classInfo">
    <h4>무료 수업 진행상태</h4>
    <div class="input-wrapper">
        <div class="text-box">
            <label>이름 (ID)</label>
            <p>{{classInfo.student.userName}} ({{classInfo.student.id}})</p>
        </div>
        <div class="text-box">
            <label>이름 (ID)</label>
            <p>{{classInfo.student.tel}}</p>
        </div>
        <div class="text-box">
            <label>협력사</label>
            <p>{{classInfo.company}}</p>
        </div>
        <div class="input-box">
            <label>테스트 레벨</label>
            <v-select :items="levelItems"  dense v-model="classInfo.testLevel"></v-select>
        </div>
        <div class="input-box">
            <label>수업 일자</label>
            <v-menu  ref="menu"  v-model="menu"  :close-on-content-click="false"  :return-value.sync="classInfo.testDay"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="classInfo.testDay"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu.save(classInfo.testDay)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="classInfo.testDay"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>

        </div>
        <div class="input-box">
            <label>수업 시간</label>
            <v-select :items="timeItems"  dense v-model="classInfo.time"></v-select>
        </div>

        <div class="input-box">
            <label>강사</label>
            <p v-if="classInfo.tutor !== null">{{classInfo.tutor.tutorName}}</p>
            <button class="blue" @click="searchingTutor">검색</button>
        </div>
        
        <table v-if="searchTutor">
            <thead>
                <tr>
                    <th>강사이름</th>
                    <th>성별</th>
                    <th>레벨</th>
                    <th>회원수 (수업)</th>
                    <th>수업기간</th>
                    <th>수업시간</th>
                    <th>횟수</th>
                    <th>등록</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(tutor, idx) in tutorData" :key="'tutor' + idx">
                    <td>{{tutor.tutorName}}</td>
                    <td>{{tutor.sex}}</td>
                    <td>Free</td>
                    <td>2 / 0</td>
                    <td>2022.07 ~ 2023.07.28</td>
                    <td>18:00 ~ 18:10 (10분)</td>
                    <td>23회</td>
                    <td><button class="blue" @click="classInfo.tutor = {tutorName:  tutor.tutorName, id:  tutor.id}">등록</button></td>
                </tr>
            </tbody>
        </table>

        <div class="button-wrapper">
            <button class="blue" @click="editStatus" >등록</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.free-class-status{

    .input-wrapper{
        @include flex(flex-start, flex-start);
        flex-wrap: wrap;
        width: 100%;
        max-width: 730px;
        flex-wrap: wrap;
        button{
            padding: 3px 10px;
            border-radius: 12px;
        }
        .text-box,  .input-box{
            @include flex(flex-start);
            width:50%;
            height: 40px;
            overflow: hidden;
            margin-bottom: 10px;
            &.full{
                width: 100%;
                height: auto;
            }
            label{
                font-size: 14px;
                font-family: "SCDream4";
                min-width: 120px;
                white-space: nowrap;
                padding-right: 20px;
                font-weight: 600;
                line-height: 30px;
                width: auto;
            }
            p{
                margin-bottom: 0;
                height: 30px;
                line-height: 30px;
                span{
                    color: red;
                }
                &+button{
                    margin-left: 10px;
                }
            }
            input[type="text"],input[type="date"], select, textarea, .v-input__slot{
                border: 1px solid #e7e7e7;
                border-radius: 5px;
                padding: 3px 10px;
                width: 100%;
                min-width: 100px;
                height: 30px;
                color: $black;
                font-size: 14px;
            }
            textarea{
                height: 100px;
            }
            .v-input{
                flex-direction: row-reverse;
                max-width: 200px;
                font-size: 14px;
                max-height: 30px;
            }
            .v-text-field{
                margin: 0;
                padding: 0;
            }
            .v-input__control{
                font-size: 14px;
                
            }
            .v-text-field.v-text-field--solo .v-input__control{
                min-height: 10px !important;
            } 
            .v-menu__content--fixed{
                margin-top: 30px;
            }
    
        }
        table{
            margin-top: 20px;
            width: 100%;
            white-space:nowrap;
            border-collapse:collapse;
            border: 1px solid $gray;
            thead{
                background-color: #eeeeee;
            }
            th, td{
                text-align: center;
                padding: 5px 10px;
                border: 1px solid $gray;
            }
     
        }

    
    }
    .button-wrapper{
        @include flex(flex-start);
        width: 100%;
        margin: 30px 0 20px;
        height: 40px;
        div{
            width: auto;
        }
        button{
            flex: 1;
            padding: 8px;
            border-radius: 5px;
            width: 150px;
            max-width: 150px;
            &+button{
                margin-left: 10px;
            }
        }
    
    }

}    


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            classInfo: null,
            tutorData: null,
            searchTutor: false,
            menu: false,
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
            levelItems: ['junior', 'senior']
            // levelItems: ['100-200', '200-300', '300-400', '400-500']
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/leveltest/'+ this.selectData).then(data =>{
            this.classInfo = data;
            console.log(data)
        }).catch((error)=>{
            console.log(error.data)
        });
    },

    mounted() {
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async editStatus(){
            this.cancle('ok')
            
            await this.$axios.put('/api/edit/leveltest', this.classInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            
        },
        async searchingTutor(){
            await this.$axios.$get('/api/tutor').then(data =>{
                this.tutorData = data;
            }).catch((error)=>{
                console.log(error.data)
            });

            this.searchTutor = true;
        }
    }
}
</script>
