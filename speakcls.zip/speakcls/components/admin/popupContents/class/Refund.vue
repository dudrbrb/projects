<template>
<div  class="refund-application">
    <h4>환불관리</h4>
    <div class="input-wrapper">
        <div class="text-box">
            <label>이름</label>
            <p v-if="classInfo.student">{{classInfo.student.userName}}</p>
        </div>
        <div class="input-box">
            <label>환불금액</label>
            <input type="text">
        </div>
        <div class="input-box">
            <label>환불일자</label>
            <v-menu  ref="menu"  v-model="menu"  :close-on-content-click="false"  :return-value.sync="date"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="date"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu.save(date)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="date"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>

        </div>

        <div class="button-wrapper">
            <button class="blue" @click="refund">등록</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.refund-application{

    .input-wrapper{
        @include flex(flex-start, flex-start, column);
        flex-wrap: wrap;
        width: 100%;
        max-width: 1000px;
        .text-box,  .input-box{
            @include flex(flex-start, flex-start);
            width: 100%;
            margin-bottom: 10px;
            label{
                font-size: 14px;
                font-family: "SCDream4";
                min-width: 80px;
                margin-right: 15px;
                font-weight: 600;
                line-height: 30px;
            }
            p{
                margin-bottom: 0;
                height: 30px;
                line-height: 30px;
            }
            input[type="text"],input[type="date"], select, textarea, .v-input__slot{
                border: 1px solid #e7e7e7;
                border-radius: 5px;
                padding: 3px 10px;
                width: 100%;
                min-width: 100px;
                height: 30px;
                color: $black;
            }
            input[type="radio"]{
                margin-right: 5px;
            }
            .v-input{
                flex-direction: row-reverse;
            }
            .v-text-field{
                margin-top: 0;
                padding-top: 0;
            }

    
        }

    
    }
    .button-wrapper{
        @include flex(flex-start);
        width: 100%;
        margin: 30px 0 20px;
        height: 40px;
        div{
            width: auto;
        }
        button{
            flex: 1;
            padding: 8px;
            border-radius: 5px;
            width: 150px;
            max-width: 150px;
            &+button{
                margin-left: 10px;
            }
        }
    
    }

}    


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            classInfo:{

            },
            date: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            menu: false,
           
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/class/'+ this.selectData).then(data =>{
            this.classInfo = data;
            console.log(data)
        }).catch((error)=>{
            console.log(error.data)
        });
    },

    mounted() {
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async refund(){
            await this.$axios.put('/api/edit/class', this.classInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });

            this.cancle('ok')
        }
    }
}
</script>
