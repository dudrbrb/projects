<template>
<div  class="change-class" v-if="classInfo">
    <h4>변경</h4>
    <div class="input-wrapper">
        <div class="text-box">
            <label>이름 (ID)</label>
            <p>{{classInfo.student.userName}} ({{classInfo.student.id}})</p>
        </div>
        <div class="input-box">
            <label>변경수업일</label>
            <v-menu  ref="menu1"  v-model="menu1"  :close-on-content-click="false"  :return-value.sync="date1"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="date1"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu1 = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu1.save(date)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="date1"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>

        </div>
        <div class="input-box">
            <label>수업시작일</label>
            <v-menu  ref="menu2"  v-model="menu2"  :close-on-content-click="false"  :return-value.sync="date2"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="date2"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu2 = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu2.save(date)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="date2" dense  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>

        </div>
        <div class="input-box">
            <label>요청시간</label>
            <v-select :items="timeItems" outlined  dense v-model="classInfo.time"></v-select>
        </div>
        <div class="input-box">
            <label>수업 진행 시간</label>
            <v-select :items="minuteItems" outlined  dense v-model="classInfo.classTime"></v-select>
        </div>
   
        <div class="input-box">
            <label>수업 요일</label>
            <v-select :items="weekItems" outlined  dense v-model="classInfo.week"></v-select>
        </div>
        <div class="input-box">
            <label>대체강사</label>
            <p v-if="replaceTutor !== null">{{replaceTutor.tutorName}}</p>
            <button class="blue" @click="searchingTutor">검색</button>
        </div>
        
        <table v-if="searchTutor">
            <thead>
                <tr>
                    <th>강사이름</th>
                    <th>성별</th>
                    <th>레벨</th>
                    <th>회원수 (수업)</th>
                    <th>수업기간</th>
                    <th>수업시간</th>
                    <th>횟수</th>
                    <th>등록</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(tutor, idx) in tutorData" :key="'tutor' + idx">
                    <td>{{tutor.tutorName}}</td>
                    <td>{{tutor.sex}}</td>
                    <td>Free</td>
                    <td>2 / 0</td>
                    <td>2022.07 ~ 2023.07.28</td>
                    <td>18:00 ~ 18:10 (10분)</td>
                    <td>23회</td>
                    <td><button class="blue" @click="replaceTutor = tutor">등록</button></td>
                </tr>
            </tbody>
        </table>

        <div class="button-wrapper">
            <button class="blue" @click="cancle('ok')" >등록</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.change-class{

    .input-wrapper{
        @include flex(flex-start, flex-start);
        flex-wrap: wrap;
        width: 100%;
        max-width: 800px;
        flex-wrap: wrap;
        button{
            padding: 3px 10px;
            border-radius: 12px;
        }
        .text-box,  .input-box{
            @include flex(flex-start, flex-start);
            width:100%;
            height: 40px;
            overflow: hidden;
            margin-bottom: 10px;
            &.full{
                width: 100%;
                height: auto;
            }
            label{
                font-size: 14px;
                font-family: "SCDream4";
                min-width: 120px;
                white-space: nowrap;
                padding-right: 20px;
                font-weight: 600;
                line-height: 30px;
                width: auto;
            }
            p{
                margin-bottom: 0;
                height: 30px;
                line-height: 30px;
                span{
                    color: red;
                }
                &+button{
                    margin-left: 10px;
                }
            }
            input[type="text"],input[type="date"], select, textarea, .v-input__slot{
                border: 1px solid #e7e7e7;
                border-radius: 5px;
                padding: 3px 10px;
                width: 100%;
                min-width: 100px;
                height: 30px;
                color: $black;
                font-size: 14px;
            }
            textarea{
                height: 100px;
            }
            .v-input{
                flex-direction: row-reverse;
                max-width: 200px;
                font-size: 14px;
                max-height: 30px;
            }
            .v-text-field{
                margin: 0;
                padding: 0;
            }
            .v-input__control{
                font-size: 14px;
                
            }
            .v-text-field.v-text-field--solo .v-input__control{
                min-height: 10px !important;
            } 
            .v-menu__content--fixed{
                margin-top: 30px;
            }
    
        }
        table{
            margin-top: 20px;
            width: 100%;
            white-space:nowrap;
            border-collapse:collapse;
            border: 1px solid $gray;
            thead{
                background-color: #eeeeee;
            }
            th, td{
                text-align: center;
                padding: 5px 10px;
                border: 1px solid $gray;
            }
     
        }

    
    }
    .button-wrapper{
        @include flex(flex-start);
        width: 100%;
        margin: 30px 0 20px;
        height: 40px;
        div{
            width: auto;
        }
        button{
            flex: 1;
            padding: 8px;
            border-radius: 5px;
            width: 150px;
            max-width: 150px;
            &+button{
                margin-left: 10px;
            }
        }
    
    }

}    


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            classInfo: null,
            tutorData: null,
            replaceTutor: null,
            searchTutor: false,
            date1: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            date2: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            menu1: false,
            menu2: false,
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
            minuteItems: ['10분', '25분'],
            weekItems:[ '월, 화, 수, 목, 금', '월, 수, 금', '화, 목']
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/class/'+ this.selectData).then(data =>{
            this.classInfo = data;
            console.log(data)
        }).catch((error)=>{
            console.log(error.data)
        });
    },

    mounted() {
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async searchingTutor(){
            await this.$axios.$get('/api/tutor').then(data =>{
                this.tutorData = data;
            }).catch((error)=>{
                console.log(error.data)
            });

            this.searchTutor = true;

        }
    }
}
</script>
