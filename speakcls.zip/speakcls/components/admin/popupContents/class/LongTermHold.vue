<template>
<div  class="long-term-hold">
    <h4>장기홀드</h4>
    <div class="input-wrapper">
        <div class="text-box">
            <label>이름</label>
            <p v-if="classInfo.student">{{classInfo.student.userName}}</p>
        </div>
        <div class="input-box">
            <label>장기홀드요청</label>
            <v-menu  ref="menu1"  v-model="menu1"  :close-on-content-click="false"  :return-value.sync="date1"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="date1"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu1 = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu1.save(date)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="date1"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>

        </div>
        <div class="text-box">
            <label>ID</label>
            <p v-if="classInfo.student">{{classInfo.student.id}}</p>
        </div>
        <div class="input-box">
            <label>재시작예정일</label>
            <v-menu  ref="menu2"  v-model="menu2"  :close-on-content-click="false"  :return-value.sync="date2"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="date2"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu2 = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu2.save(date)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="date2"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>

        </div>
        <div class="input-box full">
            <label>남은수업</label>
            <p><span v-if="classInfo.attendance">( {{classInfo.attendance.remain}} ) 회</span> 수업이 남아있습니다</p>
        </div>
        <div class="input-box full">
            <label>메모</label>
            <textarea name="memo" id="memo" cols="30" rows="10"></textarea>
        </div>

        <div class="button-wrapper">
            <button class="blue" @click="refund">등록</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.long-term-hold{

    .input-wrapper{
        @include flex(flex-start, flex-start);
        flex-wrap: wrap;
        width: 100%;
        max-width: 500px;
        flex-wrap: wrap;
        .text-box,  .input-box{
            @include flex(flex-start, flex-start);
            width:50%;
            height: 40px;
            overflow: hidden;
            margin-bottom: 10px;
            &.full{
                width: 100%;
                height: auto;
            }
            label{
                font-size: 14px;
                font-family: "SCDream4";
                min-width: 75px;
                white-space: nowrap;
                padding-right: 20px;
                font-weight: 600;
                line-height: 30px;
                width: auto;
            }
            p{
                margin-bottom: 0;
                height: 30px;
                line-height: 30px;
                span{
                    color: red;
                }
            }
            input[type="text"],input[type="date"], select, textarea, .v-input__slot{
                border: 1px solid #e7e7e7;
                border-radius: 5px;
                padding: 3px 10px;
                width: 100%;
                min-width: 100px;
                height: 30px;
                color: $black;
                font-size: 14px;
            }
            textarea{
                height: 100px;
            }
            .v-input{
                flex-direction: row-reverse;
            }
            .v-text-field{
                margin-top: 0;
                padding-top: 0;
            }
            .v-input__control{
                font-size: 14px;
                
            }

    
        }

    
    }
    .button-wrapper{
        @include flex(flex-start);
        width: 100%;
        margin: 30px 0 20px;
        height: 40px;
        div{
            width: auto;
        }
        button{
            flex: 1;
            padding: 8px;
            border-radius: 5px;
            width: 150px;
            max-width: 150px;
            &+button{
                margin-left: 10px;
            }
        }
    
    }

}    


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            classInfo:{

            },
            date1: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            date2: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            menu1: false,
            menu2: false,
           
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/class/'+ this.selectData).then(data =>{
            this.classInfo = data;
            console.log(data)
        }).catch((error)=>{
            console.log(error.data)
        });
    },

    mounted() {
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async refund(){
            await this.$axios.put('/api/edit/class', this.classInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });

            this.cancle('ok')
        }
    }
}
</script>
