<template>
<div  class="long-term-hold">
    <h4>결제상태</h4>
    <div class="input-wrapper" v-if="classInfo !== null ">
        <div class="text-box">
            <label>이름</label>
            <p>{{classInfo.student.userName}}</p>
        </div>
        <div class="input-box">
            <label>결제상태</label>
            <v-select :items="statusItems" outlined  dense v-model="classInfo.payment.status"></v-select>
        </div>
        <div class="text-box">
            <label>입금자</label>
            <p>{{classInfo.student.id}}</p>
        </div>
        <div class="input-box">
            <label>결제수단</label>
            <v-select :items="methodItems" outlined  dense v-model="classInfo.payment.method"></v-select>
        </div>
        <div class="input-box">
            <label>입금일</label>
            <p>{{classInfo.payment.day}} </p>
        </div>
        <div class="input-box">
            <label>총 금액</label>
            <input type="text" v-model="classInfo.price" readonly />
        </div>
        <div class="input-box full">
            <label>메모</label>
            <textarea name="memo" id="memo" cols="30" rows="10"></textarea>
        </div>

        <div class="button-wrapper">
            <button class="blue" @click="refund">등록</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.long-term-hold{

    .input-wrapper{
        @include flex(flex-start, flex-start);
        flex-wrap: wrap;
        width: 100%;
        max-width: 500px;
        flex-wrap: wrap;
        .text-box,  .input-box{
            @include flex(flex-start, flex-start);
            width:50%;
            height: 40px;
            overflow: hidden;
            margin-bottom: 10px;
            &.full{
                width: 100%;
                height: auto;
            }
            label{
                font-size: 14px;
                font-family: "SCDream4";
                min-width: 75px;
                white-space: nowrap;
                padding-right: 20px;
                font-weight: 600;
                line-height: 30px;
                width: auto;
            }
            p{
                margin-bottom: 0;
                height: 30px;
                line-height: 30px;
                span{
                    color: red;
                }
            }
            input[type="text"],input[type="date"], select, textarea, .v-input__slot{
                border: 1px solid #e7e7e7;
                border-radius: 5px;
                padding: 3px 10px;
                width: 100%;
                min-width: 100px;
                height: 30px;
                color: $black;
                font-size: 14px;
            }
            textarea{
                height: 100px;
            }
        }

    
    }
    .button-wrapper{
        @include flex(flex-start);
        width: 100%;
        margin: 30px 0 20px;
        height: 40px;
        div{
            width: auto;
        }
        button{
            flex: 1;
            padding: 8px;
            border-radius: 5px;
            width: 150px;
            max-width: 150px;
            &+button{
                margin-left: 10px;
            }
        }
    
    }

}    


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            classInfo: null,
            statusItems: ['미결제', '결제완료', '환불요청', '환불완료'],
            methodItems: ['무통장', '카드'],
           
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/class/'+ this.selectData).then(data =>{
            this.classInfo = data;
            console.log(data)
        }).catch((error)=>{
            console.log(error.data)
        });
    },

    mounted() {
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async refund(){
            await this.$axios.put('/api/edit/class', this.classInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });

            this.cancle('ok')
        }
    }
}
</script>
