<template>
<div  class="level-test">
    <h4>무료 수업 등록</h4>
    <div class="input-wrapper">
        <div class="text-box">
            <label>이름</label>
            <p>{{userInfo.userName}} ({{userInfo.id}})</p>
        </div>
        <div class="text-box">
            <label>ID</label>
            <p>{{userInfo.engName}}</p>
        </div>
        <div class="text-box">
            <label>수업레벨</label>
            <div class="input-box">
                <input type="radio" name="level" id="junior" value="junior" v-model="appliData.testLevel">
                <label for="junior">Junior</label>
                <input type="radio" name="level" id="senior" value="senior" v-model="appliData.testLevel">
                <label for="senior">Senior</label>
            </div>
        </div>
        <div class="text-box">
            <label>수업시작일</label>
            <div class="input-box">
            <v-menu  ref="menu"  v-model="menu"  :close-on-content-click="false"  :return-value.sync="appliData.date.fixed"  transition="scale-transition"  offset-y  min-width="auto" >
                <v-date-picker  v-model="appliData.date.fixed"  no-title  scrollable  >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        Cancel
                    </v-btn>
                    <v-btn  text  color="primary"  @click="$refs.menu.save(appliData.date.fixed)" >
                        OK
                    </v-btn>
                </v-date-picker>
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field  v-model="appliData.date.fixed"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                </template>
            </v-menu>
                <!-- <input type="date" name="date" id="date" v-model="appliData.date.fixed"> -->
            </div>
        </div>
        <div class="text-box">
            <label>수업시간</label>
            <div class="input-box " >
                <div class="select-wrapper time-select">
                    <input class="select" type="text"  readonly @click="selectTime( 'open')" v-model="appliData.time.value">
        
                        <ul class="options" v-if="appliData.time.open">
                            <li v-for="(t ,idx) in timeItems" :key="`time${idx}`" @click="selectTime(t)">{{t}}</li>
                        </ul>
                </div>
            </div>
        </div>
             <div class="text-box">
                <label>연락처</label>
                <div class="input-box">
                    <p>{{userInfo.userTel}}</p>
                </div>
            </div>
         <div class="text-box column">
            <label>학습수준</label>
            <div class="input-box column">
                <div>
                    <input type="radio" name="testLevel" value="tel" id="tel" v-model="appliData.testLevel">
                    <label for="tel">기초 단어를 따라 말할 수 있어요.</label>
                </div>
                <div>
                    <input type="radio" name="testLevel" value="video" id="video" v-model="appliData.testLevel">
                    <label for="video">간단한 문장을 말할 수 있어요.</label>
                </div>
                <div>
                    <input type="radio" name="testLevel" value="video" id="video" v-model="appliData.testLevel">
                    <label for="video">자유롭게 프리토킹이가능해요.</label>
                </div>
            </div>
        </div>
         <div class="text-box full">
            <label>특이사항</label>
            <div class="input-box">
                <textarea name="toTutor" id="toTutor" cols="30" rows="10" v-model="appliData.toTutor"></textarea>
            </div>
        </div>

        <div class="button-wrapper">
            <button class="blue" @click="addFreeClass">등록</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.input-wrapper{
    @include flex(flex-start, flex-start);
    flex-wrap: wrap;
    width: 100%;
    max-width: 700px;
    .text-box{
        @include flex(flex-start, center);
        width: 50%;
        margin-bottom: 10px;
        &.column{
            @include flex(flex-start, flex-start);
        }
        >label{
            font-size: 14px;
            font-family: "SCDream5";
            min-width: 80px;
        }
        p{
            margin-bottom: 0;
            height: 30px;
            line-height: 30px;
        }
        &.full{
            width: 100%;
            align-items: flex-start;
            margin-top: 10px;
            .input-box{
                width: 100%;
                input, textarea{
                    width: 100%;
                }
                textarea{
                    height: 100px;
                }
            }
        }

        .input-box{
            @include flex(flex-start, center);
            &.column{
               @include flex(flex-start, flex-start, column);
               div{
                    @include flex();
                    height: 24px;
               }
            }
            label{
                min-width: 0;
                margin-right: 15px;
                font-family: "SCDream3";
                line-height: 24px;

            }
            input[type="text"],input[type="date"], select, textarea{
                border: 1px solid #e7e7e7;
                border-radius: 5px;
                padding: 3px 10px;
                width: 100%;
                min-width: 100px;
                height: 30px;
                color: $black;
                &:focus{
                    border-color: $blue;
                }
            }
            input[type="radio"]{
                margin-right: 5px;
            }
        }
        .select-wrapper{
            position: relative;
            width: 100px;
            margin-right: 5px;
            &.time-select{
                ul{
                    @include flex(flex-start);
                    flex-wrap: wrap;
                    width: 273px;
                    padding: 5px;
                    box-shadow: $shadow;
                    border: 2px solid $blue;
                    border-radius: 5px;
                    margin-top: 5px;
                    @include flex(space-between);
                    white-space: nowrap;
                    li{ 
                        padding: 0px 10px;
                        border: 1px solid $gray;
                        margin: 3px;
                        cursor: pointer;
                        border-radius: 5px;
                        &:hover{
                            border: 1px solid $blue;
                        }
                    }
                }
            

            }
            input.select{
                width: 100%;
                min-width: 0;
                text-align: left;
                cursor: pointer;
                background: url('@/assets/img/input-arrow.png') no-repeat 95%;

            }
            .options{
                position: absolute;
                background-color: $white;
                box-shadow: $shadow;
                padding: 0;
                width: 100%;
                border: 1px solid $lightGray;
                z-index: 1;
                padding: 10px 0;
                top: 30px;
                li{
                    font-size: 14px;
                    padding: 0 10px;
                    cursor: pointer;
                    line-height: 30px;
                    &:hover{
                        background-color: #f1f4f6d0;
                    }
                }
            }
        }

    }

}
.button-wrapper{
    @include flex(flex-end);
    width: 100%;
    margin: 30px 0 20px;
    height: 40px;
    div{
        width: auto;
    }
    button{
        flex: 1;
        padding: 8px;
        border-radius: 5px;
        width: 150px;
        max-width: 150px;
        &+button{
            margin-left: 10px;
        }
    }

}



</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            menu: false,
            userInfo:{
                userName: null,
                engName: null,
                age: null,
                birthday: null,
                address: null,
                id: null,
                pw: null,
                sex: null,
                userTel: null,
                membership: '일반',
                consulting: null,
                joinData: {
                    root: null,
                    day: null,
                    recommendPerson:{
                        name: null,
                        tel: null
                    }
                },
            },
            appliData: {
                time:{
                    open: false,
                    value: '선택'
                },
                testLevel: null,
                status: '미접수',
                consulting: false,
                testLevel: null,
                date:{
                    want: null,
                    fixed: null,
                },
                tutor: null,
                level: null,
                result:{
                    average:null,
                    pronunciation:null,
                    grammer:null,
                    vocabulary:null,
                    understanding:null,
                    fluency:null,
                },
                toTutor: null,
                note: null,
                request: null
            },
            today: null,
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],

           
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/user/'+ this.selectData).then(data =>{
            this.userInfo = data;
        }).catch((error)=>{
            console.log(error.data)
        });
        this.appliData.date.fixed = (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)
    },

    mounted() {
        this.getDate();
    },
    methods:{   
        getDate(){
            var today = new Date(),
                year = today.getFullYear(),
                month = ('0' + (today.getMonth() + 1)).slice(-2),
                day = ('0' + today.getDate()).slice(-2);

            this.today=  year + '.' + month  + '.' + day;
        },   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
    
        async addFreeClass(){
            this.cancle('ok');
            this.appliData.time = this.appliData.time.value;
            this.appliData.testLevel = this.appliData.testLevel;
            this.appliData.regDay = this.today;


            await this.$axios.post('/api/add/leveltest', this.userInfo).then( (response) => {
                console.log(response);
                this.editUserLeveltest()
            }).catch( (error) => {
                console.log(error);
            });
        },
        selectTime(v){
            this.appliData.time.open = !this.appliData.time.open;
            if(v !== 'open'){
                this.appliData.time.value = v;
            }
           

        }
    }
}
</script>
