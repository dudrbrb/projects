<template>
<div class="add-member">
    <h4 v-if="value == 'add'">회원 등록</h4>
    <h4 v-if="value == 'edit'">회원 정보 수정</h4>
    <div class="input-wrapper">
        <div class="input-box">
            <label>이름</label>
            <input type="text" v-model="userInfo.userName">
        </div>
        <div class="input-box">
            <label>영어 이름</label>
            <input type="text" v-model="userInfo.engName">
        </div>
        <div class="input-box">
            <label>생년월일</label>
            <input type="date" v-model="userInfo.birthday" @input="getAge">
        </div>
        <div class="input-box">
            <label>성별</label>
            <select v-model="userInfo.sex">
                <option value="남">남</option>
                <option value="여">여</option>
            </select>
        </div>
        <div class="input-box">
            <label>연락처</label>
            <input type="text" v-model="userInfo.userTel">
        </div>
        <div class="input-box">
            <label>주소</label>
            <input type="text" v-model="userInfo.address">
        </div>
        <div class="input-box">
            <label>ID</label>
            <input type="text" v-model="userInfo.id">
        </div>
        <div class="input-box">
            <label>PW</label>
            <input type="text" v-model="userInfo.pw">
        </div>

        <div class="input-box">
            <label>추천인</label>
            <input type="text" v-model="userInfo.joinData.recommendPerson.name">
        </div>
        <div class="input-box">
            <label>추천인 연락처</label>
            <input type="text" v-model="userInfo.joinData.recommendPerson.tel">
        </div>
        <div class="input-box">
            <label>가입 경로</label>
            <select v-model="userInfo.joinData.root">
                <option value="인터넷 광고">인터넷 광고</option>
                <option value="인스타 후기">인스타 후기</option>
                <option value="지인 추천">지인 추천</option>
            </select>
        </div>
    </div>

    <div class="input-wrapper" v-if="value == 'edit'">
        <hr>
        <h4>레벨테스트 정보</h4>
        <div class="input-box" >
            <label>진행 상태</label>
            <input v-model="userInfo.levelTest.status" readonly>
        </div>
        <div class="input-box" >
            <label>고객 연락 유/무</label>
            <input type="text" v-model="userInfo.levelTest.consulting">
        </div>
        <div class="input-box" >
            <label>희망 날짜</label>
            <input type="date"  v-model="userInfo.levelTest.date.want" readonly>
        </div>
        <div class="input-box" >
            <label>확정 날짜</label>
            <input type="date"  v-model="userInfo.levelTest.date.fixed">
        </div>
        <div class="input-box" >
            <label>강사명</label>
            <input type="text"  v-model="userInfo.levelTest.tutor">
        </div>
        <div class="input-box" >
            <label>레벨</label>
            <input type="text"  v-model="userInfo.levelTest.level">
        </div>
        <div class="full">
            <div class="input-box" >
                <label>결과점수 평균</label>
                <input type="text"  v-model="userInfo.levelTest.result.average">
            </div>
            <div class="input-box" >
                <label>1. 발음</label>
                <input type="text"  v-model="userInfo.levelTest.result.pronunciation">
            </div>
            <div class="input-box" >
                <label>2. 문법</label>
                <input type="text"  v-model="userInfo.levelTest.grammer">
            </div>
            <div class="input-box" >
                <label>3. 어휘</label>
                <input type="text"  v-model="userInfo.levelTest.vocabulary">
            </div>
            <div class="input-box" >
                <label>4. 이해</label>
                <input type="text" v-model="userInfo.levelTest.understanding" >
            </div>
            <div class="input-box" >
                <label>5. 유창성</label>
                <input type="text"  v-model="userInfo.levelTest.fluency">
            </div>
        </div>
        <div class="full" >
            <div class="input-box text-box" >
                <label>강사에게 전달사항</label>
                <textarea name="toTutor" id="" cols="20" rows="100" v-model="userInfo.levelTest.toTutor"></textarea>
            </div>
        </div>
        <div class="full" >
            <div class="input-box text-box">
                <label>회원 요청사항</label>
                <textarea name="request" id="" cols="20" rows="100" v-model="userInfo.levelTest.request" readonly> </textarea>
            </div>
        </div>
        <div class="full" >
            <div class="input-box text-box">
                <label>관리자 비고</label>
                <textarea name="request" id="" cols="20" rows="100" v-model="userInfo.levelTest.note" readonly> </textarea>
            </div>
        </div>

    </div>


    <div class="button-wrapper">
        <button class="blue" @click="addUser" v-if="value == 'add'">등록</button>
        <button class="blue" @click="editUser" v-if="value == 'edit'" >수정 완료</button>
        <button class="pink" @click="deleteMember" v-if="value == 'edit'">회원 삭제</button>
        <button class="gray" @click="cancle">취소</button>
  
    </div>

</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.input-wrapper{
    @include flex(space-between, flex-start);
    flex-wrap: wrap;
    width: 100%;
    max-width: 1000px;
    hr{
        width: 100%;
        margin: 20px 0 30px;
    }
    .full{
        width: 100%;
        @include flex(space-between);
        .input-box{
            width: 15.5%;
            &.text-box{
                width: 100%;
                textarea{
                    height: 80px;
                }
            }
            input, select, textarea{
                width: 100%;
                min-width: 0;
            }
        }
         
    }

    .input-box{
        @include flex(space-between, flex-start, column);
        width: 49%;
        margin-bottom: 10px;
        label{
            margin-bottom: 5px;
            font-size: 14px;
            font-family: "SCDream4";
        }
        input, select, textarea{
            border: 1px solid #e7e7e7;
            border-radius: 5px;
            padding: 3px 10px;
            width: 100%;
            min-width: 200px;
            height: 40px;
            color: $black;
        }
        select{
            background: url('@/assets/img/down-arrow.png') no-repeat 95%;
            background-size: 10px;
        }
    }

}
.button-wrapper{
    @include flex(flex-start);
    width: 100%;
    margin: 60px 0 20px;
    height: 40px;
    div{
        width: auto;
    }
    button{
        flex: 1;
        padding: 8px;
        border-radius: 5px;
        width: 150px;
        max-width: 150px;
        &+button{
            margin-left: 10px;
        }
    }

}


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            userDetail: null,
            userInfo:{
                userName: null,
                engName: null,
                age: null,
                birthday: null,
                address: null,
                id: null,
                pw: null,
                sex: null,
                userTel: null,
                membership: '일반',
                today: null,
                consulting: null,
                joinData: {
                    root: null,
                    day: null,
                    recommendPerson:{
                        name: null,
                        tel: null
                    }
                },
                levelTest:{
                    status: '미접수',
                    consulting: false,
                    date:{
                        want: null,
                        fixed: null
                    },
                    tutor: null,
                    level: null,
                    result:{
                        average:null,
                        pronunciation:null,
                        grammer:null,
                        vocabulary:null,
                        understanding:null,
                        fluency:null,
                    },
                    toTutor: null,
                    note: null,
                    request: null
                }
            }
           
        }
    },
    async fetch() {
        if(this.value == 'edit'){
            await this.$axios.$get('/api/detail/user/'+ this.selectData).then(data =>{
                this.userInfo = data;
            }).catch((error)=>{
                console.log(error.data)
            });
        }
    },
    filters:{
        boolean(v){
            if(v == true) return v='유'
            if(v == false) return v='무'
        }
    },
    mounted() {
        this.getDate();
    },
    methods:{   
        getDate(){
            var today = new Date(),
                year = today.getFullYear(),
                month = ('0' + (today.getMonth() + 1)).slice(-2),
                day = ('0' + today.getDate()).slice(-2);

            this.userInfo.joinData.day =  year + '.' + month  + '.' + day;
        },   
        getAge(){
            var birthYear = this.userInfo.birthday.split('-')[0];
            var thisYear = new Date().getFullYear();
            
            this.userInfo.age = thisYear - birthYear +1;
        },
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async addUser(){
            this.cancle('ok');
            
            await this.$axios.post('/api/add/user', this.userInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
        },
        
        async editUser(){
            this.cancle('ok');
            
            await this.$axios.put('/api/edit/user', this.userInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
        },
        async deleteMember(){
            this.$axios.request(`/api/delete/user`, {
                data: {
                    selectData: this.selectData
                },
                method: 'delete'
            }).then(()=>{
                this.$router.go();
            });

            
        }
    }
}
</script>
