<template>
<div class="add-tutor">
    <h4>강사 등록하기</h4>
    <div class="input-wrapper">
        <div class="input-box">
            <label>이름</label>
            <input type="text" v-model="userInfo.tutorName">
        </div>
        <div class="input-box">
            <label>생년월일</label>
            <input type="date" v-model="userInfo.birthday">
        </div>
        <div class="input-box">
            <label>ID</label>
            <input type="text" v-model="userInfo.id">
        </div>
        <div class="input-box">
            <label>PW</label>
            <input type="text" v-model="userInfo.pw">
        </div>
        <div class="input-box">
            <label>성별</label>
            <select v-model="userInfo.sex">
                <option value="남">남</option>
                <option value="여">여</option>
            </select>
        </div>
        <div class="input-box">
            <label>소속 지점</label>
            <select v-model="userInfo.center">
                <option value="강남점">강남점</option>
                <option value="청담점">청담점</option>
                <option value="잠실점">잠실점</option>
            </select>
        </div>
        <div class="input-box">
            <label>국적</label>
            <input type="text" v-model="userInfo.country">
        </div>
        <div class="input-box">
            <label>zoom 주소</label>
            <input type="text" v-model="userInfo.zoomUrl">
        </div>
            <div class="input-box">
            <label>youtube 주소</label>
            <input type="text" v-model="userInfo.youtube">
        </div>
        <div class="input-box">
            <label>수업시간</label>
            <input type="text" v-model="userInfo.time">
        </div>
        <div class="input-box">
            <label>휴식시간</label>
            <input type="text" v-model="userInfo.classInfo.breakTime">
        </div>
        <div class="input-box">
            <label>수업 회당 금액</label>
            <input type="text" v-model="userInfo.classInfo.payPerClass">
        </div>
        <div class="input-box">
            <label>메모</label>
            <input type="text" v-model="userInfo.memo">
        </div>
        <div class="input-box">
            <label>자기소개</label>
            <input type="text" v-model="userInfo.introduce">
        </div>
        <div class="input-box">
            <label>프로필 사진</label>
            <input type="file" >
        </div>
        
        <div class="button-wrapper">
            <button class="blue" @click="addUser" v-if="value == 'add'">등록</button>
            <button class="blue" @click="editUser" v-if="value == 'edit'" >수정 완료</button>
            <button class="pink" @click="deleteMember" v-if="value == 'edit'">회원 삭제</button>
            <button class="gray" @click="cancle">취소</button>
    
        </div>
    </div>
</div>

</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
}
.input-wrapper{
    @include flex(space-between, flex-start);
    flex-wrap: wrap;
    width: 100%;
    max-width: 1000px;
    hr{
        width: 100%;
        margin: 20px 0 30px;
    }
    .full{
        width: 100%;
        @include flex(space-between);
        .input-box{
            width: 15.5%;
            &.text-box{
                width: 100%;
                textarea{
                    height: 80px;
                }
            }
            input, select, textarea{
                width: 100%;
                min-width: 0;
            }
        }
         
    }

    .input-box{
        @include flex(space-between, flex-start, column);
        width: 49%;
        margin-bottom: 10px;
        label{
            margin-bottom: 5px;
            font-size: 14px;
            font-family: "SCDream4";
        }
        input, select, textarea{
            border: 1px solid #e7e7e7;
            border-radius: 5px;
            padding: 3px 10px;
            width: 100%;
            min-width: 200px;
            height: 40px;
            color: $black;
        }
        select{
            background: url('@/assets/img/down-arrow.png') no-repeat 95%;
            background-size: 10px;
        }
    }

}
.button-wrapper{
    @include flex(flex-start);
    width: 100%;
    margin: 60px 0 20px;
    height: 40px;
    div{
        width: auto;
    }
    button{
        flex: 1;
        padding: 8px;
        border-radius: 5px;
        width: 150px;
        max-width: 150px;
        &+button{
            margin-left: 10px;
        }
    }

}



</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            userInfo:{
                tutorName: null,
                birthday: null,
                country: null,
                id: null,
                pw: null,
                sex: null,
                joinDay: null,
                center: null,
                zoomUrl: null,
                youtube: null,
                introduce: null,
                classInfo: {
                    payPerClass: null,
                    breakTime: null,
                },
                gpa: 0,
                profile: null,
                memo: null,
                time: null,
            }
           
        }
    },
    async fetch() {
        if(this.value == 'edit') {
            await this.$axios.$get('/api/detail/tutor/'+ this.selectData).then(data =>{
                this.userInfo = data;
                console.log(this.userInfo)
            }).catch((error)=>{
                console.log(error.data)
            });
        }
    },

    mounted() {
        this.getDate();
    },
    methods:{   
        getDate(){
            var today = new Date(),
                year = today.getFullYear(),
                month = ('0' + (today.getMonth() + 1)).slice(-2),
                day = ('0' + today.getDate()).slice(-2);

            this.userInfo.joinDay =  year + '.' + month  + '.' + day;
        },   
          cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async addUser(){
            this.$nuxt.$emit("popup-close", false)
            this.$router.go();
            
            await this.$axios.post('/api/add/tutor', this.userInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            

        },
        async editUser(){
            this.cancle('ok');
            
            await this.$axios.put('/api/edit/tutor', this.userInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
        },
        async deleteMember(){
            this.$axios.request(`/api/delete/tutor`, {
                data: {
                    selectData: this.selectData
                },
                method: 'delete'
            }).then(()=>{
                this.$router.go();
            });

            
        }
        

    }
}
</script>
