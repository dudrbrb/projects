<template>
<div  class="class-manage-wrapper" v-if="userData !== null" >
    <div v-if="show=='manage'">
        <h4>수강관리 <span>({{userData.userName}} / {{userData.id}})</span> </h4>
        <div class="class-list">
            <div class="table">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th v-for="(data, idx) in tableData" :key="`data${idx}`">
                                {{data.text}}
                            </th>
                            <th>연장신청</th>
                        </tr>
                    </thead>
                    <tbody v-if="classData.length !== 0">
                        <tr v-for="(classes, idx) in classData" :key="`classes${idx}`">
                            <td><p>{{Number(idx) + 1}}</p></td>
                            <td  v-for="(data, idx2) in tableData" :key="`classes${idx}-${idx2}`" :class="data.value">
                                <div>
                                    <p v-if="data.subValue ">
                                        {{ classes[data.value][data.subValue]}}
                                    </p>
                                    <p v-else>
                                        {{classes[data.value]}}
                                    </p>
                                </div>
                            </td>
                            <td><button class="blue" @click="show = 'delay'; selectClass = classes" >신청</button></td>
                        </tr>
                    </tbody>
                    <tbody  v-else>
                        <tr>
                            <td colspan="9">등록된 내용이 없습니다.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="button-wrapper">
                <button class="blue" @click="show = 'apply'" >수강 신청하기</button>
                <button class="gray" @click="cancle">닫기</button>
        
            </div>
        </div>
    </div>
    <div v-if="show=='apply'" >
        <h4>수강신청</h4>
        <div class="apply-form form">
            <div class="input-box">
                <label>이름 (ID)</label>
                <p>{{userData.userName}} ({{userData.id}})</p>
            </div>
            <div class="input-box">
                <label>연락처</label>
                <p>{{userData.userTel}}</p>
                
            </div>
            <div class="input-box">
                <label>수강명</label>
                <v-text-field     ></v-text-field>
            </div>
            <div class="input-box">
                <label>교재</label>
                <v-text-field  ></v-text-field>
            </div>
            <div class="input-box">
                <label>수업시작일</label>
                <v-menu  ref="menu"  v-model="menu"  :close-on-content-click="false"  :return-value.sync="selectClass.startDay"  transition="scale-transition"  offset-y  min-width="auto" >
                    <v-date-picker  v-model="selectClass.startDay"  no-title  scrollable  >
                        <v-spacer></v-spacer>
                        <v-btn text color="primary" @click="menu = false">취소</v-btn>
                        <v-btn  text  color="primary"  @click="$refs.menu.save(selectClass.startDay)" >선택</v-btn>
                    </v-date-picker>
                    <template v-slot:activator="{ on, attrs }">
                        <v-text-field  v-model="selectClass.startDay"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                    </template>
                </v-menu>
            </div>
            <div class="input-box">
                <label>수업시간</label>
                <v-select  :items="timeItems"  v-model="applyInfo.class.time"  ></v-select>

            </div>
            <div class="input-box">
                <label>금액</label>
                <v-text-field suffix="원"></v-text-field>
            </div>
            <div class="input-box">
                <label>할인금액</label>
                <v-text-field suffix="원" ></v-text-field>
            </div>
             <div class="input-box">
                <label>강사</label>
                <v-text-field @click="searchingTutor" v-model="applyInfo.class.tutor" readonly ></v-text-field>
            </div>
            <table v-if="searchTutor">
                <thead>
                    <tr>
                        <th>강사이름</th>
                        <th>성별</th>
                        <th>레벨</th>
                        <th>회원수 (수업)</th>
                        <th>수업기간</th>
                        <th>수업시간</th>
                        <th>횟수</th>
                        <th>등록</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(tutor, idx) in tutorData" :key="'tutor' + idx">
                        <td>{{tutor.tutorName}}</td>
                        <td>{{tutor.sex}}</td>
                        <td>Free</td>
                        <td>2 / 0</td>
                        <td>2022.07 ~ 2023.07.28</td>
                        <td>18:00 ~ 18:10 (10분)</td>
                        <td>23회</td>
                        <td><button class="blue" @click="applyInfo.class.tutor = tutor; searchTutor=false;">선택</button></td>
                    </tr>
                </tbody>
            </table>

            <div class="input-box full">
                <label>메모</label>
                <v-textarea ></v-textarea>
            </div>
        </div>
        <div class="button-wrapper">
            <button class="blue" >등록하기</button>
            <button class="gray" @click="cancle">취소</button>
        </div>

    </div>
    <div v-if="show=='delay'" >
        <h4>연장신청</h4>
        <div class="apply-form form">
            <div class="input-box">
                <label>이름 (ID)</label>
                <p>{{userData.userName}} ({{userData.id}})</p>
            </div>
            <div class="input-box">
                <label>연락처</label>
                <p>{{userData.userTel}}</p>
            </div>
            <div class="input-box">
                <label>수강명</label>
                <p>{{selectClass.title}}</p>
            </div>
            <div class="input-box">
                <label>교재</label>
                <p>{{selectClass.textbook.title}}</p>
            </div>
            <div class="input-box">
                <label>수업시작일</label>
                <v-menu  ref="menu"  v-model="menu"  :close-on-content-click="false"  :return-value.sync="selectClass.startDay"  transition="scale-transition"  offset-y  min-width="auto" >
                    <v-date-picker  v-model="selectClass.startDay"  no-title  scrollable  >
                        <v-spacer></v-spacer>
                        <v-btn text color="primary" @click="menu = false">취소</v-btn>
                        <v-btn  text  color="primary"  @click="$refs.menu.save(selectClass.startDay)" >선택</v-btn>
                    </v-date-picker>
                    <template v-slot:activator="{ on, attrs }">
                        <v-text-field  v-model="selectClass.startDay"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                    </template>
                </v-menu>
            </div>
            <div class="input-box">
                <label>연장신청일</label>
                <v-menu  ref="menu2"  v-model="menu2"  :close-on-content-click="false"  :return-value.sync="delay"  transition="scale-transition"  offset-y  min-width="auto" >
                    <v-date-picker  v-model="delay"  no-title  scrollable  >
                        <v-spacer></v-spacer>
                        <v-btn text color="primary" @click="menu2 = false">취소</v-btn>
                        <v-btn  text  color="primary"  @click="$refs.menu.save(delay)" >선택</v-btn>
                    </v-date-picker>
                    <template v-slot:activator="{ on, attrs }">
                        <v-text-field  v-model="delay"  prepend-icon="mdi-calendar"  readonly  v-bind="attrs"  v-on="on" ></v-text-field>
                    </template>
                </v-menu>
            </div>
            <div class="input-box full">
                <label>메모</label>
                <v-textarea ></v-textarea>
            </div>
        </div>
        <div class="button-wrapper">
            <button class="blue"  @click="cancle">등록하기</button>
            <button class="gray" @click="cancle">취소</button>
        </div>

    </div>
</div> 



</template>
<style lang="scss" scoped>
h4{
    font-size: 24px;
    margin-bottom: 20px;
    width: 100%;
    span{
        font-size: 18px
    }
}
.class-manage-wrapper{
    flex-wrap: wrap;
    width: 100%;
    max-width: 1000px;
    .form{
        width: 755px;
        @include flex();
        flex-wrap: wrap;
        .input-box{
            @include flex(flex-start);
            width: 50%;
            margin-bottom: 10px;
            margin-right: auto;
            label{
                width: 100px;
            }
            p{
                margin-bottom: 0;
            }

            &.full{
                @include flex(flex-start, flex-start);
                width: 100%;
                textarea{
                    width: 100%;
                    height: 100px;
                }
            }
        }
        table{
            margin: 20px 0;
            width: 100%;
            white-space:nowrap;
            border-collapse:collapse;
            border: 1px solid $gray;
            thead{
                background-color: #eeeeee;
            }
            th, td{
                text-align: center;
                padding: 5px 10px;
                border: 1px solid $gray;
                button{
                    padding: 3px 10px;
                    border-radius: 15px
                }
            }
        
        }
    }
   .table{
        width: 100%;
        max-width: 2000px;
        overflow:auto;
        table{
            width: 100%;
            white-space:nowrap;
            border-collapse:collapse;
            background-color: $white;
            tr{
                td{
                    text-align: center;
                    padding: 8px 10px;
                    border: 0;
                    border-collapse : collapse;
                    word-break: keep-all;
                    white-space: nowrap;
                    border: 1px solid #ebebeb;
                }
            }
    
            thead{
                border: 1px solid #ebebeb;
                background-color: #f3f3f3;
                border-radius: 5px;
                tr{
                    th{
                        padding: 10px 15px;
                        border-left: 1px solid #e6e6e6;
                        &:first-child{
                            padding: 10px;
                        }
                    }
                }
            }
            tbody{
                border: 1px solid #eaeaea;
                tr{
                    height: auto;
                    td{
                        p{
                            margin-bottom: 0;
                        }
                        button{
                            padding: 3px 10px;
                            border-radius: 20px;
                        }
                    }
                }
            }
        }
   }

}
.button-wrapper{
    @include flex(flex-end);
    width: 100%;
    margin: 150px 0 20px;
    height: 40px;
    
    div{
        width: auto;
    }
    button{
        flex: 1;
        padding: 8px;
        border-radius: 5px;
        width: 150px;
        max-width: 150px;
        &+button{
            margin-left: 10px;
        }
    }

}

.form + .button-wrapper{
    margin-top: 80px;
}


</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            userData:null,
            tutorData: null,
            classData: [],
            tableData:[
                {text: '신규 / 연장', value: 'extension'},
                {text: '정규수업 시작일', value: 'startDay'},
                {text: '시간', value: 'time'},
                {text: '요일', value: 'week'},
                {text: '남은 횟수', value: 'attendance', subValue: 'remain'},
                {text: '정규 강사', value: 'tutor'},
                {text: '결제', value: 'payment', subValue: 'method'},
            ],
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
            show: 'manage',
            menu: false,
            menu2: false,
            delay: null,
            
            applyInfo:{
                student:{
                    userName: null,
                    id: null,
                    tel: null
                },
                tutor: null,
                class:{
                    day:  (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                    time: null,
                    week: null,
                    runningTime: null,
                    tutor: null
                }
            },
            searchTutor: false,
            selectClass: null

           
        }
    },
    async fetch() {
        await this.$axios.$get('/api/detail/user/'+ this.selectData).then(data =>{
            this.userData = data;
            this.$axios.$get('/api/detail/class/bystudent/'+ data._id).then(data2 =>{
                this.classData.push(data2);
                console.log(this.classData)
            }).catch((error)=>{
                console.log(error.data2)
            });
        }).catch((error)=>{
            console.log(error.data)
        });

    },

    mounted() {

    },
    methods:{  
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        async searchingTutor(){
            await this.$axios.$get('/api/tutor').then(data =>{
                this.tutorData = data;
            }).catch((error)=>{
                console.log(error.data)
            });

            this.searchTutor = true;

        }
    }
}
</script>
