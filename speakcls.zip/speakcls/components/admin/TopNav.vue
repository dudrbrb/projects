<template>
    <div class="top-nav-wrapper" v-if="subMenuList !== null">
        <nav>
            <ul class="menu">
                <li v-for="(menu, idx) in subMenuList" :key="`menu${idx}`">
                    <nuxt-link :to="menu.to">{{menu.menuName}}</nuxt-link >
                </li>
            </ul>
        </nav>
    </div>
</template>
<style lang="scss" scoped>
.top-nav-wrapper{
    nav{
        padding: 0 20px 20px;
        width: auto;
        margin-top: -20px;
        margin-bottom: 10px;
        ul{
            @include flex(flex-start);
            padding-left: 0;
            li{
                &+li{
                    margin-left: 10px;
                }
                a{
                    word-break: keep-all;
                    white-space: nowrap;
                    display: inline-block;
                    color: $black;
                    font-size: 14px;
                    border: 1px solid #dee5e9;
                    padding: 3px 10px;
                    border-radius: 5px;
                    background-color: #f1f4f67a;
                }
            }
        }
    }
}

</style>
<script>
export default {
    name: 'TopNav',
    props:['subMenuList'],
    data(){
        return {
            menuList: null
        }
    },
    created() {
        this.getData();
      
    },
     watch:{
        '$route' (to, from) {
            this.subMenuList = null;
            this.getData();
        }
    },
    
    methods:{
        getData(){
            this.$nuxt.$on('topNav', (data) => {
                this.menuList = data;
            });
        }

    }
}
</script>