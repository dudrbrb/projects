<template>
<div>
    <div class="tool-wrapper left" v-if="memberValue == 'free-class'" :class="memberValue">
        <div class="search-wrapper">
            <b>검색하기</b>
            <div class="search-box">
                <div class="select-wrapper">
                    <input class="select" name="freeClassFilter" id="freeClassFilter" v-model="search.tagKor" readonly @click="search.open = !search.open" :class="{act: search.tagKor !== '선택'}">
                    <ul class="options" v-if="search.open">
                        <li v-for="(filter, idx) in freeClassFilter" :key="`filter${idx}`" @click="selectOption(filter.text, filter.value)" >
                            {{filter.text}}
                        </li>
                    </ul>
                </div>
            </div>
        </div> 
    </div>
    <div class="tool-wrapper" v-else>
        <Popup v-if="popup.open" :path="path" :value="popup.value" :selectData="editPopup.data"></Popup>
        <div class="search-wrapper">
            <b>검색하기</b>
            <div class="search-box">
                <div class="select-wrapper">
                    <input class="select" name="searchTag" id="searchTag" v-model="search.tagKor" readonly @click="search.open = !search.open" :class="{act: search.tagKor !== '선택'}">
                    <ul class="options" v-if="search.open">
                        <li v-for="(filter, idx) in memberFilter" :key="`filter${idx}`" @click="selectOption(filter.text, filter.value)" >
                            {{filter.text}}
                        </li>
                    </ul>
                </div>
                <input type="text" id="searchText" v-model="search.text" :class="{act: search.text !== null}">
                <button @click="searchEvent">검색</button>
            </div>
        </div> 
        <div class="button-wrapper">
            <button id="addMember" @click="openPopup('add')" class="blue">추가</button>
            <button id="deleteMember" @click="deleteMember" class="red">삭제</button>
        </div>
    </div>

</div>


</template>
<style lang="scss" scoped>
.tool-wrapper{
    @include flex(center, flex-end);
    padding: 20px;
    width: 100%;
    margin-bottom: 20px;
    &.left{
        @include flex(flex-start);
        width: 100%;
        .search-wrapper{
            flex-wrap: nowrap;
            b{
                margin-right: 30px;
                margin-bottom: 0;
            }
            .search-box{
                .select-wrapper{
                    width: 150px;
                    input{ 
                    }
                }
            }
        }
    }
    .search-wrapper{
        @include flex(flex-start);
        flex-wrap: wrap;
        b{
            width: 100%;
            margin-bottom: 7px;
        }
        .search-box{
            @include flex(flex-start);
            input{
                background-color: $white;
                padding: 3px 10px;
                border-radius: 5px;
                height: 30px;
                text-align: right;
                border: 1px solid #c9cfd3;
                position: relative;
                margin-right: 10px;
                font-size: 14px;
                &:focus, &.act{
                    border: 1px solid  #027fd4;
                }
            }
            .select-wrapper{
                position: relative;
                width: 100px;
                margin-right: 5px;
                input.select{
                    width: 100%;
                    text-align: left;
                    cursor: pointer;
                    background: url('@/assets/img/input-arrow.png') no-repeat 95%;

                }
                .options{
                    position: absolute;
                    background-color: $white;
                    box-shadow: $shadow;
                    padding: 0;
                    width: 100%;
                    border: 1px solid $lightGray;
                    z-index: 1;
                    padding: 10px 0;
                    li{
                        font-size: 14px;
                        padding: 0 10px;
                        cursor: pointer;
                        line-height: 30px;
                        &:hover{
                            background-color: #f1f4f6d0;
                        }
                    }
                }
            }
            button{
                @include blue-button();
                padding: 3px 10px;
                border-radius: 5px;
                height: 30px;
            }
            
        }
    }
    .button-wrapper{
        margin-left: auto;
        button{
            padding: 3px 10px;
            border-radius: 5px;
            height: 30px;
            color: $white;
        }
    }

}
</style>
<script>
import Popup from '@/components/admin/Popup.vue'
export default {
    name: 'SearchTool',
    components:{Popup},
    props:['selectData', 'editPopup', 'memberValue'],
    data(){
        return {
            path: null,
            search:{
                tag: 'null',
                tagKor: '선택',
                text: null,
                open: false
            },
            popup:{
                open: false,
                path: null,
                value: null
            },
            memberFilter:[
                {text: '이름', value: 'userName'},
                {text: '연락처', value: 'userTel'},
                {text: '스픽클 ID', value: 'userID'},
            ],
            freeClassFilter:[
                {text: '전체', value: 'all'},
                {text: '당일 무료수업', value: 'today'},
                {text: '이전 무료수업', value: 'last'},
            ]
        }
    },
    mounted() {
        this.$nuxt.$on("popup-close", v =>{
            this.popup.open = false;
        })

        var getPath = this.$route.path.split('/');
        this.path = getPath[getPath.length -1];

    },
    watch:{
        editPopup:{
            deep: true,
            handler(e){
                if( e.open == false) return
                else this.openPopup('edit');
            }
        },
    },
    methods:{       
        searchEvent(){
            if(this.search.text == null) return alert('검색어를 입력해주세요.') 
            // this.$router.push({ path: '/member', query: {tag: this.search.tag, text: this.search.text} });
            this.$axios.$get('/api/search?tag=' + this.search.tag + '&text=' + this.search.text).then(data =>{
                console.log(data)
                this.userData = data;
            }).catch((error)=>{
                console.log(error.data)
            });
        },
        async deleteMember(){
            if(this.selectData.lenght == 0) return;
            if(this.path == 'student'){
                this.selectData.forEach(e=>{
                    this.$axios.request(`/api/delete/user`, {
                        data: {
                            selectData: e
                        },
                        method: 'delete'
                    }).then(()=>{
                        this.$router.go();
                    });
    
                })
                return
            }
            if(this.path == 'tutor'){
                this.selectData.forEach(e=>{
                    this.$axios.request(`/api/delete/tutor`, {
                        data: {
                            selectData: e
                        },
                        method: 'delete'
                    }).then(()=>{
                        this.$router.go();
                    });
    
                })
                return
            }
            
            
        },
        selectOption(t, v){
            this.search.tagKor = t;
            this.search.tag = v; 
            this.search.open = false;
        },
        openPopup(v){
            this.popup.open = true;
            this.popup.value = v;
            this.popup.path = this.path;
        }
        
    }
}
</script>
