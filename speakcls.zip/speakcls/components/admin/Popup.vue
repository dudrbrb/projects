<template>
<div class="popup-wrapper" @click="closePopup($event)">
    <div class="popup">
        <!-- 회원관리 -->
        <AddMember  v-if="(path=='student') && (value=='add' || value=='edit')" :value="value" :selectData="selectData"></AddMember>
        <AddTutor  v-if="path == 'tutor'" :value="value" :selectData="selectData"></AddTutor>
        <Leveltest  v-if="path=='student' && value=='leveltest'" :selectData="selectData"></Leveltest>
        <ClassManagement  v-if="path=='student' && value=='class'" :selectData="selectData"></ClassManagement>
        
        <!-- 수업관리 -->
        <Apply  v-if="path=='classes' && value=='apply' " :selectData="selectData"></Apply>
        <Change  v-if="path=='classes' && value=='change'" :selectData="selectData"></Change>
        <Refund  v-if="path=='classes' && value=='refund'" :selectData="selectData"></Refund>
        <LongTermHold  v-if="path=='classes' && value=='longterm-hold'" :selectData="selectData"></LongTermHold>
        <PaymentStatus  v-if="path=='classes' && value=='payment-status'" :selectData="selectData"></PaymentStatus>

        <!-- 무료수업관리 -->
        <EditFreeClass  v-if="path=='classes' && value=='edit-free-class'" :selectData="selectData"></EditFreeClass>
        <FreeClassStatus  v-if="path=='classes' && value=='status'" :selectData="selectData"></FreeClassStatus>

    </div> 
</div>

</template>
<style lang="scss" scoped>
.popup-wrapper{
    background-color: $popupBg;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 9999;
    @include flex();
    *{font-size: 14px;}
    .popup{
        background-color: $white;
        border-radius: 5px;
        padding: 30px 30px 0 30px;
        width: auto;
        min-width: 350px;
        max-height: 85vh;
        overflow-y: scroll;
    }

}
</style>
<script>

// 회원관리
import AddMember from '@/components/admin/popupContents/member/AddMember.vue';
import AddTutor from '@/components/admin/popupContents/member/AddTutor.vue';
import Leveltest from '@/components/admin/popupContents/member/Leveltest.vue';
import ClassManagement from '@/components/admin/popupContents/member/ClassManagement.vue';
// 수업관리
import Change from '@/components/admin/popupContents/class/Change.vue';
import Refund from '@/components/admin/popupContents/class/Refund.vue';
import Apply from '@/components/admin/popupContents/class/Apply.vue';
import LongTermHold from '@/components/admin/popupContents/class/LongTermHold.vue';
import PaymentStatus from '@/components/admin/popupContents/class/PaymentStatus.vue';

//무료수업
import EditFreeClass from '@/components/admin/popupContents/class/EditFreeClass.vue';
import FreeClassStatus from '@/components/admin/popupContents/class/FreeClassStatus.vue';

export default {
    name: 'Popup',
    props:['value', 'path', 'selectData'],
    components: {AddMember, AddTutor, Leveltest, ClassManagement, Refund, LongTermHold, Change, PaymentStatus, Apply, EditFreeClass, FreeClassStatus}, 
    data(){
        return {
            userInfo:{
                userName: null,
                userEngName: null,
                userAge: null,
                userBirthday: null,
                userId: null,
                userPw: null,
                userSex: null,
                userTel: null,
                membership: '일반',
                today: null,
                joinRoot: null,
                recommendPersonName: null,
                recommendPersonTel: null,
            }
           
        }
    },
    mounted() {
        this.getDate();
    },
    methods:{   
        getDate(){
            var today = new Date(),
                year = today.getFullYear(),
                month = ('0' + (today.getMonth() + 1)).slice(-2),
                day = ('0' + today.getDate()).slice(-2);

            this.userInfo.today =  year + '.' + month  + '.' + day;
        },   
        getSelectUser(){

        },
        cancle(v){
            this.$emit("popup-close", false)
            if(v == 'ok'){
                this.$router.go();
            }
        },
        async addUser(){
            await this.$axios.post('/api/add/user', this.userInfo)
            .then( (response) => {
                console.log(response);
                this.cancle('ok')
            })
            .catch( (error) => {
                console.log(error);
            });
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.$nuxt.$emit("popup-close", false)
            }
        }

    }
}
</script>
