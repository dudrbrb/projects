import Vue from 'vue'
import { Swiper, SwiperSlide } from 'vue-awesome-swiper' 
import 'swiper/css/swiper.css' 


Vue.component('Swiper', Swiper)
Vue.component('SwiperSlide', SwiperSlide)

