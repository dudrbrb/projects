import Vue from 'vue'
import DraggableCal from 'vue-draggable-cal';

Vue.component('DraggableCal', DraggableCal)

