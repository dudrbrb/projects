<template>
  <v-app>
    <div id="adminWrapper">
      <Nav />
      <TermsOfUse keep-alive />
      <div id="container">
        <div class="page-title">
            <h1>{{title}}</h1>
        </div>
        <Nuxt id="adminPage"/>
      </div>
    </div>
  </v-app>
</template>

<style lang="scss">
#adminWrapper{
    #container{
        @include flex(flex-start, flex-start, column);
        background: $lightGray;
        width: 100%;
        min-height: 100vh;
        padding: 50px 50px 50px 250px;
        .page-title{
            @include flex(space-between);
            margin-bottom: 30px;
            width: 100%;
        }
        #adminPage{
            width: 100%;
            min-height: 100%;
            background-color: $white;
            border-radius: 5px;
            padding-bottom: 30px;
            &.chart-wrapper{
                background: none;
            }
        
            .table-wrapper{
                width: 100%;
                max-width: 2000px;
                overflow:auto;
                table{
                    width: 100%;
                    white-space:nowrap;
                    border-collapse:collapse;
                    background-color: $white;
                    tr{
                        td{
                            text-align: center;
                            padding: 8px 10px;
                            border: 0;
                            border-collapse : collapse;
                            word-break: keep-all;
                            white-space: nowrap;
                        }
                    }
            
                    thead{
                        border: 1px solid #ff469c;
                        background-color: $pink;
                        border-radius: 5px;
                        tr{
                            th{
                                padding: 10px 15px;
                                color: $white;
                                border-left: 1px solid #ff469c;
                                &:first-child{
                                    padding: 10px;
                                }
                            }
                        }
                    }
                    tbody{
                        border: 1px solid #eaeaea;
                        tr{
                            height: auto;
                            &:nth-child(even){
                                background-color: #f8f8f8e7;
                            }
                            &:hover{
                                td{ 
                                    p, span{
                                        color: $pink;
                                    }
                                    &.userName, &.tutorName{
                                        p{
                                            text-decoration-color:$pink;
                                        }
                                    }

                                }
                            }
                            td{
                                border-left: 1px solid #eaeaea;
                                li, p, button{
                                    font-size: 14px;
                                    margin: 0;
                                }
                                button{
                                    padding: 3px 10px;
                                    border-radius: 20px;
                                }
                                input[type=checkbox]{
                                    width: 15px;
                                    height: 15px;
                                }
                                &.userName, &.tutorName{
                                    cursor: pointer;
                                    p{
                                        text-decoration: underline;
                                        text-underline-position: under;
                                        text-decoration-color: rgb(191, 191, 191);
                                    }
                                }
                                &.history{
                                    cursor: pointer;
                                }
                                &.coupon{
                                    ul{
                                        overflow: hidden;
                                        max-height: 20px;
                                        cursor: pointer;
                                        position: relative;
                                        padding-right: 20px;
                                        li{
                                            &:first-child::after{
                                                content: '';
                                                background: url('@/assets/img/down-arrow.png') no-repeat center;
                                                background-size: 13px;
                                                width: 20px;
                                                height: 20px;
                                                position: absolute;
                                                right: -3px;
                                                top: 0;
                                            }
                                            &+li{
                                                margin-top: 5px;
                                            }
                                            span{
                                                display: block;
                                                font-size: 12px;
                                                color: #5f5f5f;
                                            }
                                            &.use{
                                                text-decoration: line-through;
                                                color: #808080;
                                                span{
                                                    color: #808080;
                                                }
                                            }
                                        }
                                        &.open{
                                            max-height: 1000px;
                                            li::after{
                                                transform: rotate(180deg);
                                            }
                                        }
            
                                    }
                                }
                            }
                        }
                    }
            
                }
            }
        }
    }
}
</style>
<script>
import Nav from '@/components/admin/Nav.vue';
import TermsOfUse from '@/components/TermsOfUse.vue';

export default {
    name: 'AdminLayout',
    components: {Nav, TermsOfUse},
    data () {
        return {
        title: null,
        topNavData: null
        }
    },
    watch:{
        '$route' (to, from) {
            this.getTitle();
        }
    },
    created(){
        this.getTitle();
    },
    methods:{
        getTitle(){
            this.$nuxt.$on('pageTitle', (data) => {
                this.title = data;
            });

        }
    }
}
</script>
