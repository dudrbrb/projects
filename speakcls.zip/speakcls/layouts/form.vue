<template>
    <div id="wrapper" :class="{ios: $device.isMacOS}" >
        <TopNav :login="login"  :width="width" keep-alive />
        <TermsOfUse keep-alive />
        <Nuxt  class="form" :class="{login: login}" :login="login" :width="width" :style="{marginTop : (login?'50px' : 0)}" keep-alive />
        <Footer v-if="$route.path !== '/login'&& $route.path !== '/join'" />
    </div>
</template>


<style lang="scss">
.form{
    header, section{
        position: relative;
        background: #f6f5fb;
        width: 100%;
        height: 100%;
        max-width: 560px;
        margin: 130px auto 80px;
        @include flex(center, flex-start);
        *{
            font-family: "SCDream5";
        }
        >div{
            width: 100%;
            padding: 50px 40px;
            @include flex(center, center, column);
        }
        h1{
            font-size: 34px;
            line-height: 50px;
            margin: 0 0 30px;
            text-align: center;
        }
        h2 {
            font-size: 30px;
            line-height: 40px;
            margin: 0 0 50px;
            text-align: center;
        }
        .select-how+h2{
            margin-top: 60px;
            font-size: 26px;
            line-height: 34px;
        }
        li, a, span, div, input, input::placeholder{
            font-size: 16px;
            line-height: 22px;
        }
        p, label{
            font-size: 14px;
            line-height: 20px;
        }
        input{
            width: 100%;
            background-color: $white;
            height: 55px;
            margin-bottom: 10px;
            padding: 0 20px;
            border-radius: 8px;
        }
        label{
            color: #6b6a6f;
            margin-right: 10px;
        }
        input::placeholder{
            color: $gray;
        }
        input[type=checkbox]{
            display: none;
        }
        input[type=checkbox]+label.checkbox{
            width: 20px;
            min-width: 20px;
            height: 20px;
            margin-right: 5px;
            border: 2px solid #c9c9c9;
        }
        input[type=checkbox]:checked+label.checkbox{
            background: url('@/assets/img/login/checkbox.png') no-repeat center;
            background-size: cover;
            border: none;
        }
        input[type=checkbox]+label.checkbox + label{
            margin-right: 15px;
        }
        input[type='radio']{
            appearance: none;
            width: 18px;
            height: 19px;
            border: 3px solid $gray;
            margin: 0;
            padding: 0;
            border-radius: 50%;
            margin-right: 10px;
            background: rgba(255, 255, 255, 0);
        }
        input[type='radio']:checked {
            border-color: $pink;
            background-color: $pink;
        }
        input:read-only{
            background-color: rgb(239, 239, 239);
        }
        button{
            width: 100%;
            height: 60px;
            line-height: 60px;
            margin: 30px 0 10px;
            border-radius: 35px;
            font-size: 18px;
        }
        button.gray{
            background-color: #e3e3ec;
        }
        button.gray.pink,
        button.pink{
            color: $white;
            background-color: $pink;
        }
        .font3{
            font-family: "SCDream3";
        }
        .font6{
            font-family: "SCDream6";
        }
        .flex-wrapper{
            @include flex(flex-start);
            width: auto;
            margin : 5px auto 15px 0;
            div{
                @include flex(flex-start);

            }
        }
        .select-how{
            width: 100%;
            position: absolute;
            top: 0;
            @include flex();
            >div{
                width: 50%;
                text-align: center;
                height: 60px;
                line-height: 60px;
                border-bottom: 2px solid $gray;
                font-family: "SCDream6";
                cursor: pointer;
                &.act{
                    border-color: $pink;
                }
            }
        }

        .sns-list{
            @include flex();
            flex-wrap: wrap;
            div{
                width: 65px;
                height: 65px;
                cursor: pointer;
                img{
                    width: 100%;
                }
                &+div{
                    margin-left: 10px;
                }
            }
            p{
                width: 100%;
                margin: 30px 0 0;

            }
        }
        .border{
            width: 100%;
            text-align: center;
            margin: 40px 0;
            hr{
                width: 100%;
                margin-top: -10px;
            }
            p{
                background-color: #f6f5fb;
                display: inline-block;
                width: auto;
                margin: 0 auto;
                z-index: 1;
                padding: 0 15px;
            }
    
        }
        
    }
    .confirmPopup{
        position:fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: #0000005d;
        z-index: 99999;
        display: flex;
        justify-content: center;
        align-items: center;
        >div{
            background-color: $white;
            width: 350px;
            height: 180px;
            border-radius: 10px;
            text-align: center;
            @include flex(center, center, column);
            padding: 0 15px;
            >div{
                font-size: 20px;
                margin-top: 20px;
                button{
                    background-color: $pink;
                    color: $white;
                    margin: 0;
                    padding: 10px 20px;
                    border-radius: 10px;
                    font-size: 18px;
                    line-height: 33px;
                    font-weight: 600;
                    width: auto;
                    height: 50px;
                    
                }
            }
        }

    }

}
@media screen and (max-width: 767px){
.form{
    background: #f6f5fb;
    // min-height: 100vh;
    header, section{
        width: 100%;
        max-width: 1000px;
        margin: 0;
        padding: 70px 20px 20px;
        overflow: scroll;
        -ms-overflow-style: none;
        &::-webkit-scrollbar{
            display:none;
        }
        >div{
            width: 100%;
            // min-height: 100vh;
            padding: 0;
            margin: 0;
            h1{
                font-size:28px;
                line-height: 30px;
                margin:  30px 0;
            }
            h2{
                font-size: 26px;
                line-height: 32px;
                margin: 0 0 30px;
            }
            .select-how+h2{
                margin-top: 70px;
                font-size: 26px;
                line-height: 34px;
            }
             input, input::placeholder{
                 font-size: 16px;
                 line-height: 20px
             }
            p, li, a, span, label, div{
                font-size: 14px;
                line-height: 18px
            }
            input{
                height: 55px;
            }
            input[type='radio']{
                width: 14px;
                height: 15px;
            }   
            input[type=checkbox]+label.checkbox{
                width: 18px;
                min-width: 18px;
                height: 18px;
            }
            
            button{
                height: 55px;
                line-height: 55px;
                font-size: 20px;
                margin: 30px 0 10px;
            }
            .border{
                margin: 30px 0;
                hr{
                    margin-top: -11px;
                }
            }
            .sns-list{
                div{
                    width: 55px;
                    height: 55px;
                }
                p{
                    margin-top: 30px;
                }
            }

        }
    }
}

}

</style>
<script>
import TopNav from "@/components/TopNav.vue";
import Footer from "@/components/Footer.vue";
import TermsOfUse from "@/components/TermsOfUse.vue";
export default {
    data() {
        return {
            login: false,
            width: null
        };
    },
    components: {
        TopNav,
        Footer,
        TermsOfUse
    },
    watch:{
        '$route' (to, from) {
			this.getCookie();
		}
    },
    mounted(){
        this.getCookie();
        this.handleResize();
        window.addEventListener('resize', this.handleResize);
    },

    methods: {
        getCookie(){
			this.login = this.$cookies.get('login');
		},
        handleResize() {
            this.width = window.innerWidth;
            this.$nuxt.$emit('commonData',{'login': this.login, 'width': this.width})    
        },
    },
    beforeDestroy(){
        window.addEventListener('resize', this.handleResize);
    }
};
</script>