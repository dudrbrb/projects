<template>
    <div id="wrapper" :class="{ios: $device.isMacOS}" >
        <TopNav :login="login" :width="width" keep-alive  />
        <TermsOfUse keep-alive />
        <Nuxt class="mypage mb" v-if="$device.isMobileOrTablet" keep-alive />
        <div class="mypage-wrapper" v-else keep-alive >
            <div class="side-menu">
                <nuxt-link :to="'/mypage'" class="logo"><img :src="require('@/assets/img/logo-w.webp')" alt="스픽클 로고"></nuxt-link>
                <ul>
                    <li> <nuxt-link :to="'/mypage/schedule'">스케쥴 </nuxt-link></li>
                    <li> <nuxt-link :to="'/mypage/feedback'"> 튜터 피드백</nuxt-link></li>
                    <li> <nuxt-link :to="'/mypage/'"> 이용안내</nuxt-link></li>
                    <li> <nuxt-link :to="'/mypage/class/list/?retake=true'">재수강 신청 </nuxt-link></li>
                    <li @click="subMenu = true" class="onlyLi" :class="{margin0: subMenu}"> 무료 수업 </li>
                    <ul class="sub-menu" v-if="subMenu">
                        <li><nuxt-link :to="'/level-test'">신청하기</nuxt-link></li>
                        <li><nuxt-link :to="'/mypage/free-class/result'">결과확인</nuxt-link></li>
                    </ul>
                    <li> <nuxt-link :to="'/level-test'">레벨테스트 </nuxt-link></li>
                    <li> <nuxt-link :to="'/'" @click="removeCookies('로그아웃')">로그아웃</nuxt-link></li>
                    
                    </ul>
            </div>
            <Nuxt class="mypage" />
        </div>
        <Footer />
    </div>
</template>


<style lang="scss">
.mypage-wrapper{
    width: 100%;
    max-width: 1180px;
    margin: 80px auto;
    position: relative;
    @include flex(flex-start,flex-start);
    background-color: #c63967 ;
    border-radius: 20px;
    padding: 30px;
    margin-top: 100px;
    .mypage{
        border-radius: 20px;
        background-color: $white;
        min-height: 70vh;
        >*{
            padding-left: 20px;
            padding-right: 20px;
        }
        .page-title{
            h2{
                font-size: 28px;
            }
             button#back{
                display: none;
                
            }
        }
        .component{
            width: 50%;
            &.full{
                width: 100%;
            }
            .component{
                width: 100%;
            }
            &+.component{
                margin-left: 30px;
            }
        }
    }
    .side-menu{
        padding-top: 20px;
        padding: 20px 40px 0 20px;
        width: 18%;
        .logo{
            display: inline-block;
            width: 100%;
            margin-bottom: 40px;
            position: relative;
            img{
                margin-left: 50%;
                transform: translateX(-50%);
                width: 45px;
            }
        }
        ul{
            width: 150px;
            li{
                margin-bottom: 20px;
                width: 100%;
                cursor: pointer;
                &.margin0{
                    margin-bottom: 0;
                }

            }
            
            .sub-menu{
                margin: 5px 0 20px;
                li{
                    font-family: "SCDream4";
                    margin-bottom: 0;
                    a{
                        padding: 3px 0 3px 20px;
                        font-size: 18px;
                    }
                }
            }
            a, .onlyLi{
                width: 100%;
                color: $white;
                font-family: "SCDream4";
                padding: 3px 10px;
                display: inline-block;
                font-size: 20px;
                &:hover,
                &.act{
                    background-color: $white;
                    border-radius: 20px;
                    color: $pink;
                }
            }
        }

    }
    #container{
        width: 82%;
        padding: 30px 0 ;
        .pc-wrapper{
            @include flex(center, flex-start);
            .column-wrapper{
                @include flex(flex-start, flex-start, column);
                width: 50%;
                .component{
                    width: 100%;
                    &+.component{
                        margin-left: 0;
                    }
                }
            }
        }
    }
}
.mypage.mb{
    padding-top: 105px;
    header, section{
        position: relative;
        width: 100%;
        height: 100%;
        // max-width: 560px;
        margin: 0 auto;
        padding: 0 20px;
        >div{
            width: 100%;
        }
    }
    .page-title{
        position: relative;
        width: 100%;
        height: 60px;
        // position: fixed;
        z-index: 5;
        background-color: #fefefe;
        top: 0;
        left: 0;
        h2{
            width: 100%;
            text-align: center;
            line-height: 60px;
            font-size: 18px;
            font-family: "SCDream4";
            letter-spacing: -1.5px;
        }
        button#back{
            width: 60px;
            height: 60px;
            background: url('@/assets/img/arrow.png') no-repeat center;
            transform: rotate(180deg);
            position: absolute;
            top: 0;
            left: 0;

        }
    }
    section{
        padding: 0 20px 80px;
        button.black{
            width: 100%;
            height: 55px;
            background-color: rgb(48, 48, 48);
            color: $white;
            border-radius: 5px;
            font-size: 18px;
        }
        p, li, a, span, label, div{
            font-size: 16px;
        }
        &.notice{
            h3{
                font-size: 20px;
                margin-top: 30px;
            }
            ul{
                margin-top: 5px;
                li{
                    width: 100%;
                    line-height: 50px;
                    border-bottom: 1px solid #e7e7e7;
                    @include flex(space-between);
                    position: relative;
                    span{
                        color: $pink;
                        position: absolute;
                        right: 20px;
                    }
                    a{
                        width: 100%;
                        padding-right: 25px;
                        background: url('@/assets/img/arrow.png') no-repeat right center;
                    }
                }
            }
        }

    }
}

</style>
<script>
import TopNav from "@/components/TopNav.vue";
import Footer from "@/components/Footer.vue";
import TermsOfUse from "@/components/TermsOfUse.vue";
export default {
    data() {
        return {
            login: false,
            width: null,
            subMenu: false

        };
    },
    components: {
        TopNav,
        Footer,
        TermsOfUse
    },
    watch:{
        '$route' (to, from) {
			this.getCookie();
            this.subMenu = false;
		}
    },
    mounted(){
        this.getCookie();
        this.handleResize();
        window.addEventListener('resize', this.handleResize);
   
    },

    methods: {
        getCookie(){
			this.login = this.$cookies.get('login');
        },
        handleResize() {
            this.width = window.innerWidth;
            this.$nuxt.$emit('commonData',{'login': this.login, 'width': this.width})   
        
        },
        removeCookies(v) {
            if(v !== '로그아웃') return false
            this.$cookies.remove('login');
            this.$router.push({ path: '/' });
			this.$router.go();
        }
    },
    beforeDestroy(){
        window.addEventListener('resize', this.handleResize);
    }
};
</script>