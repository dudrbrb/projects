<template>
    <div id="wrapper" :class="{ios: $device.isMacOS}">
        <TermsOfUse keep-alive />
        <TopNav :login="login"  :width="width" keep-alive />
        <Nuxt  class="web" :class="{login: login}" keep-alive />
        <Footer />
    </div>
</template>


<style lang="scss">
.web{
    width: 100%;
    header, section{
        position: relative;
        @include flex;
        max-width: 2000px;
        width: 100%;
        >div{
            width: 100%;
            max-width: 980px;
            margin: 80px auto;
            position: relative;
            h1 {
                font-size: 40px;
                line-height: 55px;
                margin-bottom: 15px;
            }
            h2{
                font-size: 45px;
                line-height: 55px;
                margin-bottom: 15px;
            }
            p, li, a, span, button{
                font-size: 24px;
                line-height: 32px;
            }
            input, label{
                font-size: 20px;
            }
            h1+p, h2+p{
                color: $subText;
            }
        }
    }

    @media screen and (max-width: 1024px){

        header, section{
            padding: 0 30px;
            >div{
                h1, h2{
                    font-size: 40px;
                    line-height: 55px;
                    margin-bottom: 15px;
                }
                p, li, a, span{
                    font-size: 22px;
                    line-height: 30px;
                }
            }
        }


    }

    }
    @media screen and (max-width: 767px){
        .web{
            &.login{
                header,section{
                    &:first-child{
                        padding-top: 50px;
                    }
                }
            }
            header, section{
                padding: 0 20px;
                > div{
                    h1{
                        font-size: 38px;
                        line-height: 46px;
                    }
                    h2{
                        font-size:28px;
                        line-height: 34px;
                    }
                    p, li, a, span{
                        font-size: 18px;
                        line-height: 24px
                    }
                }
    
            }
        }

}

</style>

<script>
import TopNav from "@/components/TopNav.vue";
import Footer from "@/components/Footer.vue";
import TermsOfUse from "@/components/TermsOfUse.vue";

export default {
    data() {
        return {
            login: false,
            width: null
        };
    },
    components: {
        TopNav,
        Footer,
        TermsOfUse
    },
    watch:{
        '$route' (to, from) {
			this.getCookie();
		}
    },
    mounted(){
        this.getCookie();
        this.handleResize();
        window.addEventListener('resize', this.handleResize);
    },

    methods: {
        getCookie(){
            this.login = this.$cookies.get('login');
		},
        handleResize() {
            this.width = window.innerWidth;
            this.$nuxt.$emit('commonData',{'login': this.login, 'width': this.width})    
        },
    },
    beforeDestroy(){
        window.addEventListener('resize', this.handleResize);
    }
};
</script>