<template>
  <v-app>
    <div id="wrapper">
      <Nav />
      <div id="container">
        <div class="page-title">
            <h1>{{title}}</h1>
        </div>
        <Nuxt id="page"/>
      </div>
    </div>
  </v-app>
</template>

<style lang="scss">

</style>
<script>
import Nav from '@/components/Nav.vue';
import '@/assets/scss/app.scss';

export default {
    name: 'DefaultLayout',
    components: {Nav},
    data () {
        return {
            title: null,
        }
    },
    watch:{
        '$route' (to, from) {
            this.getTitle();
        }
    },
    created(){
        this.formatDate();
        this.getTitle();
    },
    methods:{
        getTitle(){
            this.$nuxt.$on('pageTitle', (data) => {
                this.title = data;
            });

        },
        formatDate(){
            this.$nuxt.$on('formatDate', (datas) => {
                var dataList = datas[0],
                    target = datas[1],
                    deep = datas[2];

                if(deep == 'deep'){
                    dataList.map(e=>{
                        var year = new Date(e[target].DAY).getFullYear();
                        var month = new Date(e[target].DAY).getMonth() + 1;
                        var date = new Date(e[target].DAY).getDate();

                        e[target].DAY = `${year}-${month}-${date}`
                    })
                } else{
                    dataList.map(e=>{
                        var year = new Date(e[target]).getFullYear();
                        var month = new Date(e[target]).getMonth() + 1;
                        var date = new Date(e[target]).getDate();

                        e[target] = `${year}-${month}-${date}`
                    })

                }
                // console.log(dataList[Object.keys(target)])

                // var date = dataList.filter((data) => { 
                //     return data == target
                // });
                // console.log(date);


            });
        }
    }
}
</script>
