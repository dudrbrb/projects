<template>
    <div class="chart-wrapper">
        <div class="chart-box"><MixedChart></MixedChart></div>
        <div class="chart-box"><AreaChart></AreaChart></div>
        <div class="chart-box"><DoughnutChart></DoughnutChart></div>
        <div class="chart-box"><BarChart></BarChart></div>
        <div class="chart-box"><LineChart></LineChart></div>
    </div>
</template>
<style lang="scss" scoped>
.chart-wrapper{
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    width: 100%;
    max-width: 2000px;
    .chart-box{
        width : 49%;
        background: #fefefe;
        padding: 30px;
        margin-bottom: 30px;
        box-shadow: $shadow;
        border-radius: 5px;
    }
}
</style>
<script>
// 모든 차트는 components/charts/ 에 셋팅하기

import MixedChart from "@/components/charts/Mixed.vue";
import AreaChart from "@/components/charts/Area.vue";
import DoughnutChart from "@/components/charts/Doughnut.vue";
import BarChart from "@/components/charts/Bar.vue";
import LineChart from "@/components/charts/Line.vue";

export default {
    name: 'IndexPage',
    components:{MixedChart, AreaChart, DoughnutChart, BarChart, LineChart},
    data(){
        return {

        }
    },
    created(){
        // 페이지 좌측 상단 제목
        this.$nuxt.$emit("pageTitle", '대시보드')
    },
    mounted(){
    },
    methods:{

    }

  }
</script>