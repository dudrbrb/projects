<template>
    <div class="class-list">
        <div class="tool-wrapper">
            <div class="search-wrapper">
                <v-select outlined  :items="filter" v-model="search.tag" class="small"></v-select>
                <v-text-field outlined  v-model="search.text" class="right"></v-text-field>
                <v-btn depressed @click="searchEvent" class="search-btn" color="primary">검색</v-btn>

                <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="date" 
                transition="scale-transition" offset-y min-width="auto">
                    <template v-slot:activator="{ on, attrs }">
                        <v-text-field outlined v-model="date" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on" :style="{'margin-left': '20px'}"></v-text-field>
                    </template>
                    <v-date-picker v-model="date" no-title scrollable >
                        <v-spacer></v-spacer>
                        <v-btn text color="primary" @click="menu = false">
                            취소
                        </v-btn>
                        <v-btn text color="primary" @click="$refs.menu.save(date)">
                            선택
                        </v-btn>
                    </v-date-picker>
                </v-menu>
                <v-select outlined  :items="timeItems"  class="small" v-model="time" ></v-select>
                <v-btn depressed color="error" @click="formatData" 
                    v-if="search.tag !== '선택' || search.text !== null || filterClasses.replace !== false || filterClasses.retake !== false || date !== null || time !== null">
                    초기화
                </v-btn>
            
                <v-btn depressed color="primary" @click="openPopup($event, 'class-add')" :style="{'margin-left': 'auto'}">무료수업 등록</v-btn>
                <v-btn depressed color="error" @click="deleteUser">선택 삭제</v-btn>
            </div> 
            <div class="button-wrapper">
                <v-btn depressed small :class="{act: filterClasses.replace}" @click="filterClasses.replace = !filterClasses.replace; filterClasses.retake = false">대체수업관리</v-btn>
                <v-btn depressed small :class="{act: filterClasses.retake}" @click="filterClasses.retake = !filterClasses.retake; filterClasses.replace = false">재수강관리</v-btn>
                <v-btn depressed small >수업취소</v-btn>
                <v-btn depressed small >장기홀드</v-btn>
                <v-btn depressed small >카톡 발송</v-btn>
            </div>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>선택</th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`header${idx}`">
                            {{data.text}}
                        </th>
                        <th>환불</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-if="classData == null">
                        <td colspan="17">데이터를 찾을 수 없습니다.</td>
                    </tr>
                    <tr v-for="(classes, idx) in classData" :key="`classes${idx}`">
                        <td class="checkbox"><v-checkbox  color="primary" v-model="selected" :value="classes._id"></v-checkbox></td>
                        <td>{{idx+1}}</td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="data.value" @click="editUser($event, 'class-edit', classes)">
                            <p :class="data.value" @click="openPopup($event, 'class-edit', classes)" >
                                {{data.subValue ? classes[data.value][data.subValue] :classes[data.value]}}
                            </p>
                        </td>
                        <td><v-btn rounded elevation="0" color='primary' @click="openPopup($event, 'class-refund', classes)">신청</v-btn></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</template>
<style lang="scss" scoped>
.class-list{
    table{
        td{
            .CLS_NAME{
                cursor: pointer;
                text-decoration: underline;
                text-underline-position: under;
            }
        }
    }
}
</style>
<script>
export default {
    name: 'StudentList',
    components: {},
    data(){
        return {
            classData : null,
            classData : null,
            leveltestData : null,
            selected: [],
            filter:['선택', 'ID', '이름', '연락처'],
            search: {
                tag : '선택',
                value : '선택',
                text: null
            },
            tableData:[
                {text: '신청일자', value: 'LVT_REG_DATE.DAY'},
                {text: '신규/연장', value: 'LVT_REG_DATE.DAY'},
                {text: '학생 이름', value: 'LVT_CLS_DATA,NAME'},
                {text: '학생 아이디', value: 'LVT_CLS_DATA.ID'},
                {text: '협력사', value: 'CLS_COMPANY'},
                {text: '수업 시작일', value: 'LVT_FIXED_DATE.DAY'},
                {text: '시간', value: 'LVT_FIXED_DATE.TIME'},
                {text: '요일', value: 'LVT_FIXED_DATE.WEEK'},
                {text: '잔여 수업 횟수', value: 'CLS_ATTENDANCE'},
                {text: '출석 /결석', value: 'CLS_ATTENDANCE'},
                {text: '정규 강사 (대체강사)', value: 'LVT_TUTOR'},
                {text: '취소 횟수', value: 'LVT_TUTOR'},
                {text: '결제 방법', value: 'LVT_TUTOR'},
                {text: '결제 상태', value: 'LVT_TUTOR'},
            ],
            popup:{
                value: null,
                data: null,
                open: false
            },
            filterClasses: {
                replace: false,
                retake: false
            },
            date: null,
            time: null,
            menu: false,
            today: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
        }
    },
    async created(){
        // 수업목록 불러오기
        await this.$axios.$get(`/class/list`).then(datas =>{
            this.classData = datas.data;
        }).catch((error)=>{
            console.log(error.data)
        });

        // 좌측 상단 페이지 제목
        this.$nuxt.$emit("pageTitle", '수업관리')
    },
    mounted(){
        this.$nuxt.$on("popup-close", v => {
            this.popup.open = false;
            this.popup.value = null;
        });
    },
    watch:{
        search:{
            deep: true,
            handler(e){
                // 검색시 필커 변경
                if(e.tag == 'ID') e.value = 'CLS_ID'
                if(e.tag == '이름') e.value = 'CLS_NAME'
                if(e.tag == '연락처') e.value = 'CLS_TEL'
            }
        },

    },
    methods:{
        async formatData(){
            // 검색어, 필터 등 초기화
            this.search.tag= '선택';
            this.search.text= null;
            this.filterClasses.replace = false ;
            this.filterClasses.retake = false ;
            this.date = null;
            this.time = null;

            await this.$axios.$get(`/class/list`).then(datas =>{
                this.classData = datas.data;
            }).catch((error)=>{
                console.log(error.data)
            });
        },
        openPopup(e, v, data){
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = data;
        },
        openHistory(){
            alert('준비중입니다');
        },
        editUser(e, v, data){
            if(e.target.classList.contains('CLS_NAME') == false) return
            else this.openPopup(e, v, data)
        },
        deleteUser(){
            this.openPopup( '', 'class-delete', this.selected)
        },
        searchEvent(){
            // 검색 기능
            if(this.search.tag == '선택') return alert('검색 필터를 선택해주세요.') ;
            if(this.search.text == null) return alert('검색어를 입력해주세요.') ;
   
            this.$axios.$get('/class/search',
                {params:{tag: this.search.value, text: this.search.text}},
                { withCredentials: true }).then(res =>{
                    this.classData = res.data;
                    console.log('111', res)
            }).catch((error)=>{
                console.log( error.data)
                if(error.response.status == 404){
                    this.classData = null;
                }

            });
        },
    }

  }
</script>