<template>
    <div class="class-list">
        <div class="tool-wrapper">
            <div class="search-wrapper">
                <v-select outlined  :items="filter" v-model="search.tag" class="small"></v-select>
                <v-text-field outlined  v-model="search.text" class="right"></v-text-field>
                <v-btn depressed @click="searchEvent" class="search-btn" color="primary">검색</v-btn>

                <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="date" 
                transition="scale-transition" offset-y min-width="auto">
                    <template v-slot:activator="{ on, attrs }">
                        <v-text-field outlined v-model="date" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on" :style="{'margin-left': '20px'}"></v-text-field>
                    </template>
                    <v-date-picker v-model="date" no-title scrollable >
                        <v-spacer></v-spacer>
                        <v-btn text color="primary" @click="menu = false">
                            취소
                        </v-btn>
                        <v-btn text color="primary" @click="$refs.menu.save(date)">
                            선택
                        </v-btn>
                    </v-date-picker>
                </v-menu>
                <v-select outlined  :items="timeItems"  class="small" v-model="time" ></v-select>
                <v-btn depressed color="error" @click="formatData" 
                    v-if="search.tag !== '선택' || search.text !== null || date !== null || time !== null">
                    초기화
                </v-btn>
            
                <v-btn depressed color="primary" @click="openPopup($event, 'class-add')" :style="{'margin-left': 'auto'}">수업 등록</v-btn>
                <v-btn depressed color="error" @click="deleteClass">선택 삭제</v-btn>
            </div> 
            <div class="button-wrapper">
    
            </div>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>선택</th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`header${idx}`">
                            {{data.text}}
                        </th>
                        <th>환불</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-if="classData == null">
                        <td colspan="14">데이터를 찾을 수 없습니다.</td>
                    </tr>
                    <tr v-for="(classes, idx) in classData" :key="`classes${idx}`">
                        <td class="checkbox"><v-checkbox  color="primary" v-model="selected" :value="classes._id"></v-checkbox></td>
                        <td>{{idx+1}}</td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="data.value" @click="editClass($event, 'class-edit', classes)">
                            <p :class="data.value" @click="openPopup($event, 'class-edit', classes)" >
                                {{data.value2 ? classes[data.value][data.value2] :classes[data.value]}}
                            </p>
                        </td>
                        <td><v-btn rounded elevation="0" color='primary' @click="openPopup($event, 'class-refund', classes)">신청</v-btn></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</template>
<style lang="scss" scoped>
.class-list{
    table{
        td{
            .CLS_NAME{
                cursor: pointer;
                text-decoration: underline;
                text-underline-position: under;
            }
        }
    }
}
</style>
<script>
export default {
    name: 'StudentList',
    components: {},
    data(){
        return {
            classData : null,
            selected: [],
            filter:['선택', 'ID', '이름', '연락처'],
            search: {
                tag : '선택',
                value : '선택',
                text: null
            },
            tableData:[
                {text: '신청일자', value: 'CLS_REG_DAY'},
                {text: '학생 이름', value: 'CLS_USER_DATA', value2: 'USER_NAME'},
                {text: '학생 아이디', value: 'CLS_USER_DATA', value2: 'USER_ID'},
                {text: '협력사', value: 'CLS_USER_DATA.USER_COMPANY'},
                {text: '수업 시작일', value: 'CLS_START_DAY'},
                {text: '시간', value: 'CLS_START_TIME'},
                {text: '요일', value: 'CLS_DAY_OF_WEEK'},
                {text: '취소 횟수', value: 'CLS_CANCLE_COUNT'},
                {text: '결제 방법', value: 'CLS_PAYMENT', value2: 'METHOD'},
                {text: '결제 상태', value: 'CLS_PAYMENT', value2: 'STATUS'},
            ],
            popup:{
                value: null,
                data: null,
                open: false
            },
            date: null,
            time: null,
            menu: false,
            today: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
        }
    },
    async created(){
        // 목록 불러오기
        await this.$axios.$get(`/class/list`).then(datas =>{
            this.classData = datas.data;
        }).catch((error)=>{
            console.log(error.data)
        });

        // 좌측 상단 페이지 제목
        this.$nuxt.$emit("pageTitle", '접수관리')
    },
    mounted(){
        this.$nuxt.$on("popup-close", v => {
            this.popup.open = false;
            this.popup.value = null;
        });

        this.classData = [{
            CLS_REG_DAY: '2022-08-22',
            CLS_USER_DATA:{
                USER_NAME:'김학생',
                USER_ID:'student1',
                USER_COMPANY:'협력사',
            },
            CLS_START_DAY: '2022-09-01',
            CLS_START_TIME: '14:00',
            CLS_DAY_OF_WEEK: '월, 수, 금',
            CLS_CANCLE_COUNT: 0,
            CLS_PAYMENT: {
                METHOD: '카드',
                STATUS: '결제완료',
            },
        }]
    },
    watch:{
    },
    methods:{
        async formatData(){
            this.search.tag= '선택';
            this.search.text= null;

            await this.$axios.$get(`/class/list`).then(datas =>{
                this.classData = datas.data;
            }).catch((error)=>{
                console.log(error.data)
            });
        },
        openPopup(e, v, data){
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = data;
        },
        editClass(e, v, data){
            if(e.target.classList.contains('CLS_NAME') == false) return
            else this.openPopup(e, v, data)
        },
        deleteClass(){
            this.openPopup( '', 'class-delete', this.selected)
        },
    }

  }
</script>