<template>
    <div class="leveltest-list">
        <LeveltestAdd v-if="popup.value == 'leveltest-add'||popup.value =='leveltest-edit'|| popup.value =='leveltest-edit-result' || popup.value == 'leveltest-edit-tutor'" :value="popup.value" :selectData="popup.data"></LeveltestAdd>
        <DeleteAlert v-if="popup.value =='leveltest-delete'"  :value="popup.value" :selectData="popup.data"></DeleteAlert>

        <div class="tool-wrapper">
            <div class="search-wrapper">
                <v-select outlined  :items="filter" v-model="search.tag" class="small"></v-select>
                <v-text-field outlined  v-model="search.text" class="right"></v-text-field>

                <v-btn depressed @click="searchEvent" class="search-btn" color="primary">검색</v-btn>
                <v-btn depressed color="error" @click="formatData"  v-if="search.tag !== '선택' || search.text !== null || filterClasses.today !== false || filterClasses.last !== false">초기화</v-btn>
            
                <v-btn depressed color="error" @click="deleteLeveltest" :style="{'margin-left': 'auto'}">선택 삭제</v-btn>
            </div> 
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>선택</th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`header${idx}`">
                            {{data.text}}
                        </th>
                        <th>수강신청</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-if="leveltestData == null">
                        <td colspan="14">데이터를 찾을 수 없습니다.</td>
                    </tr>
                    <tr v-for="(leveltest, idx) in leveltestData" :key="`leveltest${idx}`">
                        <td class="checkbox"><v-checkbox  color="primary" v-model="selected" :value="leveltest._id"></v-checkbox></td>
                        <td>{{idx+1}}</td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="[data.value, {underline:data.value2 == 'NAME' || data.value2 == 'TOTAL'}]" 
                            @click="editLeveltest($event, 'leveltest-edit', leveltest)">
                            <v-btn @click="openPopup($event, 'leveltest-edit-tutor', leveltest)" color="primary"
                                v-if="data.value == 'LVT_TUTOR' && leveltest[data.value] == null">
                                선택
                            </v-btn>
                            <p @click="editResult($event, 'leveltest-edit-result', leveltest)"  :class="[data.value, 'underline']"
                                v-else-if="data.value2 == 'TOTAL' && leveltest[data.value].TOTAL == null">
                                결과 입력
                            </p>
                            
                            <p v-else-if="data.value == 'LVT_RESULT' && data.value2 == 'DIAGNOSIS'" class="result">
                               
                                <span v-for="(data, key, idx) in leveltest[data.value][data.value2]" :key="'diagnosis' + idx">
                                    <b>{{diagnosisList[idx]}} : </b> {{data}} 
                                </span>
                            </p>
                            <p v-else-if="data.value == 'LVT_RESULT' && data.value2 == 'SCORE'" class="result">
                        
                                <span v-for="(data, key, idx) in leveltest[data.value][data.value2]" :key="'score' + idx">
                                    <b>{{scoreList[idx]}} :</b> {{data ? data : 0}}점
                                </span>
                            </p>
                            <p v-else @click="editResult($event, 'leveltest-edit-result', leveltest)"
                                :class="[data.value, {underline:data.value2 == 'NAME' || data.value2 == 'TOTAL'}]">
                                {{data.value2 ? leveltest[data.value][data.value2] :leveltest[data.value]}}
                            </p>
                        </td>
                        <td><v-btn rounded elevation="0" color='secondary'>신청</v-btn></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</template>
<style lang="scss" scoped>
.leveltest-list{
    .tool-wrapper{
        .v-input.small{
                max-width: 120px !important;
        }
    }
    .table-wrapper{
        table{
            tbody{
                tr{
                    td{
                        p{
                            &.result{
                                span{
                                    display: block;
                                    text-align: left;
                                    b{
                                        color: rgb(82, 82, 82);
                                        width: 70px;
                                        display: inline-block;
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
    }
}
</style>
<script>
import LeveltestAdd from '@/components/class/LeveltestAdd.vue';
import DeleteAlert from '@/components/DeleteAlert.vue';
export default {
    name: 'StudentList',
    components: {LeveltestAdd, DeleteAlert},
    data(){
        return {
            leveltestData : null,
            classData : null,
            leveltestData : null,
            selected: [],
            filter: ['선택', '학생 이름', '강사 이름'],
            filterClasses: {
                today: false,
                last: false
            },
            search: {
                tag : '선택',
                value : '선택',
                text: null
            },
            newMember: false,
            tableData:[
                {text: '테스트 일자', value: 'LVT_FIXED_DATE', value2: 'DAY'},
                {text: '테스트 시간', value: 'LVT_FIXED_DATE', value2: 'TIME'},
                {text: '학생 이름', value: 'LVT_USER_DATA', value2: 'NAME'},
                {text: '테스트 강사', value: 'LVT_TUTOR'},
                {text: '결과 레벨', value: 'LVT_RESULT', value2: 'TOTAL'},
                {text: '영역별 진단', value: 'LVT_RESULT', value2: 'DIAGNOSIS'},
                {text: '영역별 점수', value: 'LVT_RESULT', value2: 'SCORE'},
                {text: '총 평가', value: 'LVT_TOTAL_EVALUATION'},
                {text: '튜터의 코멘트', value: 'LVT_TUTOR_COMMEND'},
            ],
            popup:{
                value: null,
                data: null,
                open: false
            },
            today: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            diagnosisList: ['SR / AR', 'CEFR' ,'LEXILE', '학년 평균'],
            scoreList: ['발음', '문법' ,'어휘', '이해', '유창성']
        }
    },
    created(){
        this.formatData()

        // 좌측 상단 페이지 제목
        this.$nuxt.$emit("pageTitle", '레벨테스트 관리')
    },
    mounted(){
        this.$nuxt.$on("popup-close", v => {
            this.popup.open = false;
            this.popup.value = null;
        });
    },
    watch:{
        search:{
            deep: true,
            handler(e){
                if(e.tag == '학생 이름') e.value = 'LVT_USER_DATA.NAME'
                if(e.tag == '강사 이름') e.value = 'LVT_TUTOR'
            }
        },
    },
    methods:{
        async formatData(){
            // 초기화
            this.search.tag= '선택';
            this.search.text= null;

            await this.$axios.$get(`/leveltest/list`).then(datas =>{
                this.leveltestData = datas.data;
            }).catch((error)=>{
                console.log(error.data)
                if(error.response.status == 404){
                    this.leveltestData = null;
                }
            });

            if(this.leveltestData !== null){
                this.leveltestData.map(data=>{
                    var origin = new Date(data.LVT_FIXED_DATE.DAY);
                    
                    data.LVT_FIXED_DATE.DAY = `${origin.getFullYear()}-${(origin.getMonth()+1 < 10 ? '0'+(origin.getMonth()+1) : origin.getMonth()+1)}-${origin.getDate()}`;
                })
            }
        },

        openPopup(e, v, data){
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = data;
        },
        editLeveltest(e, v, data){
            if(e.target.classList.contains('LVT_USER_DATA') == false) return
            else this.openPopup(e, v, data)
        },
        editResult(e, v, data){
            if(e.target.classList.contains('LVT_RESULT') && e.target.classList.contains('underline')) {
                this.openPopup(e, v, data)
            }
        },
        deleteLeveltest(){
            this.openPopup( '', 'leveltest-delete', this.selected)
        },
        searchEvent(){
            // 검색기능
            if(this.search.tag == '선택') return alert('검색 필터를 선택해주세요.') ;
            if(this.search.text == null) return alert('검색어를 입력해주세요.') ;
   
            this.$axios.$get('/leveltest/search',
                {params:{tag: this.search.value, text: this.search.text}},
                { withCredentials: true }).then(res =>{
                    this.leveltestData = res.data;
            }).catch((error)=>{
                console.log( error.data)
                if(error.response.status == 404){
                    this.leveltestData = null;
                }

            });

        },

    }

  }
</script>