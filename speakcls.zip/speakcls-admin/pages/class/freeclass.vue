<template>
    <div class="freeclass-list">
        <DeleteAlert v-if="popup.value =='freeclass-delete'"  :value="popup.value" :selectData="popup.data"></DeleteAlert>
        <FreeclassEdit v-if="popup.value =='freeclass-edit'"  :value="popup.value" :selectData="popup.data"></FreeclassEdit>

        <div class="tool-wrapper">
            <div class="search-wrapper">
                <v-select outlined  :items="filter" v-model="search.tag" class="small"></v-select>
                <v-text-field outlined  v-model="search.text" class="right"></v-text-field>

                <v-btn depressed @click="searchEvent" class="search-btn" color="primary">검색</v-btn>
                <v-btn depressed color="error" @click="formatData"  v-if="search.tag !== '선택' || search.text !== null || filterClasses.today !== false || filterClasses.last !== false">초기화</v-btn>
            
                <v-btn depressed color="error" @click="deletefreeclass" :style="{'margin-left': 'auto'}">선택 삭제</v-btn>
            </div> 
            <div class="button-wrapper">
                <v-btn depressed small :class="{act: filterClasses.today}" @click="filterClasses.today = !filterClasses.today; filterClasses.last = false">당일 무료수업</v-btn>
                <v-btn depressed small :class="{act: filterClasses.last}" @click="filterClasses.last = !filterClasses.last; filterClasses.today = false">지난 무료수업</v-btn>
            </div>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>선택</th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`header${idx}`">
                            {{data.text}}
                        </th>
                        <th>수강신청</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-if="freeclassData == null">
                        <td colspan="14">데이터를 찾을 수 없습니다.</td>
                    </tr>
                    <tr v-for="(freeclass, idx) in freeclassData" :key="`freeclass${idx}`">
                        <td class="checkbox"><v-checkbox  color="primary" v-model="selected" :value="freeclass._id"></v-checkbox></td>
                        <td>{{idx+1}}</td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="[data.value, {underline:data.value2 == 'NAME' || data.value2 == 'TOTAL'}]" 
                            @click="editFreeclass($event, 'freeclass-edit', freeclass)">
                            <p :class="data.value" @click="editFreeclass($event, 'freeclass-edit', freeclass)" >
                                {{data.value2 ? freeclass[data.value][data.value2] :freeclass[data.value]}}
                            </p>
                        </td>
                        <td><v-btn rounded elevation="0" color='secondary' @click="openPopup($event, 'freeclass-add')">신청</v-btn></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</template>
<style lang="scss" scoped>
.freeclass-list{
    .tool-wrapper{
        .v-input.small{
            max-width: 120px !important;
        }
    }
}
</style>
<script>
import FreeclassEdit from '@/components/class/FreeclassEdit.vue';
import DeleteAlert from '@/components/DeleteAlert.vue';
export default {
    name: 'StudentList',
    components: {FreeclassEdit, DeleteAlert},
    data(){
        return {
            freeclassData : null,
            classData : null,
            freeclassData : null,
            selected: [],
            filter:['선택', '학생 이름', '강사 이름'],
            filterClasses: {
                today: false,
                last: false
            },
            search: {
                tag : '선택',
                value : '선택',
                text: null
            },
            newMember: false,
            tableData:[
                {text: '신청일자', value: 'FRC_REG_DATE', value2: 'DAY'},
                {text: '학생 이름', value: 'FRC_USER_DATA', value2: 'NAME'},
                {text: '협력사', value: 'USER_COMPANY'},
                {text: '진행상태', value: 'FRC_STATUS'},
                {text: '시작일', value: 'FRC_FIXED_DATE', value2: 'DAY'},
                {text: '시간', value: 'FRC_FIXED_DATE', value2: 'TIME'},
                {text: '요일', value: 'FRC_FIXED_DATE', value2: 'DAY_OF_WEEK'},
                {text: '튜터', value: 'FRC_TUTOR'},
                {text: '상담 유/무', value: 'FRC_CONSULT'},
            ],
            popup:{
                value: null,
                data: null,
                open: false
            },
            today: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)
        }
    },
    async created(){
        // 무료수업 불러오기
        await this.$axios.$get(`/freeclass/list`).then(datas =>{
            this.freeclassData = datas.data;
        }).catch((error)=>{
            console.log(error.data)
            if(error.response.status == 404){
                this.freeclassData = null;
            }
        });

        // 좌측 상단 페이지 제목
        this.$nuxt.$emit("pageTitle", '무료수업 관리')
        
        // 데이터 중 날짜 부분 변경
        if(this.freeclassData !== null){
            this.freeclassData.map(data=>{
                var origin1 = new Date(data.FRC_REG_DATE.DAY);
                var origin2 = new Date(data.FRC_FIXED_DATE.DAY);
                
                data.FRC_REG_DATE.DAY = `${origin1.getFullYear()}-${(origin1.getMonth()+1 < 10 ? '0'+(origin1.getMonth()+1) : origin1.getMonth()+1)}-${origin1.getDate()}`;
                data.FRC_FIXED_DATE.DAY = `${origin2.getFullYear()}-${(origin2.getMonth()+1 < 10 ? '0'+(origin2.getMonth()+1) : origin2.getMonth()+1)}-${origin2.getDate()}`;
            })
        }
    },
    mounted(){
        this.$nuxt.$on("popup-close", v => {
            this.popup.open = false;
            this.popup.value = null;
        });
    },
    watch:{
        search:{
            deep: true,
            handler(e){
                if(e.tag == '학생 이름') e.value = 'FRC_USER_DATA.NAME'
                if(e.tag == '튜터 이름') e.value = 'TUTOR_NAME'
            }
        },
        filterClasses: {
            deep: true,
            async handler(e){
                if(e.today){
                    await this.$axios.$get(`/freeclass/list/today`).then(datas =>{
                        this.freeclassData = datas.data;
                    }).catch((error)=>{
                        console.log(error.data)
                    });
                }else if(e.last){
                    await this.$axios.$get(`/freeclass/list/last`).then(datas =>{
                        this.freeclassData = datas.data;
                    }).catch((error)=>{
                        console.log(error.data)
                    });
                }else{
                    await this.$axios.$get(`/freeclass/list`).then(datas =>{
                        this.freeclassData = datas.data;
                    }).catch((error)=>{
                        console.log(error.data)
                    });

                }
            }
        }
    },
    methods:{
        async formatData(){
            this.search.tag= '선택';
            this.search.text= null;
            
            Object.keys(this.filterClasses).forEach(key => {
                this.filterClasses[key] = false;
            });

            await this.$axios.$get(`/freeclass/list`).then(datas =>{
                this.freeclassData = datas.data;
            }).catch((error)=>{
                console.log(error.data)
            });

            if(this.freeclassData !== null){
            this.freeclassData.map(data=>{
                var origin1 = new Date(data.FRC_REG_DATE.DAY);
                var origin2 = new Date(data.FRC_FIXED_DATE.DAY);
                
                data.FRC_REG_DATE.DAY = `${origin1.getFullYear()}-${(origin1.getMonth()+1 < 10 ? '0'+(origin1.getMonth()+1) : origin1.getMonth()+1)}-${origin1.getDate() < 10 ? '0'+ (origin1.getDate()) : origin1.getDate()}`;
                data.FRC_FIXED_DATE.DAY = `${origin2.getFullYear()}-${(origin2.getMonth()+1 < 10 ? '0'+(origin2.getMonth()+1) : origin2.getMonth()+1)}-${origin2.getDate() < 10 ? '0' +( origin2.getDate()) : origin2.getDate()}`;
            })
        }
        },

        openPopup(e, v, data){
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = data;
        },
        editFreeclass(e, v, data){
            if(e.target.classList.contains('FRC_USER_DATA') == false) return
            else this.openPopup(e, v, data)
        },
        deletefreeclass(){
            this.openPopup( '', 'freeclass-delete', this.selected)
        },
        searchEvent(){
            // 검색기능
            if(this.search.tag == '선택') return alert('검색 필터를 선택해주세요.') ;
            if(this.search.text == null) return alert('검색어를 입력해주세요.') ;
   
            this.$axios.$get('/freeclass/search',
                {params:{tag: this.search.value, text: this.search.text}},
                { withCredentials: true }).then(res =>{
                    this.freeclassData = res.data;
            }).catch((error)=>{
                console.log( error.data)
                if(error.response.status == 404){
                    this.freeclassData = null;
                }

            });
        },
    }

  }
</script>