<template>
    <div class="tutor-list">
        <TutorAdd v-if="popup.value == 'tutor-add' || popup.value == 'tutor-edit'" :selectData="popup.data" :value="popup.value"></TutorAdd>
        <DeleteAlert v-if="popup.value == 'tutor-delete'" :selectData="popup.data" :value="popup.value"></DeleteAlert>
        <div class="tool-wrapper">
            <div class="search-wrapper">
                <v-select outlined  :items="filter" v-model="search.tag" class="small"></v-select>
                <v-text-field outlined  v-model="search.text" class="right"></v-text-field>

                <v-btn depressed @click="searchEvent" class="search-btn" color="primary">검색</v-btn>
                <v-btn depressed color="error" @click="formatData"  v-if="search.tag !== '선택' || search.text !== null || newMember == true">초기화</v-btn>

                <v-btn depressed color="secondary" @click="openPopup($event, 'tutor-add')" :style="{'margin-left': 'auto'}">강사 등록</v-btn>
                <v-btn depressed color="error" @click="deleteTutor">선택 삭제</v-btn>
            </div> 
            <div class="button-wrapper">
                <v-btn depressed small>대체신청</v-btn>
                <v-btn depressed small>접속 URL 미등록</v-btn>
            </div>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>선택</th>
                        <th>No</th>
                        <th v-for="(data, idx) in tableData" :key="`header${idx}`">
                            {{data.text}}
                        </th>
                        <th>히스토리</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(tutor, idx) in tutorData" :key="`tutor${idx}`">
                        <td class="checkbox"><v-checkbox  color="primary" v-model="selected" :value="tutor._id"></v-checkbox></td>
                        <td>{{idx+1}}</td>
                        <td  v-for="(data, idx2) in tableData" :key="`${idx}-${idx2}`" :class="[data.value, {underline:data.value== 'TTR_NAME'}]" @click="editTutor($event, 'tutor-edit', tutor)">
                            <p v-if="data.value == 'TTR_SCHEDULE'">
                                {{tutor[data.value].START}} ~ {{tutor[data.value].FINISH}} 
                            </p>
                            <p v-else @click="editTutor($event, 'tutor-edit', tutor)" :class="data.value">
                                {{tutor[data.value]}}
                            </p>
                        </td>
                       <td><v-btn rounded  elevation="0" color='accent' @click="openPopup($event, 'history')">보기</v-btn></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</template>
<style lang="scss" scoped>

</style>
<script>
    import TutorAdd from '@/components/member/TutorAdd.vue';
import DeleteAlert from '@/components/DeleteAlert.vue';
export default {
    name: 'StudentList',
    components: {TutorAdd, DeleteAlert},
    data(){
        return {
            tutorData : null,
            selected: [],
            filter:['선택', '이름', 'ID'],
            search: {
                tag : '선택',
                value : '선택',
                text: null
            },
            newMember: false,
            tableData:[
                {text: '등록일자', value: 'TTR_REG_DAY'},
                {text: '이름', value: 'TTR_NAME'},
                {text: '아이디', value: 'TTR_ID'},
                {text: '성별', value: 'TTR_GENDER'},
                {text: '수업시간', value: 'TTR_SCHEDULE'},
                {text: '수업상태', value: 'TTR_NUMBER_OF_CLASS'},
            ],
            popup:{
                value: null,
                data: null,
                open: false
            },
            today: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)
        }
    },
    async fetch(){
        // 튜터 목록 불러오기
        await this.$axios.$get(`/tutor/list`).then(datas =>{
            this.tutorData = datas.data;
        }).catch((error)=>{
            console.log(error.data)
        });
    },
    created(){
        // 페이지 좌측 상단 제목
        this.$nuxt.$emit("pageTitle", '강사관리')
    },
    mounted(){
        this.$nuxt.$on("popup-close", v => {
            this.popup.open = false;
            this.popup.value = null;
        });
    },
    watch:{
        search:{
            deep: true,
            handler(e){
                if(e.tag == '이름') e.value = 'TTR_NAME'
                if(e.tag == 'ID') e.value = 'TTR_ID'
            }
        }
    },
    methods:{
        async formatData(){
            // 검색어와 필터링 등 초기화

            this.search.tag= '선택';
            this.search.text= null;
            this.newMember = false

            await this.$axios.$get(`/tutor/list`).then(datas =>{
                this.tutorData = datas.data;
            }).catch((error)=>{
                console.log(error.data)
            });
        },
        openPopup(e, v, data){
            if(v == undefined) return
             
            this.popup.open = true;
            this.popup.value = v;
            this.popup.data = data;
        },
        editTutor(e, v, data){
            // 튜터 이름 클릭시에만 수정 팝업 열리게
            if(e.target.classList.contains('TTR_NAME') == false) return
            else this.openPopup(e, v, data)
        },
        deleteTutor(){
            this.openPopup( '', 'tutor-delete', this.selected)
        },
        searchEvent(){
            // 검색 이벤트
            if(this.search.tag == '선택') return alert('검색 필터를 선택해주세요.') ;
            if(this.search.text == null) return alert('검색어를 입력해주세요.') ;
            
            this.$axios.$get('/tutor/search',
                {params:{tag: this.search.value, text: this.search.text}},
                { withCredentials: true }).then(res =>{
                    this.tutorData = res.data;
            }).catch((error)=>{
                console.log( error.data)
                if(error.response.status == 404){
                    this.tutorData = null;
                }

            });
        },
    }

  }
</script>