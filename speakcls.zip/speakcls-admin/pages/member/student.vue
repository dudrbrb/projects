<template>
  <div class="user-list">
    <DeleteAlert
      v-if="popup.value == 'user-delete'"
      :value="popup.value"
      :selectData="popup.data"
    ></DeleteAlert>
    <UserAdd
      v-if="popup.value == 'user-add' || popup.value == 'user-edit'"
      :value="popup.value"
      :selectData="popup.data"
    ></UserAdd>
    <UserAddLeveltest
      v-if="popup.value == 'user-add-leveltest'"
      :value="popup.value"
      :selectData="popup.data"
    ></UserAddLeveltest>
    <UserAddFreeclass
      v-if="popup.value == 'user-add-freeclass'"
      :value="popup.value"
      :selectData="popup.data"
    ></UserAddFreeclass>
    <UserClassManage
      v-if="popup.value == 'user-add-class'"
      :value="popup.value"
      :selectData="popup.data"
    ></UserClassManage>

    <div class="tool-wrapper">
      <div class="search-wrapper align-baseline">
        <div class="font-weight-black mr-4">검색하기</div>
        <v-select outlined :items="filter" v-model="search.tag" class="small"></v-select>
        <v-text-field outlined v-model="search.text" class="right"></v-text-field>

        <v-btn
          depressed
          @click="searchEvent"
          class="search-btn"
          outlined
          color="unstyled"
          border-color="black"
          >검색</v-btn
        >
        <v-btn depressed @click="searchEvent" class="search-btn" outlined color="unstyled"
          >신규가입</v-btn
        >
        <v-btn
          depressed
          color="error"
          @click="formatData"
          v-if="search.tag !== '선택' || search.text !== null || newMember == true"
          >초기화</v-btn
        >

        <v-btn
          depressed
          color="accent"
          @click="openPopup($event, 'user-add')"
          :style="{ 'margin-left': 'auto' }"
          >추가</v-btn
        >
        <v-btn depressed color="error" @click="deleteUser">삭제</v-btn>
      </div>
      <div class="button-wrapper">
        <v-btn depressed @click="newMember = !newMember" :class="{ act: newMember }"
          >회원 등록</v-btn
        >
        <v-btn depressed>엑셀 Output</v-btn>
      </div>
    </div>

    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>선택</th>
            <th>번호</th>
            <th v-for="(data, idx) in tableData" :key="`header${idx}`">
              {{ data.text }}
            </th>
            <th>수강 상태</th>
            <th>무료수업 신청</th>
            <th>수강 신청</th>
            <th>히스토리</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="userData == null">
            <td colspan="10">데이터를 찾을 수 없습니다.</td>
          </tr>
          <tr v-for="(user, idx) in userData" :key="`user${idx}`">
            <td class="checkbox">
              <v-checkbox color="primary" v-model="selected" :value="user._id"></v-checkbox>
            </td>
            <td>{{ idx + 1 }}</td>
            <td
              v-for="(data, idx2) in tableData"
              :key="`${idx}-${idx2}`"
              :class="[data.value, { underline: data.value == 'USER_NAME' }]"
              @click="editUser($event, 'user-edit', user)"
            >
              <p @click="openPopup($event, 'user-edit', user)">
                {{ data.subValue ? user[data.value][data.subValue] : user[data.value] }}
              </p>
            </td>
            <td>
              <p>{{ user.class ? user.class.status : "미접수" }}</p>
            </td>
            <!-- <td>
              <v-btn
                rounded
                elevation="0"
                color="secondary"
                @click="openPopup($event, 'user-add-leveltest', user)"
                :disabled="user.leveltest && user.leveltest !== null"
                >신청</v-btn
              >
            </td> -->
            <td>
              <v-btn
                rounded
                elevation="0"
                color="secondary"
                @click="openPopup($event, 'user-add-freeclass', user)"
                >신청</v-btn
              >
            </td>
            <td>
              <v-btn
                rounded
                elevation="0"
                color="primary"
                @click="openPopup($event, 'user-add-class', user)"
                >신청</v-btn
              >
            </td>
            <td><v-btn rounded elevation="0" color="accent" @click="openHistory">보기</v-btn></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<style lang="scss" scoped></style>
<script>
import UserAdd from "@/components/member/UserAdd.vue";
import UserAddLeveltest from "@/components/member/UserAddLeveltest.vue";
import UserAddFreeclass from "@/components/member/UserAddFreeclass.vue";
import UserClassManage from "@/components/member/UserClassManage.vue";
import DeleteAlert from "@/components/DeleteAlert.vue";

export default {
  name: "StudentList",
  components: { UserAdd, UserAddLeveltest, UserAddFreeclass, UserClassManage, DeleteAlert },
  data() {
    return {
      userData: null,
      classData: null,
      leveltestData: null,
      selected: [],
      filter: ["선택", "ID", "이름", "연락처"],
      search: {
        tag: "선택",
        value: "선택",
        text: null,
      },
      newMember: false,
      tableData: [
        { text: "등록일자", value: "USER_REG_DAY" },
        { text: "이름", value: "USER_NAME" },
        { text: "아이디", value: "USER_ID" },
        { text: "협력사", value: "USER_COMPANY" },
      ],
      popup: {
        value: null,
        data: null,
        open: false,
      },
      today: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
        .toISOString()
        .substr(0, 10),
    };
  },
  async created() {
    // 학생 회원 목록 불러오기
    await this.$axios
      .$get(`/user/list`)
      .then((datas) => {
        this.userData = datas.data;
      })
      .catch((error) => {
        console.log(error.data);
      });

    // 좌측 상단 페이지 제목
    this.$nuxt.$emit("pageTitle", "회원관리");

    // 테스트 날짜 변경
    if (this.leveltestData !== null) {
      this.leveltestData.map((data) => {
        var origin = new Date(data.LVT_FIXED_DATE.DAY);

        data.LVT_FIXED_DATE.DAY = `${origin.getFullYear()}-${
          origin.getMonth() + 1 < 10 ? "0" + (origin.getMonth() + 1) : origin.getMonth() + 1
        }-${origin.getDate()}`;
      });
    }
  },
  mounted() {
    this.$nuxt.$on("popup-close", (v) => {
      this.popup.open = false;
      this.popup.value = null;
    });
  },
  watch: {
    search: {
      deep: true,
      handler(e) {
        // 검색 필터 선택 시 api에 보낼 값 변경
        if (e.tag == "ID") e.value = "USER_ID";
        if (e.tag == "이름") e.value = "USER_NAME";
        if (e.tag == "연락처") e.value = "USER_TEL";
      },
    },
    newMember: {
      async handler(e) {
        // 신규 가입 회원 필터링

        this.search.tag = "선택";
        this.search.text = null;

        if (e == false) {
          // 모든 회원 불러오기
          await this.$axios
            .$get(`/user/list`)
            .then((datas) => {
              this.userData = datas.data;
            })
            .catch((error) => {
              console.log(error.data);
            });
        }
        if (e == true) {
          // 신규 회원 불러오기
          this.$axios
            .$get("/user/search", { params: { today: this.today } }, { withCredentials: true })
            .then((res) => {
              console.log(res);
              this.userData = res.data;
            })
            .catch((error) => {
              console.log(error.data);
            });
        }
      },
    },
  },
  methods: {
    async formatData() {
      // 검색어와 필터링 등 초기화
      this.search.tag = "선택";
      this.search.text = null;
      this.newMember = false;

      await this.$axios
        .$get(`/user/list`)
        .then((datas) => {
          this.userData = datas.data;
        })
        .catch((error) => {
          console.log(error.data);
        });
    },
    openPopup(e, v, data) {
      if (v == undefined) return;

      this.popup.open = true;
      this.popup.value = v;
      this.popup.data = data;
    },
    openHistory() {
      alert("준비중입니다");
    },
    editUser(e, v, data) {
      // 학생 이름 클릭시에만 수정 팝업 열리게
      if (e.target.classList.contains("USER_NAME") == false) return;
      else this.openPopup(e, v, data);
    },
    deleteUser() {
      this.openPopup("", "user-delete", this.selected);
    },
    searchEvent() {
      // 검색 이벤트
      if (this.search.tag == "선택") return alert("검색 필터를 선택해주세요.");
      if (this.search.text == null) return alert("검색어를 입력해주세요.");

      this.$axios
        .$get(
          "/user/search",
          { params: { tag: this.search.value, text: this.search.text } },
          { withCredentials: true }
        )
        .then((res) => {
          this.userData = res.data;
        })
        .catch((error) => {
          console.log(error.data);
          if (error.response.status == 404) {
            this.userData = null;
          }
        });
    },
  },
};
</script>
