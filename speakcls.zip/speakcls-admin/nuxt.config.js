import colors from 'vuetify/es5/util/colors'

export default {
  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    titleTemplate: '%s - admin',
    title: 'admin',
    htmlAttrs: {
      lang: 'en'
    },
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: '' },
      { name: 'format-detection', content: 'telephone=no' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ]
  },
  server: { port: 8080 } ,
  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
  ],

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    { src : '@/plugins/vue-apexchart.js', ssr : false }
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: true,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [
    // https://go.nuxtjs.dev/vuetify
    '@nuxtjs/vuetify',
    '@nuxtjs/style-resources',
  ],
  styleResources: {
    scss: [
      '@/assets/scss/_mixin.scss',
      '@/assets/scss/_colors.scss',
      '@/assets/scss/app.scss',
    ],
   },

  // Vuetify module configuration: https://go.nuxtjs.dev/config-vuetify
  vuetify: {
    theme: {
      themes: {
        light: {
          primary: '#448aca',
          secondary: '#00b7ee',
          accent: '#3f6ad8',
          error: '#ff5252',
          my_color: '#ffffff',
        }
      }
    }
  },
  serverMiddleware: ['@/api/index.js'],
  modules: ['@nuxtjs/axios'],
  axios: {
    baseURL: 'http://182.162.104.160/api'
  },

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    vendor : [
      'vue-apexchart'
    ]
  }
}
