const MongoClient = require('mongodb').MongoClient; // mongoDB호출
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());



// var db;
// MongoClient.connect('mongodb://speakcls:speakcls123@speakcls-shard-00-00.lxv5s.mongodb.net:27017,speakcls-shard-00-01.lxv5s.mongodb.net:27017,speakcls-shard-00-02.lxv5s.mongodb.net:27017/?ssl=true&replicaSet=atlas-2w0fmt-shard-0&authSource=admin&retryWrites=true&w=majority', (err, client) => {
//     // DB연결 성공하면 할 일
//     if(err) return console.log('에러', err)
    
//     // speakcls 이라는 database에 연결
//     db = client.db('speakcls');
// });


// // USER

// app.get('/user', (req, res) => {
//     db.collection('USER').find().toArray((err, data) => {
//         if(err) return console.log('에러', err)
//         if(data) res.json(data)
//     });
// });


// app.get('/user/detail/:id', (req, res) =>{
// 	db.collection('USER').findOne({ _id : parseInt(req.params.id) }, (err, data)=>{
//         if(data) res.json(data)
// 	})
// });


// // 새로운 DB 추가하기

// app.post('/user/add', (req, res) => {
//     db.collection('COUNTER').findOne({TARGET: 'USER'}, function(err, count){
//         var userData = {
//             USER_INDEX:  count.number + 1,
//         };

//         db.collection('USER').insertOne(userData, (err, result) => {
//             if(err) return console.log(err)
//             if(result) {
//                 db.collection('COUNTER').updateOne({TARGET: 'USER'}, {$inc: {number: 1}}, function(에러, 결과){
//                     if(에러) return console.log(에러)
//                 })
//             }
//         });

//     });
// });

// // DB 삭제하기

// app.delete('/user/delete', (req, res) => {
//     var deleteData = {_id: parseInt(req.body.selectData)}

//     db.collection('USER').deleteOne(deleteData, (err, result) => {
//         if(err) console.log(err)
//         res.status(200).send({message: '성공했습니다'});

//         db.collection('COUNTER').findOne({TARGET: 'TUTOR'}, function(err, count){
//             db.collection('COUNTER').updateOne({TARGET: 'USER'}, {$inc: {REMOVE: 1}}, function(에러, 결과){
//                 if(에러) return console.log(에러)
//             })

//         });
    
//     })
// });


// // DB 수정하기

// app.put('/user/update', (req, res) => {
//     db.collection('USER').updateOne(
//         {_id: parseInt(req.body._id)},
//         {$set:{  
//             USERName: req.body.USERName,
//             engName: req.body.engName,
//             age: req.body.age,
//             birthday: req.body.birthday,
//             id: req.body.id,
//             pw: req.body.pw,
//             sex: req.body.sex,
//             USERTel: req.body.USERTel,
//             address: req.body.address,
//             membership: req.body.membership,
//             joinData: {
//                 root: req.body.joinData.root,
//                 day: req.body.joinData.day,
//                 recommendPerson:{
//                     name: req.body.joinData.recommendPerson.name,
//                     tel: req.body.joinData.recommendPerson.tel,
//                 }
//             },
//             coupon: req.body.coupon,
//             levelTest:{
//                 status: '미접수',
//                 consulting: false,
//                 date:{
//                     want: null,
//                     fixed: null
//                 },
//                 TUTOR: null,
//                 level: null,
//                 result:{
//                     average:null,
//                     pronunciation:null,
//                     grammer:null,
//                     vocabulary:null,
//                     understanding:null,
//                     fluency:null,
//                 },
//                 toTUTOR: null,
//                 request: null,
//                 note: null
//             }
//         }},
//         (err, 결과) => {
//             if(err) console.log(err)
//         }
//     )
// });



// // 검색하기 

// app.get('/user/search', (req, res) => {
//     console.log(req.query)
//     var searchData = [
//         {
//           $search: {
//             index: 'USERSearch',
//             text: {
//               query: req.query.text, // 실제 검색 부분
//               path: [req.query.tag] // 제목날짜 둘다 찾고 싶으면 ['title', 'date']
//             }
//           }
//         },
//        { $sort : { _id : -1 } }, // 정렬, _id 순서로 정렬 (-1로 하면 반대순서로 정렬)
//        { $limit : 10 }, // 제한걸기. 상위 10개만 가져와주세요
//     //    { $project : { USERName : 1, id : 1, _id : 1 } } // 검색 결과를 뭘 보여줄지 선택 (1은 가져옴, 0이면 안가져옴)
//     ];

//     db.collection('USER').aggregate(searchData).toArray((err, data)=>{
//         if(err) return console.log('에러', err)
//         if(data) res.json(data)
//     });
// });

// app.get('/user/search/today', (req, res) => {
//     var searchData = [
//         { $match : {  regDay : req.query.day  }},
//         { $sort : { _id : -1 } },
//     ];
//     db.collection('USER').aggregate(searchData).toArray((err, data)=>{
//         if(err) return console.log('에러', err)
//         if(data) res.json(data)
//         console.log(data)
//     });
// });


// app.get('leveltest/search/today', (req, res) => {
//     var searchData = [
//         { $match : {  testDay : req.query.day  }},
//         { $sort : { _id : -1 } },
//     ];
//     db.collection('leveltest').aggregate(searchData).toArray((err, data)=>{
//         if(err) return console.log('에러', err)
//         if(data) res.json(data)
//         console.log(data)
//     });
// });

// app.get('leveltest/search/last', (req, res) => {
//     console.log(req.query.day)
//     var searchData = [
//         { $match: {  testDay : {$ne: req.query.day  }}},
//         {$sort : { _id : -1 }} 
//     ];
//     db.collection('leveltest').aggregate(searchData).toArray((err, data)=>{
//         if(err) return console.log('에러', err)
//         if(data) res.json(data)
//         console.log(data)
//     });
// });


module.exports = {
  path: '/api',
  handler: app
};