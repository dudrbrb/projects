<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup add-member">
    <h4 v-if="value == 'tutor-add'">강사 등록</h4>
    <h4 v-if="value == 'tutor-edit'">강사 정보 수정</h4>
    
    
    <div class="input-wrapper">
        <div class="box">
            <label>이름</label>
            <v-text-field outlined v-model="tutorInfo.TTR_NAME"></v-text-field>
        </div>
        <div class="box">
            <label>성별</label>
            <v-select outlined  :items="genderItems" v-model="tutorInfo.TTR_GENDER" ></v-select>
        </div>
        <div class="box">
            <label>연락처</label>
            <v-text-field outlined v-model="tutorInfo.TTR_TEL"></v-text-field>
        </div>
        <div class="box">
            <label>소속</label>
            <v-select outlined  :items="centerItems" v-model="tutorInfo.TTR_CENTER"></v-select>
        </div>
        <div class="box">
            <label>ID</label>
            <v-text-field outlined v-model="tutorInfo.TTR_ID"></v-text-field>
            <v-btn depressed small color="secondary" v-if="value=='tutor-add'">중복체크</v-btn>
        </div>
        <div class="box">
            <label>비밀번호</label>
            <v-text-field outlined v-model="tutorInfo.TTR_PW"></v-text-field>
        </div>
        <div class="box">
            <label>사용여부</label>
            <v-select outlined  :items="activeItems" v-model="tutorInfo.TTR_STATUS"></v-select>
        </div>
        <div class="box">
            <label>접속 URL</label>
            <v-text-field outlined v-model="tutorInfo.TTR_CLS_URL"></v-text-field>
        </div>
        <div class="box">
            <label>소개 영상 첨부</label>
            <v-text-field outlined v-model="tutorInfo.TTR_INTRODUCE_VIDEO"></v-text-field>
        </div>
        <div class="box">
            <label>사진 첨부</label>
            <v-text-field outlined v-model="tutorInfo.TTR_PROFILE_IMAGE"></v-text-field>
        </div>
        <div class="box">
            <label>수업 시간</label>
            <v-select outlined  class="small" :items="timeItems" v-model="tutorInfo.TTR_SCHEDULE.START"></v-select>
            <p class="range">~</p>
            <v-select outlined  class="small" :items="timeItems" v-model="tutorInfo.TTR_SCHEDULE.FINISH"></v-select>
        </div>
        <div class="box">
            <label>휴식 시간</label>
            <v-select outlined  class="small" :items="timeItems" v-model="tutorInfo.TTR_BREAKTIME.START"></v-select>
            <p class="range">~</p>
            <v-select outlined  class="small" :items="timeItems" v-model="tutorInfo.TTR_BREAKTIME.FINISH"></v-select>
        </div>

        <div class="box full">
            <label>자기소개</label>
            <v-textarea outlined  class="full short" v-model="tutorInfo.TTR_INTRODUCE"></v-textarea>
        </div>
        <div class="box full">
            <label>메모</label>
            <v-textarea outlined  class="full short" v-model="tutorInfo.TTR_NOTE"></v-textarea>
        </div>
    </div>
    <div class="button-wrapper">
        <v-btn @click="addTutor" color="primary" v-if="value=='tutor-add'">등록</v-btn>
        <v-btn @click="editTutor" color="primary" v-if="value=='tutor-edit'">수정 완료</v-btn>
        <v-btn @click="deleteTutor" color="error" v-if="value=='tutor-edit'">회원 삭제</v-btn>
        <v-btn @click="cancle">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>

</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            tutorInfo:{
                TTR_NAME: null,
                TTR_TEL: null,
                TTR_ID: null,
                TTR_PW: null,
                TTR_GENDER: null,
                TTR_SCHEDULE:{START: null, FINISH : null},
                TTR_BREAKTIME:{START: null, FINISH : null},
                TTR_STATUS: null,
                TTR_CENTER: null,
                TTR_CLS_URL: null,
                TTR_INTRODUCE_VIDEO: null,
                TTR_PROFILE_IMAGE: null,
                TTR_INTRODUCE: null,
                TTR_NOTE: null,
            },
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
            centerItems: ['강남점', '청담점', '잠실점'],
            activeItems: ['사용', '비사용'],
            genderItems: ['남', '여'],
        }
    },
    async fetch() {
    },
    filters:{
    },
    mounted() {
        if(this.selectData){
            this.tutorInfo = this.selectData;
        }
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        async addTutor(){
            await this.$axios.post(`/tutor/create`, this.tutorInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async editTutor(){
            await this.$axios.post(`/tutor/edit/`+ this.selectData._id , this.tutorInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async deleteTutor(){
            this.$axios.$get(`/tutor/delete/`+ this.selectData._id).then(data =>{
                console.log(data)
            }).catch((error)=>{
                console.log(error.data)
            });
        
            this.cancle('ok');
        }
    }
}
</script>
