<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup add-leveltest">
    <h4>레벨테스트 신청</h4>
    
    <div class="input-wrapper">
        <div class="box">
            <label>이름</label>
            <p>{{userInfo.USER_NAME}}</p>
        </div>
        <div class="box">
            <label>영어이름</label>
            <p>{{userInfo.USER_ENGLISH_NAME}}</p>
        </div>
        <div class="box">
            <label>연락처</label>
            <p>{{userInfo.USER_TEL}}</p>
        </div>
        <div class="box">
            <label>학년</label>
            <v-select outlined  :items="gradeItems" v-model="leveltestInfo.LVT_USER_DATA.GRADE"></v-select>

            <!-- <v-radio-group  row>
                <v-radio label="Junior" value="Junior"></v-radio>
                <v-radio label="Senior" value="Senior"></v-radio>
            </v-radio-group> -->
        </div>
        <div class="box">
            <label>수업시작일</label>
            <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="leveltestInfo.LVT_FIXED_DATE.DAY" 
            transition="scale-transition" offset-y min-width="auto" >
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field outlined v-model="leveltestInfo.LVT_FIXED_DATE.DAY" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on" ></v-text-field>
                </template>
                <v-date-picker v-model="leveltestInfo.LVT_FIXED_DATE.DAY" no-title scrollable >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        취소
                    </v-btn>
                    <v-btn text color="primary" @click="$refs.menu.save(leveltestInfo.LVT_FIXED_DATE.DAY)">
                        선택
                    </v-btn>
                </v-date-picker>
            </v-menu>
        </div>
        <div class="box">
            <label>수업 시간</label>
            <v-select outlined  :items="timeItems" v-model="leveltestInfo.LVT_FIXED_DATE.TIME"></v-select>
        </div>

        <div class="box full">
            <label>학습수준</label>
            <v-radio-group v-model="leveltestInfo.LVT_USER_DATA.LEVEL">
                <v-radio label="기초 단어를 따라 말할 수 있어요." value="기초 단어를 따라 말할 수 있어요."></v-radio>
                <v-radio label="간단한 문장을 말할 수 있어요." value="간단한 문장을 말할 수 있어요."></v-radio>
                <v-radio label="자유롭게 프리토킹이 가능해요." value="자유롭게 프리토킹이 가능해요."></v-radio>
            </v-radio-group>
        </div>
        <div class="box full">
            <label>특이사항</label>
            <v-textarea outlined  class="full" v-model="leveltestInfo.LVT_TUTOR_COMMEND"></v-textarea>

        </div>
    </div>
    <div class="button-wrapper">
        <v-btn @click="addLeveltest" color="secondary">등록</v-btn>
        <v-btn @click="cancle" color="error">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>
</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            userInfo:{},
            menu: false,
            date: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
            gradeItems:['미취학', '초등학교 1학년', '초등학교 2학년', '초등학교 3학년', '초등학교 4학년', '초등학교 5학년', '초등학교 6학년', '중학교 1학년','중학교 2학년','중학교 3학년', '고등학교 1학년', '고등학교 2학년', '고등학교 3학년', '성인'],
            leveltestInfo:{
                LVT_TUTOR: null,
                LVT_REG_DATE:{
                    DAY:(new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                    TIME: null,
                    DAY_OF_WEEK : null
                },
                LVT_FIXED_DATE:{
                    DAY:(new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                    TIME: null,
                    DAY_OF_WEEK : null
                },
                LVT_RESULT:{
                    TOTAL : null,
                    DIAGNOSIS:{SR_AR:null,CEFR:null,LEXILE:null,AVERAGE: null},
                    SCORE: {PRONUNCIATION: null , GRAMMER: null, VOCABULARY: null, UNDERSTANDING: null, FLUENCY:null },

                },
                LVT_ARTICLE:{
                    COLLECT_USER_IMPORMATION:true,
                    EVENT_NOTIFICATION:true
                },
                LVT_TOTAL_EVALUATION: null,
                LVT_TUTOR_COMMEND:null,
                LVT_STATUS: "접수",
                LVT_USER_DATA:{
                    DATA_ID: null,
                    NAME: null,
                    ID:null,
                    TEL: null,
                    GRADE: null,
                    LEVEL: null
                },

            },
        
        }
    },
    mounted(){
        if(this.selectData){
            this.userInfo = this.selectData;
            this.leveltestInfo.LVT_USER_DATA.DATA_ID = this.selectData._id;
            this.leveltestInfo.LVT_USER_DATA.NAME = this.selectData.USER_NAME;
            this.leveltestInfo.LVT_USER_DATA.ID = this.selectData.USER_ID;
            this.leveltestInfo.LVT_USER_DATA.TEL = this.selectData.USER_TEL;
        }
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        getAge(){
            var birthYear = this.userInfo.birthday.split('-')[0];
            var thisYear = new Date().getFullYear();
            
            this.userInfo.age = thisYear - birthYear +1;
        },
        async addLeveltest(){
            await this.$axios.post(`/leveltest/create`, this.leveltestInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
    }
}
</script>
