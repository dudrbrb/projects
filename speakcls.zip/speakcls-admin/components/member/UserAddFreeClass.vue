<template>
  <div class="popup-wrapper" @click="closePopup($event)">
    <div class="popup add-freeclass">
      <h4>무료수업 신청</h4>

      <div class="input-wrapper">
        <div class="box">
          <label>이름</label>
          <p class="font-weight-black">{{ userInfo.USER_NAME }}</p>
        </div>
        <div class="box">
          <label>영어이름</label>
          <p class="font-weight-black">{{ userInfo.USER_ENGLISH_NAME }}</p>
        </div>
        <div class="box">
          <label>무료체험 레벨</label>
          <p class="font-weight-black">{{ userInfo.USER_ENGLISH_NAME }}</p>
        </div>
        <!-- <div class="box">
          <label>수업 시작일</label>
          <p>{{ userInfo.USER_ENGLISH_NAME }}</p>
        </div> -->
        <div class="box">
          <label>수업시작일</label>
          <v-menu
            ref="menu"
            v-model="menu"
            :close-on-content-click="false"
            :return-value.sync="freeclassInfo.FRC_FIXED_DATE.DAY"
            transition="scale-transition"
            offset-y
            min-width="auto"
          >
            <template v-slot:activator="{ on, attrs }">
              <v-text-field
                outlined
                v-model="freeclassInfo.FRC_FIXED_DATE.DAY"
                class="align-center"
                append-outer-icon="mdi-calendar-badge-outline"
                readonly
                v-bind="attrs"
                v-on="on"
              ></v-text-field>
            </template>
            <v-date-picker
              v-model="freeclassInfo.FRC_FIXED_DATE.DAY"
              no-title
              scrollable
            >
              <v-spacer />
              <v-btn text color="primary" @click="menu = false"> 취소 </v-btn>
              <v-btn
                text
                color="primary"
                @click="$refs.menu.save(freeclassInfo.FRC_FIXED_DATE.DAY)"
              >
                선택
              </v-btn>
            </v-date-picker>
          </v-menu>
        </div>
        <div class="box">
          <label>수업 시간</label>
          <v-select
            outlined
            :items="timeItems"
            v-model="freeclassInfo.FRC_FIXED_DATE.TIME"
          />
        </div>
        <div class="box">
          <label>연락처</label>
          <p class="font-weight-black">{{ userInfo.USER_TEL }}</p>
        </div>
        <div class="box">
          <label>레벨</label>
          <v-radio-group>
            <v-radio
              label="기초 단어를 따라 말할 수 있어요."
              value="1"
              class="font-weight-black"
              v-model="freeclassInfo.FRC_LEVEL.LEVEL1"
            />
            <v-radio
              label="간단한 문장을 말할 수 있어요."
              value="2"
              class="font-weight-black"
              v-model="freeclassInfo.FRC_LEVEL.LEVEL2"
            />
            <v-radio
              label="자유롭게 프리토킹이 가능해요."
              value="3"
              class="font-weight-black"
              v-model="freeclassInfo.FRC_LEVEL.LEVEL3"
            />
          </v-radio-group>
        </div>
        <div class="box"></div>
        <div class="box mt-10">
          <label>특이사항</label>
          <v-textarea
            clearable
            no-resize
            height="300"
            class="font-weight-black"
            full-width
          ></v-textarea>
        </div>
      </div>
      <div class="button-wrapper">
        <v-btn @click="addFreeclass" color="primary" depressed>등록</v-btn>
        <v-btn @click="cancle" color="unstyled" depressed>취소</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Popup",
  props: ["value", "selectData"],
  data() {
    return {
      userInfo: {},
      menu: false,
      date: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
        .toISOString()
        .substr(0, 10),
      timeItems: [
        "14:00",
        "14:30",
        "15:00",
        "15:30",
        "16:00",
        "16:30",
        "17:00",
        "17:30",
        "18:00",
        "18:30",
        "19:00",
        "19:30",
        "20:00",
        "20:30",
        "21:00",
        "21:30",
      ],
      freeclassInfo: {
        FRC_TUTOR: null,
        FRC_REG_DATE: {
          DAY: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
            .toISOString()
            .substr(0, 10),
          TIME: null,
          DAY_OF_WEEK: null,
        },
        FRC_FIXED_DATE: {
          DAY: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
            .toISOString()
            .substr(0, 10),
          TIME: null,
          DAY_OF_WEEK: null,
        },
        FRC_STATUS: "접수",
        FRC_USER_DATA: {
          DATA_ID: null,
          NAME: null,
          ID: null,
          TEL: null,
        },
        FRC_LEVEL: {
          LEVEL1: 1,
          LEVEL2: 2,
          LEVEL3: 3,
        },
      },
    };
  },
  mounted() {
    if (this.selectData) {
      this.userInfo = this.selectData;
      this.freeclassInfo.FRC_USER_DATA.DATA_ID = this.selectData._id;
      this.freeclassInfo.FRC_USER_DATA.NAME = this.selectData.USER_NAME;
      this.freeclassInfo.FRC_USER_DATA.ID = this.selectData.USER_ID;
      this.freeclassInfo.FRC_USER_DATA.TEL = this.selectData.USER_TEL;
    }
  },
  methods: {
    cancle(v) {
      this.$nuxt.$emit("popup-close", false);
      if (v == "ok") this.$router.go();
    },
    closePopup(e) {
      if (e.target.className == "popup-wrapper") {
        this.cancle();
      }
    },
    async addFreeclass() {
      // await this.$axios
      //   .post(`/freeclass/create`, this.freeclassInfo)
      //   .then((response) => {
      //     console.log(response);
      //   })
      //   .catch((error) => {
      //     console.log(error);
      //   });
      // this.cancle("ok");
      console.log(this.freeclassInfo);
    },
  },
};
</script>
