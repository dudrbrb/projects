<template>
  <!-- 수강관리 -->
  <div class="popup-wrapper" @click="closePopup($event)">
    <div class="popup add-class" v-if="popupData == 'management'">
      <h4>수강관리</h4>
      <div class="user-info">
        <p><b>이름(ID)</b>{{ userInfo.USER_NAME }} ({{ userInfo.USER_ID }} )</p>
      </div>
      <div class="class-table">
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th v-for="(data, idx) in tableData" :key="`header${idx}`">
                {{ data.text }}
              </th>
            </tr>
          </thead>
          <tbody v-if="userInfo.class == null">
            <tr>
              <td colspan="9">등록된 내용이 없습니다</td>
            </tr>
          </tbody>
          <tbody v-else>
            <tr v-for="(classes, idx) in userInfo.class" :key="`class${idx}`">
              <td>{{ idx }}</td>
              <td
                v-for="(data, idx2) in tableData"
                :key="`${idx}-${idx2}`"
                :class="data.value"
              >
                {{ classes[data.value] }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="button-wrapper">
        <v-btn @click="popupData = 'add'" color="primary" depressed
          >수강 등록하기</v-btn
        >
        <v-btn @click="cancle" color="unstyled" depressed>닫기</v-btn>
      </div>
    </div>

    <div class="popup add-class" v-else-if="popupData == 'add'">
      <h4>수강등록</h4>
      <div class="input-wrapper">
        <div class="box">
          <label>이름</label>
          <p>{{ classInfo.CLS_USER_DATA.NAME }}</p>
        </div>
        <div class="box">
          <label>연락처</label>
          <p>{{ classInfo.CLS_USER_DATA.TEL }}</p>
        </div>
        <div class="box">
          <label>교재</label>
          <v-text-field
            outlined
            v-model="classInfo.CLS_TEXTBOOK"
          ></v-text-field>
        </div>
        <div class="box">
          <label>수업시작일</label>
          <v-menu
            ref="menu"
            v-model="menu"
            :close-on-content-click="false"
            :return-value.sync="classInfo.CLS_START_DAY"
            transition="scale-transition"
            offset-y
            min-width="auto"
          >
            <template v-slot:activator="{ on, attrs }">
              <v-text-field
                outlined
                v-model="classInfo.CLS_START_DAY"
                prepend-icon="mdi-calendar"
                readonly
                v-bind="attrs"
                v-on="on"
              ></v-text-field>
            </template>
            <v-date-picker
              v-model="classInfo.CLS_START_DAY"
              no-title
              scrollable
            >
              <v-spacer></v-spacer>
              <v-btn text color="primary" @click="menu = false"> 취소 </v-btn>
              <v-btn
                text
                color="primary"
                @click="$refs.menu.save(classInfo.CLS_START_DAY)"
              >
                선택
              </v-btn>
            </v-date-picker>
          </v-menu>
        </div>
        <div class="box">
          <label>수업 시간</label>
          <v-select
            outlined
            :items="timeItems"
            v-model="classInfo.CLS_START_TIME"
          ></v-select>
        </div>
        <div class="box">
          <label>금액</label>
          <v-text-field
            outlined
            suffix="원"
            v-model="classInfo.CLS_PAYMENT.PRICE"
          ></v-text-field>
        </div>
        <div class="box">
          <label>결제상태</label>
          <v-text-field
            outlined
            v-model="classInfo.CLS_PAYMENT.STATUS"
          ></v-text-field>
        </div>

        <div class="box full">
          <label>메모</label>
          <v-textarea outlined class="full"></v-textarea>
        </div>
      </div>
      <div class="button-wrapper">
        <v-btn @click="addRegularClass" color="primary" depressed>등록</v-btn>
        <v-btn @click="cancle" color="unstyled" depressed>취소</v-btn>
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
.user-info {
  p {
    font-size: 18px;
    b {
      font-size: 1em;
      display: inline-block;
      margin-right: 10px;
    }
  }
}
.class-table {
  table {
    width: 100%;
    white-space: nowrap;
    border-collapse: collapse;
    background-color: $white;
    tr {
      td,
      th {
        text-align: center;
        padding: 8px 10px;
        border: 0;
        border-collapse: collapse;
        word-break: keep-all;
        white-space: nowrap;
        vertical-align: top;
      }
    }

    thead {
      background-color: $lightGray;
      border: 1px solid $gray;
      border-radius: 5px;
      tr {
        th {
          padding: 10px 15px;
          border-left: 1px solid $gray;
        }
      }
    }
    tbody {
      border: 1px solid $gray;
      tr {
        height: auto;
        &:nth-child(even) {
          background-color: #f8f8f8e7;
        }
        td {
          border-left: 1px solid $gray;
          vertical-align: middle;
          text-align: center;

          button {
            border-radius: 20px;
            padding: 0;
          }
        }
      }
    }
  }
}
</style>
<script>
export default {
  name: "Popup",
  props: ["value", "selectData"],
  data() {
    return {
      userInfo: {},
      popupData: "management",
      tableData: [
        { text: "신규, 연장", value: "USER_REG_DAY" },
        { text: "정규수업 확정 시작일", value: "USER_NAME" },
        { text: "시간", value: "USER_ID" },
        { text: "요일", value: "USER_COMPANY" },
        { text: "남은횟수", value: "USER_COMPANY" },
        { text: "정규강사", value: "USER_COMPANY" },
        { text: "결제상태", value: "USER_COMPANY" },
        { text: "수강신청", value: "USER_COMPANY" },
      ],
      classInfo: {
        CLS_REG_DAY: new Date(
          Date.now() - new Date().getTimezoneOffset() * 60000
        )
          .toISOString()
          .substr(0, 10),
        CLS_USER_DATA: {
          NAME: null,
          DATA_ID: null,
          ID: null,
          TEL: null,
          COMPANY: "협력사",
        },
        CLS_START_DAY: new Date(
          Date.now() - new Date().getTimezoneOffset() * 60000
        )
          .toISOString()
          .substr(0, 10),
        CLS_START_TIME: null,
        CLS_DAY_OF_WEEK: null,
        CLS_CANCLE_COUNT: 0,
        CLS_TEXTBOOK: null,
        CLS_PAYMENT: {
          METHOD: null,
          STATUS: null,
          PRICE: null,
          DATE: null,
        },
      },
      timeItems: [
        "14:00",
        "14:30",
        "15:00",
        "15:30",
        "16:00",
        "16:30",
        "17:00",
        "17:30",
        "18:00",
        "18:30",
        "19:00",
        "19:30",
        "20:00",
        "20:30",
        "21:00",
        "21:30",
      ],
      date: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
        .toISOString()
        .substr(0, 10),
      menu: false,
    };
  },
  mounted() {
    if (this.selectData) {
      this.userInfo = this.selectData;
      this.classInfo.CLS_USER_DATA.NAME = this.selectData.USER_NAME;
      this.classInfo.CLS_USER_DATA.DATA_ID = this.selectData._id;
      this.classInfo.CLS_USER_DATA.ID = this.selectData.USER_ID;
      this.classInfo.CLS_USER_DATA.TEL = this.selectData.USER_TEL;
    }
  },
  methods: {
    cancle(v) {
      this.$nuxt.$emit("popup-close", false);
      if (v == "ok") this.$router.go();
    },
    closePopup(e) {
      if (e.target.className == "popup-wrapper") {
        this.cancle();
      }
    },
    getAge() {
      var birthYear = this.userInfo.birthday.split("-")[0];
      var thisYear = new Date().getFullYear();

      this.userInfo.age = thisYear - birthYear + 1;
    },
    async addRegularClass() {
      await this.$axios
        .post(`/class/create`, this.classInfo)
        .then((response) => {
          console.log(response);
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
