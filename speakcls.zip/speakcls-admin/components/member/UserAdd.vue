<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup add-member">
    <h4 v-if="value == 'user-add'">회원 등록</h4>
    <h4 v-if="value == 'user-edit'">회원 정보 수정</h4>
    
    
    <div class="input-wrapper">
        <div class="box">
            <label>이름</label>
            <v-text-field outlined v-model="userInfo.USER_NAME"></v-text-field>
        </div>
        <div class="box">
            <label>영어이름</label>
            <v-text-field outlined v-model="userInfo.USER_ENGLISH_NAME"></v-text-field>
        </div>
        <div class="box">
            <label>ID</label>
            <v-text-field outlined v-model="userInfo.USER_ID"></v-text-field>
            <v-btn depressed small color="secondary" v-if="value=='user-add'">중복체크</v-btn>
        </div>
        <div class="box">
            <label>비밀번호</label>
            <v-text-field outlined v-model="userInfo.USER_PW"></v-text-field>
        </div>
        <div class="box">
            <label>연락처</label>
            <v-text-field outlined v-model="userInfo.USER_TEL"></v-text-field>
        </div>
        <div class="box">
            <label>성별</label>
            <v-select outlined  :items="genderItems"  v-model="userInfo.USER_GENDER"></v-select>
        </div>
        <div class="box">
            <label>주소</label>
            <v-text-field outlined v-model="userInfo.USER_ADDRESS"></v-text-field>
        </div>
        <div class="box">
            <label>가입경로</label>
            <v-text-field outlined v-model="userInfo.USER_REG_ROOT"></v-text-field>
        </div>
        <div class="box">
            <label>추천인</label>
            <v-text-field outlined v-model="userInfo.USER_RECD_NAME"></v-text-field>
        </div>
        <div class="box">
            <label>쿠폰</label>
            <v-text-field outlined v-model="userInfo.USER_COUPON"></v-text-field>
        </div>
        <div class="box full">
            <label>메모</label>
            <v-textarea outlined  class="full" v-model="userInfo.USER_NOTE"></v-textarea>
        </div>
    </div>
    <div class="button-wrapper">
        <v-btn @click="addUser" color="primary" v-if="value=='user-add'">등록</v-btn>
        <v-btn @click="editUser" color="primary" v-if="value=='user-edit'">수정 완료</v-btn>
        <v-btn @click="deleteUser" color="error" v-if="value=='user-edit'">회원 삭제</v-btn>
        <v-btn @click="cancle">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>

</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            userInfo:{
                USER_NAME: null,
                USER_ENGLISH_NAME: null,
                USER_ID: null,
                USER_PW: null,
                USER_TEL:null,
                USER_GENDER: null,
                USER_ADDRESS: null,
                USER_REG_ROOT: null,
                USER_REG_DAY: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                USER_RECD_NAME: null,
                USER_RECD_TEL: null,
                USER_COUPON : null,
                USER_LEVEL_RESULT: null,
                USER_NOTE: null
            },
            genderItems: ['남', '여'],
        }
    },
    async fetch() {
    },
    filters:{
    },
    mounted() {
        if(this.selectData){
            this.userInfo = this.selectData
        }
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        getAge(){
            var birthYear = this.userInfo.birthday.split('-')[0];
            var thisYear = new Date().getFullYear();
            
            this.userInfo.age = thisYear - birthYear +1;
        },
        async addUser(){
            await this.$axios.post(`/user/create`, this.userInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async editUser(){
            await this.$axios.post(`/user/edit/`+ this.selectData._id , this.userInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async deleteUser(){
            this.$axios.$get(`/user/delete/`+ this.selectData._id).then(data =>{
                console.log(data)
            }).catch((error)=>{
                console.log(error.data)
            });
        
            this.cancle('ok');
        }
    }
}
</script>
