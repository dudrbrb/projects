<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup class-refund">
    <h4>환불 신청</h4>
    
    <div class="input-wrapper column">
        <div class="box">
            <label>이름 (ID)</label>
            <p>신청학생 (아이디)</p>
        </div>
        <div class="box">
            <label>환불 금액</label>
            <v-text-field outlined ></v-text-field>
        </div>
        <div class="box">
            <label>환불 일자</label>
            <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="date" 
            transition="scale-transition" offset-y min-width="auto">
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field outlined v-model="date" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on" ></v-text-field>
                </template>
                <v-date-picker v-model="date" no-title scrollable >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        취소
                    </v-btn>
                    <v-btn text color="primary" @click="$refs.menu.save(date)">
                        선택
                    </v-btn>
                </v-date-picker>
            </v-menu>
        </div>
    </div>
    <div class="button-wrapper">
        <v-btn @click="cancle" color="primary">등록</v-btn>
        <v-btn @click="cancle">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>

</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            refundInfo : null,
            menu: false,
            date: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
        }
    },
    async fetch() {
    },
    filters:{
    },
    mounted() {
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
      
    }
}
</script>
