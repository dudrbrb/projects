<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup add-class">
    <h4>수강 신청</h4>
    
    <div class="input-wrapper">
        <div class="box">
            <label>이름 (ID)</label>
            <p>신청학생 (아이디)</p>
        </div>
        <div class="box">
            <label>영어이름</label>
            <v-text-field outlined v-model="classInfo.LVT_ENGLISH_NAME"></v-text-field>
        </div>
        <div class="box">
            <label>비밀번호</label>
            <v-text-field outlined v-model="classInfo.LVT_PW"></v-text-field>
        </div>
        <div class="box">
            <label>연락처</label>
            <v-text-field outlined v-model="classInfo.LVT_TEL"></v-text-field>
        </div>
        <div class="box">
            <label>성별</label>
            <v-select outlined  :items="genderItems"  v-model="classInfo.LVT_GENDER"></v-select>
        </div>
        <div class="box">
            <label>주소</label>
            <v-text-field outlined v-model="classInfo.LVT_ADDRESS"></v-text-field>
        </div>
        <div class="box">
            <label>가입경로</label>
            <v-text-field outlined v-model="classInfo.LVT_REG_ROOT"></v-text-field>
        </div>
        <div class="box">
            <label>추천인</label>
            <v-text-field outlined v-model="classInfo.LVT_RECD_NAME"></v-text-field>
        </div>
        <div class="box">
            <label>쿠폰</label>
            <v-text-field outlined v-model="classInfo.LVT_COUPON"></v-text-field>
        </div>
        <div class="box full">
            <label>메모</label>
            <v-textarea outlined  class="full" v-model="classInfo.LVT_NOTE"></v-textarea>
        </div>
    </div>
    <div class="button-wrapper">
        <v-btn @click="addClass" color="primary">등록</v-btn>
        <v-btn @click="cancle">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>

</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            classInfo:{
                CLS_NAME: null,
                CLS_ENGLISH_NAME: null,
                CLS_ID: null,
                CLS_PW: null,
                CLS_TEL:null,
                CLS_GENDER: null,
                CLS_ADDRESS: null,
                CLS_REG_ROOT: null,
                CLS_REG_DAY: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                CLS_RECD_NAME: null,
                CLS_RECD_TEL: null,
                CLS_COUPON : null,
                CLS_LEVEL_RESULT: null,
                CLS_NOTE: null
            },
            genderItems: ['남', '여'],
        }
    },
    async fetch() {
    },
    filters:{
    },
    mounted() {
        if(this.selectData){
            this.classInfo = this.selectData
        }
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        getAge(){
            var birthYear = this.classInfo.birthday.split('-')[0];
            var thisYear = new Date().getFullYear();
            
            this.classInfo.age = thisYear - birthYear +1;
        },
        async addClass(){
            await this.$axios.post(`/class/create`, this.classInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async editClass(){
            await this.$axios.post(`/class/edit/`+ this.selectData._id , this.classInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async deleteClass(){
            this.$axios.$get(`/class/delete/`+ this.selectData._id).then(data =>{
                console.log(data)
            }).catch((error)=>{
                console.log(error.data)
            });
        
            this.cancle('ok');
        }
    }
}
</script>
