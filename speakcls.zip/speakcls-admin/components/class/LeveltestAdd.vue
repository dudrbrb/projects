<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup add-leveltest">
    <h4 v-if="value == 'leveltest-add'">레벨테스트 신청</h4>
    <h4 v-if="value == 'leveltest-edit'">레벨테스트 정보 수정</h4>
    <h4 v-if="value == 'leveltest-edit-result'">레벨테스트 결과 입력</h4>
    <h4 v-if="value == 'leveltest-edit-tutor'">레벨테스트 강사 선택</h4>
    <div class="input-wrapper">
        <div class="box">
            <label>학생 이름</label>
            <p v-if="infoFix">{{leveltestInfo.LVT_USER_DATA.NAME}}</p>
            <v-text-field outlined v-else v-model="leveltestInfo.LVT_USER_DATA.NAME" ></v-text-field>
        </div>
        <div class="box">
            <label>학생 연락처</label>
            <p v-if="infoFix">{{leveltestInfo.LVT_USER_DATA.TEL}}</p>
            <v-text-field outlined v-else v-model="leveltestInfo.LVT_USER_DATA.TEL" ></v-text-field>
        </div>
        <div class="box">
            <label>학년</label>
            <p v-if="infoFix">{{leveltestInfo.LVT_USER_DATA.GRADE}}</p>
            <v-select outlined  v-else :items="gradeItems" v-model="leveltestInfo.LVT_USER_DATA.GRADE"></v-select>
        </div>
        <div class="box">
            <label>테스트 날짜</label>
            <p v-if="infoFix">{{leveltestInfo.LVT_FIXED_DATE.DAY}}</p>
            <v-menu v-else ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="leveltestInfo.LVT_FIXED_DATE.DAY" 
            transition="scale-transition" offset-y min-width="auto" >
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field outlined v-model="leveltestInfo.LVT_FIXED_DATE.DAY" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on" ></v-text-field>
                </template>
                <v-date-picker v-model="leveltestInfo.LVT_FIXED_DATE.DAY" no-title scrollable >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        취소
                    </v-btn>
                    <v-btn text color="primary" @click="$refs.menu.save(leveltestInfo.LVT_FIXED_DATE.DAY)">
                        선택
                    </v-btn>
                </v-date-picker>
            </v-menu>
        </div>
        <div class="box">
            <label>테스트 시간</label>
            <p v-if="infoFix">{{leveltestInfo.LVT_FIXED_DATE.TIME}}</p>
            <v-select outlined  v-else :items="timeItems" v-model="leveltestInfo.LVT_FIXED_DATE.TIME"></v-select>
        </div>
        <div class="box" :class="{full : value !== 'leveltest-edit-result'}">
            <label>학습수준</label>
            <p v-if="infoFix">{{leveltestInfo.LVT_USER_DATA.LEVEL}}</p>
            <v-radio-group v-else v-model="leveltestInfo.LVT_USER_DATA.LEVEL">
                <v-radio label="기초 단어를 따라 말할 수 있어요." value="기초 단어를 따라 말할 수 있어요." ></v-radio>
                <v-radio label="간단한 문장을 말할 수 있어요." value="간단한 문장을 말할 수 있어요."></v-radio>
                <v-radio label="자유롭게 프리토킹이 가능해요." value="자유롭게 프리토킹이 가능해요."></v-radio>
            </v-radio-group>
        </div>
        <div v-if="value == 'leveltest-edit-result'" class="box-wrap">
            <h5>영역별 진단</h5>
            <div class="box">
                <label>SR / AR</label>
                <v-select outlined  :items="arsrItems" v-model="leveltestInfo.LVT_RESULT.DIAGNOSIS.SR_AR"></v-select>
            </div>
            <div class="box">
                <label>CEFR</label>
                <v-select outlined  :items="crefItems" v-model="leveltestInfo.LVT_RESULT.DIAGNOSIS.CEFR"></v-select>
            </div>
            <div class="box">
                <label>LEXILE</label>
                <v-select outlined  :items="lexileItems" v-model="leveltestInfo.LVT_RESULT.DIAGNOSIS.LEXILE"></v-select>
            </div>
            <div class="box">
                <label>평균 학년 수준</label>
                <v-select outlined  :items="averageItems" v-model="leveltestInfo.LVT_RESULT.DIAGNOSIS.AVERAGE"></v-select>
            </div>
        </div>
        <div v-if="value == 'leveltest-edit-result'" class="box-wrap">
            <h5>영역별 점수</h5>
            <div class="box">
                <label>발음 </label>
                <v-text-field outlined v-model="leveltestInfo.LVT_RESULT.SCORE.PRONUNCIATION"  type="number" suffix="점" ></v-text-field>
            </div>
            <div class="box">
                <label>문법 </label>
                <v-text-field outlined v-model="leveltestInfo.LVT_RESULT.SCORE.GRAMMER"  type="number" suffix="점" ></v-text-field>
            </div>
            <div class="box">
                <label>어휘 </label>
                <v-text-field outlined v-model="leveltestInfo.LVT_RESULT.SCORE.VOCABULARY"  type="number" suffix="점" ></v-text-field>
            </div>
            <div class="box">
                <label>이해 </label>
                <v-text-field outlined v-model="leveltestInfo.LVT_RESULT.SCORE.UNDERSTANDING"  type="number" suffix="점" ></v-text-field>
            </div>
            <div class="box">
                <label>유창성 </label>
                <v-text-field outlined v-model="leveltestInfo.LVT_RESULT.SCORE.FLUENCY"  type="number" suffix="점" ></v-text-field>
            </div>
        </div>
        <div v-if="value == 'leveltest-edit-result'" class="box-wrap">
            <h5>총 평가</h5>
            <div class="box">
                <label>종합 레벨 </label>
                <v-select outlined  :items="levelItems" v-model="leveltestInfo.LVT_RESULT.TOTAL" ></v-select>
            </div>
            <div class="box full">
                <label>전체 평가</label>
                <v-textarea outlined  class="full" v-model="leveltestInfo.LVT_TOTAL_EVALUATION"></v-textarea>
            </div>
            <div class="box full">
                <label>튜터의 코멘트 </label>
                <v-textarea outlined  class="full"  v-model="leveltestInfo.LVT_TUTOR_COMMEND"></v-textarea>
            </div>
        </div>

    </div>
    <div class="button-wrapper">
        <v-btn @click="addLeveltest" color="primary" v-if="value == 'leveltest-add'">등록</v-btn>
        <v-btn @click="editLeveltest" color="primary" v-if="value == 'leveltest-edit' || value == 'leveltest-edit-result'">수정 완료</v-btn>
        <v-btn @click="cancle">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>
.add-leveltest{
    .input-wrapper{
        justify-content: flex-start !important;
        .box-wrap{
            width: 100%;
            @include flex(flex-start);
            flex-wrap: wrap;
            h5{
                width: 100%;
                font-size: 18px;
                margin: 20px 0 15px;
            }
        }
        
    }
}
</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            leveltestInfo:{
                LVT_TUTOR: null,
                LVT_REG_DATE:{
                    DAY:(new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                    TIME: null,
                    DAY_OF_WEEK : null
                },
                LVT_FIXED_DATE:{
                    DAY:(new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
                    TIME: null,
                    DAY_OF_WEEK : null
                },
                
                LVT_RESULT:{   
                    TOTAL: null,
                    DIAGNOSIS:{SR_AR:null,CEFR:null,LEXILE:null,AVERAGE: null},
                    SCORE: {PRONUNCIATION: null , GRAMMER: null, VOCABULARY: null, UNDERSTANDING: null, FLUENCY:null }
                },
                LVT_ARTICLE:{
                    COLLECT_USER_IMPORMATION:true,
                    EVENT_NOTIFICATION:true
                },
                LVT_TOTAL_EVALUATION: null,
                LVT_TUTOR_COMMEND:null,
                LVT_STATUS:"접수",
                LVT_USER_DATA:{
                    DATA_ID:null,
                    NAME: null,
                    TEL: null,
                    GRADE: null,
                    LEVEL: null
                },

            },
            menu: false,
            infoFix: false,
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
            gradeItems:['미취학', '초등학교 1학년', '초등학교 2학년', '초등학교 3학년', '초등학교 4학년', '초등학교 5학년', '초등학교 6학년', '중학교 1학년','중학교 2학년','중학교 3학년', '고등학교 1학년', '고등학교 2학년', '고등학교 3학년', '성인'],
            arsrItems:['0 ~ 1', '1.1 ~ 1.2', '1.3 ~ 1.4', '1.6 ~ 1.7', '2.3 ~ 2.6', '2.7 ~ 2.8', '2.9 ~ 3.0'],
            crefItems:['~A1', 'A1', 'A1+', 'A12', 'A2+', 'B1', 'B2~'],
            lexileItems:['0 ~ 100', '100 ~ 150', '150 ~ 300', '300 ~ 425', '425 ~ 475', '475 ~ 525', '525 ~ 650'],
            averageItems:['미취학아동', '초1 ~ 초2', '초2 ~ 초3', '초3 ~ 초4', '초4 ~ 초5', '초5 ~ 초6', '초6 ~ 중1'],
            levelItems:['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6'],
        }
    }, 
    async fetch() {
    },
    filters:{
    },
    mounted() {
        if(this.selectData){
            this.leveltestInfo = this.selectData;
        }
        if(this.value == 'leveltest-edit-tutor' || this.value == 'leveltest-edit-result'){
            this.infoFix = true
        }
        this.getToday()
        
    },
    watch:{
        leveltestInfo:{
            deep: true,
            handler(info){
                console.log(info)
                var date = info.LVT_FIXED_DATE.DAY;
                var week = new Array('일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일');
                
                info.LVT_FIXED_DATE.DAY_OF_WEEK = week[new Date(date).getDay()]

            }
        },
        
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        getToday(){
            var today = new Date(),
                hours = ('0' + today.getHours()).slice(-2),
                minutes = ('0' + today.getMinutes()).slice(-2),
                seconds = ('0' + today.getSeconds()).slice(-2); 
            
            var week = new Array('일', '월', '화', '수', '목', '금', '토');

            this.leveltestInfo.LVT_REG_DATE.TIME = `${hours}:${minutes}:${seconds}`
            this.leveltestInfo.LVT_REG_DATE.DAY_OF_WEEK = week[today.getDay()]

        },
        async addLeveltest(){
            await this.$axios.post(`/leveltest/create`, this.leveltestInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
        async editLeveltest(){
            await this.$axios.post(`/leveltest/edit/`+ this.selectData._id , this.leveltestInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });
            this.cancle('ok');
        },
 
    }
}
</script>
