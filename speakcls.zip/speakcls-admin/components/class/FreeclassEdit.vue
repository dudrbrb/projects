<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup add-freeclass">
    <h4>무료수업 수정</h4>
    
    <div class="input-wrapper">
        <div class="box">
            <label>이름</label>
            <p>{{freeclassInfo.FRC_USER_DATA.NAME}}</p>
        </div>
        <div class="box">
            <label>아이디</label>
            <p>{{freeclassInfo.FRC_USER_DATA.ID}}</p>
        </div>
        <div class="box">
            <label>연락처</label>
            <p>{{freeclassInfo.FRC_USER_DATA.TEL}}</p>
        </div>
        <div class="box">
            <label>수업시작일</label>
            <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="freeclassInfo.FRC_FIXED_DATE.DAY" 
            transition="scale-transition" offset-y min-width="auto" >
                <template v-slot:activator="{ on, attrs }">
                    <v-text-field outlined v-model="freeclassInfo.FRC_FIXED_DATE.DAY" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on" ></v-text-field>
                </template>
                <v-date-picker v-model="freeclassInfo.FRC_FIXED_DATE.DAY" no-title scrollable >
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                        취소
                    </v-btn>
                    <v-btn text color="primary" @click="$refs.menu.save(freeclassInfo.FRC_FIXED_DATE.DAY)">
                        선택
                    </v-btn>
                </v-date-picker>
            </v-menu>
        </div>
        <div class="box">
            <label>수업 시간</label>
            <v-select outlined  :items="timeItems" v-model="freeclassInfo.FRC_FIXED_DATE.TIME"></v-select>
        </div>
    </div>
    <div class="button-wrapper">
        <v-btn @click="editFreeclass" color="secondary">등록</v-btn>
        <v-btn @click="cancle" color="error">취소</v-btn>
    </div>

</div>
</div>

</template>
<style lang="scss" scoped>
</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            freeclassInfo:{},
            menu: false,
            date: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            timeItems:['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30' ],
        }
    },
    created(){
        this.freeclassInfo = this.selectData;
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        async editFreeclass(){
            await this.$axios.post(`/freeclass/edit/`+ this.freeclassInfo._id , this.freeclassInfo).then( (response) => {
                console.log(response);
            }).catch( (error) => {
                console.log(error);
            });

            // this.cancle('ok');
        },
    }
}
</script>
