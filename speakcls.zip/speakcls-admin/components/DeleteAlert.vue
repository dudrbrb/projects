<template>
<div class="popup-wrapper"  @click="closePopup($event)">
<div class="popup delete-member" v-if="selectData.length == 0">
    <p v-if="value == 'user-delete'">삭제할 회원을 선택해주세요.</p>
    <p v-if="value == 'tutor-delete'">삭제할 강사를 선택해주세요.</p>
    <p v-if="value == 'leveltest-delete'">삭제할 레벨테스트를 선택해주세요.</p>
    <p v-if="value == 'freeclass-delete'">삭제할 무료수업을 선택해주세요.</p>
    <div class="button-wrapper">
        <v-btn color='primary' @click="cancle">확인</v-btn>
    </div>
</div>

<div class="popup delete-member" v-else>
    <div>
        <h4 v-if="value == 'user-delete'">학생 정보 삭제</h4>
        <h4 v-if="value == 'tutor-delete'">강사 정보 삭제</h4>
        <h4 v-if="value == 'leveltest-delete'">레벨테스트 신청 내역 삭제</h4>
        <h4 v-if="value == 'freeclass-delete'">무료수업 신청 내역 삭제</h4>

        <p v-if="value == 'leveltest-delete' || value == 'freeclass-delete'">{{selectData.length}}개의 데이터를 영구적으로 삭제하시겠습니까?</p>
        <p v-else>{{selectData.length}}명의 데이터를 영구적으로 삭제하시겠습니까?</p>

        <div class="button-wrapper">
            <v-btn @click="deleteEvent" color="error" >삭제</v-btn>
            <v-btn @click="cancle">취소</v-btn>
        </div>
    </div>
</div>
</div>

</template>
<style lang="scss" scoped>
.delete-member{
    max-width: 400px;
}
</style>
<script>
export default {
    name: 'Popup',
    props:['value', 'selectData'],
    data(){
        return {
            userInfo:{},
        }
    },
    async fetch() {
    },
    filters:{
    },
    mounted() {
        if(this.selectData){
            this.$axios.$get(`/tutor/info/`+ this.selectData).then(data =>{
                console.log( data.data[0]);
                this.userInfo = data.data[0];
            }).catch((error)=>{
                console.log(error.data)
            });
        }
    },
    methods:{   
        cancle(v){
            this.$nuxt.$emit("popup-close", false)
            if(v== 'ok') this.$router.go();
        },
        closePopup(e){
            if(e.target.className == "popup-wrapper"){
                this.cancle();
            }
        },
        deleteEvent(){
            if(this.value == 'user-delete') {
                this.deleteUser();
            } else if(this.value == 'tutor-delete'){
                this.deleteTutor();
            } else if(this.value == 'leveltest-delete'){
                this.deleteLeveltest();
            } else if(this.value == 'freeclass-delete'){
                this.deleteFreeclass();
            }
            
        },
        async deleteUser(){
            this.selectData.forEach(e =>{
                this.$axios.$get(`/user/delete/`+ e).then(data =>{
                    console.log(data)
                }).catch((error)=>{
                    console.log(error.data)
                });
            })
        
            this.cancle('ok');
        },
        async deleteTutor(){
            this.selectData.forEach(e =>{
                this.$axios.$get(`/tutor/delete/`+ e).then(data =>{
                    console.log(data)
                }).catch((error)=>{
                    console.log(error.data)
                });
            })
        
            this.cancle('ok');
        },
        async deleteLeveltest(){
            this.selectData.forEach(e =>{
                this.$axios.$get(`/leveltest/delete/`+ e).then(data =>{
                    console.log(data)
                }).catch((error)=>{
                    console.log(error.data)
                });
            })
        
            this.cancle('ok');
        },
        async deleteFreeclass(){
            this.selectData.forEach(e =>{
                this.$axios.$get(`/freeclass/delete/`+ e).then(data =>{
                    console.log(data)
                }).catch((error)=>{
                    console.log(error.data)
                });
            })
        
            this.cancle('ok');
        }
    }
}
</script>
