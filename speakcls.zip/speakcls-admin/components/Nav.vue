<template>
  <div class="nav-wrapper">
    <nav>
      <nuxt-link :to="'/'">
        <img :src="require('@/assets/img/logo.png')" class="logo" />
      </nuxt-link>
      <ul class="menu">
        <li
          v-for="(menu, idx) in menuList"
          :key="`menu${idx}`"
          :class="{ open: selectMenu == idx }"
        >
          <b @click="selectMenu == idx ? (selectMenu = null) : (selectMenu = idx)" class="arrow">{{
            menu.menuName
          }}</b>
          <ul>
            <li v-for="(sub, idx2) in menu.subMenu" :key="`sub menu${idx2}`">
              <b v-if="sub.subInSub" class="font3">{{ sub.title }}</b>
              <div v-if="sub.subInSub">
                <nuxt-link
                  v-for="(sub2, idx3) in sub.subInSub"
                  :key="`sub in sub menu${idx3}`"
                  :to="sub2.to"
                  class="subInSub"
                >
                  {{ sub2.title }}
                </nuxt-link>
              </div>
              <nuxt-link :to="sub.to" v-else> {{ sub.title }}</nuxt-link>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
  </div>
</template>
<style lang="scss" scoped>
.nav-wrapper {
  background-color: #343a40;
  position: fixed;
  left: 0;
  top: 0;
  overflow-x: hidden;
  overflow-y: scroll;
  width: 200px;
  height: 100%;
  z-index: 999;
  box-shadow: $shadow;
  &::-webkit-scrollbar {
    width: 0px;
  }

  nav {
    position: relative;
    margin-right: 50px;
    padding: 30px 0;
    width: 100%;
    .logo {
      width: 130px;
      margin-bottom: 10px;
      margin-left: 20px;
    }
    .menu {
      padding-left: 0;
      width: 100%;

      > li {
        line-height: 50px;
        max-height: 50px;
        border-bottom: 1px solid #000;
        overflow: hidden;
        transition: max-height 0.5s;
        b {
          width: 100%;
          list-style: none;
          display: inline-block;
          position: relative;
          cursor: pointer;
          line-height: 1;
          font-size: 15px;
          margin-left: 20px;
          color: $white;
        }
        a {
          display: block;
          @include flex(flex-start);
          font-size: 14px;
          &.nuxt-link-active {
            color: $pink;
          }
        }
        .arrow::after {
          @include arrow();
          transform: rotate(0);
          transition: transform 0.3s;
          right: 40px;
          filter: brightness(100);
        }
        > ul {
          background-color: $white;
          padding-right: 20px;
          li {
            line-height: 40px;
            &:first-child {
              padding-top: 5px;
              border-top: 2px solid rgb(255, 255, 255);
            }
            &:last-child {
              padding-bottom: 5px;
            }

            b {
              margin-left: 0;
            }
            a {
              display: block;
              @include flex(flex-start);
              font-size: 14px;
              &.nuxt-link-active {
                color: $pink;
              }
            }
            li,
            a,
            b {
              color: $black;
            }
          }
        }

        .subInSub::before {
          content: "";
          width: 6px;
          height: 6px;
          margin-right: 5px;
          border-left: 1px solid #000;
          border-bottom: 1px solid #000;
        }
        &.open {
          border-bottom: none;
          background-color: $white;
          max-height: 560px;
          li,
          a,
          b {
            color: $black;
          }
          .arrow::after {
            transform: rotate(180deg);
            filter: brightness(0);
          }
          > ul {
            > li {
              &:first-child {
                border-top: 2px solid #000;
              }
            }
          }
        }
      }
    }
  }
}
</style>
<script>
export default {
  name: "Nav",
  data() {
    return {
      menuList: [
        {
          menuName: "대시보드",
          subMenu: [
            { title: "통계 데이터", to: "/data/stats" },
            { title: "월간 통계 데이터", to: "/data/monthly-stats" },
            { title: "정산 데이터", to: "/data/settlement" },
          ],
        },
        {
          menuName: "회원관리",
          subMenu: [
            { title: "회원관리", to: "/member/student" },
            { title: "강사관리", to: "/member/tutor" },
          ],
        },
        {
          menuName: "스케쥴관리",
          subMenu: [
            { title: "일간스케쥴", to: "/schedule/daily" },
            { title: "주간스케쥴", to: "/schedule/weekly" },
            { title: "월간스케쥴", to: "/schedule/monthly" },
          ],
        },
        {
          menuName: "수업관리",
          subMenu: [
            { title: "레벨테스트 관리", to: "/class/leveltest" },
            { title: "무료수업 관리", to: "/class/freeclass" },
            { title: "접수 관리", to: "/class/accept" },
            { title: "수업 관리", to: "/class/regular" },
            { title: "변경 관리", to: "/class/change" },
            { title: "장기홀드 관리", to: "/class/hold" },
          ],
        },
        {
          menuName: "사이트관리",
          subMenu: [
            { title: "교재/컨텐츠 관리", to: "/site/textbook" },
            { title: "휴일 관리", to: "/site/holiday" },
            {
              title: "게시판 관리",
              to: "/site/board",
              subInSub: [
                { title: "공지사항", to: "/site/board/notice" },
                { title: "자주묻는질문", to: "/site/board/faq" },
                { title: "이벤트", to: "/site/board/event" },
                { title: "수강후기", to: "/site/board/review" },
              ],
            },
            { title: "강좌 관리", to: "/site/class" },
            { title: "팝업 관리", to: "/site/popup" },
            { title: "팀원 관리", to: "/site/member" },
          ],
        },
        {
          menuName: "결제관리",
          subMenu: [
            { title: "학생 결제 관리", to: "/payment/student" },
            { title: "강사 급여 관리", to: "/payment/tutor" },
          ],
        },
        {
          menuName: "마케팅관리",
          subMenu: [
            { title: "접속 통계", to: "/marketing/access" },
            { title: "유입 통계", to: "/marketing/inflow" },
            { title: "카톡 발송 내역", to: "/marketing/kakaotalk" },
          ],
        },
      ],
      selectMenu: null,
    };
  },
  mounted() {},
  watch: {
    $route(to, from) {},
  },
  methods: {},
};
</script>
